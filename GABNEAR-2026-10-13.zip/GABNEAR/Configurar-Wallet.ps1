﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (Test-Path -LiteralPath 'data/wallet-v2.dpapi') { throw 'Ya hay una wallet importada desde el panel. Usá CONECTAR WALLET para cambiarla o desbloquearla.' }
$botAccount = Read-Host 'Cuenta secundaria NEAR (nunca la cuenta principal Meteor)'
if ($botAccount -notmatch '^[a-z0-9._-]{2,64}$') { throw 'Cuenta inválida' }
$botSecret = Read-Host 'Clave privada ed25519 de la cuenta secundaria' -AsSecureString
$botPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($botSecret)
try {
  $botText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($botPointer)
  if ($botText -notmatch '^ed25519:[1-9A-HJ-NP-Za-km-z]+$') { throw 'Clave inválida' }
  New-Item -ItemType Directory -Path 'data' -Force | Out-Null
  $botSecret | ConvertFrom-SecureString | Set-Content -LiteralPath 'data/wallet.dpapi' -Encoding UTF8
  $botAccount | Set-Content -LiteralPath 'data/account.txt' -Encoding UTF8
  $botAccount | Set-Content -LiteralPath 'data/selected-account.txt' -Encoding UTF8
  Write-Output 'Guardada con Windows DPAPI, vinculada a tu usuario de Windows. Reiniciá GABNEAR. REAL queda desactivado hasta habilitarlo en el panel.'
} finally {
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($botPointer)
  $botText = $null
}
