@echo off
setlocal
cd /d "%~dp0"
title GABNEAR - Crear paquete para amigos
call npm run empaquetar
echo.
pause
