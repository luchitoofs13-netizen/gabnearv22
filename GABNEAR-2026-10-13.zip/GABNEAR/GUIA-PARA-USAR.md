# GABNEAR: guía para usarlo sin saber programar

GABNEAR abre un panel en tu navegador para comprar y vender tokens de NEAR. El programa corre en **tu PC**, con **tu wallet** y **tus datos**; nada se comparte con otras personas. **DRY RUN simula; REAL usa dinero real.** Es software personal sin auditoría externa: invertí solo lo que podés perder.

## 1. Instalar una sola vez

Necesitás Windows 10/11 e internet. La firma local solo funciona en Windows.

1. Instalá **Node.js 24 LTS** desde [nodejs.org](https://nodejs.org/en/download) (Windows Installer, opciones normales, con npm).
2. Conseguí el programa: **Code → Download ZIP** en GitHub, o el zip que te pasó tu amigo. Clic derecho → **Extraer todo** y abrí la carpeta extraída (no lo ejecutes desde dentro del zip).
3. Doble clic en **`Iniciar-GABNEAR.bat`**. No hace falta ser administrador. La primera vez instala y compila (unos minutos) y crea tu `.env` con valores seguros: slippage máximo 10 %, tope de **1 NEAR por compra** y **5 NEAR por día**.
4. Se abre **http://127.0.0.1:4317**. Dejá la ventana negra abierta mientras lo uses; para cerrar, Ctrl+C en ella (cerrar la pestaña no detiene el programa).

El lanzador no instala Node por vos, no crea ninguna wallet, no activa REAL y no compra nada solo.

## 2. Probar sin gastar (DRY RUN)

1. Dejá el modo **DRY RUN** (es el inicial).
2. **CONECTAR WALLET → Solo dirección** y poné tu dirección NEAR: solo consulta saldos, no puede firmar. (O pasá directo al punto 3 de la sección siguiente.)
3. Pegá el **contrato del token** (por ejemplo `algo.tkn.near`) o un enlace de nearly.trade o nearblocks. Pegar **no compra**: precarga precio, liquidez, chart y el análisis de riesgo.
4. En **COMPRAR** elegí un importe con los 4 botones rápidos. **Solo cargan la cantidad**; no compran. Debajo ves su valor en dólares y **cuántos tokens recibirías**, el impacto de precio y un aviso si el pool es chico.
5. Pulsá el botón verde **SIMULAR COMPRA**. Se abre una **posición simulada**: arriba aparece el **% de ganancia o pérdida en grande**, y también en la cabecera («P/L SIM») y en la pestaña **Posiciones**.
6. En **VENDER** elegí un porcentaje y pulsá el botón de venta: en DRY RUN reduce la posición simulada.

El P/L simulado usa el precio real del pool menos la comisión de salida. Es una estimación: el precio final real puede diferir por impacto y slippage.

## 3. Operar con dinero real

1. **CONECTAR WALLET → Crear wallet nueva**: la clave nace en tu PC. Elegí una contraseña de GABNEAR (mínimo 12 caracteres). Te muestra **12 palabras una sola vez: anotalas en papel**. Sin ellas, si perdés la PC o el archivo, perdés los fondos. Nadie puede recuperarlas.
2. Mandale desde tu wallet principal **solo lo que quieras arriesgar** (con 2 NEAR alcanza para probar). La dirección de la wallet nueva se muestra en el panel.
3. Cuando el panel muestre el saldo: marcá la casilla de uso de fondos reales y pulsá **ACTIVAR REAL**.

**Desde ese momento el botón verde y VENDER envían operaciones reales.** Mirá siempre el importe antes de pulsarlos.

En cada arranque: **CONECTAR WALLET → Desbloquear** con tu contraseña y volver a activar REAL (es a propósito). Otras opciones: *Importar clave* (si ya tenés una clave dedicada) y *Solo dirección* (no firma).

**Antes de subir los topes**, hacé las fases de [docs/PRUEBA-REAL.md](docs/PRUEBA-REAL.md) con 0,1 NEAR: varios caminos nunca se validaron con fondos reales.

## 4. Guía botón por botón

| Control | Para qué sirve |
|---|---|
| **Contrato o enlace** | Elige el token. Pegar precarga datos pero no envía nada. |
| **COMPRAR / VENDER** (pestañas del panel) | Alterna entre comprar y vender el token elegido. |
| **4 importes rápidos** | Cargan la cantidad a comprar (en NEAR). **No compran.** |
| **4 porcentajes de venta** | Cargan el % del saldo a vender. |
| **⚙ (ruedita)** | Cambiás tus 4 importes de compra y tus 4 porcentajes de venta; quedan guardados. |
| **Botón verde (COMPRAR / SIMULAR COMPRA)** | Ejecuta la compra con el importe cargado. En DRY RUN simula; en REAL envía fondos. |
| **VENDER** | Vende el porcentaje elegido del saldo on-chain consultado justo antes de operar. |
| **Slippage** | Variación de precio aceptada. Más alto = podés recibir menos. Compra y venta son independientes. |
| **AUTO SELL AL COMPRAR** | Opcional: take profit (+%), stop loss (−%) y/o trailing. Se aplica cuando una compra REAL se completa. |
| **⚡ ARMAR** | Registra el token y deja wNEAR listo antes de comprar para que la compra sea un solo swap. |
| **PREPARAR wNEAR** | En REAL convierte NEAR a wNEAR por adelantado. Gasta NEAR pero no compra el token. Opcional. |
| **ACTIVAR REAL / VOLVER A DRY RUN** | Habilita o apaga las operaciones con fondos reales. |
| **PARADA DE EMERGENCIA** | Impide nuevos envíos y apaga REAL. No revierte lo ya enviado. |
| **BLOQUEAR FIRMA LOCAL / DESCONECTAR CUENTA** | Bloquean la firma y apagan REAL. No borran tu wallet. |
| **Hash ↗ / CONSULTAR AHORA** | Abren la operación en Nearblocks / consultan una operación incierta por su hash (sin reenviarla). |

**Pestañas del panel principal:** *Swaps en vivo* (lo que pasa en el pool, tus swaps resaltados), *Posiciones* (reales y simuladas, P/L y AUTO SELL), *Telegram* (menciones de contratos en canales públicos), *Vigilancia*, *Historial* y *Actividad*.

## 5. P/L, posiciones y AUTO SELL

- **P/L en vivo:** una tarjeta sobre el panel muestra el **porcentaje** (grande) y el monto en dólares de tu posición; la cabecera suma el total. En REAL usa tu costo real; en DRY RUN, la posición simulada.
- **AUTO SELL:** con REAL activado vende solo cuando se cumple take profit, stop loss o trailing (tras 2 lecturas seguidas). Con DRY RUN solo avisa «habría vendido». Si falla 3 veces seguidas se pausa. **Un stop loss no garantiza el precio:** si el pool se vacía, no hay a quién vender.
- **SALIR DE TODO** (en Posiciones): vende todas las posiciones abiertas, de a una, con confirmación y solo con REAL activo.
- **IMPORTAR TOKENS COMPRADOS POR FUERA** (en Posiciones): para seguir el P/L de algo que compraste en otro lado; indicá cuánto te costó.

## 6. Más herramientas

- **Vigilancia:** pegá el contrato de un token que todavía no tiene pool, poné la liquidez mínima y cuánto vigilar; compra **una sola vez** cuando aparece el pool. Probala primero en DRY RUN.
- **🔔 Alertas y ☆ Seguir:** avisos de precio (sonido, aviso del navegador y Telegram si lo configuraste) y lista de seguimiento.
- **Telegram:** en el `.env`, `TELEGRAM_BOT_TOKEN` y `TELEGRAM_CHAT_ID` activan avisos al celular (órdenes, AUTO SELL, alertas). Nunca salen claves ni saldos.
- **⚡ Velocidad:** «confirmación rápida» da la operación por hecha ~1,5 s antes. Probala primero con importes chicos.
- **Tokens que cotizan en otro token** (el panel dice «PAR RHEA» u otro): GABNEAR paga con NEAR y hace solo dos swaps (NEAR → RHEA → token). Si el segundo falla, el RHEA queda en tu wallet y el mensaje lo dice. No se validó con fondos reales.

## 7. Qué muestran las pantallas

- **RPC CONECTADO:** hay conexión verificada a mainnet.
- **Balance NEAR / wNEAR:** «disponible» ya descuenta almacenamiento y reserva de gas.
- **Valor en USD:** estimación anterior al gas.
- **Historial:** órdenes, estado y hash. **DRY RUN no significa que hayas comprado nada.**

Si una orden dice **RECUPERANDO**, **ENVIADA** o **VERIFICANDO**: esperá. No compres de nuevo para «arreglarlo» ni borres el historial; la recuperación consulta el hash sin repetir la transacción.

## 8. Abrir, cerrar y actualizar

- **Otro día:** doble clic en `Iniciar-GABNEAR.bat`.
- **Cerrar:** volvé a DRY RUN, esperá que termine cualquier operación enviada y pulsá Ctrl+C en la ventana negra.
- **Actualizar:** extraé la versión nueva **encima** de tu carpeta, reemplazando archivos. Tu wallet, historial y configuración (`data/` y `.env`) no vienen en el zip, así que se conservan.
- **Tu wallet** pertenece a tu usuario de Windows en esa PC: copiar `data/` a otra computadora no sirve (y no debés hacerlo). En otra PC creá otra wallet.

## 9. Si algo no funciona

| Problema | Qué hacer |
|---|---|
| Falta Node / versión incorrecta | Instalá Node **24.x** (npm 11.x) y reabrí el lanzador. |
| Falló la instalación | Revisá internet y volvé a ejecutar el lanzador. |
| Puerto ocupado | Cerrá la otra copia de GABNEAR, o cambiá `PORT=4317` en tu `.env`. |
| No se abre el navegador | Abrí `http://127.0.0.1:4317` a mano. |
| Error 429 / RPC lento | Los RPC públicos gratuitos se saturan. Poné tu propia clave gratuita (dRPC o FastNEAR) en `NEAR_RPC_URL` y reiniciá. `npm run rpc:latency` mide cuál te conviene. |
| «tope por compra… supera MAX_BUY_NEAR» (o «tope diario») | Es `MAX_BUY_NEAR` / `MAX_DAILY_NEAR` del `.env`. Subilo con cuidado y reiniciá. |
| REAL bloqueado | Desbloqueá la wallet, revisá que no esté la parada de emergencia, marcá la casilla y pulsá ACTIVAR REAL. |
| Botón deshabilitado | Hay una orden en curso, falta wallet o token, o hay parada activa. Leé el mensaje. |
| Contraseña incorrecta | Es la contraseña de GABNEAR que elegiste al crear la wallet. No existe forma de recuperarla; con las 12 palabras podés crear la wallet de nuevo. |
| Recuperación pendiente | Dejá el programa abierto y consultá el hash. No repitas la orden ni borres `data/`. |

Para pedir ayuda mandá el mensaje de error o una captura **sin palabras de recuperación, contraseñas, claves ni URL de RPC con clave**.

## 10. Seguridad en cinco líneas

1. Wallet **nueva y dedicada**, con poco saldo. Nunca la semilla de tu wallet principal.
2. Las 12 palabras en papel; nunca en chat, foto ni nube.
3. Perfil de navegador limpio, sin extensiones, solo para GABNEAR.
4. Empezá siempre con importes chicos y subí los topes solo después de probar.
5. Leé [docs/SEGURIDAD.md](docs/SEGURIDAD.md) (5 minutos).

Más detalle técnico en el [README](README.md) y en [docs/REFERENCIA.md](docs/REFERENCIA.md).
