@echo off
setlocal
cd /d "%~dp0"
title GABNEAR - Inicio automatico
set "PSModulePath=%SystemRoot%\System32\WindowsPowerShell\v1.0\Modules"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Iniciar-GABNEAR.ps1" %*
set "GABNEAR_EXIT=%ERRORLEVEL%"
if not "%GABNEAR_EXIT%"=="0" echo No se pudo iniciar. Lee el mensaje de arriba y la GUIA-PARA-USAR.md.
pause
exit /b %GABNEAR_EXIT%
