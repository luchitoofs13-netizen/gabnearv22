param([switch]$PrepareOnly,[switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$env:PSModulePath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\Modules'
Set-Location -LiteralPath $PSScriptRoot
$browserJob = $null
try {
    Write-Host ''
    Write-Host 'GABNEAR - Preparacion e inicio automaticos' -ForegroundColor Cyan
    $nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
    $npmCommand = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if (-not $nodeCommand -or -not $npmCommand) {
        throw 'Falta Node.js. Instala Node 24 LTS desde https://nodejs.org/en/download (Windows Installer), cierra esta ventana y vuelve a abrir Iniciar-GABNEAR.bat. npm viene incluido.'
    }
    $nodeVersion = & $nodeCommand.Source --version
    if ($LASTEXITCODE -ne 0 -or $nodeVersion -notmatch '^v24\.') {
        throw 'Se necesita Node.js 24.x. Instala esa version desde https://nodejs.org/en/download y vuelve a abrir el lanzador.'
    }
    $npmVersion = & $npmCommand.Source --version
    if ($LASTEXITCODE -ne 0 -or $npmVersion -notmatch '^11\.') {
        throw 'Se necesita npm 11.x. Reinstala Node.js 24 con npm incluido y vuelve a abrir el lanzador.'
    }
    Write-Host "Node $nodeVersion / npm $npmVersion - OK"
    if (-not (Test-Path -LiteralPath 'package-lock.json')) { throw 'Falta package-lock.json. Descarga y extrae de nuevo el proyecto completo.' }
    if (-not (Test-Path -LiteralPath '.env')) {
        Copy-Item -LiteralPath '.env.example' -Destination '.env'
        Write-Host 'Configuracion inicial creada. No hace falta editarla para empezar.'
    }
    # La marca es local y esta ignorada por Git. Cambiar el lock o Node fuerza npm ci.
    $stamp = '.cache/setup-version.txt'
    $fingerprint = (Get-FileHash -LiteralPath 'package-lock.json' -Algorithm SHA256).Hash + ':' + (Get-FileHash -LiteralPath 'package.json' -Algorithm SHA256).Hash + ':' + $nodeVersion + ':' + $npmVersion
    $installed = (Test-Path -LiteralPath 'node_modules/tsx/dist/cli.mjs') -and (Test-Path -LiteralPath 'node_modules/vite/bin/vite.js') -and (Test-Path -LiteralPath 'node_modules/typescript/package.json')
    $oldFingerprint = if (Test-Path -LiteralPath $stamp) { [IO.File]::ReadAllText((Join-Path $PSScriptRoot $stamp)) } else { '' }
    if (-not $installed -or $oldFingerprint -ne $fingerprint) {
        Write-Host 'Instalando dependencias. La primera vez puede tardar unos minutos; necesita Internet.'
        & $npmCommand.Source ci --include=dev --no-fund
        if ($LASTEXITCODE -ne 0) { throw 'Fallo la instalacion. Comprueba Internet y vuelve a abrir el lanzador. No se inicio el servidor.' }
        New-Item -ItemType Directory -Path '.cache' -Force | Out-Null
        [IO.File]::WriteAllText((Join-Path $PSScriptRoot $stamp), $fingerprint)
    } else {
        Write-Host 'Dependencias instaladas - OK'
    }
    Write-Host 'Compilando y comprobando TypeScript...'
    & $npmCommand.Source run build
    if ($LASTEXITCODE -ne 0) { throw 'Fallo la compilacion. No se inicio el servidor. Conserva el mensaje de error para pedir ayuda.' }
    if ($PrepareOnly) { Write-Host 'Preparacion terminada. No se inicio el servidor ni se abrio el navegador.'; exit 0 }

    # Lee solo PORT. No imprime configuraciones RPC, cuentas ni secretos.
    $portText = $env:PORT
    if (-not $portText) {
        $portLine = Get-Content -LiteralPath '.env' | Where-Object { $_ -match '^\s*(?:export\s+)?PORT\s*=' } | Select-Object -Last 1
        if ($portLine) {
            $portText = (($portLine -split '=',2)[1] -replace '\s+#.*$', '').Trim().Trim('"').Trim("'")
        }
    }
    if (-not $portText) { $portText = '4317' }
    $portNumber = 0
    if (-not [int]::TryParse($portText,[ref]$portNumber) -or $portNumber -lt 1024 -or $portNumber -gt 65535) { throw 'PORT debe ser un numero entre 1024 y 65535. Revisa solo esa linea del archivo .env.' }
    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$portNumber)
    try { $listener.Start() } catch { throw "El puerto $portNumber ya esta ocupado. Cierra la otra ventana de GABNEAR o el programa que lo usa y vuelve a intentar. No se cerro ningun proceso." } finally { $listener.Stop() }
    $panelUrl = "http://127.0.0.1:$portNumber"
    if (-not $NoBrowser) {
        $browserJob = Start-Job -ArgumentList $panelUrl -ScriptBlock {
            param($url)
            for ($attempt = 0; $attempt -lt 60; $attempt++) {
                try {
                    $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 1
                    if ($response.StatusCode -eq 200) { Start-Process $url; return }
                } catch { }
                Start-Sleep -Milliseconds 500
            }
        }
    }
    Write-Host ''
    Write-Host "Panel: $panelUrl" -ForegroundColor Green
    Write-Host 'Deja esta ventana abierta mientras uses GABNEAR. Ctrl+C detiene el servidor.'
    Write-Host 'Arranca en DRY RUN. La wallet y REAL se habilitan desde el panel.'
    & $nodeCommand.Source 'node_modules/tsx/dist/cli.mjs' 'server/index.ts'
    if ($LASTEXITCODE -ne 0) { throw 'El servidor se detuvo con un error. Revisa el mensaje anterior.' }
} catch {
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
} finally {
    if ($browserJob) { Stop-Job -Job $browserJob -ErrorAction SilentlyContinue; Remove-Job -Job $browserJob -Force -ErrorAction SilentlyContinue }
}
