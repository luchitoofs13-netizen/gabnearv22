# GABNEAR

Terminal **local** para comprar y vender tokens de **NEAR mainnet** (React + TypeScript + Express + `near-api-js`). Pegás el contrato de cualquier token NEP-141 con pool en **Rhea DCL** o **Ref v1** (Nearly, meme.cooking, Hoot, Shore, tkn/tknx…) y operás con importes rápidos, AUTO SELL y P/L en vivo. Corre en tu PC, sobre `127.0.0.1`: no hay servidor ajeno ni cuenta de usuario.

> **Aviso.** Software personal, sin auditoría externa. Arranca en **DRY RUN** (simula, no gasta). REAL se activa a mano y se apaga en cada reinicio. **No se validó con fondos reales** el puente NEAR→RHEA, AUTO SELL, SALIR DE TODO ni la vigilancia de pool en REAL. Usá una wallet nueva y dedicada, con poco saldo.

## Qué hace

- **Cualquier token de NEAR:** al pegar el contrato analiza pool, impacto de precio, pérdida de ida y vuelta, liquidez y **cuántos tokens recibirías**; avisa si el pool es chico y frena compras riesgosas.
- **Mercado en vivo:** precio, market cap, liquidez on-chain, volumen, holders, chart de velas (NEAR o USD) y swaps en el momento.
- **Comprar:** 4 importes rápidos configurables (⚙) que solo cargan la cantidad; ejecutás con el botón verde. Todo con su valor en USD.
- **Vender:** 4 porcentajes configurables (1–100 %) sobre el saldo on-chain.
- **P/L en vivo con el % grande:** en REAL sobre la posición real; en DRY RUN sobre una **posición simulada** abierta por la compra simulada.
- **Tokens que cotizan en otro token** (p. ej. RHEA): compra pagando con NEAR; el bot hace NEAR → RHEA → token.
- **AUTO SELL** (take profit, stop loss, trailing), **SALIR DE TODO**, **vigilancia de pool** (una compra cuando aparece el pool), alertas de precio, lista de seguimiento, rastreador de canales públicos de Telegram y avisos por Telegram.
- **Seguridad:** wallet cifrada (scrypt + DPAPI de Windows), política de firma que solo permite wrap, registro y swap a Rhea/Ref, topes de gasto por compra y por día, cabeceras CSP, guardas de `Host`/origen y órdenes idempotentes. Ver [docs/SEGURIDAD.md](docs/SEGURIDAD.md).

## Instalar (Windows 10/11)

Requisitos: **Node.js 24 LTS** (con npm 11) e internet. La firma local usa Windows PowerShell + DPAPI: **solo Windows**.

1. Descargá el proyecto (**Code → Download ZIP** y *Extraer todo*) o cloná el repositorio.
2. Doble clic en **`Iniciar-GABNEAR.bat`** y dejá la ventana abierta. Instala, compila, crea tu `.env` con valores seguros (1 NEAR por compra, 5 por día) y abre **http://127.0.0.1:4317**.
3. **CONECTAR WALLET → Crear wallet nueva**, con tu propia contraseña. Anotá las 12 palabras en papel.

Guía paso a paso, botón por botón: [GUIA-PARA-USAR.md](GUIA-PARA-USAR.md).

Con terminal en vez del lanzador:

```powershell
npm ci
Copy-Item .env.example .env
npm run verify     # pruebas + compilación
npm run dev        # http://127.0.0.1:5173  (interfaz con recarga en caliente)
# o bien: npm run build && npm start   # http://127.0.0.1:4317
```

## Primeros pasos seguros

1. Probá todo en **DRY RUN**: no firma ni envía nada.
2. Fondeá la wallet nueva con poco (2 NEAR alcanzan para probar).
3. Seguí las fases de [docs/PRUEBA-REAL.md](docs/PRUEBA-REAL.md) con 0,1 NEAR antes de subir importes o topes.
4. Usá un perfil de navegador limpio, sin extensiones, solo para GABNEAR.

## Configuración (`.env`)

`.env.example` documenta cada variable; el `.env` real no se sube a Git. Las principales:

| Variable | Para qué |
|---|---|
| `NEAR_RPC_URL`, `NEAR_RPC_READ_FALLBACK`, `NEAR_RPC_BROADCAST` | RPC principal, respaldo de lectura y difusión de la misma firma. Una URL con clave es un secreto: solo va en `.env`. Medí tu mejor opción con `npm run rpc:latency`. |
| `MAX_BUY_NEAR`, `MAX_DAILY_NEAR` | Topes de gasto por compra y por 24 h, aplicados en el servidor. |
| `MAX_SLIPPAGE_BPS` | Slippage máximo aceptado (1000 = 10 %). |
| `CONFIRM_LEVEL`, `PREP_LEVEL`, `AUTO_ARM` | Velocidad: cuándo se da por hecha una operación (también en el panel ⚡ Velocidad). |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` | Avisos opcionales por Telegram. |
| `PORT` | Puerto local (4317 por defecto). |

## Comandos

| Comando | Qué hace |
|---|---|
| `npm test` | Pruebas automáticas (incluido el pentest del servidor) desde un directorio vacío: no leen tu `data/` ni tu `.env`. |
| `npm run build` | Chequeo de tipos y build de la interfaz. |
| `npm run verify` | Pruebas + build. |
| `npm run dev` / `npm start` | Desarrollo con recarga / servidor con el build. |
| `npm run empaquetar` | Crea un zip **sin tus datos** para pasarle a un amigo ([docs/COMPARTIR.md](docs/COMPARTIR.md)). |
| `npm run rpc:latency` | Mide desde tu PC la latencia a cada RPC de NEAR. |
| `npm run test:*`, `benchmark*` | Scripts manuales contra mainnet/testnet (`tests/manual/`); no forman parte de `npm test`. |

## Estructura

```
server/     API local (Express): análisis, cotizaciones, wallet y firma, órdenes, mercado, AUTO SELL
src/        interfaz (React + Vite)
tests/      pruebas automáticas (node:test) · tests/manual/ = scripts que usan red o fondos
scripts/    empaquetador para compartir
public/     imágenes de la interfaz
docs/       documentación (referencia técnica, seguridad, prueba real, auditoría…)
Iniciar-GABNEAR.bat / .ps1   lanzador para Windows
```

`data/` (wallet cifrada, historial, posiciones) y `.env` se crean en cada PC y están en `.gitignore`.

## Documentación

| Documento | Contenido |
|---|---|
| [GUIA-PARA-USAR.md](GUIA-PARA-USAR.md) | Para quien no programa: instalación, wallet, comprar/vender, botones, problemas comunes |
| [docs/PRUEBA-REAL.md](docs/PRUEBA-REAL.md) | Cómo validar con NEAR real gastando lo mínimo |
| [docs/SEGURIDAD.md](docs/SEGURIDAD.md) | Modelo de amenaza, defensas, pentest y riesgo residual |
| [docs/COMPARTIR.md](docs/COMPARTIR.md) | Pasar el programa a amigos sin datos propios |
| [docs/AUDITORIA.md](docs/AUDITORIA.md) | Qué se encontró y corrigió, y qué sigue sin validar |
| [docs/RESUMEN-CAMBIOS.md](docs/RESUMEN-CAMBIOS.md) | Todos los cambios, por ronda |
| [docs/REFERENCIA.md](docs/REFERENCIA.md) | Referencia técnica larga |
| [docs/OPTIMIZACION.md](docs/OPTIMIZACION.md), [docs/BENCHMARK_RPC.md](docs/BENCHMARK_RPC.md), [docs/BENCHMARK_SIGNING.md](docs/BENCHMARK_SIGNING.md) | Latencia y mediciones |
| [docs/QUOTE_ASSETS.md](docs/QUOTE_ASSETS.md) | Tokens que cotizan en otro token |

## Límites conocidos

- **Solo Windows** (DPAPI). La wallet cifrada no se traslada entre PCs ni usuarios de Windows.
- Los RPC públicos gratuitos dan 429 en horas pico; con una clave propia (dRPC, FastNEAR) se evita.
- Los precios y tiempos son estimaciones; un stop loss es una orden de mercado, no una garantía de precio. Si el pool se vacía no hay a quién vender.
- Operar tokens nuevos es de alto riesgo (trampas del contrato, impuestos ocultos, pools que se vacían). Invertí solo lo que podés perder.
