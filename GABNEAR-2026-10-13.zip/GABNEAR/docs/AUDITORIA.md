# Auditoría y cambios — 12 de octubre de 2026

Revisión completa del código recibido (GABNEAR-main), correcciones, y dos funciones nuevas: **tokens de cualquier launchpad de NEAR** y **AUTO SELL real** (take profit / stop loss / trailing con libro de posiciones y P/L).

Estado al cierre: `npm run verify` → **163 pruebas** (112 originales + 51 nuevas) y build TypeScript/Vite en verde; `npm audit` → 0 vulnerabilidades; `test:http` (8) y `test:operations` (11) contra el servidor vivo en verde; `npm run test:generic` (solo lectura, mainnet real) en verde para un token de cada launchpad.

## 1. Seguridad: lo que se revisó

- **Sin exfiltración.** Los únicos destinos de red del servidor son el RPC configurado, el fallback de lectura y `api.exchange.coinbase.com` (precio USD). Sin `eval`, `exec` ni código remoto. Los únicos contratos fijos son `nearlytrade.near`, `dclv2.ref-labs.near`, `v2.ref-finance.near` y `wrap.near`; no hay transferencias a cuentas de terceros.
- **Dependencias:** `package-lock.json` con 248 entradas, todas de `registry.npmjs.org` con integridad; el único script de instalación relevante es el de `esbuild`. `npm audit`: 0.
- **Clave:** semilla → clave derivada, verificada contra una access key FullAccess (solo viaja la clave pública), cifrada con scrypt + AES-256-GCM y además DPAPI. Servidor solo en loopback, rechazo de host/origen ajenos y de POST sin cabecera propia.
- **Mejora aplicada:** scrypt pasó de N=16384 (valor por defecto de Node) a **N=2¹⁷**, guardado en el archivo (`v:2`); las bóvedas `v1` ya creadas siguen abriendo, y un archivo manipulado no puede pedir memoria arbitraria.
- **Sin cambios, a tener presente:** la clave vive en memoria mientras la wallet está desbloqueada y un proceso del mismo usuario de Windows puede descifrar el DPAPI. `style.css` carga fuentes de Google (una petición del navegador a un tercero). El autor original compartió una semilla por chat en algún momento: nunca uses una wallet cuya semilla haya pasado por un chat; creá una nueva y dedicada.

## 2. Errores encontrados y corregidos

| # | Gravedad | Hallazgo | Corrección |
|---|---|---|---|
| 1 | Alta (latencia) | Cada `history.update` reescribía **todo** el historial indentado y de forma síncrona, y cada marca de tiempo de una orden disparaba una (~25 por compra). Con 500 filas (el tope) medí **5 830 ms de event loop bloqueado** solo en las marcas y 227 ms para persistir el hash antes de enviar. | Telemetría con escritura diferida y agrupada (200 ms); hashes, estados y fondos siguen persistiéndose al instante; JSON compacto; `lastOutcome` sin pruebas Merkle ni perfiles de gas. Mismo escenario: **0 ms** y **19 ms**. Flush al salir (Ctrl+C incluido). |
| 2 | Alta (robustez) | Si la red **rechazaba** una transacción en validación (nonce, saldo, firma, expirada…), se la trataba como incierta para siempre y la recuperación consultaba un hash que no existe eternamente, **bloqueando la cuenta** hasta editar `history.json` a mano. | Los rechazos de validación se reconocen por clase de error; antes de liberar se consulta el hash (un reintento interno del provider pudo aceptar la primera copia). `InvalidNonce` es ambiguo y no se libera sin prueba. Además: liberación por **ventana de validez vencida** (86 400 bloques) o por **nonce consumido por otra tx**, y botón de **descarte manual** (≥ 3 min, exige que la red siga sin conocer el hash). Nunca se libera una tx con resultado FINAL. |
| 3 | Media (latencia) | `near-api-js` reintenta 12 veces con backoff (~2 min) ante 500/503 antes de fallar, así que el fallback de lectura no llegaba a tiempo; y un 429 sin fallback no se reintentaba. | Intentos acotados (`NEAR_RPC_RETRIES`, 3); un 429 sin fallback se reintenta una vez. Reenviar la misma firma es idempotente. |
| 4 | Media (funcional) | `extractToken` solo aceptaba cuentas `.near` con punto y solo enlaces de nearly.trade: imposible operar tokens `.tg`, `.sweat`, implícitos, etc. | Validación de cuenta de token generalizada; se siguen rechazando `wrap.near` (es el quote), `.testnet`, dominios, mayúsculas y hosts parecidos. Se aceptan enlaces de nearblocks.io. |
| 5 | Media (funcional) | Un token sin eventos NEP-297 dejaba toda compra en «VERIFICANDO TOKENS» para siempre, aunque hubiera salido bien. | Evidencia atribuible al hash: eventos NEP-141 → retiro nativo de wNEAR → `ft_transfer` dentro de los recibos de ese hash. En el camino vivo (cuenta bloqueada para sí) hay un último recurso de delta de saldo, marcado como tal; la recuperación tras reinicio nunca lo usa. |
| 6 | Media | La verificación del retiro nativo de wNEAR solo reconocía a DCL como exchange. | Reconoce DCL y Ref v1. |
| 7 | Baja | Con Express 5, `req.body` queda indefinido sin cuerpo JSON; JSON inválido o enorme devolvía HTML. | Guarda de cuerpo + manejador de errores JSON. |
| 8 | Baja | `AutoSell`/`exitDecision` heredados no estaban conectados y esperaban un objeto distinto al de las filas del historial. | Reemplazados por `positions.ts` + `exit-monitor.ts` (el archivo viejo queda marcado obsoleto solo por sus pruebas). |
| 9 | Baja | Documentación desactualizada («79 pruebas», «AUTO SELL pendiente», un solo launchpad). | README actualizado; este documento. |
| 10 | Mía, corregida | Al construir la UI: el fee DCL está en ppm (10 000 = 1 %) y el de Ref v1 en bps; lo mezclé y la UI mostraba «fee 100 %». También `display()` no admite negativos y un P/L realizado negativo se habría mostrado como basura. | Fee normalizado a bps; `displaySigned`. Ambos con prueba. |

## 3. Tokens de cualquier launchpad

Hecho verificado contra mainnet: `v2.ref-finance.near` expone `auto_whitelisted_postfix = [.tknx.near, .launch.shoremarkets.near, .launchpad.justhoot.near, .meme-cooking.near, .tkn.near]`, y los tokens de esos launchpads (y los de Nearly) tienen pools contra wNEAR en **Ref v1** y/o **Rhea DCL**. Por eso la integración cubre esos dos exchanges.

- Descubrimiento: DCL por id construido (`get_pools` en lote, 4 fees) + Ref v1 por un índice incremental (`get_number_of_pools` / `get_pools` / `get_pool_by_ids`; primer escaneo de ~9 mil pools ≈ 2 s). Tres lecturas por token; rutas candidatas cacheadas 10 s (nunca las cotizaciones, nunca resultados vacíos).
- Ranking por mayor salida (cotizaciones en paralelo), con impacto de precio medido contra una orden 20 veces menor, ida y vuelta simulada al pegar el contrato, y límites configurables (`.env.example`).
- Resultados reales (solo lectura, 0.1 NEAR): Nearly `ai-8` → DCL, impacto 0.01 %; meme.cooking `nene-2250` → **Ref v1 #8943**, ida y vuelta 0.32 %; JustHoot `wth-0b2227` → **DCL** sobre Ref v1, 2.0 %; Shore `shore-4lzt` → DCL entre 4 pools, 2.0 %; tkn `soul` → Ref v1; tknx `cocoon` → **bloqueado**: un pool diminuto movería el precio 22 % con solo 0.1 NEAR.
- Análisis DRY RUN de un token de meme.cooking de punta a punta en la UI: **497 ms**.

**Límites explícitos**

1. Tokens que aún están en la fase previa de un launchpad (curva de bonding, fase de depósito) y todavía no tienen pool en Ref/Rhea **no se pueden comprar**. Cada launchpad requeriría su propio adaptador; solo existe el de Nearly. Sería el siguiente paso si querés comprar *antes* del pool (y, para eso, una vigilancia de pools nuevos).
2. Solo pools simples directos token/wNEAR. Sin multi-hop ni pools estables/rated/degen.
3. **No se puede detectar** un contrato que bloquee transferencias, tenga lista negra o cobre un impuesto oculto. La simulación de ida y vuelta solo ve el pool. Los tokens con impuesto de transferencia aparecen como «importe inferior al mínimo».
4. **El camino de ejecución Ref v1 no se validó con fondos.** El formato del mensaje sale de `@ref-finance/ref-sdk` y de la inspección del WASM mainnet (`TokenReceiverMessage::Execute` acepta `actions`; `skip_unwrap_near` no forma parte de ese mensaje, por eso la verificación acepta salida envuelta o nativa). Si el mensaje fuera inválido, `ft_transfer_call` devuelve los tokens (estado REEMBOLSADA) y solo se pierde el gas. Probá primero con un importe mínimo.

## 4. AUTO SELL y posiciones

Detalle en el README. Resumen de decisiones:

- Una posición por token y cuenta, con **costo promedio** (monto usado + gas + almacenamiento) y P/L realizado por cada venta, manual o automática. Importar posiciones de tokens comprados por fuera exige declarar el costo.
- El monitor valúa con la **cotización ejecutable de salida** (no con un precio de referencia), neta de impuesto de venta y de un gas estimado, y exige N lecturas consecutivas.
- Dispara por el mismo camino idempotente que las ventas manuales. Solo con REAL activo, sin parada de emergencia y sin otra operación en curso; si no, solo registra «habría vendido».
- Verificado: 15 pruebas del libro/decisión/monitor (confirmaciones, racha rota, TP parcial que no se repite, cotización fallida, rechazo de envío, pausa tras 3 fallos, polvo, tokens movidos, orden perdida) + prueba en el navegador contra mainnet en DRY RUN (importé una posición, el monitor la valuó en vivo y registró «STOP_LOSS alcanzado; no se vende: REAL desactivado»).
- **No se validó una venta automática real con fondos.**

## 5. Recomendaciones que no cambié (decisión tuya)

- `.env.example` trae `MAX_SLIPPAGE_BPS=9900` (99 %): con ese máximo el mínimo de salida es casi nulo y un sándwich te vacía. Sugerido ≤ 500–1000.
- Usá un RPC con clave (dRPC / FastNEAR) y el fallback del `.env`: los RPC públicos gratuitos devuelven 429 y las lecturas del descubrimiento son varias.
- Hacé una compra y una venta mínimas en REAL con un token de cada venue (Rhea DCL y Ref v1) antes de confiar el AUTO SELL a importes grandes. El stop loss es una orden de mercado evaluada cada pocos segundos: no hay garantía de precio ni protege de un pool que se vacía.

## 6. Archivos nuevos y modificados

Nuevos: `server/constants.ts`, `server/venues.ts`, `server/positions.ts`, `server/exit-monitor.ts`, `src/Positions.tsx`, `tests/venues.test.ts`, `tests/positions.test.ts`, `tests/fixes.test.ts`, `tests/manual/generic-mainnet.ts`, este archivo.
Modificados: `server/{history,transactions,recovery,rpc,pools,analysis,trading,operations,validation,quote-asset,quotes,vault,index}.ts`, `src/{main.tsx,style.css}`, `.env.example`, `package.json` (script `test:generic`), `README.md`.

---

# Segunda ronda — wallet, velocidad y mercado en vivo (12/10/2026)

Estado: `npm run verify` → **202 pruebas** (163 de la primera ronda + 39 nuevas, repetido 3 veces sin fallos) y build en verde; `npm audit` → 0 vulnerabilidades (250 paquetes, todos de `registry.npmjs.org` con integridad; se sumó `lightweight-charts@5.2.1` y su única dependencia `fancy-canvas`, sin scripts de instalación). Verificado además contra mainnet real y las APIs públicas (`npm run test:market`) y en el navegador integrado con una instancia aislada (otro directorio de datos y puerto).

## 8. Wallet

- **Mejor forma de importar:** no importar. **Crear una wallet nueva dedicada dentro del bot**: la clave nace en la PC y no pasa por Meteor ni otra wallet; la cuenta es la implícita (hex de la clave pública, existe al recibir NEAR); se fondea con lo que se esté dispuesto a arriesgar. Alternativa aceptable: importar la **clave privada** de una cuenta secundaria (expone menos que una semilla). Lo menos recomendable: la semilla de la wallet principal.
- Nuevo: `generate` (frase de 12 palabras mostrada **una sola vez**, cierre bloqueado hasta confirmar el respaldo, espera de fondos), `importKey` (validación canónica ed25519 de 64 bytes + FullAccess on-chain), y **archivo automático de la bóveda anterior** (antes `importSeed` la sobrescribía en silencio y podía dejar fondos sin clave).
- Corregido: con la wallet legada de `Configurar-Wallet.ps1`, cada firma lanzaba PowerShell para descifrar DPAPI (+300-700 ms por llamada); ahora se descifra una vez y queda en memoria hasta bloquear.
- Una cuenta recién creada y sin fondos ya no rompe el panel (`exists:false`), y activar REAL sin fondos da un mensaje claro en vez de un error genérico.
- Verificado en la UI (instancia aislada): 12 palabras, dirección de 64 hex, cierre bloqueado hasta confirmar, bóveda de 1,5 KB en disco **sin ninguna clave en texto plano**.

## 9. Velocidad

Medición desde esta PC: **RTT ≈ 270-300 ms a cada RPC** (dRPC 271 ms, FastNEAR 294 ms; el oficial `rpc.mainnet.near.org` 3,6 s; otros cuatro públicos no operativos). Reabrir conexiones tras estar inactivo **no** agrega latencia medible (306/751/302/296 ms), así que el keep-alive quedó opcional y apagado. Lo que sí cuesta: los pasos secuenciales con espera de finalidad.

| Cambio | Efecto estimado | Riesgo |
|---|---|---|
| Pasos previos (registro, wrap) esperan **ejecución** y no FINAL (`PREP_LEVEL`, por defecto `optimistic`) | ~1,5 s por paso | bajo |
| **ARMAR**: registra el token y deja wNEAR listo (botón o automático): comprar = 1 solo swap | ~5-6 s menos | bajo (gasta ≈0,00125 NEAR por token) |
| `CONFIRM_LEVEL=optimistic`: el swap se da por hecho al ejecutarse | ~1,5 s | bajo-medio: un vigilante verifica FINAL; si el hash desaparece vuelve a «recuperando» por hash, sin reenviar |
| Difusión de la **misma firma** a varios RPC (`NEAR_RPC_BROADCAST`, solo https, máx. 3, verificados mainnet) | robustez + cola de latencia | nula: mismo hash, jamás se ejecuta dos veces |
| Compra pedida mientras se arma: queda en cola y sale al terminar | evita perder el Enter | — |
| `rpc:latency`: mide los RPC desde tu PC y sugiere orden | decisión informada | — |

Con wNEAR listo y token registrado la compra pasa de ~10 s a ~3 s (FINAL) o ~1,5-2 s (rápida). **No se validó con fondos reales**; probar con importes mínimos. Lo que el código no puede cambiar es la distancia: un **VPS en EE. UU. este / Europa** baja el RTT a ~20-60 ms.

## 10. Mercado en vivo

- Backend: `/api/market/:token` (precio, market cap, liquidez por pool, supply, volumen, txns, variación, antigüedad, holders), `/candles`, `/trades`, `/api/launches` y `/api/stream` (SSE). Un único WebSocket upstream (Intear) para todas las pestañas, con reconexión exponencial y vigilancia de silencio; GeckoTerminal espaciado a 2,3 s y cacheado (límite ~30/min); todo con degradación elegante.
- Precio/market cap/liquidez **on-chain** (coinciden con DexScreener: liquidez de `ai-8` $23 699 vs $23 676) y velas de GeckoTerminal con actualización en vivo; pools nuevos se grafican con velas propias desde los swaps; entrada/TP/SL dibujados sobre el chart.
- Hallazgos de los datos reales: GeckoTerminal marca `pool_created_at` = 2023 para todos los pools (inservible; se usa `pairCreatedAt` de DexScreener); Intear no tiene historial de tokens muy tranquilos (respaldo con GeckoTerminal `/trades`); la liquidez de pools DCL se calcula con `total_x/total_y` (verificado contra DexScreener).
- `nene-2250.meme-cooking.near` ya sirve de ejemplo de alerta: un holder (`nene_token.tg`) tiene 44,6 % del supply.

## 11. Pendiente / siguiente paso

Comprar **antes** de que exista el pool (adaptadores por launchpad) y compra automática al detectar un pool nuevo (con reglas de riesgo estrictas); validar con fondos reales los caminos Ref v1, confirmación rápida y venta automática; y un VPS cerca de los validadores.

---

# Tercera ronda — datos vs DexScreener, swaps en vivo y chart (12/10/2026)

- **Datos de mercado:** `parseDexScreener(body, token)` ya no suma todos los pares que devuelve DexScreener (incluía pools diminutos y pares donde el token es la cotización de otro): usa el **par principal** (mayor liquidez, token como base) para txns, volumen, variación, antigüedad, FDV y MC; solo la liquidez suma los pools propios. Verificado en vivo con NINU (`ninu-4.nearlytrade.near`): 72/73 txns contra 72/72 de la web de DexScreener. Quedan diferencias inherentes y ahora documentadas en tooltips: precio spot del pool vs último swap con comisión (~1 %), liquidez (~2-3 %), supply de MC/FDV y antigüedad (dato de DexScreener).
- **Tabla de swaps:** la clase `.sell` del botón VENDER (fondo rosa opaco) también pintaba las filas; filas renombradas `t-buy`/`t-sell`/`t-mine`/`t-big` y tabla rediseñada (hora relativa, barra de tamaño, filtro MÍOS, precio USD).
- **Bug del chart:** vaciar la serie (`setData([])`) al cambiar token/timeframe lanzaba «Value is null» desde el bucle de dibujo de lightweight-charts. Ahora se recrea el chart en cada cambio (6 cambios seguidos sin errores). Altura responsive `clamp(300px,45vh,460px)`.
- **Panel COMPRAR:** estado de wNEAR en vivo y explicación de qué es wNEAR / qué hace ARMAR; botón «CONVERTIR NEAR → wNEAR»; «HOLDERS (TOP)» → «TOP HOLDER».
- **Pruebas:** 202 (se reescribió la de `parseDexScreener`). Resumen completo de las tres rondas en `RESUMEN-CAMBIOS.md`; guía de la prueba con fondos reales en `PRUEBA-REAL.md`.

---

# Cuarta ronda — seguridad, vigilancia de pool y herramientas de trading (12/10/2026)

Estado: `npm run verify` → **238 pruebas** y build en verde; `npm audit` → 0; `npm audit signatures` → 183 paquetes con firma verificada. Detalle de seguridad en `SEGURIDAD.md`.

- **Seguridad:** CSP cerrada + anti-iframe + cabeceras; fuentes empaquetadas (adiós a Google Fonts); `Host` global; `Sec-Fetch-Site`; tope de streams; **política de firma** (`server/call-policy.ts`); **topes de gasto** (`server/limits.ts`); pentest automatizado con servidor real (`tests/security.test.ts`, 12 pruebas, verificado por mutación).
- **Pruebas aisladas:** `npm test` ya no lee tu `data/` ni tu `.env` (dos pruebas fallaban porque tu cuenta conectada quedaba en `data/selected-account.txt`).
- **Vigilancia de pool** (`server/sniper.ts`): una compra por objetivo, `requestId` fijo, expira, pausa sin REAL, respeta riesgo y topes. `PoolNotReady` distingue «todavía no hay pool» de un error real. Verificado en vivo con un token sin pool (`stock-1.launch-v2.intear.near`): 14 lecturas en 10 s, rechazo de `ninu-4` por ya tener pool, REAL sin wallet rechazado.
- **SALIR DE TODO** (`exit-monitor.ts`, trigger `MANUAL_EXIT`), **alertas de precio** (`src/market/alerts.ts`), **lista de seguimiento** (`/api/watch`), **marcas de tus operaciones** en el chart, **avisos por Telegram** (`server/notify.ts`, mensajes sin datos sensibles, frecuencia limitada).
- Launchpads reconocidos: + Intear, tknport, NearFi.
