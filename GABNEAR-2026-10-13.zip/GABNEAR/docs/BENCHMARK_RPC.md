# Benchmark de lectura

Fecha UTC: 2026-10-12T01:52:17.210Z. Sin envío de fondos. Tres muestras por RPC; cinco por escenario. Percentiles descriptivos, insuficientes para inferir estabilidad a largo plazo.

| RPC | Errores / 3 | Status p50 | Cuenta p50 | Bloque p50 | wNEAR p50 | Access key p50 |
|---|---:|---:|---:|---:|---:|---:|
| https://free.rpc.fastnear.com | 0 | 211.0 | 235.3 | 345.8 | 280.9 | 195.0 |
| https://rpc.mainnet.near.org | 0 | 3213.3 | 3523.6 | 3723.3 | 3321.0 | 3230.4 |
| https://1rpc.io/near | 3 | — | — | — | — | — |
| https://near.drpc.org | 0 | 242.0 | 245.6 | 279.6 | 246.2 | 238.6 |

Tiempos en ms. RPC utilizado para el análisis completo: https://near.drpc.org. Puede elegirse con BENCHMARK_RPC_URL; la comparación de métodos simples no garantiza ausencia de cuotas en el flujo completo. No se modifica automáticamente .env.

| Análisis | p50 ms | p90 ms | p95 ms | Consultas por muestra |
|---|---:|---:|---:|---|
| baseline-readonly | 1088.7 | 1603.6 | 1603.6 | 13, 13, 13, 13, 13 |
| cold | 834.5 | 1095.1 | 1095.1 | 12, 12, 12, 12, 13 |
| hot | 1022.1 | 1303.2 | 1303.2 | 8, 8, 12, 9, 12 |

Cambio de mediana baseline→hot: 6.1% de reducción (negativo significa más lento). El baseline ejecuta el análisis actual sin caché y con status por orden; compara políticas de caché, no reproduce el código anterior ni una compra completa.

Muestras pequeñas. Solo lectura; no mide firma real, envío, wrap, registración, confirmación ni visualización.

Datos detallados locales: data/benchmark-readonly.json. Repetir con npm run benchmark.
