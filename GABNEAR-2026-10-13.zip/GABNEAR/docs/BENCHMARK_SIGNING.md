# Construcción y firma offline

Fecha UTC: 2026-10-12T01:41:47.813Z. Veinte muestras con clave sintética sin fondos, nonce y bloque ficticios. Sin RPC ni envíos. No representa una compra completa ni incluye acceso a la wallet, obtención de nonce, bloque o escritura del historial.

| Etapa | p50 ms | p90 ms | p95 ms |
|---|---:|---:|---:|
| construction | 0.020 | 0.036 | 0.058 |
| signing | 0.666 | 1.147 | 2.063 |
| total | 0.699 | 1.205 | 2.099 |

Datos completos locales en data/benchmark-signing.json. Repetir: npm run benchmark:signing.
