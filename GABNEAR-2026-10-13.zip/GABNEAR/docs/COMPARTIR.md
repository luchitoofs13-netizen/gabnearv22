# Compartir GABNEAR con amigos

GABNEAR es una terminal **local**: cada persona la corre en su propia PC, con su propia wallet, su propio historial y sus propias posiciones. Nada se comparte entre PCs.

## Para quien lo comparte
1. Doble clic en **`Empaquetar-Para-Amigos.bat`** (o `npm run empaquetar`).
2. Crea `D:\proyectos\gabnear-share\GABNEAR-AAAA-MM-DD.zip` y **se niega a crearlo** si encuentra una clave, un token de Telegram, una URL de RPC con clave o cualquier cuenta de tu instalación dentro de los archivos.
3. El zip lleva solo el programa. **Nunca** lleva: `data/` (tu wallet, historial, posiciones, cuenta seleccionada), `.env` (tus topes, RPC, Telegram), `node_modules`, `dist` ni cachés.
4. Pasale el zip por un canal que uses normalmente. Que tu amigo compare el `sha256` que imprime el empaquetador si quiere estar seguro de que no se alteró.

## Para tu amigo (Windows 10/11)
1. Instalar **Node.js 24 LTS** desde nodejs.org (con npm).
2. **Extraer** el zip (clic derecho → Extraer todo; no ejecutar desde adentro del zip) en una carpeta suya, por ejemplo `D:\GABNEAR`.
3. Doble clic en **`Iniciar-GABNEAR.bat`**. La primera vez instala y compila (unos minutos, necesita internet) y crea su propio `.env` con valores seguros: slippage máximo 10 %, tope de **1 NEAR por compra** y **5 NEAR por día**.
4. En la pantalla: **CONECTAR WALLET → Crear wallet nueva** con su propia contraseña. Anotar las 12 palabras **en papel**. Mandarle solo lo que quiera arriesgar.
5. Empezar en **DRY RUN** (simulación, no gasta nada). REAL se activa a mano y se apaga en cada reinicio.
6. Leer `PRUEBA-REAL.md` y `SEGURIDAD.md` (5 minutos cada uno).

## Qué es propio de cada PC (y por qué no hay problemas de wallets)
| Cosa | Dónde vive | Se comparte |
|---|---|---|
| Wallet / clave | `data/wallet-v2.dpapi`, cifrada con la contraseña propia **y** con Windows DPAPI de *ese usuario de ese equipo* | No: aunque alguien copie el archivo a otra PC, no se abre |
| Cuenta elegida, historial, posiciones, velocidad | `data/` (se crea sola al primer uso) | No |
| Configuración (`MAX_BUY_NEAR`, RPC, Telegram…) | `.env` (se crea solo desde `.env.example`) | No |
| Importes rápidos, alertas, seguimiento, posiciones simuladas | `localStorage` del navegador | No |
| Puerto | `PORT` del `.env` (4317 por defecto; solo escucha en 127.0.0.1) | No |

Cada amigo debe **crear su wallet nueva**; no usen la misma cuenta en dos PCs ni importen la frase de su wallet principal.

## Recomendaciones para amigos
- **RPC propio.** El `.env` trae RPC públicos gratuitos compartidos por todos los usuarios del mundo: dan error 429 en horas pico. Con una clave propia gratuita (dRPC, FastNEAR) se pone en `NEAR_RPC_URL` y se reinicia.
- **Perfil de navegador limpio, sin extensiones**, solo para GABNEAR.
- **Subir los topes solo después** de que sus 4 fases de prueba real salgan bien.
- Solo Windows (la bóveda usa DPAPI). En Mac/Linux no funciona.

## Actualizar a una versión nueva
Extraer el zip nuevo **encima** de la carpeta vieja (reemplazando archivos): como el zip no trae `data/` ni `.env`, su wallet, historial y configuración quedan intactos. Después `Iniciar-GABNEAR.bat` reinstala lo que haga falta.

## Verificación automática
`npm test` incluye pruebas que (1) comprueban qué archivos entran y cuáles no, (2) buscan claves, tokens y datos personales en todo el paquete y (3) copian el paquete a otra carpeta y arrancan una terminal nueva para confirmar que empieza con wallet, historial y posiciones vacíos y crea su propia `data/`.
