# GABNEAR: optimización de latencia

Revisión: 10 de octubre de 2026. Cambios implementados y probados sin nuevas operaciones con fondos. La validación de esta versión con compras mainnet sigue pendiente.

## 1. Causas de demora

El flujo anterior consultaba `status` para cada orden, descubrimiento en dos tandas, cotización/almacenamiento, balances nativos y wNEAR en serie, almacenamiento nuevamente, wrap y su confirmación, cotización nuevamente, saldo previo, nonce/bloque, firma, envío esperando FINAL y saldo posterior. Crear un firmante por llamada añadía trabajo local; el frontend consultaba el estado cada segundo. Una compra anterior registrada tardó 15.704 ms, pero no tenía desglose por etapas: no se puede atribuir retrospectivamente esa demora ni usarla para calcular una mejora de compra sin una nueva compra comparable.

## 2. Mediciones disponibles

`BENCHMARK_RPC.md` contiene los resultados de lectura, tres muestras por nodo y cinco por escenario. En el mismo RPC de análisis, dRPC:

| Escenario de análisis | p50 ms | p90 ms | p95 ms |
|---|---:|---:|---:|
| Referencia, sin caché y con status por orden | 1493,654 | 1749,297 | 1749,297 |
| Frío, identidad de red reciente | 987,735 | 1275,325 | 1275,325 |
| Precargado, metadata con TTL | 974,500 | 1212,675 | 1212,675 |

Reducción de mediana de análisis: **34,757%**. Son pocas muestras y los escenarios se ejecutaron en tandas, con variaciones de red: no prueban una reducción equivalente de compras. El análisis precargado siguió realizando 7–10 llamadas, según vencimientos. No se alcanzó ni demostró un envío real inferior a un segundo.

## 3. RPC

FastNEAR tuvo consultas individuales de unos 205–257 ms de mediana, pero una corrida de análisis recibió 429 por cuota. El nodo oficial tuvo medianas alrededor de 3,2–3,4 segundos. 1RPC falló las tres muestras. dRPC pasó las consultas y el análisis completo; su mediana individual fue aproximadamente 294–336 ms. La configuración local se cambió a dRPC con FastNEAR como fallback exclusivamente de lectura. El benchmark no cambia `.env` por sí mismo.

Se reutiliza una instancia SDK/provider y el transporte HTTP de Node, sin abrir procesos por consulta. La identidad mainnet verificada dura 10 segundos; saldo, cotización, pool, reglas e impuestos se consultan nuevamente. El fallback valida mainnet y solo actúa ante errores transitorios de lectura: nunca retransmite una transacción. No se selecciona el proveedor dentro de cada compra.

## 4. Camino frío

Se comprueban contrato NEP-141, lanzamiento terminado, pool activo y coincidente, ruta directa wNEAR y restricciones soportadas. Se mantienen las consultas dinámicas y los depósitos se verifican después de su confirmación. La compra reutiliza almacenamiento comprobado en el análisis de la misma orden, misma cuenta y con menos de 10 segundos de antigüedad; si no cumple esas condiciones lo vuelve a consultar. Preparación, wrap y swap mantienen sus dependencias y confirmaciones.

## 5. Camino precargado

Al escribir/pegar un enlace válido, un debounce de 200 ms dispara un prefetch de lectura. La metadata y evidencia de despliegue se guardan durante cinco segundos, con deduplicación de consultas en curso, expulsión de errores y máximo de 256 entradas. El registro de lanzamiento, ruta/pool activo, impuestos, reglas y cotización no se toman de esa caché.

El botón **ANALIZAR PREPARACIÓN wNEAR** calcula el déficit en DRY RUN. En REAL pasa a **PREPARAR wNEAR ANTES DE COMPRAR**: usa el importe de compra como saldo objetivo de wNEAR, registra si hace falta y envuelve solo el déficit. Es una orden separada con UUID e historial, no una compra de tokens. Tener saldo suficiente evita la transacción de wrap durante la compra. Esta nueva acción se verificó con mocks y DRY RUN, no con fondos en esta revisión.

## 6. Construcción y firma

El firmante local se reutiliza en memoria y se invalida al bloquear, cambiar o desbloquear la wallet. El secreto nunca se devuelve al frontend. No se conserva un contador local de nonces: cada transacción consulta la access key actual y un bloque finalizado, en paralelo. En el swap esas consultas se solapan con cotización y balances; luego se construye mediante `createTransaction` oficial y se firma. El contexto vence a los diez segundos y debe corresponder a la cuenta seleccionada. Operaciones serializadas, sin reintentos de compra ni incremento especulativo del nonce.

`BENCHMARK_SIGNING.md` mide veinte firmas sintéticas offline: construcción p50 0,014 ms, firma p50 0,664 ms, total p50 0,685 ms. Excluye obtención de nonce/bloque, wallet, historial y RPC. Es una medición de CPU, no una velocidad de operación real. Las pruebas comprueban persistencia del hash antes de transmitir, exclusión, resultado incierto y recuperación tras reinicio.

## 7. Envío

Cada transacción registra hash, cuenta, contrato y método antes del RPC. La opción `NEAR_ASYNC_SEND=true` usa `send_tx` con `NONE`, registra el acuse y consulta el estado sin volver a enviar. Ahora es el valor predeterminado y está **true** localmente; el acuse tiene un límite de 3 segundos. No se validó un envío nuevo mainnet en esta revisión: sí simulaciones y consultas reales de hashes existentes. Con false se conserva el envío esperando FINAL y su límite antiguo de 15 segundos.

El timeline del historial distingue `orderReceived`, análisis, registración, preparación wNEAR, `signerReady`, `nonceAndBlockReady`, construcción, firma, `hashComputed`, `rpcSendStarted`, `rpcAcknowledged`, `blockchainFinal`, `tokensVerified` y finalización. El hash calculado localmente no demuestra aceptación por el RPC. Cada transacción de preparación también aporta sus etapas; no mezclar su envío con el envío del swap al comparar.

## 8. Confirmación y visualización

El modo asíncrono consulta con pausas progresivas de 150 a 1000 ms, durante un máximo orientativo de 60 segundos más la consulta RPC en curso. Exige FINAL y verifica importe mediante eventos NEP-141 o recibos de retiro nativo; Si falta evidencia en los recibos, se conserva la recuperación; no se usa un delta posterior para inventar el importe. Un error deja recuperación automática persistente con backoff y fallback de solo lectura, incluso tras reinicio. Sin FINAL se retienen recursos de la cuenta; con FINAL y posición no verificada se retiene solo ese token. Las próximas órdenes releen nonce y balances. No se retransmite ni se atribuye un balance posterior a una operación histórica.

Eventos SSE locales despiertan al frontend cuando cambia la orden; la consulta cada segundo queda como respaldo. El navegador registra una oportunidad de pintado tras dos `requestAnimationFrame`, medida desde el clic mediante su reloj local. Es una aproximación de presentación, no una prueba de que la pantalla haya mostrado físicamente cada píxel; no mezclarla con el reloj monotónico del backend. Los tiempos de etapa se muestran en el panel. La valoración USD queda fuera del camino de compra.

## 9. Límites de blockchain y presupuesto real

Eliminar RPC repetidos no elimina bloques, finalización, recibos entre contratos ni preparación de almacenamiento. No se agrupan acciones de contratos distintos como si fueran atómicas. Ni SSE ni `NONE` hacen más rápido el consenso: adelantan información al usuario. Precio, liquidez y saldo pueden cambiar entre lectura y ejecución, por eso se conserva un mínimo explícito y no se relaja el slippage.

La campaña autorizada limita cada compra a exactamente 0,1 NEAR, como máximo cinco intentos y **0,5 NEAR incluyendo todos los costos**. Cinco compras consumen el límite antes de gas. `benchmark:plan` proyectó dos intentos bajo una reserva muy conservadora de gas, total estimado 0,448 NEAR para la cuenta consultada ya registrada y sin wNEAR. Es una proyección basada en gas observado, no un techo protocolar garantizado. Recalcular con la wallet definitiva y antes de operar.

`BenchmarkBudget` es una utilidad de ledger persistente para la campaña: reserva principal más costos, registra hashes, cuenta fallos, bloquea pendientes, cambio de cuenta, exceso de importe y sexto intento. No está conectada a los botones normales. El ejecutor separado `npm run benchmark:real` sí utiliza este ledger: comprueba cuenta pública autorizada, wallet desbloqueada, REAL, presupuesto, reglas, ruta, balance y cotización de salida antes de reservar y enviar. Tiene un lock de archivo para evitar ejecutores simultáneos. No se validó de extremo a extremo con fondos; permanece pendiente esa comprobación.

## 10. Próximos pasos y validación

Falta completar la campaña con una credencial cargada exclusivamente en el panel local y medir compras reales comparables. La credencial compartida por chat no se utilizó ni se guardó para hacerlo. Sustituirla antes de pruebas con fondos. Las ventas no forman parte de esta autorización; validar una cotización de salida no autoriza vender.

RPC dedicado y ubicación próxima a nodos pueden mejorar RTT/jitter, pero requieren mediciones desde ese entorno. No se contrataron servicios, desplegó VPS ni trasladaron claves. WebSocket/subscripciones y acceso a mempool no se implementaron: no se comprobó una API oficial compatible de Nearly que mejore este flujo de enlace recibido. Un VPS introduce custodia remota; una conexión Ethernet puede reducir variación local, pero no se midió esa comparación.

Comandos: `npm run verify`, `npm run test:http`, `npm run test:operations`, `npm run test:mainnet`, `npm run benchmark`, `npm run benchmark:signing`, `npm run benchmark:plan`. Los comandos de consulta, `benchmark`, `benchmark:signing` y `benchmark:plan` no compran tokens. `benchmark:real` sí ejecuta compras y tiene requisitos explícitos; no está incluido en `verify`. `test:testnet` sí tiene su propio flujo con tokens de prueba: no se ejecutó de nuevo en esta revisión.

Fuentes consultadas: [transacciones y wait_until de NEAR](https://docs.near.org/api/rpc/transactions), [proveedores NEAR](https://docs.near.org/api/rpc/providers), [SDK oficial NEAR](https://github.com/near/near-api-js), [SDK Ref/Rhea](https://github.com/ref-finance/ref-sdk), [Nearly](https://nearly.trade/docs). La página Nearly es una SPA; se mantuvieron los métodos ya contrastados con su aplicación y las consultas reales, sin inventar una ruta nueva. También se inspeccionó el código instalado de near-api-js 7.3.1 para nonce, bloque finalizado y sendTransactionUntil.

## 11. Corrección del incidente de 17 segundos

Investigación de una operación real previa (informe no incluido en el repositorio): inclusión a 1,902 s, entrega de NINU a 3,634 s, último recibo ejecutado a 4,888 s desde envío; el cliente agotó 15,014868 s esperando FINAL. Son tiempos de bloques, no la hora exacta de finalidad observada. Acuse original y duración original de verificación no estaban registrados. No se gastaron fondos para investigar ni se inventó un porcentaje de mejora real.

Recuperación continua por hash, errores/timeouts por etapa, estados coherentes, entrega nativa diferenciada de gas, locks por cuenta/token con firma serial, actualización de saldo secundaria sin bloquear venta e intención de venta de una sola ejecución después de verificar la compra. La intención relee saldo/cotización/gas; prioridad frente al resto del mantenimiento. Se cancela por reinicio, parada, cambio de cuenta o desactivación REAL. AUTO SELL por TP/SL sigue pendiente.
