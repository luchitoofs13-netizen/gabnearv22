# Prueba con NEAR real — guía mínima

Objetivo: validar los caminos que todavía no se probaron con fondos (Rhea DCL, Ref v1, AUTO SELL, confirmación rápida) gastando lo mínimo. **Lo hacés vos**: GABNEAR no mueve fondos hasta que activás REAL y confirmás.

## Antes de empezar
1. Cerrá GABNEAR con Ctrl+C y abrí `Iniciar-GABNEAR.bat` de nuevo (tu instancia sigue con el código anterior; la primera vez reinstala dependencias).
2. **Conectar wallet → Crear wallet nueva** (o la que ya tengas dedicada). Anotá las 12 palabras en papel.
3. Mandale **2 NEAR** desde tu wallet principal. Alcanza de sobra: cada compra de prueba es de 0,1 NEAR y el gas ronda centésimas de NEAR.
4. `.env`: ya quedó con `MAX_SLIPPAGE_BPS=1000` (10 %), `MAX_BUY_NEAR=1` y `MAX_DAILY_NEAR=5` (topes de gasto). Dejá `CONFIRM_LEVEL=final` por ahora. Si querés comprar más de 1 NEAR por vez, subí el tope y reiniciá.
5. Usá un **perfil de navegador limpio, sin extensiones** (ver `SEGURIDAD.md`).

**Cómo se activa REAL:** Conectar wallet → *Crear wallet nueva* (o *Importar clave*; «Solo dirección» no firma) → fondearla → *Desbloquear* → tildar la casilla y **ACTIVAR REAL** en el panel de modo. No hay otro interruptor: el código no tiene nada bloqueado, REAL arranca apagado a propósito en cada sesión.

**Primer uso de una cuenta nueva:** además de la primera compra de cada token, la cuenta tiene que registrarse una vez en wrap.near; son pasos extra de ~1,5–3 s que desaparecen después (ARMAR los adelanta). La velocidad por sí sola no depende de si la wallet es nueva o importada.

## Fase A — Rhea DCL (el camino más probado)
1. Pegá un token con liquidez (por ejemplo `ninu-4.nearlytrade.near`) en DRY RUN y mirá pool, impacto e ida y vuelta.
2. Activá **REAL** (tildá la confirmación). Elegí **0,1** (importe rápido o ⚙) y slippage **3 %**.
3. Opcional: **⚡ ARMAR** y esperá «ARMADO». Pulsá el botón verde **COMPRAR**: con ARMAR previo debería ser un solo swap.
4. Mirá el **Historial**: estado final «COMPRA COMPLETADA», tokens recibidos y tiempos de cada paso. Debe aparecer la posición en **Posiciones**.
5. **VENDER 50 %** y después **VENDER 100 %**. Recibís wNEAR (queda como wNEAR).

## Fase B — Ref v1 (nunca probado con fondos)
Elegí un token cuyo mejor pool sea **Ref v1** (la tarjeta de antigüedad dice «Ref v1»; suelen ser tokens de meme.cooking o tkn con poca liquidez). Mismo ciclo con **0,1 NEAR**. Si el mensaje al exchange fuera inválido, el token devuelve los fondos (estado REEMBOLSADA) y solo pierdes el gas: es lo que hay que descartar.

## Fase C — AUTO SELL
Compra de 0,1 NEAR con **Take profit +3 %** y **Stop loss 3 %** en un token líquido. Comprobá que, cuando el precio toque uno, aparece la venta automática en Historial. No lo dejes sin mirar la primera vez.

## Fase D — Confirmación rápida (solo si A–C salieron bien)
En **⚡ Velocidad** pasá a «confirmación rápida» y repetí una compra y una venta de 0,1 NEAR. Tiene que terminar ~1,5 s antes y el vigilante marcar FINAL pocos segundos después.

## Fase B2 — Token que cotiza en RHEA (puente)
Un token de Nearly que diga «PAR RHEA» (p. ej. `kinu-3.nearlytrade.near`) con **0,1 NEAR**: el bot hace 2 swaps (NEAR → RHEA, RHEA → token). Mirá en el Historial las dos transacciones. Si el segundo falla, el RHEA queda en tu wallet y el mensaje lo dice. Después vendé el token (recibís RHEA) y, si querés, vendé el RHEA (botón ABRIR RHEA).

## Fase E — Vigilancia de pool (primero en DRY RUN)
1. Pegá un contrato sin pool (por ejemplo uno recién desplegado) y abrí la pestaña **Vigilancia**.
2. En **DRY RUN** apretá VIGILAR: debe quedar «VIGILANDO» y contar lecturas. Cuando aparezca el pool, simula la compra y la marca «SIMULADO».
3. Recién después, con REAL y **0,1 NEAR**, tildá la confirmación. Cancelala si no querés que compre.

## Fase F — SALIR DE TODO y avisos (opcional)
Con una o dos posiciones abiertas de 0,1 NEAR, probá **■ SALIR DE TODO**: vende de a una y se apaga solo. Si configuraste Telegram, comprobá que llegan los avisos.

## Qué revisar si algo sale raro
- Un estado distinto de COMPLETADA (REEMBOLSADA, FALLIDA, «RECUPERANDO ESTADO…») + el hash (botón «Hash ↗» en la fila del Historial).
- Los tiempos por paso del Historial.
- Cualquier mensaje rojo de la pantalla.

Si pasa algo: botón **PARADA DE EMERGENCIA**, y guardá el estado y el hash para revisarlo.
