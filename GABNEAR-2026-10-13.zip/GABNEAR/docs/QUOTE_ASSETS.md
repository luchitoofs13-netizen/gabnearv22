# Quotes NEP-141 genéricos

GABNEAR descubre el quote desde `get_launch_by_token(...).quote`; únicamente registros legacy sin quote usan `wrap.near`. Verifica que el pool descubierto esté Running y contenga exactamente el token objetivo y ese quote, en cualquiera de las dos orientaciones. Consulta contrato y `ft_metadata` del quote, valida `spec`, nombre, símbolo y decimales (0–38). No hay lista RIA/QTC, pool construido a mano ni swap intermedio.

El importe ingresado en COMPRAR está expresado en **unidades del quote del launch**. Se convierte con sus propios decimales y enteros BigInt. Cuando el quote es RIA o QTC, `ft_transfer_call` se envía al contrato real que devuelve `record.quote`, con `receiver_id=dclv2.ref-labs.near`, `pool_ids=[record.pool_id]`, salida al token objetivo y mínimo con slippage. Se consume el saldo FT existente: no hay conversión desde NEAR, wrap, unwrap ni swap adicional para financiarlo. Los identificadores `ria.near`, `qtc.near` de los tests son ejemplos sintéticos, no un listado de contratos reales.

La venta usa el mismo pool y `output_token=record.quote`. Cotiza la entrada después del impuesto Nearly, transfiere el importe bruto y verifica eventos del FT de salida atribuibles a ese hash. La venta preparada relee el launch y bloquea si el quote cambió desde la compra. Recovery continúa usando `swapSnapshot.input/output`, nunca balances posteriores atribuidos a una operación histórica. wNEAR conserva wrap del déficit en compras y evidencia de retiro nativo DCL en ventas.

## Capital y saldo

Por pedido del usuario, compras, ventas y preparación wNEAR no tienen un tope de capital impuesto por GABNEAR. No se exige configurar límites por quote. Las variables legacy MAX_NEAR_PER_TRADE y MAX_QUOTE_PER_TRADE_JSON se ignoran, incluso si siguen presentes en una configuración privada anterior. No se editó .env.

El importe debe ser positivo, respetar los decimales del token y caber en u128 NEP-141. Siguen vigentes saldo suficiente, gas, almacenamiento, slippage, impuestos y restricciones reales del contrato/pool. La UI permite vender 50%, 99% o 100% del saldo: 100% vende todo el saldo consultado, sujeto al impuesto y liquidez.

El análisis con cuenta consulta saldo del quote; la compra REAL vuelve a consultarlo antes de preparar. Si es un FT distinto de wNEAR y falta saldo, informa contrato, disponible y requerido sin enviar registraciones ni swaps. En wNEAR se envuelve únicamente el déficit. Se registra la cuenta en token objetivo y quote cuando corresponde, con verificación posterior. La reserva nativa incluye storage pendiente y gas. Se conservan idempotencia, parada, exclusión por cuenta/nonce y recuperación por hash.

## Archivos

- `server/quote-asset.ts`: metadatos y cantidades del quote, saldo NEP-141 y validación de importes sin tope de capital.
- `server/pools.ts`, `analysis.ts`, `trading.ts`, `operations.ts`: descubrimiento, análisis, ejecución, cotizaciones e historial con el quote real.
- `server/index.ts`, `src/main.tsx`: prefetch del quote y UI con moneda/decimales correctos. Los balances globales NEAR/wNEAR siguen mostrando reservas nativas; el saldo del quote aparece en el análisis.
- `server/usd.ts`: no multiplica una salida FT por NEAR/USD.
- `server/autosell.ts`: P/L y gas en la misma unidad del quote.
- `.env.example`, `README.md`, este documento y pruebas: alcance y verificación. Benchmarks con presupuesto fijo NEAR rechazan otros quotes.

## Limitaciones

- Solo pools directos Nearly/DCL compatibles con transferencias NEP-141 estándar y almacenamiento consultable NEP-145. Errores de pool, cotización, metadatos o storage bloquean la ejecución con contexto del contrato; no se intenta una ruta alternativa.
- Los metadatos no prueban el comportamiento de cada método mutable. FT con impuestos propios no estándar, restricciones adicionales o eventos incompatibles requieren validación específica. Los impuestos consultados siguen siendo los del token Nearly; no se inventa un impuesto del quote. Sin FINAL y evidencia suficiente de recepción se mantiene la recuperación, sin declarar FILLED ni reenviar.
- La estimación USD para un saldo positivo con quote distinto de wNEAR muestra No disponible: falta una fuente de precio validada de ese FT. La cotización de venta en el quote original sigue funcionando y no depende de USD.
- AUTO SELL sigue sin monitor activo, como en la versión anterior. El motor conserva TP/SL; para otros quotes exige `estimatedGasQuoteRaw` y `gasQuoteAsset` coincidente, además de `costRaw` en unidades mínimas del quote. No se resta gas yoctoNEAR a cantidades de RIA/QTC ni se instala una conversión automática.
- Las pruebas RIA/QTC son controladas; falta validación real de cada pool/FT. Se realizaron dos compras mainnet wNEAR autorizadas para comparar latencia (0,1 NEAR antes de reducir el importe y 0,05 NEAR después), cuyo informe no se incluye en el repositorio. No se cambiaron wallet, secretos ni configuración privada; REAL quedó desactivado. `LIVE_VALIDATED=false` se conserva porque esas muestras no validan todos los contratos ni escenarios.

## Verificación

`npm run verify` ejecuta la suite offline completa y después `tsc --noEmit` + build Vite. Los nuevos casos cubren quotes RIA/QTC/futuros sintéticos, 0/6/18/24 decimales, orientaciones del pool, ruta única, impuestos/slippage, almacenamiento, capital, saldo insuficiente/fresco, wNEAR con/sin déficit, salida FT, recovery, USD y auto-sell. Se mantienen las pruebas de wallet sintética y presupuesto en directorios temporales aislados. La última corrida pasó 112 pruebas y TypeScript/Vite. También pasaron las pruebas HTTP (8 controles) y operaciones HTTP (11 controles) sin envío de fondos. Los tests de rapidez verifican cotización fresca única para rutas financiadas, prequote antes de preparación, historial y deduplicación de status con recuperación de fallos.

Referencias de protocolo: [NEP-141](https://github.com/near/NEPs/blob/master/neps/nep-0141.md), [NEP-145](https://github.com/near/NEPs/blob/master/neps/nep-0145.md), [SDK oficial Ref/DCL](https://github.com/ref-finance/ref-sdk).
