# GABNEAR — referencia técnica detallada

> Resumen actual del proyecto: [README](../README.md). Este documento es la referencia larga, con la historia de cada ronda de cambios; donde una ronda posterior corrigió a una anterior, vale la ronda posterior.

Terminal local de compra y venta de tokens recién lanzados en NEAR mainnet: lanzamientos de **Nearly** (fábrica oficial) y **cualquier otro token NEP-141** con pool directo contra wNEAR en **Rhea DCL** o **Ref v1** (meme.cooking, Shore, JustHoot, tkn.near / tknx.near, etc.), con **AUTO SELL** (take profit, stop loss y trailing). Modo inicial **DRY RUN**, con React, TypeScript, Vite, Express y `near-api-js`.

> **Novedades (12/10/2026):** tokens de cualquier launchpad, AUTO SELL real con libro de posiciones y P/L, guardas de riesgo de compra, y correcciones de latencia/robustez. Ver [AUDITORIA.md](AUDITORIA.md) para qué se encontró, qué se corrigió y qué sigue sin validar con fondos.

## Empezar facil en Windows

**Si no sabes programar, lee [GUIA-PARA-USAR.md](../GUIA-PARA-USAR.md): instalacion desde GitHub, wallet, compra/venta y todos los botones.**

1. En GitHub: **Code → Download ZIP** y despues **Extraer todo** en Windows.
2. Instala **Node.js 24 LTS** con npm incluido desde [nodejs.org](https://nodejs.org/en/download).
3. Hace doble clic en **Iniciar-GABNEAR.bat** y deja la ventana abierta.

El lanzador instala dependencias cuando corresponde, crea `.env` solo si no existe, compila y abre el panel cuando el servidor responde. Usa normalmente **http://127.0.0.1:4317**, sin necesitar Git ni comandos. No activa REAL ni configura una wallet automaticamente. Cada usuario conecta su propia cuenta desde el panel. Para detener, Ctrl+C en la consola; cerrar la pestaña no detiene el servidor.

## Instalar desde cero en otra PC

Requisitos: Windows 10/11, Git, Node.js 24.x y npm 11.x (incluido con Node). Se verificó con Node 24.14.1 y npm 11.11.0. La firma local usa Windows PowerShell y DPAPI; en otros sistemas la importación/firma local no está soportada. Internet es necesario para npm y lecturas RPC. Si el repositorio es privado, autenticá Git con una cuenta que tenga acceso, sin escribir tokens en la URL.

Desde PowerShell o una terminal, ejecutá:

```powershell
git clone --branch main <URL-de-tu-repositorio>.git
cd GABNEAR
npm ci
Copy-Item .env.example .env
npm run verify
npm run dev
```

Con `npm run dev`, abrí http://127.0.0.1:5173. Puertos 5173 y 4317 libres; detené con Ctrl+C. Para uso normal en Windows, `Iniciar-GABNEAR.bat` automatiza instalacion y build y usa el panel compilado en 4317. Si PowerShell bloquea npm.ps1, usá `npm.cmd` para los mismos comandos. En terminales POSIX, la copia es `cp .env.example .env`.

`npm ci` instala las versiones exactas del lockfile. No hace falta `npm run install`: `npm install` se reserva para cambios deliberados de dependencias. No uses `--omit=dev`: TypeScript, tsx y Vite son necesarios para los comandos documentados.

Para ejecutar la interfaz compilada, desde la misma raíz:

```powershell
npm run build
npm start
```

Abrí http://127.0.0.1:4317. `npm start` sirve el build y la API local; necesita un build previo. `PORT` en .env cambia este puerto (el proxy de `npm run dev` sigue esperando 4317). El servidor solo escucha en loopback. No se necesita ninguna ruta absoluta ni carpeta con un nombre particular.

## Configurar una PC nueva

Editá el .env local: `BOT_ACCOUNT_ID` es una dirección pública opcional; dejalo vacío para comenzar sin wallet. `NEAR_RPC_URL` y `NEAR_RPC_READ_FALLBACK` eligen proveedores mainnet; una URL con API key es un secreto y solo va en .env. `NEAR_ASYNC_SEND` controla el acuse. Las compras REAL tienen topes de gasto por orden y por día (`MAX_BUY_NEAR`, `MAX_DAILY_NEAR`). `MAX_SLIPPAGE_BPS` y `GAS_RESERVE_NEAR` conservan sus funciones. Las variables BENCHMARK son opcionales y no se utilizan en el arranque habitual.

La app crea data/ automáticamente y comienza en DRY RUN, con firma bloqueada. Para consultas basta una dirección pública. Para firma en otra PC, configurá de nuevo una cuenta secundaria en CONECTAR WALLET o con el script local descrito abajo. Los archivos DPAPI dependen del usuario y equipo Windows: no se trasladan por GitHub. Nunca copies semillas, claves, contraseñas ni el .env de otra instalación a Git. Configurá secretos exclusivamente en la PC de destino.

Git incluye fuentes del frontend/backend, pruebas, imágenes, scripts Windows, configuración, package.json y package-lock.json, .env.example y documentación. Excluye .env, data/ (historial, cuentas, wallets cifradas y reportes privados), node_modules/, dist/, cachés, credenciales y copias temporales de páginas Nearly. Las páginas Nearly descargadas son material de investigación; el runtime no las importa. Los informes versionados contienen referencias públicas on-chain; no contienen material de firma.

## Lo que funciona

- Validación estricta de enlaces HTTPS de nearly.trade y extracción de cuentas NEAR.
- RPC mainnet, existencia del contrato, contratos globales y metadatos NEP-141.
- Descubrimiento del lanzamiento y su pool desde la fábrica, sin construir un pool supuesto.
- Comprobación de estado Running del pool y de etapa Done del lanzamiento.
- Cotización DCL para pares directos con cualquier quote NEP-141 compatible, mínimo de salida e impuestos consultados en cadena.
- Detección y validación del quote del launch; pools incompatibles quedan bloqueados sin inventar una ruta.
- Consulta de registración y balances NEAR/wNEAR cuando se configure una cuenta secundaria.
- Validación de importes positivos/slippage en el backend, historial persistido, tiempos por etapa y parada de emergencia.
- Pantalla oscura con la mascota original; no utiliza automatización de navegador para operar.

El historial distingue análisis de compra (`ANALYZED`), análisis de venta (`ANALYZED_SELL`), confirmaciones, reembolsos y resultados inciertos. DRY RUN no crea posiciones.

## Tokens de cualquier launchpad de NEAR

Pegá el contrato de cualquier token (`token.tkn.near`, `x.meme-cooking.near`, `hoot-….launchpad.justhoot.near`, `shore-….launch.shoremarkets.near`, `…tknx.near`, `…sweat`, `…tg`, cuentas implícitas de 64 hex) o un enlace de nearly.trade / nearblocks.io.

- **Nearly:** se usa la fábrica oficial (pool, impuestos y reglas). Sin cambios.
- **Cualquier otro token:** se buscan pools **directos token/wNEAR** en Rhea DCL (id `tokenA|tokenB|fee` con fee 100/400/2000/10000) y en Ref v1 (índice incremental de ~9 mil pools, solo pools simples de 2 tokens). Se cotizan todos los candidatos en paralelo y gana la mayor salida. Los lanzamientos de meme.cooking, Shore, JustHoot y tkn terminan en esos dos exchanges (verificado leyendo `v2.ref-finance.near`: su lista `auto_whitelisted_postfix` incluye esos sufijos).
- **No hay multi-hop ni pools estables/rated/degen:** lo no soportado se bloquea, no se inventa una ruta.
- **Tokens que todavía están en la fase previa de un launchpad** (curva de bonding, fase de depósito) y no tienen pool en Ref/Rhea **no se pueden comprar**: cada launchpad tendría que tener su propio adaptador y solo existe el de Nearly.

Al pegar el contrato se muestra, solo con lecturas: pool ganador, pools comparados, **impacto de precio** de tu importe, y **ida y vuelta inmediata** (qué perderías comprando y vendiendo en el acto). En REAL, la compra se **bloquea** si el impacto supera `MAX_PRICE_IMPACT_BPS` (15%), si la pérdida de ida y vuelta supera `MAX_ROUNDTRIP_LOSS_BPS` (40%) o si un pool Ref v1 tiene menos de `MIN_POOL_NEAR` de liquidez; se puede forzar marcando «ignorar bloqueo de riesgo». Esto **no detecta** contratos que bloqueen transferencias o cobren impuestos ocultos: empezá siempre con un importe chico.

Ref v1 se ejecuta con `ft_transfer_call` a `v2.ref-finance.near` y `{"force":0,"actions":[{pool_id,token_in,token_out,amount_in,min_amount_out}]}` (formato de `@ref-finance/ref-sdk`), con 300 TGas (el sobrante se devuelve). **El camino Ref v1 de ejecución real no se validó con fondos**: las cotizaciones, el descubrimiento y la verificación de recibos sí se probaron contra mainnet y con simulaciones.

## Posiciones y AUTO SELL

Cada compra REAL completada abre (o suma a) una **posición** por token con su costo real: monto usado + gas + almacenamiento, con costo promedio. Las ventas realizan P/L (también las manuales). Se puede importar a mano un token comprado por fuera declarando su costo.

En COMPRAR (o luego en la tarjeta de la posición) se configura:

- **Take profit +%**, **stop loss −%** y **trailing stop** (caída % desde el máximo neto; solo actúa después de haber estado en ganancia). El TP puede vender 50 %, 99 % o 100 %; si vende menos, el resto sigue con SL/trailing.
- Slippage de salida y **confirmaciones** (lecturas consecutivas necesarias; por defecto 2).

El monitor (cada `AUTOSELL_INTERVAL_MS`, 3 s) valúa con la **cotización ejecutable de salida**: descuenta el impuesto de venta y un gas estimado (0,005 NEAR), compara contra el costo del remanente y, al cumplirse N lecturas seguidas, vende vía el mismo camino idempotente de las ventas manuales. Vende sobre el saldo de la wallet de ese token. Reglas de seguridad:

- Solo vende con **REAL activo**, sin parada de emergencia y sin otra operación en curso. Sin REAL (o reiniciado el servidor) evalúa y registra «habría vendido», sin enviar nada.
- Una cotización fallida **nunca** dispara una venta. La orden usa un `requestId` persistido antes de enviarse; un reinicio no reenvía.
- Tres ventas automáticas fallidas seguidas **pausan** el AUTO SELL de esa posición. Un valor remanente menor al doble del gas se cierra como polvo.
- No protege contra gaps de liquidez: si el pool se vacía, no hay a quién vender. Un stop loss es una orden de mercado evaluada cada pocos segundos, no una garantía de precio.

## Comprar y vender desde el panel

1. Pegá el contrato directo (por ejemplo `ai-8.nearlytrade.near`) o un enlace Nearly. Ese mismo token se utiliza para compra y venta.
2. En COMPRAR, elegí el importe en unidades del quote detectado del launch y el slippage de compra. Los valores quedan guardados localmente para la próxima sesión. Después pegá el contrato en el campo superior y pulsá el botón verde COMPRAR (SIMULAR COMPRA en DRY RUN): inicia la compra con esos valores. Los importes rápidos solo cargan la cantidad; pegar por sí solo no envía una orden.
3. En VENDER, elegí el slippage de venta. ACTUALIZAR SALDO consulta los tokens y una cotización del 50%. No hace falta pulsar ACTUALIZAR SALDO antes de vender. VENDER 50%, VENDER 99% y VENDER 100% calculan ese porcentaje del saldo on-chain justo antes de preparar la orden. El 99% deja 1% del saldo, sujeto al redondeo de unidades mínimas; el 100% vende todo el saldo consultado.
4. DRY RUN es el modo inicial: ambas órdenes consultan mainnet y guardan resultados sin firmar ni enviar fondos. Sin tokens no se puede simular una venta ejecutable; no se inventa un saldo.
5. Para operar fondos reales, desbloqueá la wallet local, marcá la casilla de uso de fondos mainnet y pulsá ACTIVAR REAL. Se comprueba la red y la access key FullAccess. La próxima pulsación de COMPRAR o VENDER envía la operación sin otra confirmación.

REAL se habilita solo para la sesión del servidor y se revoca al reiniciar, bloquear/desconectar/cambiar wallet o activar la parada de emergencia. `.env` no habilita REAL por sí solo. La contraseña puede necesitar reingreso porque actualizar el backend reinicia el proceso y bloquea la firma.

La orden permanece visible mientras prepara almacenamiento/wNEAR, envía y confirma. Se guarda cada hash antes de transmitir. El identificador de orden evita duplicados, incluso si se pierde la respuesta HTTP. No hay reintentos automáticos de compras/ventas. La parada impide nuevos envíos; no revierte una transacción ya transmitida. Una respuesta incierta se recupera automáticamente por hash, con backoff y fallback de lectura. CONSULTAR AHORA es opcional. Sin FINAL se bloquean fondos/nonce de esa cuenta; con FINAL y recepción todavía no verificada, solo se bloquea el token afectado. COMPLETADA requiere ejecución final e importe recibido verificable en los recibos; no se atribuye un saldo actual a una operación histórica. Durante una compra REAL podés PREPARAR VENTA 50/99: se enviará una sola vez, después de verificar la compra y releer saldo, ruta y cotización; se cancela al reiniciar, cambiar wallet, apagar REAL o detener el bot. No es un monitor TP/SL.

Se ejecutan pares directos token/quote NEP-141 descubiertos en la fábrica y pool Running. wNEAR conserva su preparación automática; otros FT usan saldo existente. Ver [QUOTE_ASSETS.md](QUOTE_ASSETS.md) para alcance y limitaciones. Rutas múltiples y límites de tenencia incompatibles se rechazan. Se consultan impuestos de compra/venta: la venta cotiza la entrada después del impuesto y transfiere el importe bruto; la compra muestra salida y mínimo después del impuesto. DCL puede entregar NEAR nativo en una venta de wNEAR; se distingue de la salida en wNEAR y se contabiliza el gas para comprobar el mínimo. Gas y almacenamiento son costos adicionales al importe de compra. La cotización de venta mostrada es anterior al gas.

**La integración es experimental: se verificó firma, preparación y swaps en testnet, y se probaron los impuestos con casos controlados. No se publicaron compras ni ventas mainnet durante el desarrollo, y la fábrica testnet no implementa los impuestos actuales de mainnet.** Activar REAL no significa que todas las variantes de Nearly estén probadas. El AUTO SELL se probó con simulaciones y en DRY RUN contra mainnet; **no se validó una venta automática real con fondos**.

## Velocidad: dónde se va el tiempo de una compra

Medido desde Argentina: **~270-300 ms de ida y vuelta a cada RPC** (dRPC 271 ms, FastNEAR 294 ms; el RPC oficial `rpc.mainnet.near.org` 3,6 s: inservible). Una compra son varios pasos secuenciales y cada uno espera confirmación (~1,5 s hasta ejecutarse, ~3 s hasta FINAL):

| Paso | Qué hace | Cómo se acorta |
|---|---|---|
| Registrar el token (NEP-145) | tx + espera | **ARMAR**: se hace antes (al pegar o con el botón). Los pasos previos esperan solo la ejecución (`PREP_LEVEL=optimistic`) |
| wNEAR (wrap) | tx + espera | **Mantené wNEAR listo** (PREPARAR wNEAR / ARMAR): sale del camino de compra |
| Swap | cotización fresca + firma + envío + espera | `CONFIRM_LEVEL=optimistic` lo da por hecho al ejecutarse en vez de esperar FINAL (~1,5 s) |
| Envío | un RPC | **Difusión** de la misma firma a varios RPC (`NEAR_RPC_BROADCAST`): entra por el más rápido, idempotente |

Con wNEAR listo y el token registrado la compra es **un solo swap** (~3 s con FINAL, ~1,5-2 s con confirmación rápida) en vez de ~10 s. El panel **⚡ Velocidad** permite cambiar los niveles en caliente. La confirmación rápida acepta un swap ya ejecutado aunque aún no sea irreversible; un vigilante verifica en segundo plano que llegue a FINAL y, si el hash desapareciera (reorganización, extremadamente raro), la operación vuelve a «recuperando» por hash sin reenviar. Probala primero con importes chicos: **no se validó con fondos reales**.

Lo que **no** cambia el código: la distancia. Un **VPS en EE. UU. este o Europa** (cerca de los validadores y de los RPC) baja el RTT de ~300 ms a ~20-60 ms y recorta ~1 s más de una compra de 3 pasos; un RPC con clave (FastNEAR/dRPC de pago) evita los 429 del plan gratuito. Medí con `npm run rpc:latency`.

## Mercado en vivo: chart, market cap, liquidez y swaps

Al pegar un contrato aparece el panel de mercado (todo con el contrato como único dato enviado a terceros):

- **Precio, market cap, liquidez y supply: on-chain** (cotización del mejor pool, `ft_total_supply`, reservas de cada pool). En pruebas, la liquidez on-chain de `ai-8` coincidió con DexScreener (0,1 %). El market cap es *supply total × precio* (no descuenta supply bloqueado o quemado).
- **Volumen, txns, variación y antigüedad del par:** DexScreener. **Mayores holders:** FastNEAR (se separan los contratos de pools y se avisa si un holder tiene ≥ 30 % o los 10 mayores ≥ 70 %).
- **Chart de velas + volumen** (TradingView Lightweight Charts, versión exacta fijada): histórico de GeckoTerminal en 1m/5m/15m/1h/4h/1d, en USD o NEAR, actualizado vela a vela con cada swap en vivo. Pools recién creados (que GeckoTerminal tarda en indexar) se grafican con velas propias a partir de los swaps. Con una posición abierta se dibujan **entrada, TP y SL**.
- **Swaps en el momento:** un único WebSocket (Intear `trade_swap`) en el servidor se reparte a las pestañas por SSE; el historial inicial combina Intear y GeckoTerminal. Tus propios swaps se resaltan; hay filtro por lado/monto, pausa y presión compra/venta.

Límites: son APIs públicas gratuitas y beta (GeckoTerminal limita ~30 consultas/min, por eso se cachea y se espacia; Intear avisa que su base no está completamente rellenada). Si una fuente falla, ese dato aparece como «—» y el resto sigue. Los swaps en vivo llegan ~1-3 s después del bloque.

## Vigilancia de pool, alertas, seguimiento y avisos (4ª ronda)

- **Vigilancia de pool** (pestaña «Vigilancia»): para un contrato que todavía no se puede comprar. Lo mira cada ~1,5 s (`SNIPER_INTERVAL_MS`) y, cuando aparece un pool directo token/wNEAR con la **liquidez mínima** que pediste, dispara **una sola compra** con el importe, el slippage y el AUTO SELL de COMPRAR. Pasa por el mismo camino que un clic manual: análisis de riesgo, topes de gasto, idempotencia (el `requestId` se fija al crear la vigilancia, así que jamás compra dos veces). Máximo 3 activas, vence (60 min por defecto, tope 12 h), vive solo en memoria, se pausa si REAL se apaga o hay parada de emergencia y se cancela si cambia la wallet. En DRY RUN simula la compra cuando el pool aparece. **No compra «todo lo nuevo»** y no hace compras *antes* de que exista el pool (eso exigiría un adaptador por launchpad, validado con fondos).
- **SALIR DE TODO** (pestaña «Posiciones»): vende el 100 % de cada posición abierta, de a una, ignorando take profit / stop loss. Pide confirmación, solo con REAL activo, y se apaga solo al terminar o si REAL se desactiva.
- **Alertas de precio** (🔔 bajo el chart): «sube a» / «baja a» en USD; avisan una vez con sonido, aviso del navegador y Telegram si está configurado. Funcionan con la pestaña abierta (también en segundo plano).
- **Lista de seguimiento** (☆ SEGUIR): hasta 8 tokens con precio y variación 24 h; un clic los abre y sus precios también alimentan las alertas.
- **Tus compras y ventas sobre el chart** (▲ / ▼ con el monto en NEAR).
- **Avisos por Telegram** (opcional, `TELEGRAM_BOT_TOKEN` y `TELEGRAM_CHAT_ID` en el `.env`): estado final de cada orden REAL, AUTO SELL, vigilancia de pool y alertas. Solo sale texto corto a `api.telegram.org`; nunca claves ni saldos.
- **Topes de gasto** (`MAX_BUY_NEAR`, `MAX_DAILY_NEAR`): se aplican en el servidor justo antes de comprar y la interfaz los muestra.
- Más launchpads reconocidos en el feed: Intear, tknport y NearFi.

## Telegram, importes rápidos, P/L y pares en otro token (5ª–8ª ronda)

- **Sin lista de tokens nuevos:** se quitaron «Descubrir» y «Lanzamientos»; el token se elige pegando su contrato (o desde la lista de seguimiento).
- **Rastreador de Telegram** (pestaña «Telegram»): agregás @canales **públicos**; GABNEAR lee su vista web pública (`t.me/s/<canal>`, sin cuenta ni bot), junta los contratos de launchpads que mencionan y sube arriba los que mencionan varios canales. Máx. 10 canales, una lectura por minuto por canal, solo con la pestaña abierta (`TG_CHANNELS` en el `.env` define canales por defecto). El HTML se trata como texto.
- **X (Twitter) no se rastrea**: su API es de pago y leer la web va contra sus términos; los espejos gratuitos (Nitter) son inestables.
- **Comprar solo con el botón verde** (no hay botón ENVIAR ni compra con Enter): los 4 importes rápidos solo **cargan la cantidad** y el botón verde ejecuta. Cada importe muestra su valor en dólares.
- **P/L en vivo con el porcentaje bien grande**, también en DRY RUN: una compra simulada abre una **posición simulada** valuada con el precio real (con la comisión de salida), con tarjeta sobre el panel, chip en la cabecera y lista en «Posiciones»; vender en simulación la reduce y registra lo realizado. Las posiciones reales usan el mismo formato.
- **Tokens que cotizan en otro token** (p. ej. algunos launches de Nearly en RHEA): precio, market cap y liquidez se miden en ese par y se convierten a NEAR. **Se compran pagando con NEAR**: el bot cambia solo NEAR → RHEA (en el pool contra wNEAR de mayor salida, envolviendo NEAR si hace falta) y con lo recibido compra el token (2 swaps, ambos con mínimo de salida y topes de gasto medidos en NEAR). Si el segundo swap falla, el RHEA queda en tu wallet y el mensaje lo dice. **No validado con fondos reales.**
- **Ruedita ⚙** (junto a COMPRAR/VENDER): fijás tus 4 importes de compra (NEAR) y tus 4 porcentajes de venta (1–100 %); también rigen Alt+1…4. **Dólares en todo:** el importe a comprar, cada botón rápido y cada porcentaje de venta muestran su valor en USD; antes de comprar ves cuántos tokens recibís (y el mínimo), el impacto de precio y un aviso si el pool es chico. **P/L en vivo** en dólares: por posición (sobre el chart y el panel de venta) y total en la cabecera. En VENDER el saldo y su valor se leen solos.

## Compartir con amigos

`Empaquetar-Para-Amigos.bat` crea un zip **sin tus datos** (sin `data/`, `.env`, wallet ni cuentas; se niega si detecta una clave o un dato personal). Cada amigo corre su propia terminal local con su propia wallet y su propio historial. Detalle en **`COMPARTIR.md`**.

## Seguridad

Ver **`SEGURIDAD.md`**: modelo de amenaza, lo que se cerró (CSP, anti-clickjacking, fuentes propias, `Host`/`Sec-Fetch-Site`, topes de gasto, **política de firma** que solo permite wrap, registro propio y swap a Rhea/Ref), el pentest automatizado (`tests/security.test.ts`, incluye una prueba de mutación) y el riesgo residual que el código no puede cerrar (extensiones del navegador, malware local, tokens estafa…).

## Cuenta secundaria y secretos

El botón **CONECTAR WALLET**, arriba a la derecha, abre estas opciones:

- **Crear wallet nueva (recomendado):** la clave se genera en esta PC (12 palabras BIP-39 → ed25519), la cuenta es la **implícita** de esa clave (64 hex, no hay que «crearla»: existe al recibir NEAR) y se guarda cifrada. La frase se muestra **una sola vez** y no se guarda en ningún lado. Después le enviás desde tu wallet principal los NEAR que quieras arriesgar. Es lo más seguro porque la clave nunca pasó por Meteor ni por otra wallet, y lo más rápido porque firma sin confirmaciones externas. Si ya había una wallet local, su bóveda se **archiva** en `data/archive/` antes de reemplazarla (antes se sobrescribía en silencio).
- **Importar clave privada** (`ed25519:…`) o **frase semilla:** para una cuenta secundaria que ya tenés. La clave privada expone menos que una semilla (que puede gobernar otras cuentas). Se valida contra la cuenta en la red (FullAccess) y solo viaja la clave pública al RPC.
- **Dirección pública:** valida en mainnet una cuenta y permite consultar balances y registración sin importar secretos. También sirve para consultar la principal.
- **Importar local:** recibe la cuenta, una semilla NEAR válida y una contraseña propia de GABNEAR de al menos 12 caracteres. La derivación estándar NEAR se verifica contra una access key FullAccess de esa cuenta. Una wallet con otra derivación se rechaza; no se presume compatible. Solo la clave pública se consulta por RPC. La semilla no se guarda. La clave derivada se cifra con AES-256-GCM y scrypt, y el resultado se protege además con Windows DPAPI.
- **Desbloquear:** aparece cuando hay una clave local. Pide la contraseña de GABNEAR, no la de Meteor. La firma se bloquea al reiniciar el servidor, cambiar de cuenta o pulsar Bloquear/Desconectar. Desconectar no borra el archivo cifrado.

La importación no activa trading real. Durante el ingreso y derivación la semilla y clave existen temporalmente en memoria del navegador y del backend local; no se guardan en localStorage, historial ni logs. Preferí una cuenta secundaria dedicada al bot. No pegues secretos en este chat.

No compartas la semilla ni la clave de tu Meteor principal. Creá una cuenta independiente destinada al bot mediante tu wallet de confianza. Para DRY RUN basta poner su identificador público en `BOT_ACCOUNT_ID` dentro de `.env`: no hace falta ninguna clave.

Para preparar firma local, abrí `Configurar-Wallet.bat`: ejecuta `Configurar-Wallet.ps1`, que solicita el identificador de la cuenta secundaria y su clave **en una consola local**, con entrada oculta. Guarda únicamente la clave cifrada por Windows DPAPI en `data/wallet.dpapi`, vinculada a tu usuario de Windows. El script no crea ni financia una cuenta mainnet, ni habilita trading real. El lanzador utiliza una política temporal para ese proceso; no cambia permanentemente la política de Windows.

La clave no se manda al frontend ni se almacena en `.env`. `data/` y `.env` están excluidos de Git. DPAPI protege el archivo en reposo; un proceso que se ejecute como tu mismo usuario de Windows puede descifrarlo. Durante la firma la clave existe temporalmente en memoria.

La cuenta testnet automática se guarda por separado en `data/testnet-account.json` y `data/testnet-wallet.dpapi`; no se usa como cuenta mainnet del panel.

## Mascota Gabi Gabear

La nueva imagen IA está en `public/assets/gabi-gabear-v1.png`, creada con la herramienta integrada image_gen y el retrato proporcionado como referencia. Su prompt final se conserva en `public/assets/gabi-gabear-prompt.txt`. La mascota ocupa un bloque propio en el encabezado; las frases «el dundo», «el dundez», «el duende dundix», «cata olibeari» y «pregabear 150mg» son etiquetas decorativas fuera de los campos y botones de trading.

## Configuración

`.env.example` documenta las variables; creá tu `.env` con los pasos anteriores. Topes de gasto opcionales (`MAX_BUY_NEAR`, `MAX_DAILY_NEAR`), slippage máximo 10 % (`MAX_SLIPPAGE_BPS=1000`) y reserva de gas 0.1 NEAR. El valor de la reserva se descuenta del balance disponible mostrado, junto con el almacenamiento. No representa una garantía del costo de una compra.

El ejemplo usa https://near.drpc.org como RPC primario; sin configuración el código usa https://free.rpc.fastnear.com. Se comprueba chain_id antes de operar. `NEAR_RPC_URL` permite elegir otro proveedor. Las conexiones se reutilizan por proceso y las consultas independientes se paralelizan. Cotizaciones, liquidez e impuestos se vuelven a consultar; no se cachea un precio para una futura compra.

## Pruebas

- `npm run test`: **261 pruebas**, ejecutadas desde un directorio vacío (no leen tu `data/` ni tu `.env`). Incluye el pentest del servidor (`tests/security.test.ts`). Validación, importes exactos, límites, resultados de transacciones, errores RPC, rutas no soportadas, decisiones de salida y firma SDK offline.
- `npm run build`: chequeo TypeScript y build Vite.
- `npm run verify`: ambas verificaciones anteriores.
- Los scripts que tocan la red o fondos (`npm run test:*`, `benchmark*`, `rpc:latency`) viven en `tests/manual/` y no forman parte de `npm test`.
- `npm run test:mainnet`: lectura y cotización del token `ai-8.nearlytrade.near`, sin publicar transacciones.
- `npm run test:market`: **solo lectura**; snapshot (precio, market cap, liquidez on-chain, volumen, holders), velas y swaps de un token real contra mainnet y las APIs públicas.
- `npm run rpc:latency`: mide desde TU PC la latencia a cada RPC de NEAR y sugiere el orden (lectura, fallback y difusión). Cada paso secuencial de una compra paga ese RTT.
- `npm run test:generic`: **solo lectura** contra mainnet; descubre, cotiza y evalúa el riesgo de un token de cada launchpad (Nearly, meme.cooking, JustHoot, Shore, tknx, tkn). Usa el RPC de `.env`; con un RPC público gratuito sin fallback puede toparse con el límite de cuota.
- `npm run test:http`: prueba del servidor ya iniciado: límites, origen, bloqueo real, parada y persistencia del análisis.
- `npm run test:operations`: API de órdenes asincrónicas, idempotencia, riesgo, historial y DRY RUN contra el servidor iniciado.
- `npm run test:testnet`: prueba explícita con fondos del faucet testnet. Puede generar gastos de gas testnet y operaciones en contratos testnet. Nunca utiliza la wallet mainnet. Registra hashes antes de enviar y bloquea repeticiones si hubo un resultado pendiente.

Los reportes de red se guardan en `data/mainnet-verification.json` y `data/testnet-verification.json`. Un tiempo medido corresponde a esa corrida y no es una promesa de latencia futura.

## Módulos

`src/`: interfaz. `server/validation.ts`: enlaces, unidades y riesgo. `rpc.ts`: proveedor y tiempos máximos. `pools.ts`: token/fábrica/pools. `quotes.ts`: cotizaciones. `analysis.ts`: DRY RUN. `wallet.ts` y `secure-store.ts`: firma y DPAPI. `transactions.ts`: hashes, exclusión y resultados. `trading.ts`: preparación/compra/venta experimental con activación explícita. `operations.ts`: órdenes asincrónicas, idempotencia y recuperación. `autosell.ts`: obsoleto (lógica heredada, solo para sus pruebas). `venues.ts`: pools Rhea DCL / Ref v1, cotización por ruta, mensaje de swap y riesgo. `positions.ts`: libro de posiciones, costo promedio, P/L y decisión de salida. `exit-monitor.ts`: monitor AUTO SELL. `constants.ts`: contratos mainnet. `settings.ts` / `finality.ts`: niveles de confirmación (final/optimista) y ajustes de velocidad. `market.ts` / `market-hub.ts` / `trades.ts` / `fetcher.ts`: datos de mercado (snapshot, velas, swaps en vivo) con caché y límite de ritmo. `src/market/*`: chart, encabezado del token y feed de swaps. `history.ts`: persistencia (telemetría diferida). `bridge.ts`: puente NEAR → quote → token. `limits.ts`: topes de gasto. `call-policy.ts`: política de firma (solo wrap, registro y swap). `security.ts`: cabeceras y guardas HTTP. `sniper.ts`: vigilancia de pool. `notify.ts`: avisos Telegram. `social.ts`: rastreador de canales. `usd.ts`: precio NEAR/USD. `src/paper.ts`: posiciones simuladas. `index.ts`: API local.

## Fuentes primarias consultadas

- Nearly: https://nearly.trade/docs y sus módulos públicos del cliente vigentes el 10/10/2026.
- NEAR SDK oficial: https://github.com/near/near-api-js.
- Contratos globales NEAR: https://github.com/near/NEPs/blob/master/neps/nep-0591.md.
- Rhea/Ref SDK: https://github.com/ref-finance/ref-sdk.
- Rhea DCL: https://guide.rhea.finance/near-chain-guides/liquidity-pools/rhea-v2-pools.
- Faucet oficial y formato de creación: https://github.com/near/near-contract-helper y https://github.com/near/near-cli-rs/blob/main/docs/GUIDE.en.md.

Los receptores de las transacciones testnet fueron contratos de almacenamiento, wrap y swap de la ruta de prueba. No hay transferencias a cuentas personales de terceros.

Topes de gasto: `MAX_BUY_NEAR` por compra y `MAX_DAILY_NEAR` por 24 h (el servidor los aplica; vacío o 0 = sin tope). El slippage máximo aceptado es `MAX_SLIPPAGE_BPS` (1000 = 10 % por defecto); con un valor alto se admite un mínimo de salida muy bajo. El saldo y la reserva para gastos se comprueban igualmente.


## Presentación y valor estimado en USD

Balances NEAR/wNEAR, disponible, cantidades de tokens, cantidades recibidas y cotizaciones se presentan con dos decimales. Solo cambia la presentación; los cálculos y transacciones conservan unidades exactas.

ACTUALIZAR SALDO / COTIZAR muestra al lado VALOR EN USD · ESTIMADO para el saldo completo del token. Para quotes wNEAR, se cotiza la venta del saldo entero a NEAR, descontando el impuesto de venta y utilizando la liquidez del pool, y se multiplica por el bid NEAR/USD de Coinbase Exchange. No se duplica la cotización del 50%. El resultado es anterior al gas y a comisiones/condiciones de una conversión posterior a USD; GABNEAR no realiza esa conversión. La fuente USD puede reutilizarse hasta 30 segundos y se muestra la hora de la cotización. Si no hay cotización o fuente válida, aparece No disponible. Los envíos de compra/venta no dependen de esta consulta de precio USD.

Fuente del precio: https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-ticker.

## Optimización de latencia (10/10/2026)

El análisis precargado medido bajó de 1493,654 a 974,500 ms de mediana (34,757%); esto no es una medición de compra real. Ver `OPTIMIZACION.md`, `BENCHMARK_RPC.md` y `BENCHMARK_SIGNING.md`.

- Al pegar el enlace se precargan datos mediante consultas; no se firma ni compra hasta pulsar el botón verde.
- **ANALIZAR PREPARACIÓN wNEAR** usa el importe configurado como saldo objetivo. En REAL, **PREPARAR wNEAR ANTES DE COMPRAR** registra y envuelve solo el déficit. Esta acción utiliza fondos en REAL, pero no compra tokens. Permite evitar wrap dentro de la compra siguiente.
- El panel muestra etapas medidas y recibe cambios del backend por eventos locales, con consulta periódica de respaldo.
- `.env.example` ofrece dRPC como primario y FastNEAR como fallback de lectura. `NEAR_ASYNC_SEND=true` devuelve acuse NONE y confirma mediante consultas separadas. Acuse con límite de 3 segundos; un timeout inicia recuperación sin retransmitir. `false` conserva envío esperando FINAL con límite antiguo de 15 segundos. El nuevo envío se probó con mocks; no se emitió una transacción nueva mainnet en esta revisión.
- `npm run benchmark`: comparación de lectura RPC y análisis; `benchmark:signing`: firma sintética offline; `benchmark:plan`: proyección sin fondos. Son muestreos pequeños, no pruebas de carga sobre nodos públicos.

### Campaña de compras reales, separada del uso normal

`npm run benchmark:real` no está incluido en pruebas ni arranca automáticamente. Requiere la app abierta, cuenta secundaria desbloqueada, REAL habilitado y `BENCHMARK_ACCOUNT_ID` con la dirección pública expresamente autorizada. No acepta semillas ni contraseñas por argumentos o variables. Cargar credenciales exclusivamente en el panel local. Una credencial compartida por chat debe sustituirse antes de utilizar fondos.

El importe de cada nuevo intento es fijo: **0,05 NEAR**; cap de campaña **0,5 NEAR con gas y depósitos**, máximo **cinco intentos**, fallos incluidos. `BENCHMARK_ATTEMPTS` indica el máximo acumulado de intentos, por defecto dos. El ledger persistente cuenta intentos de ejecuciones anteriores: reiniciar no renueva el presupuesto. Permite reducir el importe histórico de 0,1 a 0,05 solo cuando no hay intentos pendientes, conservando todos los costos anteriores. `BENCHMARK_TOKEN` selecciona el token; por defecto `ninu-4.nearlytrade.near`, sujeto a verificación de ruta/reglas y cotización de salida. El token AI del enlace de análisis está excluido de compras automáticas de prueba. No se vende en esta campaña.

El script calcula reservas conservadoras según gas y storage actuales, exige una salida cotizada mínima de 0,045 NEAR para la compra de 0,05, registra hashes y conserva toda la reserva ante incertidumbre. Las reservas no garantizan un precio de gas futuro. No continúa si falla una compra, queda parcial, falta confirmación de costos o se pierde una respuesta. Nunca repite un POST de compra. Si la campaña se detiene por presupuesto, no aumentarlo ni borrar el ledger para continuar.

Archivos locales privados de campaña: `data/benchmark-real-ledger.json`, `data/benchmark-real-results.json` y `data/benchmark-real.lock`. Si el proceso se termina abruptamente, puede quedar un lock; reconciliar historial y ledger antes de retirarlo. No reiniciar una compra incierta. Los botones habituales no utilizan el ledger de campaña y se limitan con `MAX_BUY_NEAR` y `MAX_DAILY_NEAR`.

La compra REAL con saldo quote y ambos registros ya preparados usa una sola cotización fresca, calculada inmediatamente antes del swap y guardada en el historial. Si falta storage o wrap, conserva una cotización previa antes de pagar preparación y vuelve a cotizar antes de enviar. La metadata del quote se consulta en paralelo y las consultas simultáneas de identidad de red comparten una petición. Saldos, cotizaciones y estado del pool se vuelven a consultar; la finalidad de la cadena y latencia del RPC siguen condicionando los tiempos reales.

El ejecutor quedó implementado y se verificaron sus componentes y el rechazo de inicio sin cuenta autorizada configurada. **Todavía no se validó una compra real de esta versión.** La proyección de lectura de la cuenta anterior admite dos intentos con reserva conservadora; recalcular con la wallet definitiva. No se promete comprar en menos de un segundo.


## Verificación de portabilidad (10/10/2026)

Se copió exclusivamente el contenido versionable a una carpeta limpia, sin .env, data/, node_modules/ ni dist/. Con Node 24.14.1/npm 11.11.0, npm ci instaló 179 paquetes (auditoría: cero vulnerabilidades informadas), npm run verify pasó 79 pruebas y compiló TypeScript/Vite. Se comprobó el arranque de la API y frontend compilado en puerto aislado 4318, imagen original y assets, lectura RPC mainnet, wallet ausente/bloqueada, REAL apagado y rechazo de origen externo. Las pruebas de recuperación ahora usan cuenta sintética y carpeta temporal. No se enviaron compras, ventas ni transacciones testnet en esta revisión. Esto verifica una instalación Windows limpia en esta PC; no se probó físicamente otra computadora.
