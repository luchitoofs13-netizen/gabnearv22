# GABNEAR — resumen de todo lo que se hizo (12/10/2026)

Punto de partida: `GABNEAR-main (1).zip` (terminal local React + Express + near-api-js para comprar y vender tokens de **Nearly** en NEAR). Copia de trabajo: `D:\proyectos\gabnear`. Detalle técnico y tablas en `AUDITORIA.md`.

## Ronda 1 — auditoría, tokens de cualquier launchpad, AUTO SELL

**Seguridad (revisión completa).** Sin exfiltración: solo habla con el RPC, el fallback y Coinbase (precio USD); sin `eval`/`exec`; 0 vulnerabilidades en `npm audit`. Se reforzó la bóveda de la clave: scrypt pasó de N=2¹⁴ a **N=2¹⁷** (las bóvedas viejas siguen abriendo).

**Errores corregidos**

| # | Qué fallaba | Cómo quedó |
|---|---|---|
| 1 | Cada marca de tiempo de una orden reescribía **todo** `history.json` de forma síncrona: 5,8 s de servidor bloqueado con 500 filas | Escritura diferida y agrupada; hashes y estados siguen guardándose al instante → 0 ms |
| 2 | Una tx **rechazada** por la red se trataba como «incierta» para siempre y bloqueaba la cuenta hasta editar `history.json` a mano | Clasifica el rechazo, consulta el hash antes de liberar, libera por ventana vencida o nonce consumido; botón de descarte manual |
| 3 | `near-api-js` reintentaba 12 veces (~2 min) antes de usar el fallback; un 429 no se reintentaba | Reintentos acotados; un 429 sin fallback se reintenta una vez |
| 4 | Solo aceptaba tokens `.near` con punto y enlaces de nearly.trade | Acepta cualquier cuenta de token (y enlaces de nearblocks); sigue rechazando `wrap.near`, testnet, dominios |
| 5 | Un token sin eventos NEP-297 dejaba la compra en «VERIFICANDO TOKENS» para siempre | Evidencia por hash (eventos → retiro de wNEAR → `ft_transfer`); último recurso: delta de saldo, marcado |
| 6 | El retiro nativo de wNEAR solo reconocía Rhea DCL | Reconoce también Ref v1 |
| 7 | JSON inválido o sin cuerpo devolvía HTML | Guarda de cuerpo + errores en JSON |
| 8 | AUTO SELL heredado sin conectar | Reemplazado por `positions.ts` + `exit-monitor.ts` |
| 9 | Documentación desactualizada | README y auditoría reescritos |
| 10 | (Mío, al construir) fee DCL en ppm vs Ref v1 en bps → «fee 100 %»; P/L negativo ilegible | Fee normalizado a bps; `displaySigned` |

**Funciones nuevas**
- **Tokens de cualquier launchpad** (meme.cooking, tkn, tknx, Shore, JustHoot, Nearly…): descubre pools directos token/wNEAR en **Ref v1** y **Rhea DCL**, elige la mejor ruta por salida, mide impacto de precio e ida y vuelta, y bloquea pools que se moverían demasiado (con límites configurables).
- **AUTO SELL**: take profit, stop loss y trailing, con libro de posiciones (costo promedio incl. gas, P/L realizado), valuación por cotización ejecutable de salida y venta por el mismo camino idempotente que la manual.
- Todo guardado en disco D: (proyecto y caché de npm).

## Ronda 2 — wallet, velocidad, mercado en vivo

- **Wallet:** recomendación = crear una **wallet nueva dedicada dentro del bot** (cuenta implícita, 12 palabras mostradas una sola vez); alternativa, importar la **clave privada** de una cuenta secundaria. Antes, importar sobrescribía la wallet anterior en silencio: ahora la archiva. Con la wallet legada, cada firma lanzaba PowerShell (+300-700 ms): ahora se descifra una vez.
- **Velocidad** (medí ~270-300 ms de ida y vuelta por RPC desde tu PC): **⚡ ARMAR** (registra el token y deja wNEAR listo → la compra es un solo swap), pasos previos que esperan ejecución y no finalidad, **confirmación rápida** opcional con vigilante de finalidad, difusión de la misma firma a varios RPC, `npm run rpc:latency`, cola de compra mientras se arma.
- **Terminal de mercado:** precio, market cap, liquidez, volumen, txns, holders y antigüedad; **chart de velas** (1m–1d, USD/NEAR) con tus líneas de entrada/TP/SL; **swaps en vivo** (WebSocket de Intear, los tuyos resaltados); pestaña de **lanzamientos** de cada launchpad; avisos de concentración y poca liquidez.
- Pruebas: 163 → **202**.

## Ronda 3 — lo que se corrigió después de tus capturas

1. **Diferencias con DexScreener.** Causa real: DexScreener devuelve *todos* los pares donde aparece el token (pools diminutos y pares donde NINU es la moneda de cotización de otro token) y yo los sumaba → 160 txns contra 144 de su página. Ahora txns, volumen, variación y antigüedad salen del **par principal**, como en su web (verificado en vivo: 72/73 contra 72/72 de su página; la diferencia de 1 es un swap nuevo). Lo que queda distinto es **por diseño** y ahora tiene tooltip:
   - *Precio:* yo muestro el precio **spot del pool** (sin comisión); DexScreener y el chart muestran el del **último swap**, que incluye la comisión (~1 %) y salta según sea compra o venta.
   - *Liquidez:* ~2-3 % de diferencia por cómo cuenta cada uno las reservas del pool.
   - *Market cap:* yo uso el supply on-chain; DexScreener calcula MC y FDV con otro supply.
   - *Antigüedad:* la API de DexScreener da 15 d para ese pool; su página dice 16 d 1 h (dato suyo).
2. **Tabla de swaps ilegible.** Era un choque de CSS: la clase `.sell` del botón VENDER (fondo rosa opaco) también pintaba las filas de venta. Filas renombradas (`t-buy`/`t-sell`) y tabla rediseñada: hora relativa («hace 4m», fecha completa al pasar el mouse), tipo en verde/rojo, barra proporcional al tamaño, marca ● en swaps de 25+ NEAR, precio en USD, filtro **MÍOS**, tus swaps con insignia «TÚ», más alta y con filas de 34 px.
3. **Bug del chart** (lo encontré al verificar): al cambiar de token/timeframe, vaciar la serie provocaba el error interno «Value is null» de lightweight-charts durante el repintado. Ahora el chart se recrea en cada cambio; probé 6 cambios seguidos sin errores. La altura del chart se adapta a la pantalla.
4. **wNEAR, explicado en la pantalla.** Panel «¿Hace falta wNEAR?» con estado en vivo (✓ listo / ○ se convierte solo), botones renombrados («⚡ ARMAR (token + wNEAR)», «CONVERTIR NEAR → wNEAR») y el rótulo «HOLDERS (TOP)» pasó a «TOP HOLDER» (el 4,017 % es lo que tiene el mayor holder, no una cantidad de holders).
5. Prueba de `parseDexScreener` actualizada al nuevo criterio. **202 pruebas verdes**, build en verde.

## Ronda 4 — seguridad y herramientas de trading

**Seguridad** (detalle y riesgo residual en `SEGURIDAD.md`):
- Revisión del servidor + **pentest automatizado** contra el servidor real (`tests/security.test.ts`, 12 pruebas: DNS rebinding, CSRF/CORS, recorrido de rutas, cuerpos hostiles, REAL sin permiso, fuerza bruta, agotamiento de conexiones). Quitando las defensas, 4 pruebas fallan: detectan lo que deben.
- Cerrado: sin cabeceras de seguridad (se podía incrustar la terminal en un iframe) → CSP + `X-Frame-Options`; fuentes de Google en cada carga → fuentes propias; `Host` solo en `/api` → global; peticiones «same-site» → `Sec-Fetch-Site`; streams sin tope → 12; **sin tope de gasto → `MAX_BUY_NEAR` / `MAX_DAILY_NEAR`**; **firmaba cualquier llamada → política de firma** (solo wrap, registro propio y swap a Rhea/Ref).
- `npm audit` 0 y 183 paquetes con firma de registro verificada.
- Las pruebas dependían de tu `data/` y tu `.env` (tu cuenta conectada rompía 2): ahora corren aisladas.

**Funciones agregadas** (las que te propuse):
- **Vigilancia de pool**: compra una vez, apenas aparece el pool del contrato que cargues, con liquidez mínima, riesgo y topes (no «todo lo nuevo», no antes de que exista el pool).
- **SALIR DE TODO**, **alertas de precio**, **lista de seguimiento**, **marcas de tus compras/ventas en el chart**, **avisos por Telegram** (opcional).
- Launchpads nuevos en el feed: Intear, tknport, NearFi.
- Pruebas: 202 → **238**.

## Ronda 5 — error de RHEA, botón COMPRAR, Descubrir

- **El error de tu captura** («Saldo insuficiente de RHEA…»): el token KINU de Nearly **cotiza contra RHEA, no contra NEAR**; el bot pedía 4 RHEA (el importe de la caja es en la moneda del par) y tenías 0. No era un fallo de compra sino una pantalla confusa. Además el panel mostraba basura para esos tokens (precio «$—», liquidez $0.0015, «fee NaN%»): medía todo contra wNEAR. Ahora precio, market cap y liquidez se miden en el par real y se convierten a NEAR (KINU: liquidez $5.7K contra $5.8K de DexScreener), el mensaje explica qué hacer y un botón lleva a comprar RHEA con NEAR.
- **Botón COMPRAR** grande + panel COMPRAR/VENDER por pestañas (antes solo se compraba con ENVIAR o Enter).
- **Descubrir** (nuevos, en tendencia, narrativas) y **rastreador de Telegram** de canales públicos. X no (API de pago).
- Pruebas: 238 → **245**.

## Ronda 6 — compra directa con NEAR, ruedita, dólares y P/L

- **Tokens que cotizan en RHEA:** ahora «entienden» que hay que comprar RHEA, como ya hacían con wNEAR: pagás con NEAR y el bot cambia NEAR → RHEA y compra el token (2 swaps). Vista previa en pantalla: cuánto RHEA y cuántos tokens recibís.
- **Ruedita ⚙:** 4 importes de compra y 4 porcentajes de venta a tu gusto (el servidor ahora acepta cualquier porcentaje entero 1–100).
- **Dólares:** importe a comprar, botones rápidos, porcentajes de venta, saldo y valor del token (también para pares RHEA), y **P/L en vivo** por posición y total.
- **Aviso de pool y tokens a recibir:** ✓/⚠ con liquidez del pool, impacto de precio y qué parte del pool es tu compra, más «Recibís ≈ X (mín. Y)».
- **Descubrir:** sin narrativas, dividido por launchpad (Nearly / JustHoot / Otros).
- **UX corregida:** el botón de compra decía «4 quote del launch» sin token cargado; el error salía arriba, lejos del botón (ahora dentro de cada panel y en el estado de la operación); en VENDER había que tocar «actualizar» para ver el saldo (ahora se lee solo); botones deshabilitados sin explicar por qué (ahora dice el motivo).
- Pruebas: 245 → **254**.

## Ronda 7 — limpieza y compra de un clic

- **Botones «bugueados»**: los deshabilitados mostraban el cursor de *cargando* (CSS `cursor:wait`); ahora `not-allowed`.
- **Sin ENVIAR:** se compra solo con los botones del panel. Los 4 importes de la ruedita compran **de un clic** (opción en ⚙ para que solo seleccionen); el verde compra el importe escrito; Enter en el campo del contrato ya no hace nada.
- **Swaps en tiempo real:** desaparecían porque al pegar un contrato la pantalla se quedaba en otra pestaña (ahora pasa sola a «Swaps en vivo») y porque los tokens con par RHEA no tenían feed (ahora se leen contra RHEA y se convierten a NEAR).
- **Fuera «Descubrir» y «Lanzamientos»**; Telegram quedó como pestaña propia.
- Panel «Modo»: el texto se aplastaba en una columna angosta; ahora ocupa todo el ancho con los dos botones debajo.
- Menos ruido: sin errores mientras escribís el contrato, el error viejo se limpia al cambiar de token, el saldo de VENDER espera a que termines de escribir. La vigilancia de pool también paga con NEAR (tokens con par RHEA).
- Pruebas: 254 → **251** (se quitaron las de Descubrir/narrativas; se agregaron las de swaps con par RHEA).

## Ronda 8 — comprar con confirmación, P/L visible y paquete para amigos

- **Compra:** los importes rápidos **ya no compran de un clic**: solo cargan la cantidad y vos ejecutás con el botón verde (lo de un clic se había puesto por error de interpretación; se quitó).
- **P/L que faltaba:** solo aparecía con posiciones REALES, y en DRY RUN no había ninguna. Ahora una compra simulada abre una **posición simulada** que se valúa en vivo (el % arriba o abajo es lo principal), con tarjeta, chip `P/L SIM` y lista; vender en simulación la reduce.
- **Compartir con amigos:** `Empaquetar-Para-Amigos.bat` → zip sin `data/`, `.env`, wallets ni cuentas, con escáner de fugas (se niega a crearlo si hay una clave, un token, una URL con clave o tus cuentas). Verificado: extraje el zip en una carpeta nueva, corrió el lanzador completo (instala, compila, crea su `.env` seguro) y la terminal arrancó **sin cuenta, sin wallet, sin historial** y con su propia `data/`; tu `data/` no se tocó. Guía en `COMPARTIR.md`.
- Pruebas: 251 → **261**.

## Ronda 9: carpeta lista para GitHub

- **RPC:** medido desde esta PC, dRPC ~270 ms y FastNEAR ~315 ms; el resto de los RPC públicos probados no sirven (el oficial 3,2 s; otros devuelven error). La configuración ya usa lo mejor disponible: la latencia que queda es la distancia, no el código. Lo que la baja de verdad: un VPS en EE. UU. este o Europa (~20-60 ms) o una clave propia de pago (evita 429 y colas).
- **Estructura:** `docs/` para la documentación, `tests/manual/` para los scripts que usan red o fondos, README nuevo corto y exacto, README viejo conservado como `docs/REFERENCIA.md` con lo desactualizado corregido (ENVIAR/Enter, Lanzamientos, «sin tope de capital», conteo de pruebas), `GUIA-PARA-USAR.md` reescrita para el flujo actual.
- **Privacidad:** se sacó del repositorio una foto personal (`gabear.jpeg`, que además servía una ruta sin uso), un informe de traspaso a ChatGPT con el repositorio de otra persona y tres informes históricos con una cuenta real ajena y sus hashes de compras. Quedaron fuera del proyecto, no borrados.
- Verificado: un repositorio Git de prueba (fuera del proyecto) muestra que solo entran 127 archivos, sin `.env`, `data/`, wallets, `node_modules` ni `dist`; 261 pruebas y build OK.

## Qué NO está validado con fondos reales

Ejecución en **Ref v1**, **confirmación rápida**, **AUTO SELL real**, **SALIR DE TODO real**, **vigilancia de pool en REAL**, el **puente NEAR → RHEA** (usa Ref v1 si es el mejor pool) y `NEAR_ASYNC_SEND`. Todo lo demás se probó contra mainnet en solo lectura, con pruebas automáticas y en el navegador, pero ninguna compra real. Por eso `PRUEBA-REAL.md`.

## Límites conocidos

- Comprar *antes* de que exista el pool (curva de bonding, fase de depósito) sigue sin ser posible: la vigilancia espera al pool, no lo anticipa.
- No hay forma de detectar un contrato con lista negra o impuesto oculto.
- Las APIs gratuitas (GeckoTerminal ~30 req/min, Intear en beta) pueden fallar: ese dato muestra «—» y el resto sigue funcionando.
