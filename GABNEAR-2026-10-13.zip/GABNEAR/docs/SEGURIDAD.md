# Seguridad de GABNEAR — qué se revisó, qué se probó y qué sigue siendo riesgo

12/10/2026. Este documento separa tres cosas: lo que **se cerró en el código**, lo que **se probó atacándolo** (pentest automatizado, repetible con `npm test`) y lo que **no se puede cerrar con código** y depende de cómo lo uses. No es una auditoría independiente de terceros: es una revisión del código recibido más pruebas de ataque propias.

## 1. Modelo de amenaza

GABNEAR guarda la clave de una wallet que mueve fondos reales y expone una API local. Lo que un atacante querría:

| Objetivo | Vía posible |
|---|---|
| Hacer que **compres o vendas** sin querer | Página web maliciosa que llama a `127.0.0.1:4317` (CSRF, DNS rebinding, clickjacking); proceso local; error de programación |
| **Robar la clave** o la frase | Malware en tu PC; extensión del navegador; copia de `data/`; contraseña débil |
| **Vaciar la wallet** firmando otra cosa | Dependencia manipulada; llamada hostil a la API; bug |
| Engañarte con **datos falsos** | RPC o APIs de mercado que mienten; token estafa |
| **Filtrar** quién sos y qué hacés | Peticiones a terceros desde el navegador (fuentes de Google, etc.) |

## 2. Lo que se cerró (con prueba automática)

| # | Antes | Ahora |
|---|---|---|
| 1 | Sin cabeceras de seguridad: cualquier sitio podía **incrustar la terminal en un iframe** (clickjacking) | `Content-Security-Policy` cerrada (`default-src 'none'`, scripts solo propios, `frame-ancestors 'none'`, `connect-src 'self'`), `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy: no-referrer`, `Cross-Origin-*-Policy`, sin `X-Powered-By` |
| 2 | La hoja de estilos pedía las fuentes a **Google en cada carga** (tu IP y tu actividad a un tercero) | Fuentes propias empaquetadas; el navegador ya no habla con nadie que no sea 127.0.0.1 |
| 3 | La verificación de `Host` (anti DNS rebinding) cubría solo `/api` | Se aplica a **todo** (también páginas y archivos) |
| 4 | Una petición «same-site» (otro puerto de localhost, otra app local) pasaba si no traía `Origin` | Se exige `Sec-Fetch-Site: same-origin/none`; `cross-site` y `same-site` se rechazan |
| 5 | Streams en vivo sin tope: un script local podía abrir sockets sin límite | Máximo 12 conexiones abiertas por tipo de stream |
| 6 | **Sin tope de gasto**: un clic de más, un error de carga o una llamada a la API local podían gastar todo | `MAX_BUY_NEAR` (por compra) y `MAX_DAILY_NEAR` (24 h), aplicados en el servidor justo antes de comprar; un valor ilegible bloquea las compras (falla cerrado). La interfaz los muestra |
| 7 | El firmador aceptaba **cualquier llamada** a cualquier contrato | **Política de firma**: solo `near_deposit` en wrap.near, `storage_deposit` para TU cuenta (≤ 0,05 NEAR) y `ft_transfer_call` con 1 yocto hacia Rhea DCL o Ref v1. Cualquier otra cosa se rechaza antes de existir la transacción |
| 8 | Las pruebas leían tu `data/` y tu `.env` reales (una cuenta conectada rompía pruebas y un `.env` raro las falseaba) | `npm test` corre en un directorio vacío y sin tus variables: no lee ni escribe tus datos |
| 9 | `.env.example` traía `MAX_SLIPPAGE_BPS=9900` (99 %) | 1000 (10 %), y tu `.env` también |

Ya estaba bien y se verificó: servidor solo en loopback; chequeo de `Origin`; cabecera propia obligatoria en POST (fuerza una verificación CORS previa que ningún sitio ajeno supera); límite de 16 kB y errores en JSON sin trazas; bloqueo de la contraseña tras 5 intentos por minuto; REAL desactivado al arrancar, por sesión y con confirmación; scrypt N=2¹⁷ + AES-256-GCM + DPAPI; validación estricta de contratos antes de cualquier consulta a terceros.

## 3. Pentest automatizado (`tests/security.test.ts`)

Levanta el servidor **real** como proceso aparte (directorio, datos y RPC falso propios) y le dispara:

- **DNS rebinding:** 6 hosts hostiles (`evil.example`, `127.0.0.1.evil.example`, `localhost.evil.example`, `[::1]`, `0.0.0.0`…) × API, páginas y archivos → todos 403.
- **CSRF / orígenes:** origen ajeno, `Origin: null`, otro puerto de localhost, subdominios engañosos, `Sec-Fetch-Site: cross-site/same-site`, POST sin la cabecera propia, `Content-Type: text/plain` → todos 403.
- **CORS:** ninguna respuesta autoriza a otro origen; la verificación previa (`OPTIONS`) no concede nada.
- **Cabeceras:** CSP, anti-iframe, nosniff, sin huella del framework, `no-store` en la API.
- **Recorrido de rutas:** 20 variantes (`/.env`, `..%2f`, `%2e%2e`, `\`, `%00`, `/data/vault.json`, `/server/index.ts`, `//etc/passwd`…) → ninguna filtra el archivo secreto, y un control positivo prueba que el servidor de archivos sí funciona.
- **Cuerpos hostiles:** 40 kB (→ 413), JSON roto (→ 400 JSON), `null`, arrays, `__proto__`, `constructor.prototype`, operadores tipo NoSQL → sin caída, sin trazas, sin rutas del disco.
- **REAL sin autorización:** activar sin confirmación, con la confirmación como texto, sin wallet; operar REAL con REAL apagado → rechazado.
- **Rutas de mercado y streams:** 10 nombres de contrato con caracteres de ruta, consulta, CRLF o mayúsculas → 400 antes de llamar a terceros.
- **Métodos raros** (`PUT`, `DELETE`, `TRACE`, `GET` donde va `POST`) → 4xx.
- **Fuerza bruta de la contraseña:** el intento 6 en un minuto → 429.
- **Agotamiento de conexiones:** el cupo 13 → 429, y se libera al cerrar.

Además, una **prueba de mutación**: quitando las guardas del servidor, 4 de estas pruebas fallan; con ellas, pasan todas. Es decir, las pruebas realmente detectan la falta de defensas.

Cadena de suministro: `npm audit` → 0 vulnerabilidades; `npm audit signatures` → **183 paquetes con firma de registro verificada**; todas las URLs del `package-lock.json` apuntan a `registry.npmjs.org`; versiones exactas en los paquetes añadidos.

## 4. Lo que el código NO puede cerrar (riesgo residual)

Ordenado por qué tan probable es que te afecte:

1. **Extensiones del navegador.** La terminal corre en tu navegador: una extensión con permiso sobre `127.0.0.1` puede leer la pantalla y llamar a la API. → Usá un **perfil de navegador limpio, sin extensiones**, solo para GABNEAR.
2. **Malware en tu PC (mismo usuario de Windows).** Puede leer la memoria mientras la wallet está desbloqueada y descifrar el DPAPI. Ninguna app de usuario lo evita. → Wallet dedicada con poco saldo, **bloquearla** cuando no operás, no instalar software dudoso en esa PC, antivirus al día.
3. **Frase de 12 palabras.** Quien la tenga controla la cuenta. → En papel, nunca en capturas ni en el portapapeles; no importes la frase de tu wallet principal.
4. **Tokens estafa.** Honeypots, listas negras o impuestos ocultos no se detectan desde fuera; el análisis de pool (impacto, ida y vuelta, liquidez) solo ve el pool. → Importes chicos; `MAX_BUY_NEAR` bajo; no desactives el bloqueo de riesgo.
5. **El RPC.** Ve tu IP y tus consultas, y podría mentirte o demorarte. No puede firmar por vos. → RPC con clave de un proveedor serio; los swaps llevan mínimo de salida y se verifican por recibos.
6. **Sandwich / MEV.** Alguien puede mover el precio entre tu envío y la ejecución. → Slippage chico (el tope ahora es 10 %).
7. **`.env` y `data/` en texto o cifrado local.** Cualquier proceso de tu usuario puede leerlos. El token de Telegram, si lo configurás, queda en el `.env`: da acceso a **escribir** con tu bot, no a tus fondos. → Usá un bot propio, solo en chat privado.
8. **Portapapeles y clones.** Malware que cambia direcciones al pegar; versiones falsas de GABNEAR. → Verificá las primeras y últimas letras de cada contrato y descargá solo de tu fuente.
9. **Vigilancia de pool desatendida.** Compra sola. Está acotada (1 compra por vigilancia, vence, importe y slippage fijados, liquidez mínima, análisis de riesgo, topes de gasto), pero un token estafa con liquidez real pasa todos los filtros. → Importe mínimo; no la dejes días armada.

## 5. Qué NO se hizo

- No hubo auditoría de un tercero ni pruebas de intrusión sobre tu máquina real, ni fuzzing de los contratos de los exchanges.
- No se probó nada de esto contra mainnet con fondos: la política de firma se verificó con pruebas unitarias y con las pruebas existentes de los flujos de compra y venta (mocks), no firmando de verdad.
- Dependencias: se verificaron firmas y vulnerabilidades conocidas, no se revisó el código fuente de cada paquete.

## 6. Qué te recomiendo hacer ahora

1. Perfil de navegador limpio para GABNEAR.
2. Wallet **creada dentro del bot**, con 2 NEAR para la prueba.
3. Dejar los topes del `.env` bajos (`MAX_BUY_NEAR=1`, `MAX_DAILY_NEAR=3`) hasta que las 4 fases de `PRUEBA-REAL.md` salgan bien.
4. Bloquear la wallet (WALLET → BLOQUEAR FIRMA LOCAL) cuando termines.
5. Si querés avisos en el celular: bot de Telegram propio (instrucciones en `.env`).
