import {createHash} from 'node:crypto';
import {existsSync,mkdirSync,readFileSync,rmSync,statSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {listFiles,collectPersonal,scanFiles,stage} from './share-lib.js';

// npm run empaquetar → crea GABNEAR-AAAA-MM-DD.zip (por defecto en D:\proyectos\gabnear-share) listo para pasarle a un amigo, sin tus datos.
const root=resolve('.');
const shareDir=resolve(process.env.GABNEAR_SHARE_DIR||join(root,'..','gabnear-share'));
const files=listFiles(root);
for(const need of ['package.json','package-lock.json','.env.example','Iniciar-GABNEAR.bat','Iniciar-GABNEAR.ps1','server/index.ts','index.html'])if(!files.includes(need)){console.error(`Falta ${need} en el paquete: no se crea.`);process.exit(1);}
const personal=collectPersonal(root);
const leaks=scanFiles(root,files,personal);
if(leaks.length){console.error('NO se creó el paquete: hay datos que no deben compartirse.');for(const l of leaks)console.error(` · ${l.file}: ${l.reason}`);process.exit(1);}
const example=readFileSync(join(root,'.env.example'),'utf8');
if(/^[ \t]*(BOT_ACCOUNT_ID|TELEGRAM_BOT_TOKEN|TELEGRAM_CHAT_ID)[ \t]*=[ \t]*\S+/m.test(example)){console.error('.env.example trae una cuenta o un token cargado: borralo antes de compartir.');process.exit(1);}
mkdirSync(shareDir,{recursive:true});
const stamp=new Date().toISOString().slice(0,10),zip=join(shareDir,`GABNEAR-${stamp}.zip`),staging=join(shareDir,'.staging-'+process.pid);
rmSync(staging,{recursive:true,force:true});if(existsSync(zip))rmSync(zip);
try{
 stage(root,join(staging,'GABNEAR'),files);
 // Un zip estándar: cada entrada con «/» (CreateFromDirectory de .NET Framework usa «\» y algunos programas lo leen mal) y GABNEAR como carpeta raíz.
 const q=(s:string)=>s.replace(/'/g,"''");
 const script=[
  'Add-Type -AssemblyName System.IO.Compression,System.IO.Compression.FileSystem',
  `$base='${q(join(staging,'GABNEAR'))}'`,
  `$zip=[IO.Compression.ZipFile]::Open('${q(zip)}','Create')`,
  'try{ Get-ChildItem -LiteralPath $base -Recurse -File | ForEach-Object { $rel=$_.FullName.Substring($base.Length+1).Replace([char]92,[char]47); [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$_.FullName,"GABNEAR/$rel",[IO.Compression.CompressionLevel]::Optimal) | Out-Null } } finally { $zip.Dispose() }'
 ].join('; ');
 const ps=spawnSync('powershell.exe',['-NoProfile','-Command',script],{encoding:'utf8'});
 if(ps.status!==0){console.error('No se pudo crear el zip:',ps.stderr||ps.stdout);process.exit(1);}
}finally{rmSync(staging,{recursive:true,force:true});}
const sha=createHash('sha256').update(readFileSync(zip)).digest('hex');
console.log(`Paquete listo: ${zip}\n  ${files.length} archivos · ${(statSync(zip).size/1024).toFixed(0)} KB · sha256 ${sha.slice(0,16)}…\n  Revisado: sin claves, sin tokens, sin tus cuentas, sin data/ ni .env.`);
