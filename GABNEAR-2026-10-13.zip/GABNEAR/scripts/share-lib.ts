import {existsSync,mkdirSync,readdirSync,readFileSync,statSync,copyFileSync} from 'node:fs';
import {dirname,join,relative} from 'node:path';

// Paquete para compartir GABNEAR con amigos: solo el programa, NUNCA tus datos. Cada PC arma su propia terminal: el lanzador crea su .env desde
// .env.example y el programa crea su propia carpeta data/ (wallet cifrada con DPAPI de ESE usuario de Windows, historial, posiciones).
export const EXCLUDE_DIRS=new Set(['node_modules','dist','data','.cache','.git','.vscode','.idea','coverage','.vite','.near-credentials','__pycache__','venv','.venv']);
export function shouldExclude(rel:string):boolean{
 const parts=rel.replace(/\\/g,'/').split('/').filter(Boolean);if(!parts.length)return false;
 if(parts.some(p=>EXCLUDE_DIRS.has(p)))return true;
 const name=parts[parts.length-1].toLowerCase();
 if(name==='.env'||(name.startsWith('.env.')&&name!=='.env.example'))return true;
 if(/\.(log|secret|pem|key|p12|pfx|tsbuildinfo)$/.test(name))return true;
 if(/wallet.*\.json$|wallet.*\.dpapi|\.dpapi$/.test(name))return true;
 if(name==='.npmrc'||name==='.ds_store'||name==='thumbs.db')return true;
 if(/^nearly-.*\.(js|html)$/.test(name))return true;
 return false;
}
export function listFiles(root:string,dir=root):string[]{
 const out:string[]=[];
 for(const entry of readdirSync(dir,{withFileTypes:true})){
  const full=join(dir,entry.name),rel=relative(root,full).replace(/\\/g,'/');
  if(shouldExclude(rel))continue;
  if(entry.isDirectory())out.push(...listFiles(root,full));else if(entry.isFile())out.push(rel);
 }
 return out.sort();
}
const TEXT=/\.(ts|tsx|js|mjs|cjs|json|md|txt|ps1|bat|html|css|example|yml|yaml|gitignore|gitattributes|nvmrc)$/i;
export const isText=(rel:string)=>TEXT.test(rel)||!/\.[a-z0-9]+$/i.test(rel.split('/').pop()??'');
export type Leak={file:string;reason:string};
// Busca en un archivo de texto lo que jamás debe viajar: claves privadas, tokens, RPC con clave y datos personales de ESTA instalación.
export function scanText(text:string,rel:string,personal:string[]=[]):Leak[]{
 const out:Leak[]=[];
 const generic=!rel.startsWith('tests/');   // las pruebas llevan claves y tokens de mentira; los datos personales sí se buscan en todos lados
 if(generic&&/ed25519:[1-9A-HJ-NP-Za-km-z]{60,}/.test(text))out.push({file:rel,reason:'parece una clave privada ed25519'});
 if(generic&&/\b\d{6,12}:[A-Za-z0-9_-]{30,}\b/.test(text))out.push({file:rel,reason:'parece un token de bot de Telegram'});
 if(generic&&/https?:\/\/[^\s"']*(?:api[-_]?key|apikey|token|key)=[^\s&"']{8,}/i.test(text))out.push({file:rel,reason:'URL con una clave de API'});
 const lower=text.toLowerCase();
 for(const p of personal)if(p.length>=5&&lower.includes(p.toLowerCase()))out.push({file:rel,reason:`contiene un dato personal de esta instalación («${p}»)`});
 return out;
}
// Cuentas y datos de ESTA instalación que no pueden aparecer en el paquete.
export function collectPersonal(root:string):string[]{
 const set=new Set<string>(),add=(v:unknown)=>{const s=String(v??'').trim();if(s.length>=5&&s!=='wrap.near')set.add(s);};
 const read=(p:string)=>{try{return existsSync(p)?readFileSync(p,'utf8').replace(/^﻿/,''):'';}catch{return '';}};
 add(read(join(root,'data','selected-account.txt')));add(read(join(root,'data','account.txt')));
 for(const line of read(join(root,'.env')).split(/\r?\n/)){const m=/^\s*(BOT_ACCOUNT_ID|BENCHMARK_ACCOUNT_ID|TELEGRAM_CHAT_ID|TELEGRAM_BOT_TOKEN)\s*=\s*(.+?)\s*$/.exec(line);if(m)add(m[2]);}
 for(const f of ['history.json','positions.json']){try{const j=JSON.parse(read(join(root,'data',f))||'[]');if(Array.isArray(j))for(const r of j)add(r?.signer??r?.accountId);}catch{/* ilegible */}}
 return [...set];
}
export function scanFiles(root:string,files:string[],personal:string[]):Leak[]{
 const out:Leak[]=[];
 for(const rel of files){if(!isText(rel))continue;try{if(statSync(join(root,rel)).size>2_000_000)continue;out.push(...scanText(readFileSync(join(root,rel),'utf8'),rel,personal));}catch{/* ilegible */}}
 return out;
}
export function stage(root:string,dest:string,files=listFiles(root)){
 for(const rel of files){const to=join(dest,rel);mkdirSync(dirname(to),{recursive:true});copyFileSync(join(root,rel),to);}
 return files.length;
}
