import {performance} from 'node:perf_hooks';
import {NearRpc} from './rpc.js';
import {discover,WNEAR} from './pools.js';
import {extractToken,checkRisk,display,units} from './validation.js';
import {planBridge} from './bridge.js';
import {afterTax,taxRate} from './quotes.js';
import {quoteAmount,ftRaw,insufficientQuote} from './quote-asset.js';
import {quoteRoute,rankRoutes,bestRoute,assessRisk,roundTripLoss,swapCall,cachedRoundTrip,cacheRoundTrip,type Route,type Ranked,type Risk} from './venues.js';
const summarize=(r:Ranked,decimals:number,amount:bigint)=>({venue:r.route.venue,poolId:r.route.poolId,fee:r.route.fee,expected:r.quote?display(r.quote.raw,decimals):null,impactBps:r.quote&&r.probe?assessRisk(r,amount).impactBps:null,error:r.error??null});
export async function analyze(rpc:NearRpc,input:{url:string;amount:string;slippageBps:number},config:{accountId:string;maxNear:string;maxBps:number},options:{freshQuoteAtSwap?:boolean;skipQuoteBalance?:boolean}={}){
 const timings:Record<string,number>={}; const start=performance.now();
 const token=extractToken(input.url);checkRisk('0.000000000000000000000001',input.slippageBps,config.maxNear,config.maxBps);
 const d=await discover(rpc,token);timings.discoveryMs=Math.round(performance.now()-start);
 const asset=d.quoteAsset,amount=quoteAmount(input.amount,asset,input.slippageBps,config.maxNear,config.maxBps);
 const warnings:string[]=[];
 let quotation:any=null,storage:any=null,quoteStorage:any=null,quoteBalance:bigint|null=null,route:Route=d.route,risk=null as Risk|null,candidates:any[]=[];
 const t=performance.now();
 // Launch de Nearly: un único pool oficial. Token genérico: se cotizan TODOS los pools directos y gana la mayor salida.
 const routing=async()=>{
  if(!d.generic&&d.routes.length===1){
   if(options.freshQuoteAtSwap)return;
   try{quotation=await quoteRoute(rpc,route,asset.id,token,amount,input.slippageBps);}catch(e){throw new Error(`Quote ${asset.id} no ejecutable en DCL: ${(e as Error).message}`);}
   return;
  }
  const ranked=await rankRoutes(rpc,d.routes,asset.id,token,amount,input.slippageBps);
  candidates=ranked.map(r=>summarize(r,d.metadata.decimals,amount));
  const best=bestRoute(ranked);
  if(!best)throw new Error(`Ningún pool directo puede cotizar este importe: ${ranked.map(r=>`${r.route.venue} ${r.route.poolId}: ${r.error}`).join(' · ')}`);
  route=best.route;quotation=best.quote;
  risk=assessRisk(best,amount,cachedRoundTrip(token,route.poolId));
 };
 await Promise.all([routing(),config.accountId?Promise.all([rpc.view(token,'storage_balance_of',{account_id:config.accountId}),rpc.view(asset.id,'storage_balance_of',{account_id:config.accountId}),rpc.view(asset.id,'ft_balance_of',{account_id:config.accountId})]).then(([a,b,c])=>{storage=a;quoteStorage=b;quoteBalance=ftRaw(c);}):Promise.resolve()]);
 if(asset.id!==WNEAR&&quoteBalance!==null&&quoteBalance<amount&&!options.skipQuoteBalance)throw insufficientQuote(asset,quoteBalance,amount);
 // Before paying for preparation, preserve the liquidity check. Only an already
 // registered and funded route defers its sole quotation to the final swap.
 if(options.freshQuoteAtSwap&&!quotation&&(!config.accountId||!storage||!quoteStorage||(asset.id===WNEAR&&(quoteBalance===null||quoteBalance<amount)))){
  try{quotation=await quoteRoute(rpc,route,asset.id,token,amount,input.slippageBps);}catch(e){throw new Error(`Quote ${asset.id} no ejecutable en DCL: ${(e as Error).message}`);}
 }
 timings.quoteAndStorageMs=Math.round(performance.now()-t);
 if(!config.accountId)warnings.push('Sin cuenta secundaria: no se puede comprobar almacenamiento ni balances personales.');
 const buyBps=Number(d.tax?.buy_bps??0);if(!Number.isInteger(buyBps)||buyBps<0||buyBps>400)throw new Error('Tasa de compra desconocida o fuera de rango.');
 if(d.tax)warnings.push(`Impuesto de compra ${buyBps/100}%; venta ${Number(d.tax.sell_bps??0)/100}%. El mínimo DCL se aplica antes del impuesto de compra.`);
 if(d.generic)warnings.push(`Token fuera de Nearly: se opera en ${route.venue==='DCL'?'Rhea DCL':'Ref v1'} (pool ${route.poolId}, fee ${(route.fee/100).toFixed(2)}%). No se conocen impuestos ni restricciones del contrato; empezá con un importe chico.`);
 if(risk)warnings.push(...risk.warnings);
 if(Number(d.rules?.max_wallet_bps??0)>0)warnings.push('Límite de tenencia detectado: ejecución bloqueada hasta validar las reglas de este token.');
 if(input.slippageBps>300)warnings.push('Slippage elevado: puede reducir considerablemente la salida.');
 const steps:any[]=[];
 if(config.accountId&&!storage)steps.push({contract:token,method:'storage_deposit',args:{account_id:config.accountId,registration_only:true},deposit:'Consultar storage_balance_bounds.min'});
 if(config.accountId&&!quoteStorage)steps.push({contract:asset.id,method:'storage_deposit',deposit:'Consultar storage_balance_bounds.min'});
 if(asset.id===WNEAR)steps.push({contract:WNEAR,method:'near_deposit',deposit:input.amount+' NEAR (solo déficit de wNEAR)'});
 if(quotation){const call=swapCall(route,asset.id,token,amount,quotation.minRaw);steps.push({contract:asset.id,method:'ft_transfer_call',args:{receiver_id:call.receiver,amount:amount.toString(),msg:call.msg},deposit:'1 yoctoNEAR',gas:`${call.gas} TGas`});}
 else steps.push({contract:asset.id,method:'ft_transfer_call',deposit:'1 yoctoNEAR',gas:'180 TGas',note:'Cotización y mínimo frescos calculados al ejecutar swap; no hay una transacción preparada con un mínimo supuesto.'});
 timings.totalMs=Math.round(performance.now()-start);
 const record={...d.record,pool_id:route.poolId};
 return {token,...d,record,route,candidates,risk,amountRaw:amount.toString(),quoteBalance:quoteBalance===null?null:display(quoteBalance,asset.decimals),quoteBalanceRaw:quoteBalance===null?null:String(quoteBalance),accountId:config.accountId,checkedAt:new Date().toISOString(),quotation:quotation?{...quotation,expectedTokens:display(BigInt(quotation.raw)*BigInt(10000-buyBps)/10000n,d.metadata.decimals),minTokens:display(BigInt(quotation.minRaw)*BigInt(10000-buyBps)/10000n,d.metadata.decimals)}:null,storageRegistered:config.accountId?!!storage:null,quoteRegistered:config.accountId?!!quoteStorage:null,wnearRegistered:asset.id===WNEAR&&config.accountId?!!quoteStorage:null,warnings,steps,timings,mode:'DRY RUN',status:'ANALYZED',fundsSent:false};
}
// Vista previa al pegar el contrato (solo lectura): rutas candidatas, impacto y simulación de ida y vuelta.
// Los resultados de round-trip se cachean 2 min y la compra REAL los consulta sin esperar otra lectura.
// `ready`: ¿la compra sería UN solo swap? (token y quote registrados + saldo del quote suficiente). Solo con cuenta conectada.
async function readiness(rpc:NearRpc,account:string,token:string,quoteId:string,decimals:number,amount:bigint|null){
 if(!account)return null;
 const [a,b,c]=await Promise.all([rpc.view(token,'storage_balance_of',{account_id:account}),rpc.view(quoteId,'storage_balance_of',{account_id:account}),rpc.view(quoteId,'ft_balance_of',{account_id:account})]);
 const balance=ftRaw(c);
 return {tokenRegistered:!!a,quoteRegistered:!!b,quoteBalance:display(balance,decimals),enough:amount===null?null:balance>=amount,armed:amount===null?null:!!a&&!!b&&balance>=amount};
}
export async function preview(rpc:NearRpc,url:string,amountText?:string,slippageBps=300,account='',payWith?:string){
 const token=extractToken(url),d=await discover(rpc,token);
 const base={token,direct:d.direct,generic:d.generic,quoteAsset:d.quoteAsset,metadata:d.metadata,routes:d.routes.map(r=>({venue:r.venue,poolId:r.poolId,fee:r.fee})),fundsSent:false as const};
 if(!amountText)return {...base,candidates:[],risk:null,ready:await readiness(rpc,account,token,d.quoteAsset.id,d.quoteAsset.decimals,null).catch(()=>null)};
 // Pagar con NEAR un token que cotiza en otro token: el importe de la caja son NEAR; se estima cuánto quote entra y se previsualiza la compra con eso.
 let bridge:any=null;
 if(payWith==='NEAR'&&d.quoteAsset.id!==WNEAR){
  try{
   const plan=await planBridge(rpc,d.quoteAsset,units(amountText),slippageBps);
   bridge={nearAmount:amountText,quoteSymbol:d.quoteAsset.symbol,expectedQuote:display(plan.expectedRaw,d.quoteAsset.decimals),minQuote:display(plan.minRaw,d.quoteAsset.decimals),venue:plan.venue,poolId:plan.poolId,feeBps:plan.feeBps,impactBps:plan.risk.impactBps,blocked:plan.risk.blocked??null,warnings:plan.risk.warnings};
   amountText=bridge.expectedQuote;
  }catch(e){return {...base,candidates:[],risk:null,ready:null,bridge:{error:(e as Error).message,quoteSymbol:d.quoteAsset.symbol}};}
 }
 const amount=quoteAmount(amountText as string,d.quoteAsset,slippageBps,'',Number(process.env.MAX_SLIPPAGE_BPS||9900));
 const [ranked,ready]=await Promise.all([rankRoutes(rpc,d.routes,d.quoteAsset.id,token,amount,slippageBps),readiness(rpc,account,token,d.quoteAsset.id,d.quoteAsset.decimals,amount).catch(()=>null)]);
 const best=bestRoute(ranked);
 if(!best)return {...base,candidates:ranked.map(r=>summarize(r,d.metadata.decimals,amount)),risk:null,ready};
 const loss=d.generic?await roundTripLoss(rpc,best.route,d.quoteAsset.id,token,amount,best.quote!):null;
 if(loss!==null)cacheRoundTrip(token,best.route.poolId,loss);
 const buyTax=taxRate(d.tax,'buy');
 return {...base,candidates:ranked.map(r=>summarize(r,d.metadata.decimals,amount)),route:best.route,risk:assessRisk(best,amount,loss),ready,bridge,estimate:{spend:display(amount,d.quoteAsset.decimals),expectedTokens:display(afterTax(BigInt(best.quote!.raw),buyTax),d.metadata.decimals),minTokens:display(afterTax(BigInt(best.quote!.minRaw),buyTax),d.metadata.decimals)}};
}
