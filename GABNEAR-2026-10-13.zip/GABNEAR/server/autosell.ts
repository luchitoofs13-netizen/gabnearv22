// OBSOLETO: lógica heredada que nunca se conectó a la aplicación. El AUTO SELL real es positions.ts (decisión y P/L)
// + exit-monitor.ts (monitor). Se conserva solo porque sus pruebas originales siguen vigentes.
import {executableExit,sell,requireLive} from './trading.js';
import {Executor} from './transactions.js';
import {quoteAsset,WRAPPED_NEAR,ftRaw} from './quote-asset.js';
export interface ExitSettings {takeProfitBps:number;stopLossBps:number;slippageBps:number;estimatedGasYocto:string;estimatedGasQuoteRaw?:string;gasQuoteAsset?:string;}
export function exitDecision(cost:bigint,recoverable:bigint,settings:ExitSettings){
 if(cost<=0n||settings.takeProfitBps<=0||settings.stopLossBps<=0||settings.stopLossBps>=10000)throw new Error('Configuración de salida inválida.');
 const net=recoverable-BigInt(settings.estimatedGasYocto);const pnlBps=(net-cost)*10000n/cost;
 return {pnlBps:Number(pnlBps),netRaw:net.toString(),trigger:pnlBps>=BigInt(settings.takeProfitBps)?'TAKE_PROFIT':pnlBps<=-BigInt(settings.stopLossBps)?'STOP_LOSS':null};
}
// No se inicia con fondos reales bloqueados. Una cotización fallida nunca dispara una venta.
export class AutoSell {
 private busy=false;
 constructor(private ex:Executor,private stopped:()=>boolean){}
 async tick(position:any,settings:ExitSettings){
 requireLive();if(this.busy||this.stopped()||position.status!=='FILLED'||position.sold)return;
 this.busy=true;try{
 const asset=quoteAsset(position);
 // NEAR gas and FT proceeds must never be subtracted in different units.
 if(asset.id!==WRAPPED_NEAR&&(settings.gasQuoteAsset!==asset.id||settings.estimatedGasQuoteRaw===undefined))throw new Error(`Auto-sell requiere costo de gas expresado en ${asset.id}; no se mezclan unidades NEAR/FT.`);
 const gas=asset.id===WRAPPED_NEAR?settings.estimatedGasYocto:ftRaw(settings.estimatedGasQuoteRaw).toString();
 const q=await executableExit(this.ex.rpc,position,BigInt(position.receivedRaw),settings.slippageBps);
 const d=exitDecision(BigInt(position.costRaw),BigInt(q.minRaw),{...settings,estimatedGasYocto:gas});
 this.ex.history.update(position.id,{exitQuote:q,estimatedPnlBps:d.pnlBps});
 if(d.trigger){const result=await sell(this.ex,position.id,position,BigInt(position.receivedRaw),settings.slippageBps);if(result.state==='FILLED')this.ex.history.update(position.id,{sold:true,exitTrigger:d.trigger});}
 }finally{this.busy=false;}
 }
}
