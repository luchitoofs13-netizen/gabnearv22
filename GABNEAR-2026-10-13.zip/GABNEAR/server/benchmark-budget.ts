import {existsSync,readFileSync,writeFileSync,renameSync,mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
import {units,display} from './validation.js';
const LIMIT=units('0.5');
type Attempt={id:string;reservation:string;actual?:string;state:'RESERVED'|'SETTLED';hashes:string[]};
// Exclusivo para la campaña autorizada. No modifica límites de trading del usuario.
// La reserva incluye el principal UNA vez (wrap o wNEAR gastado), gas y storage.
export class BenchmarkBudget {
 readonly attempts:Attempt[];
 constructor(readonly path:string,readonly account:string,readonly purchase=units('0.1')){
  if(!account||account.endsWith('.testnet'))throw new Error('Cuenta secundaria mainnet requerida.');
  if(purchase<=0n||purchase>units('0.1'))throw new Error('Importe de prueba inválido.');
  const stored=existsSync(path)?JSON.parse(readFileSync(path,'utf8')):null;
  if(stored&&(stored.account!==account||stored.cap!=='0.5'||units(stored.purchase)<purchase||(units(stored.purchase)!==purchase&&stored.attempts.some((a:any)=>a.state==='RESERVED'))))throw new Error('La campaña no puede cambiar de cuenta, aumentar importe/presupuesto ni modificar un intento pendiente.');
  this.attempts=stored?.attempts??[];
 }
 get committed(){return this.attempts.reduce((sum,a)=>sum+BigInt(a.actual??a.reservation),0n);}
 reserve(id:string,amount:bigint,maximumExtra:bigint){
  if(amount!==this.purchase||maximumExtra<0n)throw new Error(`Cada intento debe ser exactamente ${display(this.purchase)} NEAR y tener costos acotados.`);
  if(this.attempts.some(a=>a.id===id))throw new Error('El intento ya fue contabilizado.');
  if(this.attempts.some(a=>a.state==='RESERVED'))throw new Error('Hay un intento pendiente; no se reintenta.');
  if(this.attempts.length>=5||this.committed+amount+maximumExtra>LIMIT)throw new Error('Presupuesto total o máximo de intentos agotado.');
  this.attempts.push({id,reservation:(amount+maximumExtra).toString(),state:'RESERVED',hashes:[]});this.flush();
 }
 recordHash(id:string,hash:string){const a=this.find(id);if(a.hashes.includes(hash))return;a.hashes.push(hash);this.flush();}
 settle(id:string,actual:bigint){const a=this.find(id);if(a.state!=='RESERVED'||actual<0n||actual>BigInt(a.reservation))throw new Error('Costo no verificable dentro de la reserva: detener campaña.');a.actual=actual.toString();a.state='SETTLED';this.flush();}
 private find(id:string){const a=this.attempts.find(a=>a.id===id);if(!a)throw new Error('Intento desconocido.');return a;}
 private flush(){mkdirSync(dirname(this.path),{recursive:true});writeFileSync(this.path+'.tmp',JSON.stringify({account:this.account,cap:'0.5',purchase:display(this.purchase),attempts:this.attempts},null,2));renameSync(this.path+'.tmp',this.path);}
}
