export function percentile(values:number[],percent:number){if(!values.length)return null;const sorted=[...values].sort((a,b)=>a-b);return sorted[Math.max(0,Math.ceil(percent/100*sorted.length)-1)];}
export function stats(values:number[]){return {samples:values.length,p50:percentile(values,50),p90:percentile(values,90),p95:percentile(values,95)};}
export function reduction(baseline:number,current:number){if(baseline<=0)throw new Error('Referencia inválida.');return (baseline-current)/baseline*100;}
