import {NearRpc} from './rpc.js';
import {discover,WNEAR} from './pools.js';
import {rankRoutes,bestRoute,assessRisk,cachedRoundTrip,type Route,type Risk} from './venues.js';
import type {QuoteAsset} from './quote-asset.js';

// PUENTE NEAR → quote: algunos launches (p. ej. KINU de Nearly) cotizan contra otro token (RHEA) y no contra wNEAR. Para comprarlos pagando con NEAR,
// el bot primero cambia NEAR → ese token en su propio pool contra wNEAR (igual que ya envuelve NEAR en wNEAR cuando falta) y después compra el token.
export type BridgePlan={asset:QuoteAsset;route:Route;inRaw:bigint;expectedRaw:bigint;minRaw:bigint;risk:Risk;venue:string;poolId:string;feeBps:number};

// Solo lectura: cotiza cuánto del quote se obtiene con `nearRaw` yoctoNEAR y qué tan riesgoso es ese pool.
export async function planBridge(rpc:NearRpc,asset:QuoteAsset,nearRaw:bigint,slippageBps:number):Promise<BridgePlan>{
 if(asset.id===WNEAR)throw new Error('El quote ya es wNEAR: no hace falta puente.');
 let q;try{q=await discover(rpc,asset.id);}catch(e){throw new Error(`No se puede comprar ${asset.symbol} con NEAR: ${(e as Error).message}`);}
 const ranked=await rankRoutes(rpc,q.routes,WNEAR,asset.id,nearRaw,slippageBps);
 const best=bestRoute(ranked);
 if(!best)throw new Error(`Ningún pool contra wNEAR puede cotizar ${asset.symbol} con ese importe: ${ranked.map(r=>`${r.route.venue} ${r.route.poolId}: ${r.error}`).join(' · ')}`);
 return {asset,route:best.route,inRaw:nearRaw,expectedRaw:BigInt(best.quote!.raw),minRaw:BigInt(best.quote!.minRaw),risk:assessRisk(best,nearRaw,cachedRoundTrip(asset.id,best.route.poolId)),venue:best.route.venue,poolId:best.route.poolId,feeBps:best.route.fee};
}
export const bridgeRecord=(p:BridgePlan)=>({quoteId:p.asset.id,quoteSymbol:p.asset.symbol,quoteDecimals:p.asset.decimals,inRaw:p.inRaw.toString(),expectedRaw:p.expectedRaw.toString(),minRaw:p.minRaw.toString(),venue:p.venue,poolId:p.poolId,feeBps:p.feeBps,impactBps:p.risk.impactBps,status:'PLANNED' as 'PLANNED'|'SWAPPING'|'DONE',receivedRaw:null as string|null});
