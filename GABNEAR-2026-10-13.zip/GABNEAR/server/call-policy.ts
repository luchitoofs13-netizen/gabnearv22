import {DCL,REF_V1,WRAPPED_NEAR} from './constants.js';
import {units} from './validation.js';

// Última barrera antes de firmar: GABNEAR solo firma las tres llamadas que necesita, con la forma exacta que espera. Si un error de
// programación, una dependencia manipulada o una petición local hostil intentara firmar otra cosa (transferir NEAR, mover tokens a
// una cuenta ajena, llamar a otro contrato), la firma se rechaza aquí, antes de que exista una transacción.
//   near_deposit      wrap.near, sin argumentos (envolver NEAR)
//   storage_deposit   registrar a LA PROPIA cuenta (≤ 0.05 NEAR)
//   ft_transfer_call  1 yocto, solo hacia Rhea DCL o Ref v1 (el swap)
const MAX_STORAGE_DEPOSIT=units('0.05');
const VENUES=[DCL,REF_V1];
const only=(args:Record<string,unknown>,keys:string[])=>Object.keys(args).every(k=>keys.includes(k));

export function assertAllowedCall(signer:string,contract:string,method:string,args:unknown,deposit:bigint){
 const fail=(why:string):never=>{throw new Error(`Llamada bloqueada por la política de firma: ${why}.`);};
 if(!args||typeof args!=='object'||Array.isArray(args))return fail('argumentos inválidos');
 const a=args as Record<string,unknown>;
 if(typeof contract!=='string'||!/^[a-z0-9._-]{2,64}$/.test(contract))return fail('contrato inválido');
 switch(method){
  case 'near_deposit':
   if(contract!==WRAPPED_NEAR||Object.keys(a).length>0)return fail('near_deposit solo se permite en wrap.near y sin argumentos');
   if(deposit<=0n)return fail('el depósito a envolver debe ser positivo');
   return;
  case 'storage_deposit':
   if(a.account_id!==signer||a.registration_only!==true||!only(a,['account_id','registration_only']))return fail('storage_deposit solo puede registrar tu propia cuenta');
   if(deposit<0n||deposit>MAX_STORAGE_DEPOSIT)return fail('depósito de almacenamiento excesivo');
   return;
  case 'ft_transfer_call':
   if(deposit!==1n)return fail('ft_transfer_call exige exactamente 1 yoctoNEAR');
   if(typeof a.receiver_id!=='string'||!VENUES.includes(a.receiver_id))return fail('el receptor del swap debe ser Rhea DCL o Ref v1');
   if(typeof a.amount!=='string'||!/^[1-9]\d*$/.test(a.amount))return fail('importe inválido');
   if(typeof a.msg!=='string'||a.msg.length>4000||!only(a,['receiver_id','amount','msg']))return fail('mensaje o campos inesperados');
   return;
  default:
   return fail(`el método «${method}» no está permitido`);
 }
}
