// Contratos mainnet verificados en https://guide.rhea.finance/developers/contracts (Ref v1 = exchange AMM, DCL v2 = liquidez concentrada).
export const FACTORY='nearlytrade.near';
export const DCL='dclv2.ref-labs.near';
export const REF_V1='v2.ref-finance.near';
export const WRAPPED_NEAR='wrap.near';
// Niveles de fee de pools DCL (ref-sdk DCL_POOL_FEE_LIST). El id del pool es `tokenA|tokenB|fee` con los tokens ordenados.
export const DCL_FEES=[100,400,2000,10000];
