import {randomUUID} from 'node:crypto';
import {NearRpc} from './rpc.js';
import {History} from './history.js';
import {FACTORY} from './constants.js';
import {afterTax} from './quotes.js';
import {quoteRoute} from './venues.js';
import {PositionStore,evaluateExit,gasEstimate,isNearQuote,type Position,type Trigger} from './positions.js';

export type MonitorDeps={rpc:NearRpc;history:History;store:PositionStore;submit:(raw:unknown)=>unknown;busy:()=>boolean;live:()=>boolean;stopped:()=>boolean;account:()=>string;intervalMs?:number};
const FAILED=['FAILED','REFUNDED','INTERRUPTED','CANCELLED'];
const TAX_REFRESH_MS=60000,SAVE_EVERY_MS=10000,MAX_ATTEMPTS=3;

// AUTO SELL real: valúa cada posición abierta con la cotización EJECUTABLE de salida (no con un precio de referencia),
// exige varias lecturas consecutivas antes de actuar y vende solo con REAL activo, sin parada y sin otra orden en curso.
// Una cotización fallida jamás dispara una venta. Cada orden usa un requestId persistido ANTES de enviarse.
export class ExitMonitor {
 private timer:ReturnType<typeof setInterval>|null=null;
 private running=false;
 private skipUntil=0;
 private lastSave=0;
 private exitAll=false;
 private taxAt=new Map<string,number>();
 constructor(readonly d:MonitorDeps){}
 // SALIR DE TODO: vende el 100% de cada posición abierta, de a una, ignorando take profit / stop loss y sus confirmaciones.
 // Cada venta usa la cotización ejecutable, el slippage de la posición y el mismo camino idempotente de siempre. Se apaga sola al quedar
 // sin posiciones, o si REAL se desactiva / hay parada de emergencia (nunca queda armada para disparar más tarde sin que lo veas).
 get exitingAll(){return this.exitAll;}
 requestExitAll(on:boolean){this.exitAll=on;this.skipUntil=0;}
 start(){if(this.timer)return;this.timer=setInterval(()=>{void this.tick().catch(()=>{});},this.d.intervalMs??3000);this.timer.unref();}
 stop(){if(this.timer)clearInterval(this.timer);this.timer=null;}
 async tick(){
  if(this.running||Date.now()<this.skipUntil)return;
  const account=this.d.account();if(!account)return;
  this.running=true;
  try{
   let dirty=false;
   if(this.exitAll&&(!this.d.live()||this.d.stopped()))this.exitAll=false;
   for(const p of this.d.store.positions.filter(x=>x.status==='OPEN'&&x.signer===account)){
    try{if(await this.check(p))dirty=true;}
    catch(error){
     const message=error instanceof Error?error.message:String(error);
     if(p.state.lastError!==message){p.state.lastError=message;dirty=true;}
     // Límite de cuota del RPC u otro fallo transitorio: se espera antes de volver a consultar.
     if(/429|rate|timeout|excedió|fetch/i.test(message))this.skipUntil=Date.now()+10000;
    }
   }
   if(this.exitAll&&!this.d.store.positions.some(x=>x.status==='OPEN'&&x.signer===account))this.exitAll=false;
   if(dirty||Date.now()-this.lastSave>SAVE_EVERY_MS){if(dirty||this.lastSave>0)this.d.store.save();this.lastSave=Date.now();}
  }finally{this.running=false;}
 }
 private resolvePending(p:Position):'WAIT'|'DONE'{
  const pend=p.state.pending!,row=this.d.history.rows.find(r=>r.requestId===pend.requestId);
  if(!row){
   // Se persistió la intención pero la orden nunca llegó al historial (reinicio entre ambas): no se reenvía sola.
   if(Date.now()-Date.parse(pend.at)>20000){p.state.pending=null;this.d.store.event(p,'PENDING_LOST','La orden de salida no llegó a registrarse; se reevalúa.');this.d.store.save();return 'DONE';}
   return 'WAIT';
  }
  if(['FILLED','PARTIAL'].includes(row.status)){
   this.d.store.ingest(row);
   p.state.pending=null;p.state.attempts=0;p.state.retryAt=null;p.state.streak=null;
   if(pend.trigger==='TAKE_PROFIT')p.state.tpDone=true;
   this.d.store.event(p,'SOLD',`${pend.trigger} · ${row.status==='PARTIAL'?'llenado parcial':'completada'} · recibido ${row.receivedRaw}`);
   this.d.store.save();return 'DONE';
  }
  if(FAILED.includes(row.status)){
   p.state.pending=null;p.state.attempts+=1;p.state.streak=null;
   p.state.retryAt=new Date(Date.now()+Math.min(60000,5000*2**p.state.attempts)).toISOString();
   this.d.store.event(p,'SELL_FAILED',`${pend.trigger}: ${row.error??row.status}`);
   if(p.state.attempts>=MAX_ATTEMPTS){p.settings.enabled=false;p.state.pausedReason=`${MAX_ATTEMPTS} ventas automáticas fallidas seguidas: AUTO SELL pausado. Revisá el historial y reactivalo.`;this.d.store.event(p,'PAUSED',p.state.pausedReason);}
   this.d.store.save();return 'DONE';
  }
  return 'WAIT';
 }
 private async refreshTax(p:Position){
  if(p.launchId===null||Date.now()-(this.taxAt.get(p.id)??0)<TAX_REFRESH_MS)return;
  this.taxAt.set(p.id,Date.now());
  const tax=await this.d.rpc.view<any>(FACTORY,'get_tax',{launch_id:p.launchId});
  const bps=Number(tax?.sell_bps??0);
  if(Number.isInteger(bps)&&bps>=0&&bps<=400)p.sellBps=bps;
 }
 // Devuelve true si cambió algo que conviene persistir.
 private async check(p:Position):Promise<boolean>{
  if(p.state.pending&&this.resolvePending(p)==='WAIT')return false;
  const rpc=this.d.rpc;
  const balance=BigInt(await rpc.view(p.token,'ft_balance_of',{account_id:p.signer}));
  if(balance<=0n){this.d.store.close(p,'Sin saldo del token en la wallet.');return true;}
  await this.refreshTax(p);
  const ledger=BigInt(p.tokensRaw),sellable=balance<ledger?balance:ledger;
  if(sellable<=0n){this.d.store.close(p,'Posición sin tokens en el registro.');return true;}
  const q=await quoteRoute(rpc,p.route,p.token,p.quote.id,afterTax(sellable,p.sellBps),p.settings.slippageBps);
  const exit=BigInt(q.raw);
  // Costo del remanente vendible (si se movieron tokens por fuera, se prorratea).
  const scaled:Position={...p,investedRaw:(BigInt(p.investedRaw)*sellable/ledger).toString()};
  if(isNearQuote(p)&&exit<=gasEstimate(p)*2n){this.d.store.close(p,'Valor remanente menor al doble del gas de venta (polvo).');return true;}
  const ev=evaluateExit(scaled,exit);
  p.state.peakNetRaw=ev.peakRaw.toString();p.state.lastExitRaw=exit.toString();p.state.lastNetRaw=ev.netRaw.toString();p.state.lastPnlBps=ev.pnlBps;p.state.lastCheckAt=new Date().toISOString();p.state.lastError=null;
  if(this.exitAll){
   if(p.state.retryAt&&Date.parse(p.state.retryAt)>Date.now())return false;
   return this.fire(p,'MANUAL_EXIT',p.settings.confirmTicks);
  }
  if(!ev.trigger){p.state.streak=null;return false;}
  const count=p.state.streak?.trigger===ev.trigger?p.state.streak.count+1:1;
  p.state.streak={trigger:ev.trigger,count};
  if(count<p.settings.confirmTicks||!p.settings.enabled)return false;
  if(p.state.retryAt&&Date.parse(p.state.retryAt)>Date.now())return false;
  return this.fire(p,ev.trigger,count);
 }
 private fire(p:Position,trigger:Trigger,count:number):boolean{
  const percentage=trigger==='TAKE_PROFIT'?p.settings.tpSellPct:100;
  if(!this.d.live()||this.d.stopped()){
    // Sin REAL o con parada de emergencia solo se informa, una vez por racha.
    if(count===p.settings.confirmTicks){this.d.store.event(p,'WOULD_SELL',`${trigger} (${percentage}%) alcanzado; no se vende: ${this.d.stopped()?'parada de emergencia':'REAL desactivado'}.`);return true;}
    return false;
  }
  if(this.d.busy())return false;
  const requestId=randomUUID();
  p.state.pending={requestId,trigger,percentage,at:new Date().toISOString()};
  this.d.store.event(p,'TRIGGER',`${trigger}: vendiendo ${percentage}% (P/L ${((p.state.lastPnlBps??0)/100).toFixed(1)}%).`);
  this.d.store.save();
  try{this.d.submit({requestId,side:'SELL',mode:'REAL',url:p.token,percentage,slippageBps:p.settings.slippageBps});}
  catch(error){
   // No se envió nada (otra operación en curso, REAL revocado, etc.): se reintenta en el próximo ciclo.
   p.state.pending=null;p.state.retryAt=new Date(Date.now()+15000).toISOString();
   this.d.store.event(p,'SUBMIT_REJECTED',error instanceof Error?error.message:String(error));
  }
  this.d.store.save();return true;
 }
}
