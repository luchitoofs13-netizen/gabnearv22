const sleep=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms));
// Cliente JSON para APIs públicas de terceros: caché con TTL, deduplicación de consultas simultáneas, ritmo mínimo entre
// pedidos (las APIs gratuitas limitan por minuto) y plazo máximo. Solo viaja información pública (cuentas de tokens).
export class Fetcher {
 private last=0;
 private cache=new Map<string,{at:number;ttl:number;value:Promise<any>}>();
 constructor(readonly name:string,readonly minIntervalMs=0,readonly timeoutMs=8000,readonly fetchImpl:typeof fetch=(...a)=>fetch(...a)){}
 private async slot(){const wait=Math.max(0,this.last+this.minIntervalMs-Date.now());this.last=Date.now()+wait;if(wait)await sleep(wait);}
 private cached<T>(key:string,url:string,options:{ttl?:number;timeout?:number},accept:string,parse:(r:Response)=>Promise<T>):Promise<T>{
  const ttl=options.ttl??5000,hit=this.cache.get(key);
  if(hit&&Date.now()-hit.at<hit.ttl)return hit.value;
  if(this.cache.size>200)this.cache.clear();
  const value=(async()=>{
   await this.slot();
   const response=await this.fetchImpl(url,{headers:{accept},signal:AbortSignal.timeout(options.timeout??this.timeoutMs)});
   if(!response.ok)throw new Error(`${this.name}: HTTP ${response.status}`);
   return await parse(response);
  })();
  this.cache.set(key,{at:Date.now(),ttl,value});
  // Un fallo nunca queda cacheado: el próximo pedido vuelve a intentar.
  void value.catch(()=>{if(this.cache.get(key)?.value===value)this.cache.delete(key);});
  return value;
 }
 json<T=any>(url:string,options:{ttl?:number;timeout?:number}={}):Promise<T>{return this.cached('J:'+url,url,options,'application/json',async r=>await r.json() as T);}
 // Texto (HTML de páginas públicas). Tope de 1,5 MB: una respuesta enorme no puede agotar la memoria.
 text(url:string,options:{ttl?:number;timeout?:number}={}):Promise<string>{return this.cached('T:'+url,url,options,'text/html',async r=>{const t=await r.text();if(t.length>1_500_000)throw new Error(`${this.name}: respuesta demasiado grande`);return t;});}
 clear(){this.cache.clear();}
}
