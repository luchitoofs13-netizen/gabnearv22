// Estados de `final_execution_status` con la transacción y todos sus recibos ya ejecutados. FINAL = además irreversible;
// los otros dos pueden revertirse (extremadamente raro) y por eso solo se aceptan cuando se pide confirmación rápida.
export const EXECUTED:readonly string[]=['EXECUTED_OPTIMISTIC','EXECUTED','FINAL'];
export const FINAL_ONLY:readonly string[]=['FINAL'];
export type Level='final'|'optimistic';
export const accepted=(level:Level)=>level==='optimistic'?EXECUTED:FINAL_ONLY;
