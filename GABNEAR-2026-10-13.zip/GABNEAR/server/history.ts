import {mkdirSync,existsSync,readFileSync,writeFileSync,renameSync} from 'node:fs';
import {resolve} from 'node:path';
// Parches de pura telemetría: se agrupan en una escritura diferida (≤ FLUSH_DELAY_MS) para no bloquear
// el event loop en cada marca de tiempo. Todo lo demás (hash, estado, fondos, recibos) se persiste al instante.
const LAZY=new Set(['timing','recovery','visualization','elapsedMs','quotation','exitQuote','estimatedPnlBps']);
const FLUSH_DELAY_MS=200;
const instances=new Set<History>();
export function flushAllHistories(){for(const h of instances)h.flush();}
export class History {
 readonly path=resolve('data/history.json');
 rows:any[]=[];
 readonly listeners=new Set<(id:string)=>void>();
 private timer:ReturnType<typeof setTimeout>|null=null;
 private notify(id:string){for(const listener of this.listeners)listener(id);}
 constructor(){mkdirSync('data',{recursive:true});if(existsSync(this.path))this.rows=JSON.parse(readFileSync(this.path,'utf8'));instances.add(this);}
 save(row:any){this.rows.unshift(row);const pending=['QUEUED','PREPARING','SIGNED','UNKNOWN','SUBMITTING','SENT','CONFIRMING','SETTLING','VERIFYING_TOKENS','CONFIRMED_UNMEASURED','WAITING_BUY'];this.rows=this.rows.filter((r,i)=>i<500||pending.includes(r.status));this.flush();this.notify(row.id);return row;}
 update(id:string,patch:object){
  const row=this.rows.find(x=>x.id===id);if(!row)throw new Error('Operación desconocida.');
  Object.assign(row,patch);
  if(Object.keys(patch).every(k=>LAZY.has(k)))this.schedule();else this.flush();
  this.notify(id);
 }
 private schedule(){if(this.timer)return;this.timer=setTimeout(()=>{this.timer=null;this.flush();},FLUSH_DELAY_MS);this.timer.unref();}
 flush(){
  if(this.timer){clearTimeout(this.timer);this.timer=null;}
  writeFileSync(this.path+'.tmp',JSON.stringify(this.rows));renameSync(this.path+'.tmp',this.path);
 }
}
