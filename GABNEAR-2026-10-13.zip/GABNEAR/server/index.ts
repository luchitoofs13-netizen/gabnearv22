import 'dotenv/config';
import express from 'express';
import {resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {NearRpc} from './rpc.js';
import {History,flushAllHistories} from './history.js';
import {analyze,preview} from './analysis.js';
import {requestSchema,display,displaySigned,units,extractToken,checkRisk} from './validation.js';
import {PositionStore,parseSettings,gasEstimate,type Position} from './positions.js';
import {ExitMonitor} from './exit-monitor.js';
import {getSpeed,setSpeed} from './settings.js';
import {getMarket,getCandles,getTrades,getLaunches,getWatch,discoverCached,defaultDeps,quoteNearPrice} from './market.js';
import {nearUsd} from './usd.js';
import {MarketHub} from './market-hub.js';
import {TIMEFRAMES,type Timeframe} from './trades.js';
import {rankRoutes,bestRoute} from './venues.js';
import {afterTax,taxRate} from './quotes.js';
import {accountId,walletPresent,walletState,connectPublic,importSeed,importKey,generateWallet,unlockWallet,lockWallet,disconnectWallet,localWallet} from './wallet.js';
import {LIVE_VALIDATED,setLiveSession,liveEnabled} from './trading.js';
import {Executor} from './transactions.js';
import {securityHeaders,hostGuard,apiGuard,connectionCap} from './security.js';
import {limitsSummary} from './limits.js';
import {Sniper,rpcProbe,rpcVerifyToken,MAX_ACTIVE} from './sniper.js';
import {Notifier,describeOperation,describePositionEvent,describeSniper} from './notify.js';
import {SocialTracker} from './social.js';
import {Fetcher} from './fetcher.js';
import {Operations} from './operations.js';
import {WNEAR,discover} from './pools.js';
const rpc=new NearRpc(process.env.NEAR_RPC_URL||'https://free.rpc.fastnear.com',process.env.NEAR_RPC_READ_FALLBACK);
const history=new History();let stopped=false;let busy=false;let arming=false;let liveRevision=0;
const config=()=>({accountId:accountId(),maxNear:'',capitalLimit:null,maxBps:Number(process.env.MAX_SLIPPAGE_BPS||9900)});
const executor=new Executor(rpc,history,()=>stopped||!liveEnabled());
const operations=new Operations(rpc,history,executor,()=>stopped,config);
// Solo lecturas, incluso estando REAL apagado o bajo parada de emergencia.
let maintaining=false;
const recoveryTimer=setInterval(()=>{if(!operations.active&&!maintaining){maintaining=true;void operations.maintenance().catch(()=>{}).finally(()=>{maintaining=false;});}},250);
recoveryTimer.unref();
const port=Number(process.env.PORT||4317);
if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('PORT debe ser un entero entre 1024 y 65535.');
const app=express();app.disable('x-powered-by');app.use(securityHeaders,hostGuard());app.use(express.json({limit:'16kb'}));
// Express 5 deja req.body indefinido sin cuerpo JSON; los handlers asumen un objeto.
app.use((req,_res,next)=>{if(req.body===undefined||req.body===null)req.body={};next();});
app.use('/api',apiGuard(port));
app.use('/assets',express.static(resolve('public/assets')));
app.get('/api/wallet',(_,res)=>res.json(walletState()));
let walletBusy=false,unlockAttempts=0,unlockWindow=Date.now();
app.post('/api/wallet/:action',async(req,res)=>{
 if(walletBusy||busy||operations.active||arming)return res.status(409).json({error:'Esperá a que termine la operación actual.'});
 setLiveSession(false);liveRevision++;
 res.set('Cache-Control','no-store');
 walletBusy=true;try{
 const {action}=req.params;
 if(action==='lock'){lockWallet();return res.json(walletState());}
 if(action==='disconnect')return res.json(disconnectWallet());
 const network=await rpc.status();if(network.chain_id!=='mainnet')throw new Error('RPC no conectado a mainnet.');
 if(action==='connect'){if(typeof req.body.accountId!=='string')throw new Error('Cuenta inválida.');return res.json(await connectPublic(rpc,req.body.accountId.trim()));}
 if(action==='import'){if(typeof req.body.seed!=='string'||req.body.seed.length>500||typeof req.body.password!=='string'||typeof req.body.accountId!=='string')throw new Error('Datos de importación inválidos.');return res.json(await importSeed(rpc,req.body.accountId.trim(),req.body.seed,req.body.password));}
 if(action==='generate'){if(typeof req.body.password!=='string')throw new Error('Contraseña inválida.');return res.json(await generateWallet(req.body.password));}
 if(action==='importKey'){if(typeof req.body.secret!=='string'||req.body.secret.length>200||typeof req.body.password!=='string'||typeof req.body.accountId!=='string')throw new Error('Datos de importación inválidos.');return res.json(await importKey(rpc,req.body.accountId.trim(),req.body.secret,req.body.password));}
 if(action==='unlock'){if(Date.now()-unlockWindow>60000){unlockAttempts=0;unlockWindow=Date.now();}if(++unlockAttempts>5)return res.status(429).json({error:'Esperá un minuto antes de intentar otra contraseña.'});if(typeof req.body.password!=='string'||req.body.password.length>256)throw new Error('Contraseña inválida.');return res.json(await unlockWallet(req.body.password));}
 return res.status(404).json({error:'Acción desconocida.'});
 }catch(e){res.status(400).json({error:e instanceof Error?e.message:'No se pudo conectar la wallet.'});}finally{req.body=null;walletBusy=false;}
});
app.get('/api/health',async(_,res)=>{const start=Date.now();try{const s=await rpc.status();if(s.chain_id!=='mainnet')throw new Error('El RPC no está en mainnet.');res.json({rpc:'CONNECTED',chain:s.chain_id,block:s.sync_info.latest_block_height,latencyMs:Date.now()-start,accountId:accountId(),walletPresent:walletPresent(),liveValidated:LIVE_VALIDATED,liveEnabled:liveEnabled(),stopped,config:{...config(),limits:limitsSummary(history.rows)}});}catch{res.status(503).json({rpc:'ERROR',error:'No se pudo verificar RPC mainnet.',stopped,liveEnabled:liveEnabled(),liveValidated:false,config:{...config(),limits:limitsSummary(history.rows)}});}});
app.get('/api/balances',async(_,res)=>{try{const user=accountId();if(!user)return res.json({near:null,wnear:null,available:null});const [a,w]=await Promise.all([rpc.account(user),rpc.view(WNEAR,'ft_balance_of',{account_id:user})]);const locked=BigInt(a.storage_usage)*10000000000000000000n;const available=BigInt(a.amount)-locked-units(process.env.GAS_RESERVE_NEAR||'0.1');res.json({near:display(a.amount),wnear:display(w),available:display(available>0n?available:0n),exists:true});}catch(e){if((e as any)?.name==='AccountDoesNotExistError'||/does not exist|doesn.t exist/i.test(String(e)))return res.json({near:'0',wnear:'0',available:'0',exists:false});res.status(502).json({error:'No se pudieron consultar los balances.'});}});
app.get('/api/history',(_,res)=>res.json(history.rows));
// SSE local solo anuncia cambios; el frontend sigue recuperando por ID y jamás reenvía.
app.get('/api/events',connectionCap(12),(req,res)=>{
 res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.flushHeaders();
 const notify=(id:string)=>res.write(`data: ${JSON.stringify({id})}\n\n`);history.listeners.add(notify);
 const heartbeat=setInterval(()=>res.write(': heartbeat\n\n'),15000);
 req.on('close',()=>{clearInterval(heartbeat);history.listeners.delete(notify);});
});
// Vista previa de solo lectura al pegar el contrato: venue, pools candidatos, impacto de precio y simulación de ida y vuelta.
app.post('/api/prefetch',async(req,res)=>{try{if(typeof req.body.url!=='string')throw new Error('Enlace inválido.');await rpc.mainnet();const bps=Number.isInteger(req.body.slippageBps)?req.body.slippageBps:300;res.json(await preview(rpc,req.body.url,typeof req.body.amount==='string'&&req.body.amount.trim()?req.body.amount.trim():undefined,bps,accountId(),req.body.payWith==='NEAR'?'NEAR':undefined));}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/operations/:id/visualized',(req,res)=>{
 const row=history.rows.find(r=>r.id===req.params.id);const elapsed=req.body.clientElapsedMs;
 if(!row)return res.status(404).json({error:'Operación desconocida.'});
 if(!['FILLED','PARTIAL','ANALYZED','ANALYZED_SELL','FAILED','UNKNOWN','REFUNDED'].includes(row.status)||!Number.isFinite(elapsed)||elapsed<0||elapsed>3600000)return res.status(400).json({error:'Medición inválida.'});
 if(!row.visualization)history.update(row.id,{visualization:{clientElapsedMs:elapsed,observedAt:new Date().toISOString(),source:'browser-paint-opportunity'}});
 res.json({recorded:true});
});
// Velocidad: nivel de confirmación del swap y de los pasos previos, y armado automático. Se aplica a la próxima operación.
app.get('/api/speed',(_,res)=>res.json({...getSpeed(),broadcast:rpc.broadcastCount}));
app.post('/api/speed',(req,res)=>{try{res.json({...setSpeed(req.body),broadcast:rpc.broadcastCount});}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/emergency',(req,res)=>{stopped=req.body.stopped!==false;if(stopped){setLiveSession(false);liveRevision++;}res.json({stopped});});
app.post('/api/live',async(req,res)=>{let acquired=false;try{
 if(req.body.enabled===false){setLiveSession(false);liveRevision++;return res.json({enabled:false});}
 if(req.body.enabled!==true||req.body.acknowledgeMainnet!==true)throw new Error('Confirmá explícitamente el modo REAL y el uso de fondos mainnet.');
 if(stopped||operations.active||walletBusy||busy||arming)throw new Error('No se puede activar REAL durante una operación o parada.');
 arming=true;acquired=true;const revision=liveRevision;
 const network=await rpc.status();if(network.chain_id!=='mainnet')throw new Error('RPC de red incorrecta.');
 const {signer}=await localWallet(rpc);const publicKey=await signer.getPublicKey();
 let key:any;try{key=await rpc.deadline(rpc.provider.viewAccessKey({accountId:accountId(),publicKey}));}catch{throw new Error('La cuenta todavía no existe o no tiene esta clave: enviale NEAR (≈0.5 como mínimo) desde tu wallet principal y volvé a intentar.');}
 if(key.permission!=='FullAccess')throw new Error('La clave no tiene acceso suficiente.');
 if(stopped||revision!==liveRevision)throw new Error('Activación cancelada.');setLiveSession(true);res.json({enabled:true});
 }catch(e){if(acquired)setLiveSession(false);res.status(409).json({error:(e as Error).message});}finally{if(acquired)arming=false;}});
app.post('/api/operations',(req,res)=>{try{if(walletBusy||busy||arming)throw new Error('Esperá a que termine la consulta o configuración de wallet.');const row=operations.submit(req.body);res.status(202).json(row);}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/operations/:id/sell-intent',(req,res)=>{try{if(walletBusy||arming)throw new Error('Wallet en configuración.');res.status(202).json(operations.prepareSell(req.params.id,req.body));}catch(e){res.status(400).json({error:(e as Error).message});}});
app.get('/api/operations/:id',(req,res)=>{const row=history.rows.find(r=>r.id===req.params.id);if(!row)return res.status(404).json({error:'Operación desconocida.'});res.json(row);});
app.post('/api/operations/:id/reconcile',async(req,res)=>{try{res.json(await operations.reconcile(req.params.id));}catch(e){res.status(409).json({error:(e as Error).message});}});
// Libera una operación cuya transacción la red sigue sin conocer pasados 3 minutos (jamás si la red la conoce).
app.post('/api/operations/:id/discard',async(req,res)=>{try{if(req.body.acknowledge!==true)throw new Error('Confirmá que entendés que la transacción no se ejecutó.');res.json(await operations.recovery.discard(req.params.id));}catch(e){res.status(409).json({error:(e as Error).message});}});

// ── Datos de mercado: snapshot, velas, swaps y stream en vivo ────────────────────────────────────────
const marketDeps=defaultDeps(),hub=new MarketHub();
const marketToken=(raw:string)=>extractToken(decodeURIComponent(raw));
const marketRoute=(handler:(req:express.Request)=>Promise<unknown>)=>async(req:express.Request,res:express.Response)=>{try{res.set('Cache-Control','no-store');res.json(await handler(req));}catch(e){res.status(400).json({error:e instanceof Error?e.message:'No se pudieron obtener los datos de mercado.'});}};
app.get('/api/market/:token',marketRoute(req=>getMarket(rpc,marketToken(req.params.token as string),marketDeps)));
app.get('/api/market/:token/candles',marketRoute(req=>{const tf=String(req.query.tf??'5m');if(!(tf in TIMEFRAMES))throw new Error('Timeframe inválido.');return getCandles(rpc,marketToken(req.params.token as string),tf as Timeframe,req.query.currency==='near'?'near':'usd',hub,marketDeps);}));
app.get('/api/market/:token/trades',marketRoute(req=>getTrades(rpc,marketToken(req.params.token as string),Math.min(200,Math.max(1,Math.floor(Number(req.query.limit))||60)),hub,marketDeps,accountId())));
app.get('/api/watch',marketRoute(async req=>{const raw=([] as unknown[]).concat(req.query.token??[]).map(String).slice(0,8);return getWatch(rpc,[...new Set(raw.map(marketToken))],marketDeps);}));
app.get('/api/launches',marketRoute(()=>getLaunches(hub,marketDeps)));
// Descubrir: pools nuevos y en tendencia + narrativas (GeckoTerminal) y rastreador de canales públicos de Telegram.
app.get('/api/near-usd',marketRoute(async()=>({usd:(await nearUsd()).usd})));
const social=new SocialTracker(new Fetcher('Telegram',1500,8000));
app.get('/api/social',marketRoute(()=>social.snapshot()));
app.post('/api/social/channels',(req,res)=>{try{if(typeof req.body.name!=='string')throw new Error('Nombre inválido.');res.status(201).json({name:social.add(req.body.name),channels:social.channels});}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/social/channels/remove',(req,res)=>{if(typeof req.body.name!=='string')return res.status(400).json({error:'Nombre inválido.'});social.remove(req.body.name);res.json({channels:social.channels});});
// SSE: swaps en vivo de hasta 3 tokens y (opcional) lanzamientos nuevos. Un único WebSocket upstream sirve a todas las pestañas.
const streamCap=connectionCap(12);
app.get('/api/stream',streamCap,async(req,res)=>{
 let tokens:string[]=[];
 try{const raw=([] as unknown[]).concat(req.query.token??[]).map(String).slice(0,3);tokens=[...new Set(raw.map(marketToken))];}catch(e){return res.status(400).json({error:(e as Error).message});}
 res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.flushHeaders();
 const decimals:Record<string,number>={};
 await Promise.all(tokens.map(async t=>{try{const d=await discoverCached(rpc,t);decimals[t]=d.metadata.decimals;let quote;if(d.quoteAsset&&d.quoteAsset.id!==WNEAR){const near=await quoteNearPrice(rpc,d.quoteAsset.id);if(near!==null)quote={id:d.quoteAsset.id,decimals:d.quoteAsset.decimals,near};}hub.watch(t,d.metadata.decimals,quote);}catch{/* sin metadata: los swaps llegan sin precio */}}));
 const write=(event:string,data:unknown)=>res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
 write('ready',{tokens,decimals,live:hub.connected});
 const off=hub.subscribe(tokens,req.query.launches==='1',accountId(),e=>write(e.type,e.type==='trade'?{token:e.token,...e.data}:e.data));
 const heartbeat=setInterval(()=>res.write(': heartbeat\n\n'),15000);
 req.on('close',()=>{clearInterval(heartbeat);off();});
});

// ── Posiciones y AUTO SELL ──────────────────────────────────────────────────────────────────────────
const positionStore=new PositionStore();
positionStore.syncAll(history.rows);
history.listeners.add(id=>{const row=history.rows.find(r=>r.id===id);if(row)positionStore.ingest(row);});
// Avisos por Telegram (opcional): estado final de cada orden REAL, AUTO SELL y vigilancia de pool. Un aviso por cambio de estado.
const notifier=new Notifier();const notified=new Map<string,string>();
history.listeners.add(id=>{const row=history.rows.find(r=>r.id===id);if(!row||notified.get(id)===row.status)return;const text=describeOperation(row);if(text){notified.set(id,row.status);if(notified.size>500)notified.delete(notified.keys().next().value as string);void notifier.send(text);}});
positionStore.onEvent=(p,type,detail)=>{const text=describePositionEvent(p,type,detail);if(text)void notifier.send(text);};
// Precio de NEAR en USD y de cada quote en NEAR, refrescados en segundo plano: positionView es síncrona y lo usa para mostrar P/L en dólares.
const usdCache={near:null as number|null,quote:new Map<string,number|null>()};
async function refreshUsd(){
 try{usdCache.near=(await nearUsd()).usd;}catch{/* se conserva el último */}
 for(const id of new Set(positionStore.positions.filter(p=>p.status==='OPEN').map(p=>p.quote.id))){
  if(id===WNEAR){usdCache.quote.set(id,1);continue;}
  const v=await quoteNearPrice(rpc,id).catch(()=>null);if(v!==null)usdCache.quote.set(id,v);
 }
}
const usdTimer=setInterval(()=>{void refreshUsd();},15000);usdTimer.unref();setTimeout(()=>void refreshUsd(),1500).unref();
function positionView(p:Position){
 const q=p.quote,s=p.state,invested=BigInt(p.investedRaw),exit=s.lastExitRaw?BigInt(s.lastExitRaw):null;
 const qn=q.id===WNEAR?1:usdCache.quote.get(q.id)??null,k=qn!==null&&usdCache.near!==null?qn*usdCache.near:null;      // USD por unidad del quote
 const usd=(v:string|null)=>v===null||k===null||!Number.isFinite(Number(v))?null:Number(v)*k;
 return {...p,view:{
  usd:{perQuote:k,nearUsd:usdCache.near,invested:usd(display(invested,q.decimals)),exitValue:exit===null?null:usd(display(exit,q.decimals)),net:s.lastNetRaw===null?null:usd(displaySigned(s.lastNetRaw,q.decimals)),realized:usd(displaySigned(p.realizedRaw,q.decimals)),
   unrealized:s.lastNetRaw===null?null:usd(displaySigned(BigInt(s.lastNetRaw)-invested,q.decimals))},
  tokens:display(p.tokensRaw,p.decimals),invested:display(invested,q.decimals),spentTotal:display(p.spentTotalRaw,q.decimals),
  exitValue:exit===null?null:display(exit,q.decimals),netValue:s.lastNetRaw===null?null:displaySigned(s.lastNetRaw,q.decimals),
  pnlPct:s.lastPnlBps===null?null:s.lastPnlBps/100,peakNet:display(BigInt(s.peakNetRaw),q.decimals),
  realized:displaySigned(p.realizedRaw,q.decimals),proceedsTotal:display(p.proceedsTotalRaw,q.decimals),fees:display(p.feesTotalRaw,q.decimals),
  gasEstimate:display(gasEstimate(p),q.decimals),live:liveEnabled(),stopped
 }};
}
app.get('/api/positions',(_,res)=>{const user=accountId();res.json(positionStore.positions.filter(p=>p.signer===user).slice(0,50).map(positionView));});
// SALIR DE TODO: pide al monitor vender el 100% de cada posición abierta (solo con REAL activo y sin parada de emergencia).
const openPositions=()=>positionStore.positions.filter(p=>p.status==='OPEN'&&p.signer===accountId()).length;
app.get('/api/exit-all',(_,res)=>res.json({exitAll:monitor.exitingAll,open:openPositions()}));
app.post('/api/exit-all',(req,res)=>{try{
 if(typeof req.body.enabled!=='boolean')throw new Error('enabled debe ser verdadero o falso.');
 if(req.body.enabled){
  if(req.body.acknowledge!==true)throw new Error('Confirmá que querés vender TODAS las posiciones abiertas.');
  if(!liveEnabled()||stopped)throw new Error('SALIR DE TODO necesita REAL activo y sin parada de emergencia.');
  if(openPositions()===0)throw new Error('No hay posiciones abiertas.');
 }
 monitor.requestExitAll(req.body.enabled);res.json({exitAll:monitor.exitingAll,open:openPositions()});
}catch(e){res.status(409).json({error:(e as Error).message});}});
app.post('/api/positions/:id/settings',(req,res)=>{try{
 const p=positionStore.byId(req.params.id);if(!p||p.signer!==accountId())throw new Error('Posición desconocida.');if(p.status!=='OPEN')throw new Error('La posición está cerrada.');
 const next=parseSettings(req.body,p.settings);
 if(next.enabled&&!p.settings.enabled){p.state.pausedReason=null;p.state.attempts=0;p.state.retryAt=null;p.state.streak=null;}
 p.settings=next;positionStore.event(p,'SETTINGS',next.enabled?`AUTO SELL activo · TP ${next.takeProfitPct??'—'}% · SL ${next.stopLossPct??'—'}% · trailing ${next.trailingPct??'—'}%`:'AUTO SELL desactivado');positionStore.save();
 res.json(positionView(p));
}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/positions/:id/untrack',(req,res)=>{try{
 const p=positionStore.byId(req.params.id);if(!p||p.signer!==accountId())throw new Error('Posición desconocida.');if(p.state.pending)throw new Error('Hay una venta automática en curso.');
 positionStore.close(p,'Dejada de seguir manualmente.');positionStore.save();res.json(positionView(p));
}catch(e){res.status(400).json({error:(e as Error).message});}});
// Posición de tokens comprados por fuera de GABNEAR: el usuario declara cuánto le costaron (en unidades del quote, p. ej. NEAR).
app.post('/api/positions/import',async(req,res)=>{try{
 const user=accountId();if(!user)throw new Error('Conectá una wallet.');if(typeof req.body.url!=='string'||typeof req.body.cost!=='string')throw new Error('Indicá el token y el costo.');
 await rpc.mainnet();const token=extractToken(req.body.url);
 const [d,balance]=await Promise.all([discover(rpc,token),rpc.view(token,'ft_balance_of',{account_id:user})]);
 const tokens=BigInt(String(balance));if(tokens<=0n)throw new Error('No hay saldo de ese token en la wallet.');
 const cost=units(req.body.cost.trim(),d.quoteAsset.decimals);
 let route=d.route;
 if(d.generic||d.routes.length>1){const ranked=await rankRoutes(rpc,d.routes,token,d.quoteAsset.id,afterTax(tokens,taxRate(d.tax,'sell')),500,false);const best=bestRoute(ranked);if(!best)throw new Error('Ningún pool puede cotizar la venta de ese saldo.');route=best.route;}
 const p=positionStore.importPosition({signer:user,token,symbol:d.metadata.symbol,decimals:d.metadata.decimals,quote:{id:d.quoteAsset.id,symbol:d.quoteAsset.symbol,decimals:d.quoteAsset.decimals},route,launchId:d.record.id!=null?String(d.record.id):null,sellBps:taxRate(d.tax,'sell'),tokensRaw:tokens,costRaw:cost,settings:req.body.settings});
 res.json(positionView(p));
}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/position',async(req,res)=>{try{if(typeof req.body.url!=='string'||!Number.isInteger(req.body.slippageBps)||!Number.isInteger(req.body.percentage)||req.body.percentage<1||req.body.percentage>100)throw new Error('Datos de cotización inválidos.');res.json(await operations.position(req.body.url,req.body.slippageBps,req.body.percentage,req.body.includeUsd===true));}catch(e){res.status(400).json({error:(e as Error).message});}});
app.post('/api/analyze',async(req,res)=>{
 if(stopped)return res.status(409).json({error:'Parada de emergencia activa.'});if(busy||walletBusy||operations.active)return res.status(409).json({error:'Ya hay una operación en curso.'});
 busy=true;const id=randomUUID();try{const input=requestSchema.parse(req.body);extractToken(input.url);checkRisk('0.000000000000000000000001',input.slippageBps,config().maxNear,config().maxBps);const s=await rpc.status();if(s.chain_id!=='mainnet')throw new Error('RPC de red incorrecta.');const result=await analyze(rpc,input,config());history.save({id,at:new Date().toISOString(),...input,...result});res.json({id,...result});}catch(e){const error=e instanceof Error?e.message:'Análisis fallido.';history.save({id,at:new Date().toISOString(),status:'FAILED_ANALYSIS',mode:'DRY RUN',fundsSent:false,error});res.status(400).json({error});}finally{busy=false;}
});
// JSON mal formado o demasiado grande: respuesta JSON, no una página HTML de error.
app.use('/api',(err:any,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{const status=err?.status===413?413:err?.type==='entity.parse.failed'?400:500;res.status(status).json({error:status===413?'Solicitud demasiado grande.':status===400?'JSON inválido.':'Error interno.'});});
app.use(express.static(resolve('dist')));
const monitor=new ExitMonitor({rpc,history,store:positionStore,submit:raw=>operations.submit(raw),busy:()=>operations.active||executor.busy||walletBusy||busy||arming,live:liveEnabled,stopped:()=>stopped,account:accountId,intervalMs:Number(process.env.AUTOSELL_INTERVAL_MS)||3000});
monitor.start();

// ── Vigilancia de pool (sniper acotado): espera un contrato concreto y dispara UNA compra cuando aparece el pool ───────────────────────
const sniper=new Sniper({probe:rpcProbe(rpc),verifyToken:rpcVerifyToken(rpc),rows:()=>history.rows,live:liveEnabled,stopped:()=>stopped,account:accountId,maxBps:()=>config().maxBps,onEvent:t=>{const text=describeSniper(t);if(text)void notifier.send(text);},
 submit:raw=>{if(walletBusy||busy||arming)throw new Error('Ya hay una operación en curso (consulta o wallet).');return operations.submit(raw);}});
const sniperTimer=setInterval(()=>{void sniper.tick().catch(()=>{});},Math.max(500,Number(process.env.SNIPER_INTERVAL_MS)||1500));sniperTimer.unref();
app.get('/api/notify',(_,res)=>res.json({telegram:notifier.enabled}));
app.post('/api/notify',async(req,res)=>{
 if(!notifier.enabled)return res.status(409).json({error:'Telegram no está configurado (TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID en el .env).'});
 const text=typeof req.body.text==='string'?req.body.text.slice(0,300):'';if(!text.trim())return res.status(400).json({error:'Texto vacío.'});
 res.json({sent:await notifier.send(req.body.test===true?'✅ GABNEAR: prueba de avisos por Telegram.':text)});
});
app.get('/api/sniper',(_,res)=>res.json({targets:sniper.view(),max:MAX_ACTIVE}));
app.post('/api/sniper',async(req,res)=>{try{const t=await sniper.add(req.body);res.status(201).json({...t,autoSell:undefined});}catch(e){res.status(400).json({error:e instanceof Error?e.message:'No se pudo crear la vigilancia.'});}});
app.post('/api/sniper/:id/cancel',(req,res)=>{try{res.json({...sniper.cancel(String(req.params.id)),autoSell:undefined});}catch(e){res.status(409).json({error:(e as Error).message});}});
// Conexiones calientes con los RPC mientras la wallet está lista para operar.
rpc.startWarm(()=>walletState().unlocked||liveEnabled());
// Persistencia de telemetría diferida y posiciones al salir (Ctrl+C incluido).
function persist(){try{hub.close();flushAllHistories();positionStore.save();}catch{/* sin disco no hay más que hacer */}}
process.on('exit',persist);
for(const signal of ['SIGINT','SIGTERM'] as const)process.once(signal,()=>{persist();process.exit(0);});
app.listen(port,'127.0.0.1',()=>console.log(`GABNEAR http://127.0.0.1:${port} · DRY RUN predeterminado · AUTO SELL monitoreando posiciones`));
