import {units,display} from './validation.js';
import {WNEAR} from './pools.js';

// Topes de gasto (defensa contra errores propios, un clic de más o un uso indebido de la API local). Vienen del .env (hay que reiniciar
// GABNEAR para que un cambio rija). Vacío o 0 = sin tope. Un valor ilegible bloquea las compras (falla cerrado), nunca las libera.
//   MAX_BUY_NEAR    importe máximo de UNA compra (en NEAR)
//   MAX_DAILY_NEAR  total máximo comprado en las últimas 24 h (en NEAR)
export type SpendLimits={maxBuyRaw:bigint|null;maxDailyRaw:bigint|null};
const DAY_MS=86400000;
const NOT_SPENT=['FAILED','REFUNDED','INTERRUPTED','CANCELLED','ANALYZED','ANALYZED_SELL'];

function parse(name:string,value:string|undefined):bigint|null{
 const text=(value??'').trim();if(text===''||text==='0')return null;
 let raw:bigint;try{raw=units(text);}catch{throw new Error(`${name} inválido («${text}»): usá un número en NEAR, por ejemplo 1 o 0.5.`);}
 if(raw<=0n)return null;
 return raw;
}
export function spendLimits(env:Record<string,string|undefined>=process.env):SpendLimits{
 return {maxBuyRaw:parse('MAX_BUY_NEAR',env.MAX_BUY_NEAR),maxDailyRaw:parse('MAX_DAILY_NEAR',env.MAX_DAILY_NEAR)};
}
// Compras REAL en wNEAR de las últimas 24 h que ya gastaron o pueden haber gastado fondos (las inciertas cuentan: el tope falla cerrado).
export function spentLast24h(rows:any[],now=Date.now(),exceptId?:string):bigint{
 let total=0n;
 for(const r of rows){
  if(r.id===exceptId||r.side!=='BUY'||r.mode!=='REAL'||!r.costRaw)continue;
  if(NOT_SPENT.includes(r.status)&&r.bridge?.status!=='DONE')continue;       // un puente ya hecho gastó NEAR aunque la compra final haya fallado
  const at=Date.parse(r.at);if(!Number.isFinite(at)||at<now-DAY_MS)continue;
  // Compra con puente (NEAR → otro quote): lo gastado en NEAR es el importe de entrada del puente, no el costo en el quote.
  const raw=r.bridge?.inRaw??((r.quoteAsset?.id??WNEAR)===WNEAR?r.costRaw:null);
  if(!raw)continue;
  try{total+=BigInt(raw);}catch{/* fila ilegible */}
 }
 return total;
}
// Lanza si la compra supera algún tope. Los topes están en NEAR: una compra con otro quote (poco común) no se mide con ellos.
export function checkSpend(rows:any[],rowId:string,quoteId:string,amountRaw:bigint,limits:SpendLimits=spendLimits(),now=Date.now()){
 if(quoteId!==WNEAR)return;
 if(limits.maxBuyRaw!==null&&amountRaw>limits.maxBuyRaw)throw new Error(`Compra bloqueada por el tope por compra: ${display(amountRaw)} NEAR supera MAX_BUY_NEAR=${display(limits.maxBuyRaw)}. Subilo en el .env (y reiniciá) si es intencional.`);
 if(limits.maxDailyRaw!==null){
  const spent=spentLast24h(rows,now,rowId);
  if(spent+amountRaw>limits.maxDailyRaw)throw new Error(`Compra bloqueada por el tope diario: ya compraste ${display(spent)} NEAR en 24 h y esta suma ${display(amountRaw)} (MAX_DAILY_NEAR=${display(limits.maxDailyRaw)}).`);
 }
}
export function limitsSummary(rows:any[],env:Record<string,string|undefined>=process.env,now=Date.now()){
 try{
  const l=spendLimits(env);
  return {maxBuyNear:l.maxBuyRaw===null?null:display(l.maxBuyRaw),maxDailyNear:l.maxDailyRaw===null?null:display(l.maxDailyRaw),spentTodayNear:display(spentLast24h(rows,now)),error:null as string|null};
 }catch(e){return {maxBuyNear:null,maxDailyNear:null,spentTodayNear:display(spentLast24h(rows,now)),error:(e as Error).message};}
}
