import type {SwapQuote} from './trades.js';
import {IntearStream,parseSwap,type Trade,type WsLike} from './trades.js';
import {Fetcher} from './fetcher.js';
// Sufijos de cuentas con los que cada launchpad de NEAR despliega sus tokens (ver auto_whitelisted_postfix de v2.ref-finance.near; Intear, tknport y NearFi
// se sumaron al ver sus tokens nuevos en el feed de Intear, todos con pools directos contra wNEAR).
export const LAUNCHPADS:[suffix:string,label:string][]=[['.nearlytrade.near','Nearly'],['.meme-cooking.near','meme.cooking'],['.tkn.near','tkn.near'],['.tknx.near','tknx'],['.launch.shoremarkets.near','Shore'],['.launchpad.justhoot.near','JustHoot'],['.launch-v2.intear.near','Intear'],['.tknport.near','tknport'],['.nearfitrade.near','NearFi']];
export const launchpadOf=(token:string)=>LAUNCHPADS.find(([suffix])=>token.endsWith(suffix))?.[1]??null;
export type Launch={token:string;ts:number;launchpad:string;tx:string};
export type HubEvent={type:'trade';token:string;data:Trade}|{type:'launch';data:Launch};
type Subscriber={tokens:Set<string>;launches:boolean;me:string;send:(event:HubEvent)=>void};
const RING=200,GRACE_MS=60000;

// Un único WebSocket de swaps (y otro de tokens nuevos) para todos los clientes: se filtra aquí, no se abre uno por pestaña.
// Solo se guardan swaps de los tokens que alguien está mirando.
export class MarketHub {
 private subscribers=new Set<Subscriber>();
 private watched=new Map<string,number|undefined>();
 private rings=new Map<string,Trade[]>();
 private swaps:IntearStream;
 private launches:IntearStream;
 private stopTimer:ReturnType<typeof setTimeout>|null=null;
 private launchList:Launch[]=[];
 private graceMs:number;
 constructor(options:{base?:string;create?:(url:string)=>WsLike;staleMs?:number;graceMs?:number;initialBackoffMs?:number;watchIntervalMs?:number}={}){
  const shared={base:options.base,create:options.create,initialBackoffMs:options.initialBackoffMs,watchIntervalMs:options.watchIntervalMs};
  this.graceMs=options.graceMs??GRACE_MS;
  this.swaps=new IntearStream('trade_swap',events=>this.ingestSwaps(events),{...shared,staleMs:options.staleMs??60000});
  this.launches=new IntearStream('newtoken_nep141',events=>this.ingestLaunches(events),shared);
 }
 get connected(){return this.swaps.connected;}
 // Los decimales permiten calcular el precio de cada swap; se guardan al empezar a mirar un token.
 private quotes=new Map<string,SwapQuote>();
 watch(token:string,decimals?:number,quote?:SwapQuote){if(!this.watched.has(token)||(decimals!==undefined&&this.watched.get(token)===undefined)){this.watched.set(token,decimals);}if(quote)this.quotes.set(token,quote);if(!this.rings.has(token))this.rings.set(token,[]);}
 subscribe(tokens:string[],launches:boolean,me:string,send:(event:HubEvent)=>void){
  const sub:Subscriber={tokens:new Set(tokens),launches,me,send};this.subscribers.add(sub);
  for(const t of tokens)this.watch(t);
  if(this.stopTimer){clearTimeout(this.stopTimer);this.stopTimer=null;}
  this.swaps.start();if(launches)this.launches.start();
  return ()=>{
   this.subscribers.delete(sub);
   if(!this.subscribers.size){this.stopTimer=setTimeout(()=>{this.swaps.stop();this.launches.stop();this.stopTimer=null;},this.graceMs);this.stopTimer.unref();}
  };
 }
 recent(token:string,limit=60):Trade[]{return [...(this.rings.get(token)??[])].sort((a,b)=>b.ts-a.ts).slice(0,limit);}
 recentLaunches(limit=30){return this.launchList.slice(0,limit);}
 private ingestSwaps(events:any[]){
  for(const ev of events){
   const changes=ev?.balance_changes;if(!changes||typeof changes!=='object')continue;
   for(const token of this.watched.keys()){
    if(!(token in changes))continue;
    const trade=parseSwap(ev,token,this.watched.get(token),'',this.quotes.get(token));if(!trade)continue;
    const ring=this.rings.get(token)!;if(ring.some(t=>t.id===trade.id))continue;
    ring.push(trade);if(ring.length>RING)ring.splice(0,ring.length-RING);
    for(const s of this.subscribers)if(s.tokens.has(token))s.send({type:'trade',token,data:{...trade,mine:s.me!==''&&trade.trader===s.me}});
   }
  }
 }
 private ingestLaunches(events:any[]){
  for(const ev of events){
   const token=ev?.account_id,label=typeof token==='string'?launchpadOf(token):null;if(!label)continue;
   const nanos=/^\d+$/.test(String(ev.block_timestamp_nanosec??''))?BigInt(ev.block_timestamp_nanosec):0n;
   const launch:Launch={token,ts:Number(nanos/1000000n)||Date.now(),launchpad:label,tx:String(ev.transaction_id??'')};
   if(this.launchList.some(l=>l.token===token))continue;
   this.launchList.unshift(launch);this.launchList.length=Math.min(this.launchList.length,100);
   for(const s of this.subscribers)if(s.launches)s.send({type:'launch',data:launch});
  }
 }
 // Lista inicial de lanzamientos (HTTP) para no esperar al próximo evento en vivo.
 async loadLaunches(fetcher:Fetcher){
  const rows=await fetcher.json<any[]>('https://events-v3.intear.tech/v3/newtoken_nep141/newest',{ttl:15000,timeout:8000});
  if(!Array.isArray(rows))return;
  const list:Launch[]=[];
  for(const ev of rows){const token=ev?.account_id,label=typeof token==='string'?launchpadOf(token):null;if(!label)continue;const nanos=/^\d+$/.test(String(ev.block_timestamp_nanosec??''))?BigInt(ev.block_timestamp_nanosec):0n;list.push({token,ts:Number(nanos/1000000n),launchpad:label,tx:String(ev.transaction_id??'')});}
  for(const l of [...list].reverse())if(!this.launchList.some(x=>x.token===l.token))this.launchList.unshift(l);
  this.launchList.sort((a,b)=>b.ts-a.ts);this.launchList.length=Math.min(this.launchList.length,100);
 }
 close(){this.swaps.stop();this.launches.stop();if(this.stopTimer)clearTimeout(this.stopTimer);}
}
