import {NearRpc} from './rpc.js';
import {Fetcher} from './fetcher.js';
import {discover,WNEAR} from './pools.js';
import {rankRoutes,bestRoute,type Route} from './venues.js';
import {nearUsd as defaultNearUsd} from './usd.js';
import {units} from './validation.js';
import {parseSwap,candlesFromTrades,priceNear,quoteToNearRaw,TIMEFRAMES,type Trade,type Candle,type Timeframe,type SwapQuote} from './trades.js';
import {launchpadOf,type MarketHub} from './market-hub.js';

// Fuentes públicas (solo se les envía el contrato del token, que es público):
//  · on-chain (nuestro RPC): precio, supply, liquidez de los pools        · DexScreener: volumen, txns, variación, antigüedad del par
//  · GeckoTerminal: velas OHLCV                                            · FastNEAR: mayores holders
//  · Intear: swaps recientes (historial) y, en vivo, el WebSocket de market-hub
export type MarketDeps={gecko:Fetcher;dex:Fetcher;fast:Fetcher;intear:Fetcher;nearUsd:()=>Promise<{usd:number}>};
export const defaultDeps=():MarketDeps=>({gecko:new Fetcher('GeckoTerminal',2300,9000),dex:new Fetcher('DexScreener',250,7000),fast:new Fetcher('FastNEAR',0,7000),intear:new Fetcher('Intear',0,7000),nearUsd:defaultNearUsd});
const GECKO='https://api.geckoterminal.com/api/v2/networks/near',DEXSCREENER='https://api.dexscreener.com/latest/dex/tokens',FASTNEAR='https://api.fastnear.com/v1/ft',INTEAR='https://events-v3.intear.tech/v3/trade_swap/by_token_newest';
// Contratos que custodian liquidez: no cuentan como «holders» a la hora de medir concentración.
export const EXCHANGE_LABELS:Record<string,string>={'v2.ref-finance.near':'Ref v1 (pools)','dclv2.ref-labs.near':'Rhea DCL (pools)','nearlytrade.near':'Nearly','wrap.near':'wNEAR','intents.near':'NEAR Intents','burrow.near':'Burrow','contract.main.burrow.near':'Burrow'};

// discover() hace varias lecturas; para refrescar el panel cada pocos segundos se reutiliza 20 s.
const discoverCache=new Map<string,{at:number;value:Promise<Awaited<ReturnType<typeof discover>>>}>();
export function clearMarketCache(){discoverCache.clear();}
export function discoverCached(rpc:NearRpc,token:string){
 const hit=discoverCache.get(token);if(hit&&Date.now()-hit.at<20000)return hit.value;
 if(discoverCache.size>64)discoverCache.clear();
 const value=discover(rpc,token);discoverCache.set(token,{at:Date.now(),value});
 void value.catch(()=>{if(discoverCache.get(token)?.value===value)discoverCache.delete(token);});return value;
}

const num=(v:unknown):number|null=>{const n=typeof v==='string'||typeof v==='number'?Number(v):NaN;return Number.isFinite(n)?n:null;};
const sumNull=(values:(number|null)[])=>{const known=values.filter((v):v is number=>v!==null);return known.length?known.reduce((a,b)=>a+b,0):null;};
// yocto → NEAR con BigInt (12 decimales exactos) para no arrastrar error de coma flotante a las liquidez.
const nearOf=(raw:unknown,qd=24)=>typeof raw==='string'&&/^\d+$/.test(raw)?(qd>=12?Number(BigInt(raw)/10n**BigInt(qd-12))/1e12:Number(raw)/10**qd):null;

// Liquidez del pool en unidades del QUOTE (wNEAR casi siempre; RHEA u otro en algunos launches de Nearly). `priceInNear` = precio del token en quote.
export function poolLiquidityNear(route:Route,priceInNear:number|null,decimals:number,quoteDecimals=24):number|null{
 const i=route.info??{};
 if(route.venue==='REF_V1'){const q=nearOf(i.reserveQuote,quoteDecimals);return q===null?null:q*2;}
 const q=nearOf(i.totalQuote,quoteDecimals),t=typeof i.totalToken==='string'&&/^\d+$/.test(i.totalToken)?Number(i.totalToken)/10**decimals:null;
 return q===null?null:q+(t!==null&&priceInNear!==null?t*priceInNear:0);
}
// Estadísticas de DexScreener. La API devuelve todos los pares donde aparece el token: también pools diminutos y pares donde el token es la
// moneda de COTIZACIÓN de otro (p. ej. BABYNINU/NINU). Mezclarlos infla txns y volumen frente a lo que muestra la web, así que precio, txns,
// volumen, variación y antigüedad salen del par principal (mayor liquidez, con el token como base); solo la liquidez suma los pools propios.
export function parseDexScreener(body:any,token?:string){
 const pairs=(Array.isArray(body?.pairs)?body.pairs:[]).filter((p:any)=>p?.chainId==='near');
 if(!pairs.length)return null;
 const own=token?pairs.filter((p:any)=>p?.baseToken?.address===token):pairs,base=own.length?own:pairs;
 const top=[...base].sort((a:any,b:any)=>(num(b?.liquidity?.usd)??0)-(num(a?.liquidity?.usd)??0))[0];
 const at=(w:string,side:string)=>num(top?.txns?.[w]?.[side]);
 return {
  priceChange:{m5:num(top?.priceChange?.m5),h1:num(top?.priceChange?.h1),h6:num(top?.priceChange?.h6),h24:num(top?.priceChange?.h24)},
  volumeUsd:{m5:num(top?.volume?.m5),h1:num(top?.volume?.h1),h6:num(top?.volume?.h6),h24:num(top?.volume?.h24)},
  txns:Object.fromEntries(['m5','h1','h6','h24'].map(w=>[w,{buys:at(w,'buys'),sells:at(w,'sells')}])),
  liquidityUsd:sumNull(base.map((p:any)=>num(p?.liquidity?.usd))),fdvUsd:num(top?.fdv),marketCapUsd:num(top?.marketCap),priceUsd:num(top?.priceUsd),
  pairCreatedAt:num(top?.pairCreatedAt),pairs:base.length,url:typeof top?.url==='string'?top.url:null
 };
}
// Concentración: mayores holders (FastNEAR) sobre el supply total, separando contratos que custodian liquidez.
export function parseHolders(body:any,supply:bigint|null){
 const rows:any[]=Array.isArray(body?.accounts)?body.accounts:[];
 if(!rows.length||supply===null||supply<=0n)return null;
 const list=rows.slice(0,25).map(r=>{
  let balance=0n;try{balance=BigInt(String(r.balance));}catch{/* fila ilegible */}
  return {account:String(r.account_id),balanceRaw:balance.toString(),pct:Number(balance*100000n/supply)/1000,label:EXCHANGE_LABELS[String(r.account_id)]??null};
 });
 const real=list.filter(h=>!h.label);
 const top10=real.slice(0,10).reduce((s,h)=>s+h.pct,0);
 return {top:list.slice(0,10),topHolderPct:real[0]?.pct??null,topHolder:real[0]?.account??null,top10Pct:Math.round(top10*100)/100,inPoolsPct:Math.round(list.filter(h=>h.label).reduce((s,h)=>s+h.pct,0)*100)/100};
}

// Precio de 1 token en unidades del quote (a partir de cuánto quote entra y cuántos tokens salen).
export function priceInQuote(quoteRaw:bigint,tokenRaw:bigint,decimals:number,quoteDecimals:number):number|null{
 if(quoteRaw<=0n||tokenRaw<=0n||!Number.isInteger(decimals)||decimals<0||decimals>38||!Number.isInteger(quoteDecimals)||quoteDecimals<0||quoteDecimals>38)return null;
 const p=Number(quoteRaw*10n**BigInt(decimals)*10n**30n/(tokenRaw*10n**BigInt(quoteDecimals)))/1e30;
 return Number.isFinite(p)&&p>0?p:null;
}
// Cuántos NEAR vale 1 unidad del quote: 1 si es wNEAR; si no (p. ej. RHEA) se cotiza su propio pool contra wNEAR. null = no se pudo medir.
export async function quoteNearPrice(rpc:NearRpc,quoteId:string):Promise<number|null>{
 if(quoteId===WNEAR)return 1;
 try{
  const q=await discoverCached(rpc,quoteId),probe=units('0.1');
  const best=bestRoute(await rankRoutes(rpc,q.routes,WNEAR,quoteId,probe,300,false));
  return best?priceInQuote(probe*BigInt(10000-best.route.fee)/10000n,BigInt(best.quote!.raw),q.metadata.decimals,24):null;
 }catch{return null;}
}

export async function getMarket(rpc:NearRpc,token:string,deps:MarketDeps=defaultDeps(),opts:{holders?:boolean}={}){
 const d=await discoverCached(rpc,token),decimals=d.metadata.decimals;
 // La mayoría de los tokens cotizan contra wNEAR, pero algunos launches de Nearly cotizan contra otro token (p. ej. RHEA): todo se mide en ese quote
 // y se convierte a NEAR con el precio del quote.
 const quoteId=d.quoteAsset?.id??WNEAR,qd=d.quoteAsset?.decimals??24,qSymbol=d.quoteAsset?.symbol??'wNEAR',probe=units('0.1',qd);
 const [ranked,supplyRaw,usd,dex,holdersBody,quoteNear]=await Promise.allSettled([
  rankRoutes(rpc,d.routes,quoteId,token,probe,300,false),
  rpc.view<string>(token,'ft_total_supply'),
  deps.nearUsd(),
  deps.dex.json(`${DEXSCREENER}/${token}`,{ttl:8000}),
  opts.holders===false?Promise.resolve(null):deps.fast.json(`${FASTNEAR}/${token}/top`,{ttl:90000}),
  quoteNearPrice(rpc,quoteId)
 ]);
 const best=ranked.status==='fulfilled'?bestRoute(ranked.value):undefined;
 // Precio medio del pool: la cotización incluye la comisión del pool, que se descuenta para no inflar el precio.
 const feeBps=best?best.route.fee:0;
 const priceQuote=best?priceInQuote(probe*BigInt(10000-feeBps)/10000n,BigInt(best.quote!.raw),decimals,qd):null;
 const qNear=quoteNear.status==='fulfilled'?quoteNear.value:null;
 const price=priceQuote!==null&&qNear!==null?priceQuote*qNear:null;      // precio en NEAR
 const nearUsd=usd.status==='fulfilled'&&usd.value.usd>0?usd.value.usd:null;
 let supply:bigint|null=null;if(supplyRaw.status==='fulfilled'&&/^\d+$/.test(String(supplyRaw.value)))supply=BigInt(String(supplyRaw.value));
 const supplyTokens=supply===null?null:Number(supply)/10**decimals;
 const marketCapNear=price!==null&&supplyTokens!==null?price*supplyTokens:null;
 const toNear=(v:number|null)=>v===null||qNear===null?null:v*qNear;
 const pools=d.routes.map(r=>({venue:r.venue,poolId:r.poolId,fee:r.fee,liquidityNear:toNear(poolLiquidityNear(r,priceQuote,decimals,qd)),best:!!best&&best.route.poolId===r.poolId&&best.route.venue===r.venue}));
 const liquidityNear=sumNull(pools.map(p=>p.liquidityNear));
 const stats=dex.status==='fulfilled'?parseDexScreener(dex.value,token):null;
 const holders=holdersBody.status==='fulfilled'?parseHolders(holdersBody.value,supply):null;
 const warnings:string[]=[];
 if(holders?.topHolderPct!=null&&holders.topHolderPct>=30)warnings.push(`Un solo holder (${holders.topHolder}) tiene ${holders.topHolderPct}% del supply.`);
 else if(holders&&holders.top10Pct>=70)warnings.push(`Los 10 mayores holders concentran ${holders.top10Pct}% del supply.`);
 if(liquidityNear!==null&&marketCapNear!==null&&marketCapNear>0&&liquidityNear/marketCapNear<0.02)warnings.push('La liquidez es menos del 2% del market cap: una venta grande se llevaría casi todo.');
 if(liquidityNear!==null&&liquidityNear<5)warnings.push(`Liquidez muy baja (${liquidityNear.toFixed(2)} NEAR).`);
 return {
  token,symbol:d.metadata.symbol,name:d.metadata.name,decimals,generic:d.generic,launchpad:launchpadOf(token),
  quote:{id:quoteId,symbol:qSymbol,decimals:qd,priceNear:qNear,isNear:quoteId===WNEAR},priceQuote,
  priceNear:price,priceUsd:price!==null&&nearUsd!==null?price*nearUsd:null,nearUsd,
  supply:supply===null?null:supply.toString(),supplyTokens,marketCapNear,marketCapUsd:marketCapNear!==null&&nearUsd!==null?marketCapNear*nearUsd:null,
  liquidityNear,liquidityUsd:liquidityNear!==null&&nearUsd!==null?liquidityNear*nearUsd:null,pools,
  route:best?{venue:best.route.venue,poolId:best.route.poolId,fee:best.route.fee}:null,
  tax:d.tax?{buyBps:Number(d.tax.buy_bps??0),sellBps:Number(d.tax.sell_bps??0)}:null,
  stats,holders,warnings,fetchedAt:Date.now(),
  sources:{onchain:best?(price===null?'sin precio del quote':'ok'):'sin cotización',dexscreener:stats?'ok':dex.status==='rejected'?'error':'sin datos',holders:holders?'ok':holdersBody.status==='rejected'?'error':'sin datos'}
 };
}

// ── Velas ───────────────────────────────────────────────────────────────────────────────────────────
const GECKO_FRAME:Record<Timeframe,[unit:string,aggregate:number]>={'1m':['minute',1],'5m':['minute',5],'15m':['minute',15],'1h':['hour',1],'4h':['hour',4],'1d':['day',1]};
// GeckoTerminal identifica los pools de Rhea como refv1-<id> y refv2-<token>:<quote>:<fee>.
export const geckoPoolAddress=(route:Route)=>route.venue==='REF_V1'?`refv1-${route.poolId}`:`refv2-${route.poolId.replaceAll('|',':')}`;
export function primaryRoute(routes:Route[]):Route|null{
 const liq=(r:Route)=>nearOf(r.venue==='REF_V1'?r.info?.reserveQuote:r.info?.totalQuote)??0;
 return [...routes].sort((a,b)=>liq(b)-liq(a))[0]??null;
}
export function parseGeckoOhlcv(body:any):Candle[]{
 const list=body?.data?.attributes?.ohlcv_list;if(!Array.isArray(list))return [];
 return list.map((r:any)=>({time:Number(r[0]),open:Number(r[1]),high:Number(r[2]),low:Number(r[3]),close:Number(r[4]),volume:Number(r[5])})).filter(c=>[c.time,c.open,c.high,c.low,c.close,c.volume].every(Number.isFinite)&&c.open>0&&c.high>0&&c.low>0&&c.close>0).sort((a,b)=>a.time-b.time);
}
// Historial de GeckoTerminal (hasta ~300 swaps con trader y hash). Montos ya vienen con decimales.
export function parseGeckoTrades(body:any,token:string,decimals:number,quote?:SwapQuote):Trade[]{
 const rows=Array.isArray(body?.data)?body.data:[];const out:Trade[]=[];
 for(const row of rows){
  const a=row?.attributes;if(!a||typeof a.tx_hash!=='string')continue;
  const buy=a.kind==='buy',sell=a.kind==='sell';if(!buy&&!sell)continue;
  const tokenSide=buy?a.to_token_address:a.from_token_address,nearSide=buy?a.from_token_address:a.to_token_address;
  if(tokenSide!==token||nearSide!==(quote?.id??WNEAR))continue;
  try{
   const tokenRaw=units(String(buy?a.to_token_amount:a.from_token_amount),decimals),nearRaw=quoteToNearRaw(units(String(buy?a.from_token_amount:a.to_token_amount),quote?.decimals??24),quote??{id:WNEAR,decimals:24,near:1}),ts=Date.parse(a.block_timestamp);
   if(tokenRaw<=0n||nearRaw<=0n||!Number.isFinite(ts))continue;
   out.push({id:`${a.tx_hash}:g`,ts,side:buy?'BUY':'SELL',tokenRaw:tokenRaw.toString(),nearRaw:nearRaw.toString(),priceNear:priceNear(nearRaw,tokenRaw,decimals),trader:String(a.tx_from_address??''),tx:a.tx_hash,block:Number.isFinite(Number(a.block_number))?Number(a.block_number):null,mine:false});
  }catch{/* fila con montos ilegibles */}
 }
 return out;
}
export async function getTrades(rpc:NearRpc,token:string,limit=60,hub?:MarketHub,deps:MarketDeps=defaultDeps(),me=''):Promise<Trade[]>{
 const d=await discoverCached(rpc,token);
 // Par distinto de wNEAR (p. ej. RHEA): los swaps se leen contra ese token y se convierten a NEAR.
 let quote:SwapQuote|undefined;
 if(d.quoteAsset&&d.quoteAsset.id!==WNEAR){const near=await quoteNearPrice(rpc,d.quoteAsset.id);if(near!==null)quote={id:d.quoteAsset.id,decimals:d.quoteAsset.decimals,near};}
 hub?.watch(token,d.metadata.decimals,quote);
 // Un mismo swap aparece en varias fuentes con ids distintos: se deduplica por hash de transacción (la fuente más rica gana).
 const out=new Map<string,Trade>();
 const add=(t:Trade)=>{const old=out.get(t.tx);if(!old||(old.priceNear===null&&t.priceNear!==null))out.set(t.tx,t);};
 for(const t of hub?.recent(token,200)??[])add(t);
 const route=primaryRoute(d.routes);
 const [intear,gecko]=await Promise.allSettled([
  deps.intear.json<any[]>(`${INTEAR}?account=${encodeURIComponent(token)}`,{ttl:4000,timeout:6000}),
  route?deps.gecko.json(`${GECKO}/pools/${geckoPoolAddress(route)}/trades`,{ttl:15000}):Promise.reject(new Error('sin pool'))
 ]);
 if(intear.status==='fulfilled'&&Array.isArray(intear.value))for(const ev of intear.value){const t=parseSwap(ev,token,d.metadata.decimals,me,quote);if(t)add(t);}
 if(gecko.status==='fulfilled')for(const t of parseGeckoTrades(gecko.value,token,d.metadata.decimals,quote))add(t);
 return [...out.values()].map(t=>({...t,mine:me!==''&&t.trader===me})).sort((a,b)=>b.ts-a.ts).slice(0,limit);
}
export async function getCandles(rpc:NearRpc,token:string,tf:Timeframe,currency:'usd'|'near',hub?:MarketHub,deps:MarketDeps=defaultDeps()){
 if(!(tf in TIMEFRAMES))throw new Error('Timeframe inválido.');
 const d=await discoverCached(rpc,token),route=primaryRoute(d.routes);
 let candles:Candle[]=[],source:'geckoterminal'|'trades'|'none'='none',pool:string|null=null;
 if(route){
  pool=geckoPoolAddress(route);const [unit,aggregate]=GECKO_FRAME[tf];
  try{
   const body=await deps.gecko.json(`${GECKO}/pools/${pool}/ohlcv/${unit}?aggregate=${aggregate}&limit=300&currency=${currency==='usd'?'usd':'token'}`,{ttl:20000});
   candles=parseGeckoOhlcv(body);if(candles.length)source='geckoterminal';
  }catch{/* GeckoTerminal tarda en indexar pools nuevos y limita por minuto: se cae a los swaps */}
 }
 if(!candles.length){
  // Pool recién creado o proveedor caído: velas propias a partir de los swaps recientes.
  const trades=await getTrades(rpc,token,200,hub,deps);
  let mult=1;if(currency==='usd'){try{mult=(await deps.nearUsd()).usd;}catch{mult=0;}}
  if(mult>0){candles=candlesFromTrades(trades,TIMEFRAMES[tf],mult);if(candles.length)source='trades';}
 }
 return {token,tf,currency,source,pool,candles};
}
export async function getLaunches(hub:MarketHub,deps:MarketDeps=defaultDeps()){
 try{await hub.loadLaunches(deps.intear);}catch{/* se muestran los recibidos en vivo */}
 return hub.recentLaunches(40);
}

// Lista de seguimiento: precio y variación de varios tokens con una sola llamada (sin holders ni velas, para no gastar cuota de APIs).
export type WatchRow={token:string;symbol?:string;priceUsd?:number|null;priceNear?:number|null;change24h?:number|null;liquidityUsd?:number|null;marketCapUsd?:number|null;error?:string};
export async function getWatch(rpc:NearRpc,tokens:string[],deps:MarketDeps=defaultDeps()):Promise<WatchRow[]>{
 return Promise.all(tokens.slice(0,8).map(async(token):Promise<WatchRow>=>{
  try{
   const s=await getMarket(rpc,token,deps,{holders:false});
   return {token,symbol:s.symbol,priceUsd:s.priceUsd,priceNear:s.priceNear,change24h:s.stats?.priceChange?.h24??null,liquidityUsd:s.liquidityUsd,marketCapUsd:s.marketCapUsd};
  }catch(e){return {token,error:e instanceof Error?e.message.slice(0,140):'sin datos'};}
 }));
}
