// Avisos por Telegram (opcional, apagado si no configurás nada). Solo SALE texto corto hacia api.telegram.org: estado de una orden, un
// disparo de AUTO SELL o de la vigilancia de pool, o una alerta de precio. Jamás claves, frases ni saldos completos de la wallet.
//   TELEGRAM_BOT_TOKEN  el token de tu bot (lo da @BotFather)        TELEGRAM_CHAT_ID  tu id de chat (o @canal)
// Nunca lanza: un fallo de Telegram no puede afectar a una operación. El token no se escribe en ningún registro.
export type Fetch=(url:string,init:{method:string;headers:Record<string,string>;body:string;signal?:AbortSignal})=>Promise<{ok:boolean;status:number}>;
const TOKEN=/^\d{6,12}:[A-Za-z0-9_-]{30,}$/,CHAT=/^(-?\d{5,20}|@[A-Za-z]\w{4,})$/;
export const MAX_PER_MINUTE=20,MAX_TEXT=1000;

export class Notifier{
 private sentAt:number[]=[];
 constructor(readonly env:Record<string,string|undefined>=process.env,readonly fetchImpl:Fetch=(globalThis.fetch as unknown) as Fetch,readonly now:()=>number=Date.now){}
 get enabled(){return TOKEN.test((this.env.TELEGRAM_BOT_TOKEN??'').trim())&&CHAT.test((this.env.TELEGRAM_CHAT_ID??'').trim());}
 async send(text:string):Promise<boolean>{
  if(!this.enabled)return false;
  const t=this.now();this.sentAt=this.sentAt.filter(x=>t-x<60000);
  if(this.sentAt.length>=MAX_PER_MINUTE)return false;                                   // un bucle de eventos no puede inundar el chat
  this.sentAt.push(t);
  const clean=String(text).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').slice(0,MAX_TEXT);
  if(!clean.trim())return false;
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),6000);
  try{
   const res=await this.fetchImpl(`https://api.telegram.org/bot${(this.env.TELEGRAM_BOT_TOKEN??'').trim()}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:(this.env.TELEGRAM_CHAT_ID??'').trim(),text:clean,disable_web_page_preview:true}),signal:controller.signal});
   if(!res.ok)console.warn(`[aviso] Telegram respondió ${res.status}`);
   return res.ok;
  }catch(e){console.warn(`[aviso] Telegram no respondió (${(e as Error).name})`);return false;}
  finally{clearTimeout(timer);}
 }
}

const short=(a?:string)=>!a?'—':a.length>26?`${a.slice(0,10)}…${a.slice(-10)}`:a;
const near=(raw?:string)=>{try{const n=BigInt(raw??'0'),s=10n**24n;const whole=n/s,frac=((n%s)*10000n/s).toString().padStart(4,'0').replace(/0+$/,'');return frac?`${whole}.${frac}`:`${whole}`;}catch{return '?';}};
const DONE=['FILLED','PARTIAL','FAILED','REFUNDED','INTERRUPTED','UNKNOWN'];
// Mensaje para el estado final de una orden REAL (null = no corresponde avisar).
export function describeOperation(row:any):string|null{
 if(!row||row.mode!=='REAL'||!DONE.includes(row.status))return null;
 const what=row.side==='SELL'?`VENTA ${row.percentage??''}%`.trim():row.side==='BUY'?'COMPRA':row.side==='ARM'?'ARMADO':'CONVERSIÓN wNEAR';
 const token=row.token&&row.token!=='wrap.near'?` ${short(row.token)}`:'';
 const ok=row.status==='FILLED'||row.status==='PARTIAL';
 if(!ok&&!['BUY','SELL'].includes(row.side))return `⚠ ${what}${token}: ${row.status}${row.error?` — ${String(row.error).slice(0,200)}`:''}`;
 if(!ok)return `⚠ ${what}${token}: ${row.status==='UNKNOWN'?'resultado incierto, GABNEAR lo recupera solo':row.status}${row.error?` — ${String(row.error).slice(0,200)}`:''}`;
 if(!['BUY','SELL'].includes(row.side))return null;
 return `✅ ${what}${token} ${row.status==='PARTIAL'?'(parcial) ':''}completada${row.elapsedMs?` en ${row.elapsedMs} ms`:''}`;
}
const EVENT_ICON:Record<string,string>={TRIGGER:'🎯',SOLD:'✅',SELL_FAILED:'⚠',PAUSED:'⏸',CLOSED:'🔒'};
export function describePositionEvent(p:any,type:string,detail:string):string|null{
 const icon=EVENT_ICON[type];if(!icon)return null;
 const label=type==='TRIGGER'?'AUTO SELL disparado':type==='SOLD'?'AUTO SELL vendió':type==='SELL_FAILED'?'AUTO SELL falló':type==='PAUSED'?'AUTO SELL pausado':'Posición cerrada';
 return `${icon} ${label} · ${p.symbol||short(p.token)}\n${String(detail).slice(0,300)}`;
}
const SNIPER_ICON:Record<string,string>={FIRING:'🎯',BOUGHT:'✅',BLOCKED:'⛔',FAILED:'⚠',EXPIRED:'⌛',SIMULATED:'🧪'};
export function describeSniper(t:any):string|null{
 const icon=SNIPER_ICON[t?.status];if(!icon)return null;
 return `${icon} Vigilancia ${t.symbol||short(t.token)} (${t.mode}): ${t.status}\n${String(t.detail).slice(0,300)}`;
}
export const describeAlert=(symbol:string,direction:'above'|'below',target:number,price:number)=>`🔔 ${symbol}: el precio ${direction==='above'?'superó':'cayó por debajo de'} $${target} (ahora $${price})`;
