import {randomUUID} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {z} from 'zod';
import {NearRpc} from './rpc.js';
import {History} from './history.js';
import {Executor,inspectOutcome} from './transactions.js';
import {analyze} from './analysis.js';
import {discover,WNEAR} from './pools.js';
import {buy,arm,sell,prepareWnear,executableExit,requireLive,liveEnabled,bridgeToQuote} from './trading.js';
import {planBridge,bridgeRecord,type BridgePlan} from './bridge.js';
import {percentageAmount,afterTax,taxRate} from './quotes.js';
import {rankRoutes,bestRoute} from './venues.js';
import {extractToken,checkRisk,display,units} from './validation.js';
import {estimateUsd} from './usd.js';
import {quoteNearPrice} from './market.js';
import {beginTimeline,endTimeline} from './timing.js';
import {Recovery,blocksAccount} from './recovery.js';
import {quoteAsset} from './quote-asset.js';
import {checkSpend} from './limits.js';

const autoSellSchema=z.object({takeProfitPct:z.number().positive().max(100000).nullable().optional(),stopLossPct:z.number().positive().lt(100).nullable().optional(),trailingPct:z.number().positive().lt(100).nullable().optional(),tpSellPct:z.union([z.literal(50),z.literal(99),z.literal(100)]).optional(),slippageBps:z.number().int().min(1).max(9900).optional()}).strict();
export const operationSchema=z.object({requestId:z.string().uuid(),side:z.enum(['BUY','SELL','PREPARE','ARM']),mode:z.enum(['DRY RUN','REAL']),url:z.string().max(300),amount:z.string().max(50).optional(),percentage:z.number().int().min(1).max(100).optional(),payWith:z.literal('NEAR').optional(),slippageBps:z.number().int().min(1).max(9900),allowRisk:z.boolean().optional(),autoSell:autoSellSchema.optional()}).strict();
type Input=z.infer<typeof operationSchema>;
export class Operations {
 active=false;
 readonly recovery:Recovery;
 constructor(readonly rpc:NearRpc,readonly history:History,readonly ex:Executor,readonly stopped:()=>boolean,readonly config:()=>{accountId:string;maxNear:string;maxBps:number}){
  this.recovery=new Recovery(history,ex,()=>{this.drainSales();});
  for(const r of history.rows)if(r.status==='WAITING_BUY')history.update(r.id,{status:'CANCELLED',error:'Intención de venta cancelada por reinicio; REAL no se reactiva automáticamente.'});
  for(const r of history.rows){if(['QUEUED','PREPARING','SIGNED','SUBMITTING','SENT','CONFIRMING','SETTLING'].includes(r.status)){history.update(r.id,{status:r.status==='SETTLING'||r.method==='ft_transfer_call'||r.transactions?.some((t:any)=>['SUBMITTING','SENT','CONFIRMING','UNKNOWN'].includes(t.status))?'UNKNOWN':'INTERRUPTED',error:'El proceso se reinició. No se reenvió la orden.'});}}
 }
 prepareSell(buyId:string,raw:unknown){
  const input=operationSchema.parse(raw);const buy=this.history.rows.find(r=>r.id===buyId);
  if(!buy||buy.side!=='BUY'||buy.mode!=='REAL'||buy.signer!==this.config().accountId||extractToken(input.url)!==buy.token||input.side!=='SELL'||input.mode!=='REAL'||!input.percentage)throw new Error('La intención debe corresponder a la compra REAL de esta cuenta y token.');
  requireLive();if(this.stopped())throw new Error('Parada de emergencia activa.');
  checkRisk('0.000000000000000000000001',input.slippageBps,this.config().maxNear,this.config().maxBps);
  const existing=this.history.rows.find(r=>r.requestId===input.requestId);
  if(existing){if(existing.fingerprint!==JSON.stringify(input)||existing.buyId!==buyId)throw new Error('La misma orden no puede cambiar sus parámetros.');return existing;}
  if(this.history.rows.some(r=>r.buyId===buyId))throw new Error('Esa compra ya tiene una intención de venta.');
  if(['FAILED','REFUNDED','INTERRUPTED'].includes(buy.status))throw new Error('La compra no permite preparar una venta.');
  return this.history.save({id:randomUUID(),at:new Date().toISOString(),...input,fingerprint:JSON.stringify(input),buyId,token:buy.token,signer:buy.signer,status:'WAITING_BUY',fundsSent:false});
 }
 async maintenance(){
  if(this.active||this.ex.busy)return;
  if(this.drainSales())return;
  await this.recovery.tick();
  this.drainSales();
 }
 private drainSales(){
  if(this.active||this.ex.busy)return;
  for(const r of this.history.rows.filter(r=>r.status==='WAITING_BUY')){
   const buy=this.history.rows.find(b=>b.id===r.buyId);
   if(this.stopped()||!liveEnabled()||r.signer!==this.config().accountId||!buy||['FAILED','REFUNDED','INTERRUPTED'].includes(buy.status)){
    this.history.update(r.id,{status:'CANCELLED',error:'Intención cancelada: compra fallida, cambio de wallet, parada o REAL desactivado.'});continue;
   }
   if(!['FILLED','PARTIAL'].includes(buy.status)||!buy.receivedRaw||BigInt(buy.receivedRaw)<=0n||this.history.rows.some(row=>blocksAccount(row,r.signer,r.token)))continue;
   // Se persiste el consumo ANTES de ejecutar. Un reinicio nunca repite esta intención.
   this.history.update(r.id,{status:'QUEUED'});this.active=true;
   void this.run(r,operationSchema.parse(JSON.parse(r.fingerprint)));return true;
  }
 }
 submit(raw:unknown){
  const input=operationSchema.parse(raw);const fingerprint=JSON.stringify(input);
  const previous=this.history.rows.find(r=>r.requestId===input.requestId);
  if(previous){if(previous.fingerprint!==fingerprint)throw new Error('La misma orden no puede cambiar sus parámetros.');return previous;}
  if(this.active||this.ex.busy)throw new Error('Ya hay una operación en curso.');
  if(this.stopped())throw new Error('Parada de emergencia activa.');
  const token=input.side==='PREPARE'?WNEAR:extractToken(input.url);
  if(input.mode==='REAL'&&this.history.rows.some(r=>blocksAccount(r,this.config().accountId,token)))throw new Error('Hay una transacción incierta. GABNEAR recupera automáticamente el resultado antes de usar esos fondos.');
  checkRisk(input.side==='PREPARE'?input.amount??'': '0.000000000000000000000001',input.slippageBps,this.config().maxNear,this.config().maxBps);
  if((input.side==='BUY'||input.side==='ARM')&&(!input.amount||!/^\d+(\.\d+)?$/.test(input.amount)||!/[1-9]/.test(input.amount)))throw new Error('Importe inválido o cero.');
  if(input.side==='SELL'&&!input.percentage)throw new Error('Elegí qué porcentaje vender (1–100%).');
  if(input.payWith&&input.side!=='BUY')throw new Error('Pagar con NEAR solo aplica a compras.');
  if(input.side==='SELL'&&!this.config().accountId)throw new Error('Conectá una wallet para consultar el saldo del token.');
  if(input.mode==='REAL')requireLive();
  const row=this.history.save({id:randomUUID(),fingerprint,at:new Date().toISOString(),...input,token,status:'QUEUED',fundsSent:false,signer:this.config().accountId});
  this.active=true;void this.run(row,input);return row;
 }
 private async run(row:any,input:Input){
  const start=performance.now();const clock=beginTimeline(this.history,row.id);
  try{
   if(this.rpc.mainnet)await this.rpc.mainnet();else {const network=await this.rpc.status();if(network.chain_id!=='mainnet')throw new Error('RPC de red incorrecta.');}
   if(this.stopped())throw new Error('Parada de emergencia activa.');
   if(input.side==='PREPARE'){
    const user=this.config().accountId;if(!user)throw new Error('Conectá una wallet.');
    const [native,wrapped]=await Promise.all([this.rpc.account(user),this.rpc.view(WNEAR,'ft_balance_of',{account_id:user})]);
    const amount=units(input.amount!),deficit=amount>BigInt(wrapped)?amount-BigInt(wrapped):0n;
    if(BigInt(native.amount)-BigInt(native.storage_usage)*10000000000000000000n<deficit+units(process.env.GAS_RESERVE_NEAR||'0.1'))throw new Error('NEAR disponible insuficiente para wrap y reserva.');
    this.history.update(row.id,{status:'PREPARING',wrappedBefore:wrapped,targetRaw:amount.toString(),deficitRaw:deficit.toString()});
    if(input.mode==='REAL')await this.ex.exclusive(()=>clock.measure('wnearPreparation',()=>prepareWnear(this.ex,row.id,amount)));
    this.history.update(row.id,{status:input.mode==='REAL'?'READY':'ANALYZED'});
   }else if(input.side==='BUY'||input.side==='ARM'){
    // Pagar con NEAR un token que cotiza en otro token (RHEA…): se planifica el cambio NEAR → quote y la compra se analiza con lo que se espera recibir.
    let bridge:BridgePlan|null=null,amountText=input.amount!;
    if(input.side==='BUY'&&input.payWith==='NEAR'){
     const d0=await discover(this.rpc,extractToken(input.url));
     if(d0.quoteAsset.id!==WNEAR){
      bridge=await planBridge(this.rpc,d0.quoteAsset,units(input.amount!),input.slippageBps);
      amountText=display(bridge.expectedRaw,d0.quoteAsset.decimals);
      this.history.update(row.id,{bridge:bridgeRecord(bridge)});
     }
    }
    const analysis=await analyze(this.rpc,{url:input.url,amount:amountText,slippageBps:input.slippageBps},this.config(),{freshQuoteAtSwap:input.mode==='REAL',skipQuoteBalance:!!bridge});
    clock.mark('discoveryAndAnalysis',analysis.timings.totalMs);
    this.history.update(row.id,{analysis,quoteAsset:analysis.quoteAsset,costRaw:analysis.amountRaw,status:input.mode==='REAL'?'PREPARING':'ANALYZED'});
    // Los límites de riesgo (impacto de precio, liquidez, ida y vuelta) frenan la compra REAL salvo que se pida ignorarlos.
    if(input.side==='ARM'){
     // Armar no compra: deja registro de almacenamiento y wNEAR listos. Sin REAL solo analiza.
     if(input.mode==='REAL'){await arm(this.ex,row.id,analysis,BigInt(analysis.amountRaw),input.slippageBps);this.history.update(row.id,{status:'READY'});}
     else this.history.update(row.id,{status:'ANALYZED'});
     return;
    }
    if(input.mode==='REAL'&&analysis.risk?.blocked&&!input.allowRisk)throw new Error(`Compra bloqueada por riesgo: ${analysis.risk.blocked} Podés forzarla marcando «ignorar bloqueo de riesgo».`);
    if(bridge&&bridge.risk.blocked&&input.mode==='REAL'&&!input.allowRisk)throw new Error(`Cambio a ${bridge.asset.symbol} bloqueado por riesgo: ${bridge.risk.blocked} Podés forzarlo marcando «ignorar bloqueo de riesgo».`);
    if(input.mode==='REAL'&&bridge){
     checkSpend(this.history.rows,row.id,WNEAR,bridge.inRaw);                    // el tope se mide en NEAR, que es lo que se gasta de verdad
     const received=await bridgeToQuote(this.ex,row.id,bridge,input.slippageBps);
     // Con el importe real recibido se vuelve a analizar (cotización fresca, saldo del quote ya disponible) y se compra el token.
     const real=await analyze(this.rpc,{url:input.url,amount:display(received,bridge.asset.decimals),slippageBps:input.slippageBps},this.config(),{freshQuoteAtSwap:true});
     if(real.risk?.blocked&&!input.allowRisk)throw new Error(`Compra bloqueada por riesgo: ${real.risk.blocked} Ya cambiaste NEAR por ${display(received,bridge.asset.decimals)} ${bridge.asset.symbol}: quedan en tu wallet.`);
     this.history.update(row.id,{analysis:real,costRaw:real.amountRaw});
     await buy(this.ex,row.id,real,BigInt(real.amountRaw),input.slippageBps);
    }else if(input.mode==='REAL'){
     checkSpend(this.history.rows,row.id,quoteAsset(analysis).id,BigInt(analysis.amountRaw));
     await buy(this.ex,row.id,analysis,BigInt(analysis.amountRaw),input.slippageBps);
    }
   }else{
    const position=await this.position(input.url,input.slippageBps,input.percentage!);
    if(row.buyId){const original=this.history.rows.find(r=>r.id===row.buyId);const boughtQuote=original.analysis?quoteAsset(original.analysis).id:original.swapSnapshot?.input;if(boughtQuote!==position.quoteAsset.id)throw new Error('El quote del launch cambió desde la compra; venta preparada bloqueada.');}
    if(BigInt(position.amountRaw)<=0n)throw new Error('No tenés saldo de ese token para vender.');
    this.history.update(row.id,{position,quoteAsset:position.quoteAsset,amountRaw:position.amountRaw,status:input.mode==='REAL'?'PREPARING':'ANALYZED_SELL'});
    if(input.mode==='REAL')await sell(this.ex,row.id,position,BigInt(position.amountRaw),input.slippageBps);
   }
  }catch(e){
   const latest=this.history.rows.find(r=>r.id===row.id);
   const kept=latest?.bridge?.status==='DONE'&&latest.bridge.receivedRaw?` (Ya cambiaste NEAR por ${display(latest.bridge.receivedRaw,latest.bridge.quoteDecimals)} ${latest.bridge.quoteSymbol}: quedaron en tu wallet.)`:'';
   this.history.update(row.id,{status:['UNKNOWN','SETTLING'].includes(latest?.status)?'UNKNOWN':'FAILED',error:(e instanceof Error?e.message:'Falló la operación.')+(/quedan en tu wallet|quedaron en tu wallet/.test(e instanceof Error?e.message:'')?'':kept)});
  }finally{this.history.update(row.id,{elapsedMs:Math.round(performance.now()-start)});clock.mark('completed');endTimeline(this.history,row.id);this.active=false;this.drainSales();}
 }
 async position(url:string,bps:number,percentage=50,includeUsd=false){
  const token=extractToken(url);checkRisk('0.000000000000000000000001',bps,this.config().maxNear,this.config().maxBps);
  const user=this.config().accountId;if(!user)throw new Error('Conectá una wallet.');
  if(this.rpc.mainnet)await this.rpc.mainnet();else {const network=await this.rpc.status();if(network.chain_id!=='mainnet')throw new Error('RPC de red incorrecta.');}
  const [d,balance]=await Promise.all([discover(this.rpc,token),this.rpc.view(token,'ft_balance_of',{account_id:user})]);
  if(!/^\d+$/.test(String(balance)))throw new Error('Saldo del token inválido.');
  const balanceRaw=BigInt(balance);
  const result={token,...d,balanceRaw:balanceRaw.toString(),balance:display(balanceRaw,d.metadata.decimals),percentage,amountRaw:'0',amount:'0',quotation:null as any};
  if(balanceRaw===0n)return {...result,usdValuation:includeUsd?await estimateUsd(this.rpc,result,0n,bps):null};
  if(!d.direct)throw new Error('El token necesita una ruta múltiple: venta bloqueada.');
  const amount=percentageAmount(balanceRaw,percentage);
  const asset=quoteAsset(result);
  let chosen:any=null;
  // Token genérico (varios pools posibles): se cotiza la venta en todos y gana la mayor salida.
  if(d.generic||d.routes.length>1){
   const ranked=await rankRoutes(this.rpc,d.routes,token,asset.id,afterTax(amount,taxRate(d.tax,'sell')),bps,false);
   const best=bestRoute(ranked);
   if(!best)throw new Error(`Ningún pool directo puede cotizar esta venta: ${ranked.map(r=>`${r.route.venue} ${r.route.poolId}: ${r.error}`).join(' · ')}`);
   chosen=best;result.route=best.route;result.record={...result.record,pool_id:best.route.poolId};
  }
  const [q,usdValuation]=await Promise.all([chosen?Promise.resolve(chosen.quote):executableExit(this.rpc,result,amount,bps),includeUsd?estimateUsd(this.rpc,result,balanceRaw,bps,undefined,quoteNearPrice):Promise.resolve(null)]);
  return {...result,usdValuation,amountRaw:amount.toString(),amount:display(amount,d.metadata.decimals),quotation:{...q,expectedQuote:display(q.raw,asset.decimals),minimumQuote:display(q.minRaw,asset.decimals),...(asset.id===WNEAR?{expectedNear:display(q.raw),minimumNear:display(q.minRaw)}:{})}};
 }
 async reconcile(id:string){
  if(this.active)throw new Error('Esperá a que termine la operación actual.');
  const row=this.history.rows.find(r=>r.id===id);if(!row?.txHash||!row.signer)throw new Error('No hay una transacción incierta para consultar.');
  return this.recovery.reconcile(id);
 }
}
