import {NearRpc} from './rpc.js';
import {tokenMetadata,WRAPPED_NEAR} from './quote-asset.js';
import {FACTORY,DCL,REF_V1} from './constants.js';
import {findRoutes,routeFromRecord} from './venues.js';
export {FACTORY,DCL,REF_V1};
export const WNEAR=WRAPPED_NEAR;
// El token existe pero todavía no hay dónde comprarlo (sin pool, o lanzamiento aún sin graduar). Lo distingue la vigilancia de pools nuevos.
export class PoolNotReady extends Error{constructor(message:string){super(message);this.name='PoolNotReady';}}
// Tokens lanzados en Nearly usan la fábrica (pool y reglas oficiales). Cualquier otro token NEP-141 se opera en
// pools directos token/wNEAR de Rhea DCL y Ref v1, que es donde terminan los lanzamientos de meme.cooking,
// Shore, JustHoot, tkn.near, etc.
export async function discover(rpc:NearRpc,token:string){
 const staticInfo=()=>Promise.all([rpc.account(token),rpc.view(token,'ft_metadata')]);
 const [[account,metadata],record]=await Promise.all([rpc.metadata?rpc.metadata(token,staticInfo):staticInfo(),rpc.view(FACTORY,'get_launch_by_token',{token})]);
 const deployed=(account.code_hash&&!/^1+$/.test(account.code_hash))||account.global_contract_hash||account.global_contract_account_id;
 if(!deployed||metadata.spec!=='ft-1.0.0'||!Number.isInteger(metadata.decimals)||metadata.decimals<0||metadata.decimals>38)throw new Error('Contrato no compatible con NEP-141.');
 if(!record)return discoverGeneric(rpc,token,metadata);
 if(record.token!==token)throw new Error('Lanzamiento no disponible para operar.');
 if(record.step!=='Done')throw new PoolNotReady('Lanzamiento todavía sin pool: no está disponible para operar.');
 const quoteId=record.quote??WNEAR;
 const [pool,tax,rules,quoteAsset]=await Promise.all([rpc.view(DCL,'get_pool',{pool_id:record.pool_id}),rpc.view(FACTORY,'get_tax',{launch_id:String(record.id)}),rpc.view(token,'get_rules'),tokenMetadata(rpc,quoteId)]);
 if(!pool||![pool.token_x,pool.token_y].includes(token))throw new Error('El pool no coincide con el token.');
 if(pool.state!=='Running')throw new PoolNotReady('El pool todavía no está activo.');
 const direct=quoteId!==token&&[pool.token_x,pool.token_y].includes(quoteId);
 if(!direct)throw new Error(`Quote ${quoteId} no soportado por el pool DCL ${record.pool_id}: se requiere un par directo token/quote; no se permiten rutas multi-hop.`);
 const recordInfo={id:record.id,token:record.token,pool_id:record.pool_id,quote:quoteId,step:record.step};
 const route=routeFromRecord({token,pool_id:record.pool_id,quote:quoteId},Number(pool.fee)||0);
 const tokenIsX=pool.token_x===token;
 route.info={liquidity:String(pool.liquidity??'0'),currentPoint:Number(pool.current_point),totalQuote:String((tokenIsX?pool.total_y:pool.total_x)??'0'),totalToken:String((tokenIsX?pool.total_x:pool.total_y)??'0')};
 return {metadata:{name:metadata.name,symbol:metadata.symbol,decimals:metadata.decimals},quoteAsset,record:recordInfo,pool,tax,rules,direct,generic:false,route,routes:[route]};
}
async function discoverGeneric(rpc:NearRpc,token:string,metadata:any){
 const [routes,quoteAsset]=await Promise.all([findRoutes(rpc,token,WNEAR),tokenMetadata(rpc,WNEAR)]);
 if(!routes.length)throw new PoolNotReady('Sin pools directos token/wNEAR en Rhea DCL ni Ref v1: todavía no hay dónde comprar este token.');
 const route=routes[0];
 return {metadata:{name:String(metadata.name??''),symbol:String(metadata.symbol??''),decimals:metadata.decimals as number},quoteAsset,record:{id:null,token,pool_id:route.poolId,quote:WNEAR,step:'Done',source:'GENERIC'},pool:null,tax:null,rules:null,direct:true,generic:true,route,routes};
}
