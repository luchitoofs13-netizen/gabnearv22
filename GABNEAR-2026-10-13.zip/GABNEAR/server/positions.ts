import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {units} from './validation.js';
import {routeFromRecord,type Route} from './venues.js';

export type Trigger='STOP_LOSS'|'TRAILING_STOP'|'TAKE_PROFIT'|'MANUAL_EXIT';
export type ExitSettings={enabled:boolean;takeProfitPct:number|null;stopLossPct:number|null;trailingPct:number|null;tpSellPct:50|99|100;slippageBps:number;confirmTicks:number;gasCostNear:string};
export const defaultSettings=():ExitSettings=>({enabled:false,takeProfitPct:null,stopLossPct:null,trailingPct:null,tpSellPct:100,slippageBps:500,confirmTicks:2,gasCostNear:'0.005'});

const pct=(v:unknown,name:string,max:number):number|null=>{
 if(v===null||v===undefined||v==='')return null;
 const n=Number(v);if(!Number.isFinite(n)||n<=0||n>max)throw new Error(`${name} debe ser un número entre 0 y ${max}.`);
 return Math.round(n*100)/100;
};
// Valida y completa ajustes parciales. Nunca devuelve valores fuera de rango.
export function parseSettings(raw:any,base:ExitSettings=defaultSettings()):ExitSettings{
 const r=raw&&typeof raw==='object'?raw:{};const s={...base};
 if('takeProfitPct' in r)s.takeProfitPct=pct(r.takeProfitPct,'Take profit %',100000);
 if('stopLossPct' in r)s.stopLossPct=pct(r.stopLossPct,'Stop loss %',99.9);
 if('trailingPct' in r)s.trailingPct=pct(r.trailingPct,'Trailing stop %',99.9);
 if('tpSellPct' in r){if(![50,99,100].includes(r.tpSellPct))throw new Error('El take profit vende 50%, 99% o 100%.');s.tpSellPct=r.tpSellPct;}
 if('slippageBps' in r){if(!Number.isInteger(r.slippageBps)||r.slippageBps<1||r.slippageBps>9900)throw new Error('Slippage de salida inválido (1–9900 bps).');s.slippageBps=r.slippageBps;}
 if('confirmTicks' in r){if(!Number.isInteger(r.confirmTicks)||r.confirmTicks<1||r.confirmTicks>10)throw new Error('Las confirmaciones deben ser un entero de 1 a 10.');s.confirmTicks=r.confirmTicks;}
 if('gasCostNear' in r){try{if(units(String(r.gasCostNear))>units('1'))throw new Error();}catch{throw new Error('Costo de gas estimado inválido (0–1 NEAR).');}s.gasCostNear=String(r.gasCostNear);}
 const armed=s.takeProfitPct!==null||s.stopLossPct!==null||s.trailingPct!==null;
 if('enabled' in r){if(typeof r.enabled!=='boolean')throw new Error('enabled debe ser verdadero o falso.');s.enabled=r.enabled;if(s.enabled&&!armed)throw new Error('Definí al menos un take profit, stop loss o trailing stop para activar AUTO SELL.');}
 else if('takeProfitPct' in r||'stopLossPct' in r||'trailingPct' in r)s.enabled=armed;
 if(!armed)s.enabled=false;
 return s;
}

export type Position={
 id:string;signer:string;token:string;symbol:string;decimals:number;
 quote:{id:string;symbol:string;decimals:number};route:Route;launchId:string|null;sellBps:number;
 status:'OPEN'|'CLOSED';openedAt:string;updatedAt:string;closedAt?:string;closeReason?:string;
 tokensRaw:string;investedRaw:string;spentTotalRaw:string;proceedsTotalRaw:string;realizedRaw:string;feesTotalRaw:string;
 buyRows:string[];sellRows:string[];settings:ExitSettings;
 state:{peakNetRaw:string;lastExitRaw:string|null;lastNetRaw:string|null;lastPnlBps:number|null;lastCheckAt:string|null;lastError:string|null;streak:{trigger:Trigger;count:number}|null;tpDone:boolean;pending:{requestId:string;trigger:Trigger;percentage:50|99|100;at:string}|null;attempts:number;retryAt:string|null;pausedReason:string|null;events:{at:string;type:string;detail:string}[]};
};

export const WNEAR_ID='wrap.near';
const big=(v:unknown)=>BigInt((v as string)||'0');
export const isNearQuote=(p:Pick<Position,'quote'>)=>p.quote.id===WNEAR_ID;
export const gasEstimate=(p:Pick<Position,'quote'|'settings'>)=>isNearQuote(p)?units(p.settings.gasCostNear):0n;

// Decisión pura. `exitRaw` es la salida cotizada (en unidades del quote) de vender lo vendible. El costo de referencia
// es el costo promedio del remanente más el gas estimado de la venta (solo cuando el quote es wNEAR).
export function evaluateExit(p:Position,exitRaw:bigint){
 const cost=big(p.investedRaw);
 if(cost<=0n)return {pnlBps:null as number|null,netRaw:exitRaw,peakRaw:big(p.state.peakNetRaw),trigger:null as Trigger|null};
 const net=exitRaw-gasEstimate(p);
 const peak=net>big(p.state.peakNetRaw)?net:big(p.state.peakNetRaw);
 const pnlBps=Number((net-cost)*10000n/cost);
 const s=p.settings;let trigger:Trigger|null=null;
 if(s.stopLossPct!==null&&pnlBps<=-Math.round(s.stopLossPct*100))trigger='STOP_LOSS';
 else if(s.trailingPct!==null&&peak>cost&&net*10000n<=peak*BigInt(10000-Math.round(s.trailingPct*100)))trigger='TRAILING_STOP';
 else if(s.takeProfitPct!==null&&!p.state.tpDone&&pnlBps>=Math.round(s.takeProfitPct*100))trigger='TAKE_PROFIT';
 return {pnlBps,netRaw:net,peakRaw:peak,trigger};
}

const sumGas=(rows:any)=>(rows?.transactions??[]).reduce((s:bigint,t:any)=>s+big(t.gasBurnt),0n);
const sumStorage=(row:any)=>(row?.transactions??[]).reduce((s:bigint,t:any)=>t.method==='storage_deposit'&&t.status==='FINAL'?s+big(t.deposit):s,0n);
const fresh=():Position['state']=>({peakNetRaw:'0',lastExitRaw:null,lastNetRaw:null,lastPnlBps:null,lastCheckAt:null,lastError:null,streak:null,tpDone:false,pending:null,attempts:0,retryAt:null,pausedReason:null,events:[]});

export class PositionStore {
 positions:Position[]=[];
 readonly path:string;
 constructor(path='data/positions.json',readonly defaults:()=>ExitSettings=defaultSettings){
  this.path=resolve(path);
  if(existsSync(this.path))this.positions=JSON.parse(readFileSync(this.path,'utf8'));
 }
 save(){mkdirSync(dirname(this.path),{recursive:true});writeFileSync(this.path+'.tmp',JSON.stringify(this.positions,null,1));renameSync(this.path+'.tmp',this.path);}
 byId(id:string){return this.positions.find(p=>p.id===id);}
 open(signer:string,token:string){return this.positions.find(p=>p.status==='OPEN'&&p.signer===signer&&p.token===token);}
 onEvent?:(p:Position,type:string,detail:string)=>void;
 event(p:Position,type:string,detail:string){p.state.events=[{at:new Date().toISOString(),type,detail},...p.state.events].slice(0,25);p.updatedAt=new Date().toISOString();try{this.onEvent?.(p,type,detail);}catch{/* un aviso nunca rompe el libro */}}
 // Idempotente por id de fila: se puede llamar en cada cambio del historial y tras reinicios.
 ingest(row:any):Position|null{
  if(!row||row.mode!=='REAL'||!['FILLED','PARTIAL'].includes(row.status)||!row.signer||!row.token||!/^\d+$/.test(String(row.receivedRaw??'')))return null;
  if(row.side==='BUY')return this.ingestBuy(row);
  if(row.side==='SELL')return this.ingestSell(row);
  return null;
 }
 private ingestBuy(row:any):Position|null{
  const a=row.analysis;if(!a?.metadata||!a.quoteAsset)return null;
  if(this.positions.some(p=>p.buyRows.includes(row.id)))return null;
  const spent=big(row.usedRaw??row.costRaw??a.amountRaw),tokens=big(row.receivedRaw);
  if(tokens<=0n||spent<=0n)return null;
  const quote={id:a.quoteAsset.id,symbol:a.quoteAsset.symbol,decimals:a.quoteAsset.decimals};
  const fees=quote.id===WNEAR_ID?sumGas(row)+sumStorage(row):0n;
  let p=this.open(row.signer,row.token);
  if(!p){
   const route:Route=a.route??routeFromRecord({token:row.token,pool_id:a.record.pool_id,quote:quote.id});
   const now=new Date().toISOString();
   p={id:randomUUID(),signer:row.signer,token:row.token,symbol:a.metadata.symbol,decimals:a.metadata.decimals,quote,route,launchId:a.record?.id!=null?String(a.record.id):null,sellBps:Number(a.tax?.sell_bps??0)||0,status:'OPEN',openedAt:row.at??now,updatedAt:now,tokensRaw:'0',investedRaw:'0',spentTotalRaw:'0',proceedsTotalRaw:'0',realizedRaw:'0',feesTotalRaw:'0',buyRows:[],sellRows:[],settings:parseSettings(row.autoSell??{},this.defaults()),state:fresh()};
   this.positions.unshift(p);
  }
  p.tokensRaw=(big(p.tokensRaw)+tokens).toString();p.investedRaw=(big(p.investedRaw)+spent+fees).toString();
  p.spentTotalRaw=(big(p.spentTotalRaw)+spent).toString();p.feesTotalRaw=(big(p.feesTotalRaw)+fees).toString();p.buyRows.push(row.id);
  if(row.autoSell&&p.buyRows.length>1)p.settings=parseSettings(row.autoSell,p.settings);
  if(a.route)p.route=a.route;
  this.event(p,'BUY',`+${tokens} tokens por ${spent} ${quote.symbol}`);this.save();return p;
 }
 private ingestSell(row:any):Position|null{
  const p=this.positions.find(x=>x.status==='OPEN'&&x.signer===row.signer&&x.token===row.token);
  if(!p||this.positions.some(x=>x.sellRows.includes(row.id)))return null;
  const sold0=big(row.usedRaw??row.amountRaw),proceeds=big(row.receivedRaw),have=big(p.tokensRaw);
  const sold=sold0>have?have:sold0;if(sold<=0n)return null;
  const costOut=have>0n?big(p.investedRaw)*sold/have:0n;
  const fees=p.quote.id===WNEAR_ID?sumGas(row)+sumStorage(row):0n;
  p.tokensRaw=(have-sold).toString();p.investedRaw=(big(p.investedRaw)-costOut).toString();
  p.proceedsTotalRaw=(big(p.proceedsTotalRaw)+proceeds).toString();p.feesTotalRaw=(big(p.feesTotalRaw)+fees).toString();
  p.realizedRaw=(big(p.realizedRaw)+proceeds-costOut-fees).toString();p.sellRows.push(row.id);
  this.event(p,'SELL',`-${sold} tokens → ${proceeds} ${row.outputToken==='NEAR'?'NEAR':p.quote.symbol}`);
  if(big(p.tokensRaw)<=0n)this.close(p,'Posición vendida por completo.');
  this.save();return p;
 }
 close(p:Position,reason:string){p.status='CLOSED';p.closedAt=new Date().toISOString();p.closeReason=reason;p.settings.enabled=false;p.state.pending=null;this.event(p,'CLOSED',reason);}
 // Recorre el historial completo (arranque y recuperaciones tardías).
 syncAll(rows:any[]){let changed=false;for(const row of [...rows].reverse())if(this.ingest(row))changed=true;return changed;}
 // Posición importada a mano (tokens comprados por fuera de GABNEAR): el usuario declara el costo.
 importPosition(input:{signer:string;token:string;symbol:string;decimals:number;quote:Position['quote'];route:Route;launchId:string|null;sellBps:number;tokensRaw:bigint;costRaw:bigint;settings?:any}){
  if(this.open(input.signer,input.token))throw new Error('Ya hay una posición abierta de ese token.');
  if(input.tokensRaw<=0n||input.costRaw<=0n)throw new Error('Saldo y costo deben ser positivos.');
  const now=new Date().toISOString();
  const p:Position={id:randomUUID(),signer:input.signer,token:input.token,symbol:input.symbol,decimals:input.decimals,quote:input.quote,route:input.route,launchId:input.launchId,sellBps:input.sellBps,status:'OPEN',openedAt:now,updatedAt:now,tokensRaw:input.tokensRaw.toString(),investedRaw:input.costRaw.toString(),spentTotalRaw:input.costRaw.toString(),proceedsTotalRaw:'0',realizedRaw:'0',feesTotalRaw:'0',buyRows:[],sellRows:[],settings:parseSettings(input.settings??{},this.defaults()),state:fresh()};
  this.event(p,'IMPORTED',`Posición importada: ${input.tokensRaw} tokens, costo declarado ${input.costRaw}.`);
  this.positions.unshift(p);this.save();return p;
 }
}
