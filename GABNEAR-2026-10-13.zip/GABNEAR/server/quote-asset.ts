import {NearRpc} from './rpc.js';
import {units,display,checkRisk} from './validation.js';
import {WRAPPED_NEAR} from './constants.js';
export {WRAPPED_NEAR};
export type QuoteAsset={id:string;name:string;symbol:string;decimals:number};
export function quoteAsset(position:any):QuoteAsset {
 const id=position.record?.quote??WRAPPED_NEAR;
 if(position.quoteAsset?.id===id)return position.quoteAsset;
 if(id===WRAPPED_NEAR)return {id,name:'Wrapped NEAR',symbol:'wNEAR',decimals:24};
 throw new Error(`Faltan metadatos NEP-141 del quote ${id}. Volvé a analizar el launch.`);
}
export function ftRaw(value:unknown):bigint {
 if(typeof value!=='string'||!/^\d+$/.test(value)||BigInt(value)>2n**128n-1n)throw new Error('Saldo/importe NEP-141 inválido.');
 return BigInt(value);
}
export async function tokenMetadata(rpc:NearRpc,id:string):Promise<QuoteAsset>{
 if(typeof id!=='string'||id.length<2||id.length>64||!/^[a-z0-9]+(?:[-_][a-z0-9]+)*(?:\.[a-z0-9]+(?:[-_][a-z0-9]+)*)*$/.test(id))throw new Error('Cuenta del quote NEP-141 inválida.');
 const work=()=>Promise.all([rpc.account(id),rpc.view(id,'ft_metadata')]);
 try{
  const [account,m]=await (rpc.metadata?rpc.metadata(id,work):work());
  const deployed=(account.code_hash&&!/^1+$/.test(account.code_hash))||account.global_contract_hash||account.global_contract_account_id;
  if(!deployed||m?.spec!=='ft-1.0.0'||!Number.isInteger(m.decimals)||m.decimals<0||m.decimals>38||typeof m.symbol!=='string'||typeof m.name!=='string')throw new Error('metadatos o contrato inválidos');
  if(id===WRAPPED_NEAR&&m.decimals!==24)throw new Error('decimales wNEAR inválidos');
  return {id,name:m.name,symbol:m.symbol,decimals:m.decimals};
 }catch(error){throw new Error(`Token ${id} no compatible con NEP-141: ${(error as Error).message}`);}
}
export function quoteAmount(value:string,asset:QuoteAsset,bps:number,maxNear:string,maxBps:number):bigint {
 checkRisk('0.000000000000000000000001',bps,maxNear,maxBps);
 const amount=units(value,asset.decimals);
 if(amount<=0n||amount>2n**128n-1n)throw new Error(`Importe inválido para ${asset.symbol} (${asset.id}): debe ser positivo y representable como NEP-141 u128.`);
 return amount;
}
export function insufficientQuote(asset:QuoteAsset,balance:bigint,amount:bigint){
 return new Error(`Saldo insuficiente de ${asset.symbol} (${asset.id}): disponible ${display(balance,asset.decimals)}, requerido ${display(amount,asset.decimals)}. Este token se compra con ${asset.symbol}, NO con NEAR, y no se convierte NEAR automáticamente: comprá primero ${asset.symbol} (se compra con NEAR como cualquier token) y volvé.`);
}
