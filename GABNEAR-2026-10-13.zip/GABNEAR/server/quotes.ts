import {NearRpc} from './rpc.js';
import {DCL} from './constants.js';
export function taxRate(tax:any,side:'buy'|'sell'){
 const rate=Number(tax?.[side+'_bps']??0);
 if(!Number.isInteger(rate)||rate<0||rate>400)throw new Error('Impuesto desconocido o fuera de rango.');
 return rate;
}
export function afterTax(amount:bigint,rate:number){
 if(!Number.isInteger(rate)||rate<0||rate>400)throw new Error('Impuesto inválido.');
 return amount*BigInt(10000-rate)/10000n;
}
export function percentageAmount(balance:bigint,percentage:number){
 if(!Number.isInteger(percentage)||percentage<1||percentage>100||balance<=0n)throw new Error('Sin saldo para vender o porcentaje inválido.');
 const amount=balance*BigInt(percentage)/100n;
 if(amount<=0n)throw new Error('Saldo demasiado pequeño para ese porcentaje.');
 return amount;
}
export async function quote(rpc:NearRpc,poolId:string,input:string,output:string,amount:bigint,slippageBps:number){
 if(!Number.isInteger(slippageBps)||slippageBps<1||slippageBps>9900)throw new Error('Slippage debe estar entre 0,01% y 99%.');
 const result=await rpc.view(DCL,'quote',{pool_ids:[poolId],input_token:input,output_token:output,input_amount:amount.toString(),tag:null});
 if(!result||!/^\d+$/.test(String(result.amount))||BigInt(result.amount)<=0n)throw new Error('La liquidez no permite cotizar este importe.');
 const min=BigInt(result.amount)*BigInt(10000-slippageBps)/10000n;
 if(min<=0n)throw new Error('Salida mínima nula.');
 return {raw:String(result.amount),minRaw:min.toString(),quotedAt:new Date().toISOString()};
}
