import {performance} from 'node:perf_hooks';
import type {History} from './history.js';
import type {Executor} from './transactions.js';
import {inspectOutcome,slimOutcome,isUnknownTransaction,TX_VALIDITY_BLOCKS} from './transactions.js';
import {FINAL_ONLY} from './finality.js';
import {recordStage} from './timing.js';
import {DCL,WNEAR,REF_V1} from './pools.js';
const EXCHANGES=[DCL,REF_V1];
export const recoveringStates=['UNKNOWN','SUBMITTING','SENT','CONFIRMING','SETTLING','CONFIRMED_UNMEASURED','VERIFYING_TOKENS'];
export function blocksAccount(row:any,account:string,token?:string){
 if(row.mode==='DRY RUN'||!recoveringStates.includes(row.status)||(row.signer&&row.signer!==account))return false;
 // FINAL resuelve nonce, gas y entrada. La siguiente orden relee fondos y nonce.
 // Una posición no verificada sigue bloqueando únicamente el token afectado.
 if(row.lastOutcome?.final_execution_status==='FINAL')return token!==undefined&&(!row.token||row.token===token);
 return true;
}
// Evidencia atribuible a ESTE hash, no a un balance posterior que otra operación pudo alterar.
export function receivedFromReceipts(outcome:any,token:string,owner:string,accept:readonly string[]=FINAL_ONLY):bigint|null{
 if(!accept.includes(outcome?.final_execution_status))return null;
 let net=0n,found=false;const seen=new Set<string>();
 for(const r of outcome.receipts_outcome??[]){
  if(r.outcome?.executor_id!==token||r.outcome.status?.Failure||seen.has(r.id))continue;
  seen.add(r.id);
  for(const log of r.outcome.logs??[]){if(!log.startsWith('EVENT_JSON:'))continue;
   try{const e=JSON.parse(log.slice(11));if(e.standard!=='nep141'||!Array.isArray(e.data))continue;
    for(const d of e.data){if(typeof d.amount!=='string'||!/^\d+$/.test(d.amount))continue;const n=BigInt(d.amount);
     if(e.event==='ft_transfer'){if(d.new_owner_id===owner){net+=n;found=true;}if(d.old_owner_id===owner){net-=n;found=true;}}
     if(e.event==='ft_mint'&&d.owner_id===owner){net+=n;found=true;}
     if(e.event==='ft_burn'&&d.owner_id===owner){net-=n;found=true;}
    }
   }catch{/* Un log mal formado no constituye evidencia. */}
  }
 }
 return found&&net>=0n?net:null;
}
export function nativeFromWithdrawReceipts(details:any,owner:string,accept:readonly string[]=FINAL_ONLY):bigint|null{
 if(!accept.includes(details?.final_execution_status))return null;
 const outcomes=new Map((details.receipts_outcome??[]).map((r:any)=>[r.id,r.outcome]));let total=0n,found=false;
 let withdrawn=0n;
 for(const r of details.receipts??[]){if(!EXCHANGES.includes(r.predecessor_id)||r.receiver_id!==WNEAR)continue;const outcome:any=outcomes.get(r.receipt_id);if(!outcome||outcome.status?.Failure)continue;
  for(const action of r.receipt?.Action?.actions??[]){if(action.FunctionCall?.method_name!=='near_withdraw')continue;
   try{const a=JSON.parse(Buffer.from(action.FunctionCall.args,'base64').toString());if(typeof a.amount==='string'&&/^\d+$/.test(a.amount))withdrawn+=BigInt(a.amount);}catch{}
  }
 }
 for(const receipt of details.receipts??[]){
  // Reembolsos del sistema no son venta ni retiro de wrap.near.
  if(![WNEAR,...EXCHANGES].includes(receipt.predecessor_id)||receipt.receiver_id!==owner)continue;
  const outcome:any=outcomes.get(receipt.receipt_id);if(!outcome||outcome.status?.Failure||!('SuccessValue' in (outcome.status??{})))continue;
  for(const action of receipt.receipt?.Action?.actions??[]){const amount=action.Transfer?.deposit;if(typeof amount==='string'&&/^\d+$/.test(amount)){total+=BigInt(amount);found=true;}}
 }
 return found&&withdrawn>0n&&total<=withdrawn?total:null;
}
// Tokens que no emiten eventos NEP-297: se lee el `ft_transfer` que el exchange le hizo al usuario DENTRO de los recibos
// de este hash. Es el importe bruto transferido (un impuesto de transferencia del token no es visible aquí).
export function receivedFromTransferArgs(details:any,token:string,owner:string,accept:readonly string[]=FINAL_ONLY):bigint|null{
 if(!accept.includes(details?.final_execution_status))return null;
 const outcomes=new Map((details.receipts_outcome??[]).map((r:any)=>[r.id,r.outcome]));let total=0n,found=false;
 for(const receipt of details.receipts??[]){
  if(receipt.receiver_id!==token||!EXCHANGES.includes(receipt.predecessor_id))continue;
  const outcome:any=outcomes.get(receipt.receipt_id);if(!outcome||outcome.status?.Failure)continue;
  for(const action of receipt.receipt?.Action?.actions??[]){
   if(action.FunctionCall?.method_name!=='ft_transfer')continue;
   try{const a=JSON.parse(Buffer.from(action.FunctionCall.args,'base64').toString());if(a.receiver_id===owner&&typeof a.amount==='string'&&/^\d+$/.test(a.amount)){total+=BigInt(a.amount);found=true;}}catch{/* args ilegibles no son evidencia */}
  }
 }
 return found&&total>0n?total:null;
}
// Evidencia atribuible a ESTE hash, de la más a la menos precisa: eventos NEP-141 → retiro nativo de wrap.near → ft_transfer.
export async function resolveReceived(rpc:{transactionDetails?:(hash:string,signer:string)=>Promise<any>},outcome:any,hash:string|undefined,owner:string,output:string,accept:readonly string[]=FINAL_ONLY):Promise<{amount:bigint;asset:string;evidence:string}|null>{
 const events=receivedFromReceipts(outcome,output,owner,accept);
 if(events!==null)return {amount:events,asset:output,evidence:'nep141-receipts'};
 if(!hash||!rpc.transactionDetails)return null;
 const details=await rpc.transactionDetails(hash,owner);
 if(output===WNEAR){const native=nativeFromWithdrawReceipts(details,owner,accept);if(native!==null)return {amount:native,asset:'NEAR',evidence:'wrap-withdraw-receipts'};}
 const transferred=receivedFromTransferArgs(details,output,owner,accept);
 return transferred!==null?{amount:transferred,asset:output,evidence:'ft-transfer-args'}:null;
}
export class Recovery {
 private inFlight=new Set<string>();
 private due=new Map<string,{at:number;attempts:number}>();
 constructor(readonly history:History,readonly ex:Executor,readonly onResolved:()=>void=()=>{}){}
 private release(row:any,reason:string,status='FAILED'){
  const transactions=(row.transactions??[]).map((t:any)=>t.hash===row.txHash?{...t,status:'NEVER_EXECUTED',releasedAt:new Date().toISOString()}:t);
  this.history.update(row.id,{status,fundsSent:false,transactions,error:`${reason} No se ejecutó; cuenta liberada.`,recovery:{released:true,reason,observedAt:new Date().toISOString()}});
 }
 // La red responde UnknownTransaction. Solo se libera con prueba de que NUNCA se ejecutará:
 // (a) venció su ventana de validez, o (b) su nonce fue consumido por otra transacción.
 private async releaseIfNeverExecuted(row:any):Promise<boolean>{
  const tx=(row.transactions??[]).find((t:any)=>t.hash===row.txHash);if(!tx||row.lastOutcome?.final_execution_status==='FINAL')return false;
  try{
   const height=Number((await this.ex.rpc.status()).sync_info.latest_block_height);
   if(Number.isFinite(tx.blockHeight)&&Number.isFinite(height)&&height>tx.blockHeight+TX_VALIDITY_BLOCKS+100){this.release(row,`La transacción venció (${TX_VALIDITY_BLOCKS} bloques) sin llegar a ejecutarse.`);return true;}
   if(tx.sendError==='NONCE'&&tx.signedAt&&Date.now()-Date.parse(tx.signedAt)>30000){
    const key:any=await this.ex.rpc.deadline(this.ex.rpc.provider.viewAccessKey({accountId:row.signer,publicKey:tx.publicKey,finalityQuery:{finality:'final'}}));
    if(BigInt(key.nonce)>=BigInt(tx.nonce)){this.release(row,'El nonce fue consumido por otra transacción y la red no conoce este hash.');return true;}
   }
  }catch{/* Sin prueba suficiente se mantiene la recuperación. */}
  return false;
 }
 // Descarte manual: exige que la red siga sin conocer el hash pasados 3 minutos desde la firma
 // (cubre la ventana de reintentos internos del provider). El usuario asume que no se ejecutará.
 async discard(id:string){
  const row=this.history.rows.find(r=>r.id===id);
  if(!row||!recoveringStates.includes(row.status)||!row.txHash||!row.signer)throw new Error('La operación no está pendiente de recuperación.');
  if(row.lastOutcome?.final_execution_status==='FINAL')throw new Error('La transacción ya tiene resultado final; no se puede descartar.');
  const tx=(row.transactions??[]).find((t:any)=>t.hash===row.txHash);const signedAt=tx?.signedAt?Date.parse(tx.signedAt):NaN;
  if(!Number.isFinite(signedAt)||Date.now()-signedAt<180000)throw new Error('Esperá al menos 3 minutos desde la firma antes de descartar.');
  const known=await this.ex.lookup(row.txHash,row.signer);
  if(known==='KNOWN')throw new Error('La red conoce esta transacción: no se puede descartar, se recupera sola.');
  if(known==='ERROR')throw new Error('No se pudo confirmar con la red si la transacción existe. Reintentá.');
  this.release(row,'Descartada manualmente: pasaron más de 3 minutos y la red sigue sin conocer el hash.');
  return this.history.rows.find(r=>r.id===id);
 }
 async tick(){
  for(const r of this.history.rows){if(!recoveringStates.includes(r.status)||!r.txHash||!r.signer||this.ex.busy)continue;
   if((this.due.get(r.id)?.at??0)>Date.now())continue;
   await this.reconcile(r.id);
  }
  await this.watchFinality();
 }
 // Operaciones dadas por hechas en estado optimista (confirmación rápida): se verifica en segundo plano que lleguen a FINAL.
 // Si el hash deja de existir en la red (reorganización, extremadamente raro) la fila vuelve a UNKNOWN y se recupera por hash, sin reenviar.
 private finalityDue=new Map<string,number>();
 private misses=new Map<string,number>();
 lostAfterMisses=20;
 async watchFinality(){
  let checked=0;
  for(const r of this.history.rows){
   if(r.finality!=='OPTIMISTIC'||!r.txHash||!r.signer||!['FILLED','PARTIAL','READY'].includes(r.status))continue;
   if((this.finalityDue.get(r.id)??0)>Date.now())continue;
   if(++checked>3)break;
   this.finalityDue.set(r.id,Date.now()+1500);
   try{
    const out:any=await this.ex.reconcile(r.txHash,r.signer);
    if(out?.final_execution_status==='FINAL'){
     const transactions=(r.transactions??[]).map((t:any)=>t.hash===r.txHash?{...t,status:'FINAL',finalObservedAt:new Date().toISOString()}:t);
     this.history.update(r.id,{finality:'FINAL',transactions});this.misses.delete(r.id);this.finalityDue.delete(r.id);
    }
   }catch(error){
    if(!isUnknownTransaction(error))continue;
    const n=(this.misses.get(r.id)??0)+1;this.misses.set(r.id,n);
    if(n>=this.lostAfterMisses){
     this.misses.delete(r.id);
     this.history.update(r.id,{status:'UNKNOWN',finality:'LOST',error:'La transacción confirmada de forma optimista ya no aparece en la red (posible reorganización). GABNEAR la recupera por hash, sin reenviar.'});
    }
   }
  }
 }
 async reconcile(id:string){
  const row=this.history.rows.find(r=>r.id===id);if(!row?.txHash||!row.signer)return row;
  if(this.inFlight.has(id))return row;this.inFlight.add(id);
  const started=performance.now();let phase='blockchainFinal',phaseStarted=started;const attempts=(this.due.get(id)?.attempts??0)+1;
  try{
   const outcome:any=await this.ex.reconcile(row.txHash,row.signer);
   if(outcome.transaction?.hash&&outcome.transaction.hash!==row.txHash)throw new Error('RPC devolvió un hash diferente.');
   if(outcome.transaction?.signer_id&&outcome.transaction.signer_id!==row.signer)throw new Error('RPC devolvió otra cuenta firmante.');
   if(outcome.final_execution_status!=='FINAL'){
    this.history.update(id,{status:'CONFIRMING',fundsSent:true,recovery:{attempts,observedAt:new Date().toISOString(),chainStatus:outcome.final_execution_status}});return row;
   }
   const transactions=(row.transactions??[]).map((t:any)=>t.hash===row.txHash?{...t,status:'FINAL',gasBurnt:[outcome.transaction_outcome,...outcome.receipts_outcome??[]].reduce((s:bigint,r:any)=>s+BigInt(r?.outcome?.tokens_burnt??'0'),0n).toString(),finalObservedAt:new Date().toISOString()}:t);
   this.history.update(id,{lastOutcome:slimOutcome(outcome),transactions,fundsSent:true,status:'VERIFYING_TOKENS',error:undefined,recovery:{attempts,observedAt:new Date().toISOString(),chainStatus:'FINAL'}});
   if(!row.timing?.events?.some((e:any)=>e.stage==='blockchainFinal'))recordStage(this.history,id,'blockchainFinal',performance.now()-started,{source:'read-only-recovery',historicalAcceptanceUnknown:true});
   phase='tokensVerified';phaseStarted=performance.now();
   const classification=row.method==='ft_transfer_call'?inspectOutcome(outcome):{state:outcome.status?.Failure||[outcome.transaction_outcome,...outcome.receipts_outcome??[]].some(r=>r?.outcome?.status?.Failure)?'FAILED':'CONFIRMED',used:null};
   if(['FAILED','REFUNDED'].includes(classification.state)){this.history.update(id,{status:classification.state,usedRaw:classification.used});return row;}
   if(classification.state==='UNKNOWN')throw new Error('El resultado de los recibos no permite determinar la ejecución.');
   if(row.method!=='ft_transfer_call'){
    if(row.side==='PREPARE'&&row.targetRaw){const balance=await this.ex.rpc.view(WNEAR,'ft_balance_of',{account_id:row.signer});if(BigInt(balance)>=BigInt(row.targetRaw)){recordStage(this.history,id,'tokensVerified',performance.now()-phaseStarted,{source:'fresh-wnear-balance'});this.history.update(id,{status:'READY',wrappedAfter:balance});return row;}}
    // Preparación confirmada: NO continuar automáticamente hacia una compra tras reinicio.
    this.history.update(id,{status:'INTERRUPTED',error:'Preparación confirmada; la compra posterior no se envió. Podés crear una nueva orden.'});return row;
   }
   const verificationStart=performance.now();const snap=row.swapSnapshot;
   if(!snap)throw new Error('Falta la instantánea de la operación; se mantiene la recuperación.');
   const evidence=await resolveReceived(this.ex.rpc,outcome,row.txHash,row.signer,snap.output);
   if(evidence===null)throw new Error('Recibos sin evidencia suficiente del importe recibido. No se atribuye un saldo posterior a este hash.');
   const received=evidence.amount,outputAsset=evidence.asset;
   recordStage(this.history,id,'tokensVerified',performance.now()-verificationStart,{source:evidence.evidence,receivedRaw:received.toString()});
   const partial=BigInt(classification.used!)<BigInt(snap.effective);
   const meets=received>=BigInt(snap.expectedMinimum);
   this.history.update(id,{status:received>0n&&(meets||partial)?partial?'PARTIAL':'FILLED':'VERIFYING_TOKENS',receivedRaw:received.toString(),usedRaw:classification.used,outputToken:outputAsset,receiptEvidence:true,evidence:evidence.evidence,error:meets||partial?undefined:'Importe inferior al mínimo: revisión automática, sin declarar compra completada.'});
  }catch(error){const message=error instanceof Error?error.message:String(error);
   if(isUnknownTransaction(error)&&await this.releaseIfNeverExecuted(row))return row;
   recordStage(this.history,id,phase+'Error',performance.now()-phaseStarted,{error:message,timeout:/timeout|excedió/i.test(message),source:'read-only-recovery'});
   this.history.update(id,{recovery:{attempts,error:message,observedAt:new Date().toISOString(),nextRetryMs:Math.min(10000,250*2**Math.min(attempts,6))},error:'GABNEAR recuperando automáticamente: '+message});
  }finally{this.due.set(id,{attempts,at:Date.now()+Math.min(10000,250*2**Math.min(attempts,6))});this.inFlight.delete(id);if(['FILLED','PARTIAL'].includes(row.status))this.onResolved();}
  return row;
 }
}
