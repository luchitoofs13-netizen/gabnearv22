import {JsonRpcProvider} from 'near-api-js';
export class NearRpc {
 readonly provider:JsonRpcProvider;
 private fallback:JsonRpcProvider|null;
 private fallbackVerifiedAt=0;
 private checked:{at:number;result:any}|null=null;
 private statusPending:Promise<any>|null=null;
 private metadataCache=new Map<string,{expires:number;value:Promise<any>}>();
 cacheEnabled=true;
 clearMetadata(){this.metadataCache.clear();}
 metadata<T>(key:string,work:()=>Promise<T>):Promise<T>{
  if(!this.cacheEnabled)return work();
  const old=this.metadataCache.get(key);if(old&&old.expires>Date.now())return old.value;
  if(this.metadataCache.size>=256)this.metadataCache.clear();
  const value=work();this.metadataCache.set(key,{expires:Date.now()+5000,value});
  void value.catch(()=>{if(this.metadataCache.get(key)?.value===value)this.metadataCache.delete(key);});return value;
 }
 // near-api-js reintenta 12 veces con backoff (≈2 min) ante 500/503 antes de fallar: el fallback de lectura
 // nunca llegaría a tiempo. Reintentos acotados; reenviar la MISMA firma es idempotente (mismo hash).
 private extras:JsonRpcProvider[]=[];
 private extrasVerified=new WeakSet<JsonRpcProvider>();
 private extrasCheckedAt=0;
 private warmTimer:ReturnType<typeof setInterval>|null=null;
 constructor(readonly url:string,fallbackUrl?:string,broadcastUrls:string[]=(process.env.NEAR_RPC_BROADCAST??'').split(',')){
  // `retries` = número total de intentos (mínimo 1).
  const options={retries:Math.max(1,Math.floor(Number(process.env.NEAR_RPC_RETRIES)||3)),wait:150,backoff:1.5};
  this.provider=new JsonRpcProvider({url},options);
  this.fallback=fallbackUrl&&fallbackUrl!==url?new JsonRpcProvider({url:fallbackUrl},options):null;
  // Proveedores adicionales SOLO para difundir transacciones ya firmadas (https, sin duplicados, máximo 3).
  const seen=new Set([url]);
  for(const raw of broadcastUrls.map(u=>u.trim())){if(!/^https:\/\/\S+$/.test(raw)||seen.has(raw)||this.extras.length>=3)continue;seen.add(raw);this.extras.push(new JsonRpcProvider({url:raw},{...options,retries:1}));}
 }
 get broadcastCount(){return 1+this.extras.length;}
 // Un proveedor extra solo se usa tras comprobar que está en mainnet (una firma de mainnet en otra red es inofensiva, pero no sirve).
 private async verifiedExtras(){
  if(!this.extras.length)return [];
  if(Date.now()-this.extrasCheckedAt>60000){
   this.extrasCheckedAt=Date.now();
   void Promise.all(this.extras.map(async p=>{try{const st:any=await this.deadline(p.sendJsonRpc('status',[]),4000);if(st.chain_id==='mainnet')this.extrasVerified.add(p);}catch{/* se reintenta en el próximo ciclo */}}));
  }
  return this.extras.filter(p=>this.extrasVerified.has(p));
 }
 // Difunde la MISMA firma (mismo hash: es idempotente, jamás se ejecuta dos veces) y devuelve la primera aceptación.
 // Si todos fallan se lanza el error del proveedor principal, que es el que clasifica el rechazo.
 async send(signed:any,waitUntil:'NONE'|'EXECUTED_OPTIMISTIC'|'FINAL',timeoutMs:number):Promise<any>{
  const targets=[this.provider,...await this.verifiedExtras()];
  const attempts=targets.map(p=>p.sendTransactionUntil(signed,waitUntil as any));
  if(attempts.length===1)return this.deadline(attempts[0],timeoutMs);
  const first=new Promise<any>((resolve,reject)=>{let pending=attempts.length;const errors:unknown[]=[];attempts.forEach((a,i)=>a.then(resolve,e=>{errors[i]=e;if(--pending===0)reject(errors[0]??e);}));});
  return this.deadline(first,timeoutMs);
 }
 // Opcional (NEAR_KEEPALIVE_MS, apagado por defecto): mantiene vivas las conexiones con los proveedores mientras se opera.
 // Medido desde Argentina, reabrir conexiones no agrega latencia apreciable (domina el RTT); solo gasta cuota del RPC.
 startWarm(active:()=>boolean,everyMs=Number(process.env.NEAR_KEEPALIVE_MS)||0){
  if(this.warmTimer||everyMs<=0)return;
  this.warmTimer=setInterval(()=>{if(!active())return;for(const p of [this.provider,...this.extras])void p.sendJsonRpc('status',[]).catch(()=>{});},everyMs);this.warmTimer.unref();
 }
 stopWarm(){if(this.warmTimer)clearInterval(this.warmTimer);this.warmTimer=null;}
 async deadline<T>(work:Promise<T>,timeoutMs=15000):Promise<T>{let timer:ReturnType<typeof setTimeout>;try{return await Promise.race([work,new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(new Error(`RPC excedió ${timeoutMs} ms (timeout).`)),timeoutMs);})]);}finally{clearTimeout(timer!);}}
 private async read<T>(work:(provider:JsonRpcProvider)=>Promise<T>,timeoutMs=15000):Promise<T>{
  try{return await this.deadline(work(this.provider),timeoutMs);}catch(error){
   // Sin fallback, un límite de cuota (429) se reintenta UNA vez tras una pausa corta; es una lectura, no una transacción.
   if(!this.fallback&&/429|rate.limit/i.test(String(error))){await new Promise(r=>setTimeout(r,350));return this.deadline(work(this.provider),timeoutMs);}
   if(!this.fallback||!/(429|rate.limit|RPC excedió|fetch failed|ECONN|timeout|UNKNOWN_TRANSACTION|UnknownTransaction)/i.test(String(error)))throw error;
   if(Date.now()-this.fallbackVerifiedAt>10000){const status:any=await this.deadline(this.fallback.sendJsonRpc('status',[]),timeoutMs);if(status.chain_id!=='mainnet')throw new Error('Fallback no conectado a mainnet.');this.fallbackVerifiedAt=Date.now();}
   return this.deadline(work(this.fallback),timeoutMs);
  }
 }
 async view<T=any>(contractId:string,method:string,args:Record<string,unknown>={}):Promise<T>{return await this.read(p=>p.callFunction({contractId,method,args})) as T;}
 account(accountId:string){return this.read(p=>p.query<any>({request_type:'view_account',account_id:accountId,finality:'final'}));}
 // Fallback EXCLUSIVAMENTE de lectura. Nunca retransmite una transacción firmada.
 transactionStatus(hash:string,signer:string,timeoutMs=3000){return this.read(p=>p.viewTransactionStatus({txHash:hash,accountId:signer,waitUntil:'NONE'}),timeoutMs);}
 transactionDetails(hash:string,signer:string){return this.read(p=>p.sendJsonRpc<any>('EXPERIMENTAL_tx_status',{tx_hash:hash,sender_account_id:signer,wait_until:'NONE'}),3000);}
 async status(){
  if(this.statusPending)return this.statusPending;
  const pending=this.deadline(this.provider.sendJsonRpc<any>('status',[])).then(result=>{this.checked={at:Date.now(),result};return result;});
  this.statusPending=pending;
  try{return await pending;}finally{if(this.statusPending===pending)this.statusPending=null;}
 }
 // Solo identidad de red reciente; nunca saldo, pool o cotización.
 async mainnet(){const result=this.checked&&Date.now()-this.checked.at<10000?this.checked.result:await this.status();if(result.chain_id!=='mainnet')throw new Error('RPC de red incorrecta.');return result;}
}
