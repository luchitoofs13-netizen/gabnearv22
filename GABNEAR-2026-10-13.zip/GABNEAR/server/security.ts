import type {Request,Response,NextFunction} from 'express';

// Defensas del servidor local. GABNEAR solo escucha en 127.0.0.1, pero eso no basta: cualquier página web que abras puede
// intentar hablarle a http://127.0.0.1:4317 desde tu navegador (CSRF, DNS rebinding, clickjacking). Cada medida cierra una de esas vías.

// Política de contenido: solo código propio. Sin scripts externos, sin iframes que nos incrusten, sin conexiones a terceros desde el navegador
// (los datos de mercado los pide el servidor, nunca la página). 'unsafe-inline' solo en estilos: React y el chart fijan estilos en línea.
export const CSP=[
 "default-src 'none'","script-src 'self'","style-src 'self' 'unsafe-inline'","font-src 'self'","img-src 'self' data:","connect-src 'self'",
 "frame-ancestors 'none'","base-uri 'none'","form-action 'self'","object-src 'none'"
].join('; ');

export function securityHeaders(_req:Request,res:Response,next:NextFunction){
 res.removeHeader('X-Powered-By');
 res.set({
  'Content-Security-Policy':CSP,
  'X-Frame-Options':'DENY',                                    // clickjacking: ningún sitio puede incrustar la terminal
  'X-Content-Type-Options':'nosniff',
  'Referrer-Policy':'no-referrer',
  'Permissions-Policy':'camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=()',
  'Cross-Origin-Opener-Policy':'same-origin',
  'Cross-Origin-Resource-Policy':'same-origin'
 });
 next();
}

// DNS rebinding: un dominio ajeno que resuelve a 127.0.0.1 llega con su propio Host. Solo se atiende 127.0.0.1 / localhost.
export function hostGuard(allowed:string[]=['127.0.0.1','localhost']){
 return (req:Request,res:Response,next:NextFunction)=>{
  if(allowed.includes(req.hostname))return next();
  if(req.path.startsWith('/api'))return res.status(403).json({error:'Host local requerido.'});
  res.status(403).type('text/plain').send('Host local requerido.');
 };
}

// Solo la propia terminal puede usar la API: origen conocido, nada de peticiones «same-site»/«cross-site» (otro puerto de localhost
// también es otro sitio) y cabecera propia en los POST (obliga a una verificación previa CORS que ningún sitio ajeno supera).
export function apiGuard(port:number,extraOrigins:string[]=['http://127.0.0.1:5173','http://localhost:5173']){
 const origins=new Set([...extraOrigins,`http://127.0.0.1:${port}`,`http://localhost:${port}`]);
 return (req:Request,res:Response,next:NextFunction)=>{
  const origin=req.headers.origin;
  if(origin&&!origins.has(origin))return res.status(403).json({error:'Origen no permitido.'});
  const site=req.headers['sec-fetch-site'];
  if(typeof site==='string'&&site!=='same-origin'&&site!=='none')return res.status(403).json({error:'Origen no permitido.'});
  if(req.method==='POST'&&req.headers['x-gabnear-client']!=='local')return res.status(403).json({error:'Solicitud local requerida.'});
  res.set('Cache-Control','no-store');
  next();
 };
}

// Tope de conexiones abiertas (SSE): un script local no puede agotar sockets ni memoria abriendo streams sin cerrar.
export function connectionCap(max:number){
 let open=0;
 return (_req:Request,res:Response,next:NextFunction)=>{
  if(open>=max)return res.status(429).json({error:'Demasiadas conexiones en vivo abiertas.'});
  open++;let done=false;const release=()=>{if(!done){done=true;open--;}};
  res.on('close',release);res.on('finish',release);next();
 };
}
