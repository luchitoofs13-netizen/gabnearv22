import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import type {Level} from './finality.js';
// Ajustes de velocidad. Los valores por defecto salen del .env y se pueden cambiar en caliente desde el panel (se guardan en data/speed.json).
//  confirmLevel: cuándo se da por hecho el SWAP. 'final' = irreversible (~+1,5 s); 'optimistic' = ejecutado, aún no final.
//  prepLevel:    lo mismo para los pasos previos (registro de almacenamiento, wrap). 'optimistic' es seguro en la práctica y ahorra ~1,5 s por paso.
//  autoArm:      al pegar un contrato en REAL, pre-registra el token y deja wNEAR listo (cuesta ≈0,00125 NEAR por token).
export type Speed={confirmLevel:Level;prepLevel:Level;autoArm:boolean};
const FILE='data/speed.json';
const fromEnv=():Speed=>({confirmLevel:process.env.CONFIRM_LEVEL==='optimistic'?'optimistic':'final',prepLevel:process.env.PREP_LEVEL==='final'?'final':'optimistic',autoArm:process.env.AUTO_ARM==='true'});
const level=(v:unknown,fallback:Level):Level=>v==='final'||v==='optimistic'?v:fallback;
function sanitize(raw:any,base:Speed):Speed{const r=raw&&typeof raw==='object'?raw:{};return {confirmLevel:level(r.confirmLevel,base.confirmLevel),prepLevel:level(r.prepLevel,base.prepLevel),autoArm:typeof r.autoArm==='boolean'?r.autoArm:base.autoArm};}
let current:Speed|null=null;
export function getSpeed():Speed{
 if(!current){current=fromEnv();try{if(existsSync(FILE))current=sanitize(JSON.parse(readFileSync(FILE,'utf8')),current);}catch{/* archivo ilegible: se usan los valores del .env */}}
 return current;
}
export function setSpeed(patch:unknown):Speed{
 const r=patch&&typeof patch==='object'?patch as any:{};
 for(const key of ['confirmLevel','prepLevel'])if(key in r&&r[key]!=='final'&&r[key]!=='optimistic')throw new Error(`${key} debe ser «final» u «optimistic».`);
 if('autoArm' in r&&typeof r.autoArm!=='boolean')throw new Error('autoArm debe ser verdadero o falso.');
 current=sanitize(r,getSpeed());
 mkdirSync('data',{recursive:true});writeFileSync(FILE+'.tmp',JSON.stringify(current));renameSync(FILE+'.tmp',FILE);
 return current;
}
export function resetSpeed(){current=null;}
