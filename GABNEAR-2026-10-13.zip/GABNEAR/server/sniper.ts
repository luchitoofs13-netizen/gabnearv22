import {randomUUID} from 'node:crypto';
import {NearRpc} from './rpc.js';
import {discover,WNEAR,PoolNotReady} from './pools.js';
import {rankRoutes,bestRoute} from './venues.js';
import {poolLiquidityNear} from './market.js';
import {priceNear} from './trades.js';
import {extractToken,units} from './validation.js';

// VIGILANCIA DE POOL (sniper acotado): se carga UN contrato concreto que todavía no tiene dónde comprarse. Apenas aparece un pool directo
// token/wNEAR con la liquidez mínima que pediste, dispara UNA compra por el camino de siempre (mismos límites de riesgo, mismos topes de
// gasto, mismo AUTO SELL). Una orden por objetivo, con requestId fijado al crearlo: nunca compra dos veces. Vive solo en memoria y vence.
//
// No compra «todo lo nuevo»: la mayoría de lanzamientos nuevos son estafas, y eso es una decisión que no se delega a un filtro automático.
export type SniperStatus='WATCHING'|'PAUSED'|'FIRING'|'BOUGHT'|'SIMULATED'|'BLOCKED'|'FAILED'|'EXPIRED'|'CANCELLED';
export type SniperTarget={
 id:string;requestId:string;token:string;symbol:string;account:string;mode:'DRY RUN'|'REAL';
 amount:string;slippageBps:number;minLiquidityNear:number;autoSell?:unknown;
 createdAt:string;expiresAt:string;status:SniperStatus;detail:string;checks:number;lastCheckAt:string|null;poolAt:string|null;opId:string|null;
};
export type ProbeResult={ready:false;reason:string}|{ready:true;liquidityNear:number|null;venue:string;poolId:string};
export type Probe=(token:string)=>Promise<ProbeResult>;
export type SniperDeps={
 probe:Probe;verifyToken:(token:string)=>Promise<{symbol:string}>;submit:(raw:unknown)=>{id:string};rows:()=>any[];
 live:()=>boolean;stopped:()=>boolean;account:()=>string;maxBps:()=>number;now?:()=>number;onEvent?:(t:SniperTarget)=>void;
};
const ACTIVE:SniperStatus[]=['WATCHING','PAUSED','FIRING'];
export const MAX_ACTIVE=3,MAX_KEPT=20,DEFAULT_EXPIRY_MIN=60,MAX_EXPIRY_MIN=720;
const RETRY_LATER=/operación en curso|transacción incierta/i;
const RISK=/bloqueada por (riesgo|el tope)/i;

export const rpcProbe=(rpc:NearRpc):Probe=>async token=>{
 try{
  const d=await discover(rpc,token),probe=units('0.1');
  const best=bestRoute(await rankRoutes(rpc,d.routes,WNEAR,token,probe,300,false));
  if(!best)return {ready:false,reason:'Ya hay pool, pero todavía no cotiza (sin liquidez).'};
  const price=priceNear(probe*BigInt(10000-best.route.fee)/10000n,BigInt(best.quote!.raw),d.metadata.decimals);
  return {ready:true,liquidityNear:poolLiquidityNear(best.route,price,d.metadata.decimals),venue:best.route.venue,poolId:best.route.poolId};
 }catch(e){if(e instanceof PoolNotReady)return {ready:false,reason:e.message};throw e;}
};
export const rpcVerifyToken=(rpc:NearRpc)=>async(token:string)=>{
 let meta:any;try{meta=await rpc.view(token,'ft_metadata');}catch{throw new Error(`${token} no existe o no es un token NEP-141: revisá que el contrato esté bien escrito.`);}
 if(meta?.spec!=='ft-1.0.0')throw new Error(`${token} no es un token NEP-141.`);
 return {symbol:String(meta.symbol??'')};
};

export class Sniper{
 targets:SniperTarget[]=[];
 private running=false;private skipUntil=0;
 constructor(readonly d:SniperDeps){}
 private now(){return this.d.now?.()??Date.now();}
 private set(t:SniperTarget,status:SniperStatus,detail:string){const changed=t.status!==status;t.status=status;t.detail=detail;if(changed)this.d.onEvent?.(t);}

 async add(raw:any):Promise<SniperTarget>{
  if(!raw||typeof raw!=='object')throw new Error('Datos inválidos.');
  const token=extractToken(String(raw.url??''));
  const mode=raw.mode==='REAL'?'REAL':'DRY RUN';
  const amount=String(raw.amount??'');if(!/^\d+(\.\d+)?$/.test(amount)||units(amount)<=0n)throw new Error('Importe inválido o cero.');
  const slippageBps=Number(raw.slippageBps);if(!Number.isInteger(slippageBps)||slippageBps<1||slippageBps>Math.min(this.d.maxBps(),9900))throw new Error(`Slippage máximo permitido: ${Math.min(this.d.maxBps(),9900)/100}%.`);
  const minLiquidityNear=raw.minLiquidityNear===undefined||raw.minLiquidityNear===''?10:Number(raw.minLiquidityNear);
  if(!Number.isFinite(minLiquidityNear)||minLiquidityNear<0||minLiquidityNear>1e6)throw new Error('La liquidez mínima debe ser un número de NEAR entre 0 y 1.000.000.');
  const expiryMin=raw.expiresInMin===undefined||raw.expiresInMin===''?DEFAULT_EXPIRY_MIN:Number(raw.expiresInMin);
  if(!Number.isFinite(expiryMin)||expiryMin<1||expiryMin>MAX_EXPIRY_MIN)throw new Error(`La vigilancia dura entre 1 y ${MAX_EXPIRY_MIN} minutos.`);
  const account=this.d.account();
  if(mode==='REAL'){
   if(!account)throw new Error('Conectá una wallet para vigilar en REAL.');
   if(!this.d.live())throw new Error('REAL no está activo: activalo en el panel o vigilá en DRY RUN.');
   if(this.d.stopped())throw new Error('Parada de emergencia activa.');
  }
  if(this.targets.some(t=>t.token===token&&ACTIVE.includes(t.status)))throw new Error('Ya estás vigilando este contrato.');
  if(this.targets.filter(t=>ACTIVE.includes(t.status)).length>=MAX_ACTIVE)throw new Error(`Máximo ${MAX_ACTIVE} vigilancias a la vez: cancelá una.`);
  const {symbol}=await this.d.verifyToken(token);
  // Si ya hay dónde comprar con la liquidez pedida, no tiene sentido vigilar: se evita un disparo inmediato por accidente.
  let first:ProbeResult|null=null;try{first=await this.d.probe(token);}catch{/* sin lectura: se vigila igual */}
  if(first?.ready&&(first.liquidityNear===null||first.liquidityNear>=minLiquidityNear))throw new Error('Este token ya tiene pool con esa liquidez: comprá directo con COMPRAR (la vigilancia es para esperar al pool).');
  const now=this.now();
  const target:SniperTarget={id:randomUUID(),requestId:randomUUID(),token,symbol,account,mode,amount,slippageBps,minLiquidityNear,autoSell:raw.autoSell,
   createdAt:new Date(now).toISOString(),expiresAt:new Date(now+expiryMin*60000).toISOString(),status:'WATCHING',detail:first&&!first.ready?first.reason:'Esperando un pool.',checks:0,lastCheckAt:null,poolAt:null,opId:null};
  this.targets.unshift(target);
  // Se conservan solo las últimas vigilancias terminadas (las activas nunca se descartan).
  const done=this.targets.filter(t=>!ACTIVE.includes(t.status));
  if(done.length>MAX_KEPT)this.targets=this.targets.filter(t=>ACTIVE.includes(t.status)||done.indexOf(t)<MAX_KEPT);
  this.d.onEvent?.(target);
  return target;
 }
 cancel(id:string){
  const t=this.targets.find(x=>x.id===id);if(!t)throw new Error('Vigilancia desconocida.');
  if(!ACTIVE.includes(t.status))return t;
  // Con la compra ya enviada no hay nada que cancelar: la orden sigue su camino en el historial.
  if(t.status==='FIRING'&&t.opId)throw new Error('La compra ya se disparó: seguila en el historial.');
  this.set(t,'CANCELLED','Cancelada por vos.');return t;
 }
 view(){return this.targets.map(t=>({...t,autoSell:undefined,hasAutoSell:!!t.autoSell}));}

 async tick(){
  if(this.running||this.now()<this.skipUntil)return;
  this.running=true;
  try{for(const t of this.targets.filter(x=>ACTIVE.includes(x.status)))await this.step(t);}
  finally{this.running=false;}
 }
 private async step(t:SniperTarget){
  if(this.now()>=Date.parse(t.expiresAt)&&t.status!=='FIRING'){this.set(t,'EXPIRED','Venció la vigilancia sin que apareciera un pool que cumpla.');return;}
  if(t.status==='FIRING'){this.follow(t);return;}
  if(t.mode==='REAL'){
   if(t.account!==this.d.account()){this.set(t,'CANCELLED','Cambió la wallet: vigilancia cancelada.');return;}
   if(this.d.stopped()||!this.d.live()){if(t.status!=='PAUSED'||!/REAL/.test(t.detail))this.set(t,'PAUSED','En pausa: REAL desactivado o parada de emergencia. Reanuda sola al reactivar REAL (mientras no venza).');return;}
   if(t.status==='PAUSED')this.set(t,'WATCHING','Reanudada.');
  }
  let probe:ProbeResult;
  try{probe=await this.d.probe(t.token);}
  catch(e){
   const m=e instanceof Error?e.message:String(e);t.detail=`Error de lectura (se reintenta): ${m.slice(0,120)}`;
   if(/429|rate|timeout|excedió|fetch/i.test(m))this.skipUntil=this.now()+5000;
   return;
  }
  t.checks++;t.lastCheckAt=new Date(this.now()).toISOString();
  if(!probe.ready){t.detail=probe.reason;return;}
  if(probe.liquidityNear!==null&&probe.liquidityNear<t.minLiquidityNear){t.detail=`Pool en ${probe.venue} con ${probe.liquidityNear.toFixed(2)} NEAR; esperando ${t.minLiquidityNear}.`;return;}
  t.poolAt=new Date(this.now()).toISOString();
  try{
   const row=this.d.submit({requestId:t.requestId,side:'BUY',mode:t.mode,url:t.token,amount:t.amount,slippageBps:t.slippageBps,payWith:'NEAR',...(t.autoSell?{autoSell:t.autoSell}:{})});
   t.opId=row.id;this.set(t,'FIRING',`Pool detectado en ${probe.venue}${probe.liquidityNear===null?'':` con ${probe.liquidityNear.toFixed(1)} NEAR`}: compra enviada.`);
  }catch(e){
   const m=e instanceof Error?e.message:String(e);
   if(RETRY_LATER.test(m)){t.detail=`Pool detectado; esperando que termine otra operación (${m}).`;return;}
   this.set(t,RISK.test(m)?'BLOCKED':'FAILED',m);
  }
 }
 // Sigue la orden creada: el resultado real está en el historial; acá solo se refleja.
 private follow(t:SniperTarget){
  const row=this.d.rows().find(r=>r.requestId===t.requestId||r.id===t.opId);
  if(!row){this.set(t,'FAILED','La orden no llegó a registrarse en el historial.');return;}
  if(['FILLED','PARTIAL'].includes(row.status)){this.set(t,'BOUGHT',`Comprado: ${row.status==='PARTIAL'?'llenado parcial':'completada'}. Mirá Posiciones.`);return;}
  if(row.status==='ANALYZED'){this.set(t,'SIMULATED','Simulación (DRY RUN): el pool apareció y la compra pasó el análisis. No se gastó nada.');return;}
  if(['FAILED','REFUNDED','INTERRUPTED','CANCELLED'].includes(row.status)){const m=String(row.error??row.status);this.set(t,RISK.test(m)?'BLOCKED':'FAILED',m);}
 }
}
