import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {Fetcher} from './fetcher.js';
import {extractToken} from './validation.js';
import {launchpadOf} from './market-hub.js';

// Rastreador de Telegram: lee la vista web PÚBLICA de canales (https://t.me/s/<canal>, sin cuenta ni bot) y junta los contratos de tokens
// que mencionan. Solo canales públicos que vos agregás. El HTML se procesa como texto: nada de lo que dice un canal se ejecuta ni se muestra
// como HTML. Se consulta bajo demanda (cuando abrís la pestaña), como máximo una vez por minuto por canal.
// X (Twitter) NO se rastrea: su API es de pago y leer la web va contra sus términos; ver README.
export const CHANNEL=/^[A-Za-z][A-Za-z0-9_]{4,31}$/;
export type Message={id:string;channel:string;at:string|null;text:string;link:string;contracts:string[];cashtags:string[]};
export type Mention={token:string;count:number;channels:string[];lastAt:string|null;sample:string;launchpad:string|null};

const decode=(s:string)=>s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#0?39;/g,"'").replace(/&nbsp;/g,' ').replace(/&amp;/g,'&');
// Cuentas de token con el sufijo de un launchpad conocido (así no se confunden con billeteras personales «alguien.near»).
const ACCOUNT=/[a-z0-9][a-z0-9_-]{0,40}(?:\.[a-z0-9][a-z0-9_-]{0,40}){1,4}\.near/g;
export function extractContracts(text:string):string[]{
 const out=new Set<string>();
 for(const raw of text.toLowerCase().match(ACCOUNT)??[]){
  let token:string;try{token=extractToken(raw);}catch{continue;}
  if(launchpadOf(token))out.add(token);
 }
 return [...out];
}
export const extractCashtags=(text:string)=>[...new Set((text.match(/\$[A-Za-z][A-Za-z0-9]{1,14}\b/g)??[]).map(t=>t.toUpperCase()))].slice(0,8);

export function parseChannelHtml(html:string,channel:string):Message[]{
 const out:Message[]=[];
 for(const chunk of html.split('tgme_widget_message_wrap').slice(1)){
  const post=/data-post="([A-Za-z0-9_]+\/\d+)"/.exec(chunk)?.[1];if(!post||post.split('/')[0].toLowerCase()!==channel.toLowerCase())continue;
  const body=/class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/.exec(chunk)?.[1]??'';
  // Los enlaces de la publicación también cuentan (el texto visible puede estar abreviado).
  const hrefs=[...body.matchAll(/href="([^"]{1,300})"/g)].map(m=>decode(m[1])).join(' ');
  const text=decode(body.replace(/<br\s*\/?>/g,'\n').replace(/<[^>]+>/g,'')).replace(/\s+\n/g,'\n').trim().slice(0,600);
  const at=/<time[^>]*datetime="([^"]+)"/.exec(chunk)?.[1];
  const iso=at&&Number.isFinite(Date.parse(at))?new Date(at).toISOString():null;
  out.push({id:post,channel,at:iso,text,link:`https://t.me/${post}`,contracts:extractContracts(`${text} ${hrefs}`),cashtags:extractCashtags(text)});
 }
 return out;
}
export function aggregate(messages:Message[]):Mention[]{
 const by=new Map<string,Mention>();
 for(const m of messages)for(const token of m.contracts){
  const cur=by.get(token)??{token,count:0,channels:[],lastAt:null,sample:m.text.slice(0,140),launchpad:launchpadOf(token)};
  cur.count++;if(!cur.channels.includes(m.channel))cur.channels.push(m.channel);
  if(m.at&&(!cur.lastAt||m.at>cur.lastAt)){cur.lastAt=m.at;cur.sample=m.text.slice(0,140);}
  by.set(token,cur);
 }
 return [...by.values()].sort((a,b)=>b.channels.length-a.channels.length||b.count-a.count||String(b.lastAt).localeCompare(String(a.lastAt)));
}

export class SocialTracker{
 channels:string[]=[];
 constructor(readonly fetcher:Fetcher,readonly file='data/tg-channels.json',env:Record<string,string|undefined>=process.env){
  const fromEnv=(env.TG_CHANNELS??'').split(',').map(s=>s.trim().replace(/^@/,'')).filter(c=>CHANNEL.test(c));
  let saved:string[]=[];try{if(existsSync(file)){const j=JSON.parse(readFileSync(file,'utf8'));if(Array.isArray(j))saved=j.map(String).filter(c=>CHANNEL.test(c));}}catch{/* archivo ilegible: se ignora */}
  this.channels=[...new Set([...fromEnv,...saved])].slice(0,10);
 }
 private save(){try{mkdirSync('data',{recursive:true});writeFileSync(this.file+'.tmp',JSON.stringify(this.channels));renameSync(this.file+'.tmp',this.file);}catch{/* sin disco: vive en memoria */}}
 add(raw:string){
  const name=String(raw).trim().replace(/^@/,'').replace(/^https?:\/\/t\.me\/(s\/)?/,'');
  if(!CHANNEL.test(name))throw new Error('Nombre de canal inválido: usá el @usuario de un canal PÚBLICO (5 a 32 letras, números o _).');
  if(this.channels.some(c=>c.toLowerCase()===name.toLowerCase()))throw new Error('Ya seguís ese canal.');
  if(this.channels.length>=10)throw new Error('Máximo 10 canales.');
  this.channels.push(name);this.save();return name;
 }
 remove(raw:string){this.channels=this.channels.filter(c=>c.toLowerCase()!==String(raw).toLowerCase());this.save();}
 async snapshot(){
  const errors:string[]=[];
  const results=await Promise.all(this.channels.map(async c=>{try{return parseChannelHtml(await this.fetcher.text(`https://t.me/s/${c}`,{ttl:55000}),c);}catch(e){errors.push(`${c}: ${(e as Error).message}`);return [] as Message[];}}));
  const messages=results.flat().sort((a,b)=>String(b.at).localeCompare(String(a.at)));
  return {channels:this.channels,mentions:aggregate(messages).slice(0,30),messages:messages.filter(m=>m.contracts.length||m.cashtags.length).slice(0,40),total:messages.length,errors,fetchedAt:Date.now()};
 }
}
