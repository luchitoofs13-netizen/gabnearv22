import {performance} from 'node:perf_hooks';
import type {History} from './history.js';
export class Timeline {
 readonly start=performance.now();
 readonly receivedAt=new Date().toISOString();
 readonly events:{stage:string;at:string;offsetMs:number;durationMs?:number;error?:string;timeout?:boolean}[]=[];
 constructor(readonly publish:(snapshot:object)=>void=()=>{}){}
 mark(stage:string,durationMs?:number,details:object={}){this.events.push({stage,at:new Date().toISOString(),offsetMs:Number((performance.now()-this.start).toFixed(3)),...(durationMs===undefined?{}:{durationMs:Number(durationMs.toFixed(3))}),...details});this.publish({receivedAt:this.receivedAt,events:[...this.events]});}
 async measure<T>(stage:string,work:()=>Promise<T>){const start=performance.now();try{return await work();}finally{this.mark(stage,performance.now()-start);}}
}
const clocks=new WeakMap<object,Map<string,Timeline>>();
export function beginTimeline(history:History,id:string){let map=clocks.get(history);if(!map){map=new Map();clocks.set(history,map);}const clock=new Timeline(timing=>history.update(id,{timing}));map.set(id,clock);clock.mark('orderReceived');return clock;}
export function timeline(history:History,id:string){return clocks.get(history)?.get(id);}
export function endTimeline(history:History,id:string){clocks.get(history)?.delete(id);}
// Recuperación tras reinicio: nunca presenta el reloj de pared como una medición original.
export function recordStage(history:History,id:string,stage:string,durationMs?:number,details:object={}){
 const clock=timeline(history,id);if(clock){clock.mark(stage,durationMs,details);return;}
 const row=history.rows.find(r=>r.id===id),at=new Date().toISOString();
 const receivedAt=row?.timing?.receivedAt??row?.at??at;
 const old=row?.timing?.events??[];const events=old.length>200?[...old.slice(0,100),...old.slice(-100)]:old;
 history.update(id,{timing:{receivedAt,events:[...events,{stage,at,offsetMs:Date.now()-Date.parse(receivedAt),durationMs,clock:'wall-recovery',...details}]}});
}
