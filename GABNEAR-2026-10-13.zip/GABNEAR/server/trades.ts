// Swaps de un token contra wNEAR: interpretación de eventos de Intear (trade_swap), velas y conexión WebSocket.
export type Trade={id:string;ts:number;side:'BUY'|'SELL';tokenRaw:string;nearRaw:string;priceNear:number|null;trader:string;tx:string;block:number|null;mine:boolean};
export type Candle={time:number;open:number;high:number;low:number;close:number;volume:number};
export const TIMEFRAMES={'1m':60,'5m':300,'15m':900,'1h':3600,'4h':14400,'1d':86400} as const;
export type Timeframe=keyof typeof TIMEFRAMES;
const WNEAR='wrap.near';
const big=(v:unknown):bigint|null=>typeof v==='string'&&/^-?\d+$/.test(v)?BigInt(v):null;
const abs=(n:bigint)=>n<0n?-n:n;
// Token contra el que cotiza el par cuando NO es wNEAR (p. ej. RHEA). `near` = cuántos NEAR vale 1 unidad entera de ese token: los montos se
// convierten a NEAR (al precio actual del quote) para que el feed, el chart y los filtros sigan hablando un solo idioma.
export type SwapQuote={id:string;decimals:number;near:number};
export function quoteToNearRaw(raw:bigint,q:SwapQuote):bigint{
 if(q.id===WNEAR)return raw;
 const near=Number(raw)/10**q.decimals*q.near;
 return Number.isFinite(near)&&near>0?BigInt(Math.round(near*1e12))*10n**12n:0n;
}

// Precio en NEAR por 1 token entero: (near/1e24) / (token/10^decimals), con BigInt para no perder precisión en precios minúsculos.
export function priceNear(nearRaw:bigint,tokenRaw:bigint,decimals:number):number|null{
 if(nearRaw<=0n||tokenRaw<=0n||!Number.isInteger(decimals)||decimals<0||decimals>38)return null;
 const scaled=nearRaw*10n**BigInt(decimals)*10n**30n/(tokenRaw*10n**24n);
 const p=Number(scaled)/1e30;
 return Number.isFinite(p)&&p>0?p:null;
}
// Un evento trade_swap trae los cambios de saldo del TRADER por token. Es una compra del token si recibe token y gasta wNEAR.
export function parseSwap(ev:any,token:string,decimals:number|undefined,me='',quote?:SwapQuote):Trade|null{
 const changes=ev?.balance_changes;if(!changes||typeof changes!=='object')return null;
 const dT=big(changes[token]),dQ=big(changes[quote?.id??WNEAR]);
 if(dT===null||dQ===null||dT===0n||dQ===0n||(dT>0n)===(dQ>0n))return null;      // otro par o ajuste, no un swap token↔wNEAR
 const nanos=big(ev.block_timestamp_nanosec);if(nanos===null||typeof ev.trader!=='string'||typeof ev.transaction_id!=='string')return null;
 const tokenRaw=abs(dT),nearRaw=quote?quoteToNearRaw(abs(dQ),quote):abs(dQ);
 if(nearRaw<=0n)return null;
 return {id:String(ev.receipt_id??ev.transaction_id),ts:Number(nanos/1000000n),side:dT>0n?'BUY':'SELL',tokenRaw:tokenRaw.toString(),nearRaw:nearRaw.toString(),priceNear:decimals===undefined?null:priceNear(nearRaw,tokenRaw,decimals),trader:ev.trader,tx:ev.transaction_id,block:Number.isFinite(Number(ev.block_height))?Number(ev.block_height):null,mine:me!==''&&ev.trader===me};
}
// Velas a partir de swaps (más nuevo primero o no; se ordena). `multiplier`: 1 = NEAR, o el precio NEAR/USD para mostrar USD.
export function candlesFromTrades(trades:Trade[],tfSeconds:number,multiplier=1):Candle[]{
 const ordered=trades.filter(t=>t.priceNear!==null).sort((a,b)=>a.ts-b.ts||a.id.localeCompare(b.id)),out:Candle[]=[];
 for(const t of ordered){
  const time=Math.floor(t.ts/1000/tfSeconds)*tfSeconds,price=t.priceNear!*multiplier,volume=Number(t.nearRaw)/1e24*multiplier,last=out[out.length-1];
  if(last&&last.time===time){last.high=Math.max(last.high,price);last.low=Math.min(last.low,price);last.close=price;last.volume+=volume;}
  else out.push({time,open:last?.close??price,high:Math.max(price,last?.close??price),low:Math.min(price,last?.close??price),close:price,volume});
 }
 return out;
}

export type WsLike={send(data:string):void;close():void;onopen:any;onmessage:any;onerror:any;onclose:any};
// Conexión a un stream de Intear (wss://ws-events-v3.intear.tech/events/<evento>) con reconexión exponencial y vigilancia de silencio.
export class IntearStream {
 connected=false;
 private ws:WsLike|null=null;
 private wanted=false;
 private backoff=1000;
 private lastMessage=0;
 private retry:ReturnType<typeof setTimeout>|null=null;
 private watchdog:ReturnType<typeof setInterval>|null=null;
 constructor(readonly event:string,readonly onEvents:(events:any[])=>void,readonly options:{base?:string;create?:(url:string)=>WsLike;staleMs?:number;maxBackoffMs?:number;initialBackoffMs?:number;watchIntervalMs?:number}={}){this.backoff=options.initialBackoffMs??1000;}
 start(){
  if(this.wanted)return;this.wanted=true;this.connect();
  const stale=this.options.staleMs??0;
  if(stale>0){this.watchdog=setInterval(()=>{if(this.connected&&Date.now()-this.lastMessage>stale)this.drop();},this.options.watchIntervalMs??Math.max(1000,Math.floor(stale/4)));this.watchdog.unref();}
 }
 stop(){this.wanted=false;if(this.retry)clearTimeout(this.retry);if(this.watchdog)clearInterval(this.watchdog);this.retry=null;this.watchdog=null;this.drop();}
 private connect(){
  if(!this.wanted)return;
  const url=`${this.options.base??'wss://ws-events-v3.intear.tech'}/events/${this.event}`;
  let ws:WsLike;try{ws=(this.options.create??((u:string)=>new WebSocket(u) as unknown as WsLike))(url);}catch{this.schedule();return;}
  this.ws=ws;
  ws.onopen=()=>{this.connected=true;this.backoff=this.options.initialBackoffMs??1000;this.lastMessage=Date.now();try{ws.send(JSON.stringify({And:[]}));}catch{/* se reconectará */}};
  ws.onmessage=(message:{data:unknown})=>{this.lastMessage=Date.now();try{const data=JSON.parse(String(message.data));if(Array.isArray(data))this.onEvents(data);}catch{/* un mensaje ilegible no corta el stream */}};
  ws.onerror=()=>{};
  ws.onclose=()=>{if(this.ws===ws){this.ws=null;this.connected=false;}if(this.wanted)this.schedule();};
 }
 private schedule(){
  if(this.retry)return;const wait=this.backoff;this.backoff=Math.min(this.backoff*2,this.options.maxBackoffMs??15000);
  this.retry=setTimeout(()=>{this.retry=null;this.connect();},wait);this.retry.unref();
 }
 private drop(){try{this.ws?.close();}catch{/* ya cerrado */}}
}
