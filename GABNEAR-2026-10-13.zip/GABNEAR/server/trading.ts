import {Executor,inspectOutcome} from './transactions.js';
import {NearRpc} from './rpc.js';
import {WNEAR} from './pools.js';
import {checkRisk,units,display} from './validation.js';
import {quoteAsset,quoteAmount,ftRaw,insufficientQuote} from './quote-asset.js';
import {taxRate,afterTax} from './quotes.js';
import {accountId} from './wallet.js';
import {timeline,recordStage} from './timing.js';
import {resolveReceived} from './recovery.js';
import {quoteRoute,swapCall,routeOf,dclRoute,type Route} from './venues.js';
import {performance} from 'node:perf_hooks';
import {accepted} from './finality.js';
import {getSpeed} from './settings.js';
import type {BridgePlan} from './bridge.js';
export const LIVE_VALIDATED=false; // Esta revisión aún no tiene benchmark mainnet con fondos.
// Pasos previos (registro, wrap) y swap pueden darse por hechos al ejecutarse (optimista) o recién en FINAL; ver settings.ts.
const prepOpts=()=>({confirm:getSpeed().prepLevel==='optimistic'?'OPTIMISTIC' as const:'FINAL' as const});
const swapOpts=()=>({confirm:getSpeed().confirmLevel==='optimistic'?'OPTIMISTIC' as const:'FINAL' as const});
let liveSession=false;
export function setLiveSession(enabled:boolean){liveSession=enabled;}
export function liveEnabled(){return liveSession;}
export function requireLive(){if(!liveSession)throw new Error('Modo real bloqueado: desbloqueá la wallet y habilitá REAL explícitamente en el panel.');}
function prepared(result:any,accept:readonly string[]=accepted(getSpeed().prepLevel)){return accept.includes(result?.final_execution_status)&&!result.status?.Failure&&![result.transaction_outcome,...result.receipts_outcome??[]].some(x=>x?.outcome?.status?.Failure);}
export function supportedRules(rules:any){return rules===null||rules===undefined||(typeof rules==='object'&&!Array.isArray(rules)&&Object.keys(rules).every(k=>k==='max_wallet_bps')&&Number(rules.max_wallet_bps??0)===0);}
async function register(ex:Executor,id:string,token:string,known?:boolean,minimum?:bigint){
 const user=accountId();if(known===true||(known===undefined&&await ex.rpc.view(token,'storage_balance_of',{account_id:user})))return;
 const deposit=minimum??ftRaw((await ex.rpc.view(token,'storage_balance_bounds'))?.min);if(deposit<0n||deposit>units('0.05'))throw new Error('Depósito de almacenamiento inválido o excesivo.');
 const result=await ex.call(id,token,'storage_deposit',{account_id:user,registration_only:true},deposit,30,undefined,prepOpts());
 if(!prepared(result)||!await ex.rpc.view(token,'storage_balance_of',{account_id:user}))throw new Error('Registración no confirmada.');
}
async function storagePlan(ex:Executor,token:string){
 try{
  if(await ex.rpc.view(token,'storage_balance_of',{account_id:accountId()}))return {registered:true,deposit:0n};
  const bounds=await ex.rpc.view(token,'storage_balance_bounds');const cost=ftRaw(bounds?.min);
  if(cost>units('0.05'))throw new Error(`Depósito de almacenamiento excesivo para ${token}.`);
  return {registered:false,deposit:cost};
 }catch(error){throw new Error(`Almacenamiento NEP-145 no soportado o inválido para ${token}: ${(error as Error).message}`);}
}
export async function prepareWnear(ex:Executor,id:string,amount:bigint,known?:{registered:boolean;balance:bigint;storageDeposit?:bigint}){requireLive();await register(ex,id,WNEAR,known?.registered,known?.storageDeposit);const balance=known?.balance??BigInt(await ex.rpc.view(WNEAR,'ft_balance_of',{account_id:accountId()}));if(balance<amount){const r=await ex.call(id,WNEAR,'near_deposit',{},amount-balance,10,undefined,prepOpts());if(!prepared(r))throw new Error('Falló la preparación de wNEAR.');if(BigInt(await ex.rpc.view(WNEAR,'ft_balance_of',{account_id:accountId()}))<amount)throw new Error('Balance de wNEAR insuficiente después de preparar.');}}
// Todo lo que hay que dejar listo ANTES del swap: registro del token, registro y saldo del quote (wrap). Compartido por buy() y arm().
async function preSteps(ex:Executor,id:string,analysis:any,amount:bigint,slippageBps:number){
 const buyTax=taxRate(analysis.tax,'buy');
 const asset=quoteAsset(analysis);
 quoteAmount(display(amount,asset.decimals),asset,slippageBps,'',Number(process.env.MAX_SLIPPAGE_BPS||9900));
 if(!analysis.direct||!supportedRules(analysis.rules))throw new Error('Ruta o reglas de token no soportadas.');
 const [native,balanceRaw,targetStorage,quoteStorage]=await Promise.all([ex.rpc.account(accountId()),ex.rpc.view(asset.id,'ft_balance_of',{account_id:accountId()}),storagePlan(ex,analysis.token),storagePlan(ex,asset.id)]);
 const available=BigInt(native.amount)-BigInt(native.storage_usage)*10000000000000000000n,balance=ftRaw(balanceRaw);
 if(asset.id!==WNEAR&&balance<amount)throw insufficientQuote(asset,balance,amount);
 const deficit=asset.id===WNEAR&&amount>balance?amount-balance:0n;
 if(available<deficit+targetStorage.deposit+quoteStorage.deposit+units(process.env.GAS_RESERVE_NEAR||'0.1')+1n)throw new Error('Saldo nativo insuficiente para wrap, almacenamiento y reserva de gas.');
 const clock=timeline(ex.history,id);
 const registration=()=>register(ex,id,analysis.token,targetStorage.registered,targetStorage.deposit);
 if(clock)await clock.measure('registration',registration);else await registration();
 const preparation=()=>asset.id===WNEAR?prepareWnear(ex,id,amount,{registered:quoteStorage.registered,storageDeposit:quoteStorage.deposit,balance}):register(ex,id,asset.id,quoteStorage.registered,quoteStorage.deposit);
 if(clock)await clock.measure(asset.id===WNEAR?'wnearPreparation':'quotePreparation',preparation);else await preparation();
 return {buyTax,asset};
}
export async function buy(ex:Executor,id:string,analysis:any,amount:bigint,slippageBps:number){
 requireLive();return ex.exclusive(async()=>{
  const {buyTax,asset}=await preSteps(ex,id,analysis,amount,slippageBps);
  return swap(ex,id,analysis.route??analysis.record.pool_id,asset.id,analysis.token,amount,slippageBps,0,buyTax);
 },analysis.token);
}
// ARMAR: deja el registro del token y el wNEAR listos para que la compra posterior sea UN solo swap. No compra ni vende nada.
export async function arm(ex:Executor,id:string,analysis:any,amount:bigint,slippageBps:number){
 requireLive();return ex.exclusive(async()=>{await preSteps(ex,id,analysis,amount,slippageBps);return {state:'READY'};},analysis.token);
}
// Último recurso en el camino VIVO (bajo exclusión de la cuenta): diferencia de saldo medida justo después de FINAL.
// Queda marcado como evidencia de balance; la recuperación tras reinicio jamás lo usa.
async function balanceDelta(ex:Executor,output:string,user:string,before:bigint,nativeBefore:bigint,outcome:any){
 try{
  const after=BigInt(await ex.rpc.view(output,'ft_balance_of',{account_id:user}));
  if(after>before)return {amount:after-before,asset:output,evidence:'balance-delta'};
  if(output===WNEAR){
   const account=await ex.rpc.account(user);
   const burnt=[outcome.transaction_outcome,...outcome.receipts_outcome??[]].reduce((s:bigint,r:any)=>s+BigInt(r?.outcome?.tokens_burnt??'0'),0n);
   const gained=BigInt(account.amount)-nativeBefore+burnt+1n;
   if(gained>0n)return {amount:gained,asset:'NEAR',evidence:'native-balance-delta'};
  }
 }catch{/* sin lectura no hay evidencia */}
 return null;
}
export async function swap(ex:Executor,id:string,target:string|Route,input:string,output:string,amount:bigint,slippageBps:number,inputTax=0,outputTax=0){
 requireLive();const user=accountId();
 // Un string es un pool DCL (launch de Nearly); un objeto es una ruta DCL / Ref v1 ya descubierta.
 const route:Route=typeof target==='string'?dclRoute('','',0,target):target;
 const effective=afterTax(amount,inputTax);
 const [beforeRaw,native,q,context]=await Promise.all([ex.rpc.view(output,'ft_balance_of',{account_id:user}),output===WNEAR?ex.rpc.account(user):Promise.resolve(null),quoteRoute(ex.rpc,route,input,output,effective,slippageBps),ex.context?ex.context(id):Promise.resolve(undefined)]);
 const before=BigInt(beforeRaw),nativeBefore=native?BigInt(native.amount):0n;
 timeline(ex.history,id)?.mark('freshQuoteAndBalances');
 const expectedMinimum=afterTax(BigInt(q.minRaw),outputTax);
 const row=ex.history.rows.find(r=>r.id===id);
 const refreshedAnalysis=row?.side==='BUY'&&row.analysis?{analysis:{...row.analysis,quotation:{...q,expectedTokens:display(afterTax(BigInt(q.raw),outputTax),row.analysis.metadata.decimals),minTokens:display(expectedMinimum,row.analysis.metadata.decimals)}}}:{};
 ex.history.update(id,{...refreshedAnalysis,swapSnapshot:{before:before.toString(),nativeBefore:nativeBefore.toString(),input,output,amount:amount.toString(),effective:effective.toString(),expectedMinimum:expectedMinimum.toString(),route:{venue:route.venue,poolId:route.poolId,fee:route.fee}},quotation:q});
 const call=swapCall(route,input,output,effective,q.minRaw);
 const options=swapOpts(),level=accepted(getSpeed().confirmLevel);
 const result=await ex.call(id,input,'ft_transfer_call',{receiver_id:call.receiver,amount:amount.toString(),msg:call.msg},1n,call.gas,context,options);
 const classification=inspectOutcome(result,level);if(classification.state!=='CONFIRMED'){ex.history.update(id,{status:classification.state});return classification;}
 ex.history.update(id,{status:'SETTLING'});
 const verificationStarted=performance.now();
 try{
 const hash=ex.history.rows.find(r=>r.id===id)?.txHash;
 const evidence=await resolveReceived(ex.rpc,result,hash,user,output,level)??await balanceDelta(ex,output,user,before,nativeBefore,result);
 if(evidence===null)throw new Error('Recibos sin evidencia suficiente del importe recibido. Recuperación automática, sin atribuir balances posteriores.');
 const received=evidence.amount,outputAsset=evidence.asset;
 const partial=BigInt(classification.used!)<effective;
 const status=received>0n&&(received>=expectedMinimum||partial)?partial?'PARTIAL':'FILLED':'UNKNOWN';
 recordStage(ex.history,id,'tokensVerified',performance.now()-verificationStarted,{source:evidence.evidence});
 ex.history.update(id,{status,receivedRaw:received.toString(),usedRaw:classification.used,outputToken:outputAsset,receiptEvidence:!/balance/.test(evidence.evidence),evidence:evidence.evidence});
 return {state:status,receivedRaw:received.toString(),usedRaw:classification.used};
 }catch(error){recordStage(ex.history,id,'tokensVerifiedError',performance.now()-verificationStarted,{error:String(error),timeout:/timeout|excedió/i.test(String(error))});throw error;}

}
export async function sell(ex:Executor,id:string,position:any,amount:bigint,slippageBps:number){requireLive();return ex.exclusive(async()=>{
 const sellTax=taxRate(position.tax,'sell');if(amount<=0n)throw new Error('Sin saldo para vender.');
 if(!position.direct||!supportedRules(position.rules))throw new Error('Ruta o reglas de token no soportadas.');
 checkRisk('0.000000000000000000000001',slippageBps,'',Number(process.env.MAX_SLIPPAGE_BPS||9900));
 const asset=quoteAsset(position);
 const [native,storage]=await Promise.all([ex.rpc.account(accountId()),storagePlan(ex,asset.id)]);
 if(BigInt(native.amount)-BigInt(native.storage_usage)*10000000000000000000n<storage.deposit+units(process.env.GAS_RESERVE_NEAR||'0.1')+1n)throw new Error('NEAR nativo insuficiente para almacenamiento y reserva de gas.');
 await register(ex,id,asset.id,storage.registered,storage.deposit);return swap(ex,id,routeOf(position),position.token,asset.id,amount,slippageBps,sellTax);
 },position.token);}
export async function executableExit(rpc:NearRpc,position:any,amount:bigint,bps:number){return quoteRoute(rpc,routeOf(position),position.token,quoteAsset(position).id,afterTax(amount,taxRate(position.tax,'sell')),bps);}

// PUENTE NEAR → quote (ver bridge.ts): deja wNEAR listo, registra el quote para la cuenta y lo compra con wNEAR en su propio pool. Devuelve cuánto
// quote entró de verdad (diferencia de saldo medida bajo exclusión de la cuenta: nadie más la mueve). Si falla, el token objetivo NO se compró y
// los fondos siguen como NEAR / wNEAR. Es un swap más, con la misma seguridad que el principal: mínimo de salida en el mensaje, política de firma,
// hash persistido antes de enviar.
export async function bridgeToQuote(ex:Executor,id:string,plan:BridgePlan,slippageBps:number):Promise<bigint>{
 requireLive();
 const {asset,route,inRaw}=plan;
 return ex.exclusive(async()=>{
  const user=accountId();
  checkRisk('0.000000000000000000000001',slippageBps,'',Number(process.env.MAX_SLIPPAGE_BPS||9900));
  const [native,wnear,storage]=await Promise.all([ex.rpc.account(user),ex.rpc.view(WNEAR,'ft_balance_of',{account_id:user}),storagePlan(ex,asset.id)]);
  const deficit=inRaw>BigInt(wnear)?inRaw-BigInt(wnear):0n;
  if(BigInt(native.amount)-BigInt(native.storage_usage)*10000000000000000000n<deficit+storage.deposit+units(process.env.GAS_RESERVE_NEAR||'0.1')+1n)throw new Error(`NEAR disponible insuficiente para convertir ${display(inRaw)} NEAR en ${asset.symbol} y dejar la reserva de gas.`);
  await register(ex,id,asset.id,storage.registered,storage.deposit);
  await prepareWnear(ex,id,inRaw);
  const before=BigInt(await ex.rpc.view(asset.id,'ft_balance_of',{account_id:user}));
  const q=await quoteRoute(ex.rpc,route,WNEAR,asset.id,inRaw,slippageBps);
  ex.history.update(id,{bridge:{...ex.history.rows.find(r=>r.id===id)?.bridge,status:'SWAPPING',expectedRaw:q.raw,minRaw:q.minRaw}});
  const call=swapCall(route,WNEAR,asset.id,inRaw,q.minRaw);
  const result=await ex.call(id,WNEAR,'ft_transfer_call',{receiver_id:call.receiver,amount:inRaw.toString(),msg:call.msg},1n,call.gas,undefined,swapOpts());
  const outcome=inspectOutcome(result,accepted(getSpeed().confirmLevel));
  if(outcome.state==='REFUNDED')throw new Error(`El cambio de NEAR a ${asset.symbol} fue reembolsado por el pool (no entró ${asset.symbol}). El token objetivo NO se compró y tus fondos siguen como wNEAR.`);
  if(outcome.state!=='CONFIRMED')throw new Error(`El cambio de NEAR a ${asset.symbol} no se confirmó (${outcome.state}). El token objetivo NO se compró; revisá el historial y tu saldo de ${asset.symbol}.`);
  // El saldo puede tardar un instante en reflejarse con la confirmación rápida: se reintenta unos segundos.
  let after=before;for(let i=0;i<10;i++){after=BigInt(await ex.rpc.view(asset.id,'ft_balance_of',{account_id:user}));if(after>before)break;await new Promise(r=>setTimeout(r,500));}
  const received=after-before;
  if(received<=0n)throw new Error(`El cambio de NEAR a ${asset.symbol} fue reembolsado por el pool (no entró ${asset.symbol}). El token objetivo NO se compró y tus fondos siguen como wNEAR.`);
  if(received<BigInt(q.minRaw))throw new Error(`El cambio a ${asset.symbol} entregó menos que el mínimo (${display(received,asset.decimals)} < ${display(BigInt(q.minRaw),asset.decimals)}). El token objetivo NO se compró.`);
  ex.history.update(id,{bridge:{...ex.history.rows.find(r=>r.id===id)?.bridge,status:'DONE',receivedRaw:received.toString()}});
  return received;
 },asset.id);
}
