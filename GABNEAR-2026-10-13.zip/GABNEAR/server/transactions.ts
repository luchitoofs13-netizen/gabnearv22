import {actions,baseEncode,baseDecode,createTransaction,teraToGas} from 'near-api-js';
import {assertAllowedCall} from './call-policy.js';
import {localWallet,accountId} from './wallet.js';
import {NearRpc} from './rpc.js';
import {History} from './history.js';
import {timeline,recordStage} from './timing.js';
import {blocksAccount} from './recovery.js';
import {EXECUTED,FINAL_ONLY} from './finality.js';
import {performance} from 'node:perf_hooks';
export {EXECUTED,FINAL_ONLY};
export async function awaitFinal(rpc:NearRpc,hash:string,signer:string,timeoutMs=60000,onError?:(error:unknown)=>void,accept:readonly string[]=FINAL_ONLY){
 const start=performance.now();let delay=150;
 while(performance.now()-start<timeoutMs){
  try{const result=await (rpc.transactionStatus?rpc.transactionStatus(hash,signer,Math.max(1,Math.min(3000,timeoutMs-(performance.now()-start)))):rpc.deadline(rpc.provider.viewTransactionStatus({txHash:hash,accountId:signer,waitUntil:'NONE'})));if(accept.includes(result.final_execution_status))return result;}catch(error){onError?.(error);}
  const remaining=timeoutMs-(performance.now()-start);if(remaining<=0)break;
  await new Promise(resolve=>setTimeout(resolve,Math.min(delay,remaining)));delay=Math.min(1000,Math.round(delay*1.5));
 }
 throw new Error('Confirmación pendiente: timeout de observación. La recuperación automática consulta el hash sin reenviar.');
}
// Historial liviano: sin pruebas Merkle ni perfiles de gas (≈ 80% del peso). Los recibos que se verifican
// se leen del outcome vivo o se vuelven a pedir por hash, nunca de esta copia.
export function slimOutcome(outcome:any){
 if(!outcome||typeof outcome!=='object')return outcome;
 const slim=(o:any)=>o?{id:o.id,block_hash:o.block_hash,outcome:o.outcome?{logs:o.outcome.logs,receipt_ids:o.outcome.receipt_ids,gas_burnt:o.outcome.gas_burnt,tokens_burnt:o.outcome.tokens_burnt,executor_id:o.outcome.executor_id,status:o.outcome.status}:undefined}:o;
 return {final_execution_status:outcome.final_execution_status,status:outcome.status,transaction:outcome.transaction,transaction_outcome:slim(outcome.transaction_outcome),receipts_outcome:(outcome.receipts_outcome??[]).map(slim)};
}
// Errores de validación que la red devuelve ANTES de incluir la transacción. InvalidNonce es ambiguo: un
// reintento interno del provider pudo haber aceptado la primera copia y la segunda choca con su propio nonce.
const REJECTED=new Set(['InvalidTransactionError','InvalidSignerIdError','SignerDoesNotExistError','InvalidReceiverIdError','InvalidSignatureError','NotEnoughBalanceError','CostOverflowError','InvalidChainError','TransactionExpiredError','TransactionSizeExceededError','InvalidTransactionVersionError','ShardCongestedError','ShardStuckError','NonceTooLargeError']);
export function rejectionKind(error:unknown):'REJECTED'|'NONCE'|null{
 const name=(error as any)?.name;
 if(name==='InvalidNonceError')return 'NONCE';
 return REJECTED.has(name)?'REJECTED':null;
}
export const isUnknownTransaction=(error:unknown)=>/UnknownTransaction/i.test(`${(error as any)?.name??''} ${String(error)}`);
// Una transacción es válida 86400 bloques (~24 h); pasado ese plazo sin ejecución, jamás se ejecutará.
export const TX_VALIDITY_BLOCKS=86400;
export function inspectOutcome(outcome:any,accept:readonly string[]=FINAL_ONLY){
 if(!outcome||!accept.includes(outcome.final_execution_status))return {state:'UNKNOWN',used:null};
 const all=[outcome.transaction_outcome,...outcome.receipts_outcome??[]];
 if(outcome.status?.Failure||all.some(x=>x?.outcome?.status?.Failure))return {state:'FAILED',used:null};
 try{const value=JSON.parse(Buffer.from(outcome.status.SuccessValue,'base64').toString('utf8'));if(typeof value!=='string'||!/^\d+$/.test(value))throw new Error('Retorno inválido');const used=BigInt(value);return {state:used===0n?'REFUNDED':'CONFIRMED',used:used.toString()};}catch{return {state:'UNKNOWN',used:null};}
}
export class Executor {
 busy=false;
 constructor(readonly rpc:NearRpc,readonly history:History,readonly stopped:()=>boolean){}
 async context(id:string){
  const clock=timeline(this.history,id);const start=performance.now();const {signer}=await localWallet(this.rpc);const publicKey=await signer.getPublicKey();clock?.mark('signerReady',performance.now()-start);
  const [key,block]=await Promise.all([
   this.rpc.deadline(this.rpc.provider.viewAccessKey({accountId:accountId(),publicKey,finalityQuery:{finality:'optimistic'}})),
   this.rpc.deadline(this.rpc.provider.viewBlock({finality:'final'}))
  ]);
  if(key.permission!=='FullAccess')throw new Error('La clave ya no tiene FullAccess.');
  clock?.mark('nonceAndBlockReady',performance.now()-start);
  return {signer,publicKey,account:accountId(),nonce:BigInt(key.nonce)+1n,blockHash:baseDecode(block.header.hash),blockHeight:Number(block.header.height),at:Date.now()};
 }
 // KNOWN: el nodo conoce el hash. UNKNOWN: respuesta explícita UnknownTransaction. ERROR: no se pudo averiguar.
 async lookup(hash:string,signer:string):Promise<'KNOWN'|'UNKNOWN'|'ERROR'>{
  try{
   if(this.rpc.transactionStatus)await this.rpc.transactionStatus(hash,signer,2500);
   else await this.rpc.deadline(this.rpc.provider.viewTransactionStatus({txHash:hash,accountId:signer,waitUntil:'NONE'}),2500);
   return 'KNOWN';
  }catch(error){return isUnknownTransaction(error)?'UNKNOWN':'ERROR';}
 }
 async call(id:string,contract:string,method:string,args:object,deposit:bigint,gas=30,prefetched?:Omit<Awaited<ReturnType<Executor['context']>>,'blockHeight'>&{blockHeight?:number},opts:{confirm?:'FINAL'|'OPTIMISTIC'}={}):Promise<any>{
 const optimistic=opts.confirm==='OPTIMISTIC',accept=optimistic?EXECUTED:FINAL_ONLY;
 if(this.stopped())throw new Error('Parada de emergencia activa.');
 const clock=timeline(this.history,id);let stageStart=performance.now();
 const context=prefetched&&Date.now()-prefetched.at<10000&&prefetched.account===accountId()?prefetched:await this.context(id);
 const {signer}=context;stageStart=performance.now();
 assertAllowedCall(context.account,contract,method,args,deposit);
 // Nonce fresco de cadena por transacción, sin contador local ni reintentos.
 const tx=createTransaction(context.account,context.publicKey,contract,context.nonce,[actions.functionCall(method,args,teraToGas(gas),deposit)],context.blockHash);
 clock?.mark('nonceBlockAndConstruction',performance.now()-stageStart);stageStart=performance.now();
 const signed=await signer.signTransaction(tx);
 clock?.mark('signed',performance.now()-stageStart);
 const hash=baseEncode(signed.txHash);
 clock?.mark('hashComputed');
 if(this.stopped())throw new Error('Parada activa antes del envío.');
 const row=this.history.rows.find(r=>r.id===id);
 const transactions:any[]=[...(row?.transactions??[]),{hash,signer:accountId(),publicKey:context.publicKey.toString(),nonce:context.nonce.toString(),blockHeight:context.blockHeight,signedAt:new Date().toISOString(),contract,method,deposit:deposit.toString(),status:'SUBMITTING',timing:{sendOffsetMs:clock?performance.now()-clock.start:null}}];
 this.history.update(id,{status:'SUBMITTING',txHash:hash,signer:accountId(),contract,method,transactions,fundsSent:row?.fundsSent===true?true:null});
 // Registrar el hash ANTES del envío permite recuperar resultados inciertos sin reenviar.
 const sendStarted=performance.now();let finalStarted:number|undefined;
 try{
 clock?.mark('rpcSendStarted');
 const asyncSend=process.env.NEAR_ASYNC_SEND!=='false';
 let submitted:any,knownAfterError=false;
 const waitUntil=asyncSend?'NONE':optimistic?'EXECUTED_OPTIMISTIC':'FINAL',sendTimeout=asyncSend?3000:15000;
 // `send` difunde la MISMA firma a varios RPC (idempotente: mismo hash); sin él, un único proveedor.
 try{submitted=await (this.rpc.send?this.rpc.send(signed.signedTransaction,waitUntil,sendTimeout):this.rpc.deadline(this.rpc.provider.sendTransactionUntil(signed.signedTransaction,waitUntil),sendTimeout));}
 catch(sendError){
  const kind=rejectionKind(sendError);if(!kind)throw sendError;
  // La red devolvió un rechazo de validación: antes de liberar la cuenta se comprueba por hash que no exista.
  const known=await this.lookup(hash,context.account);
  if(known==='KNOWN'){submitted={final_execution_status:'NONE'};knownAfterError=true;}
  else if(kind==='REJECTED'&&known==='UNKNOWN'){
   const detail=sendError instanceof Error?sendError.message:String(sendError);
   transactions[transactions.length-1].status='REJECTED';transactions[transactions.length-1].error=detail;
   recordStage(this.history,id,'rpcRejected',performance.now()-sendStarted,{error:detail});
   this.history.update(id,{status:'FAILED',txHash:hash,transactions,fundsSent:row?.fundsSent===true,error:'La red rechazó la transacción antes de ejecutarla; no se movieron fondos por ella. '+detail});
   throw Object.assign(new Error('Transacción rechazada por la red; no se ejecutó. '+detail),{rejected:true});
  }else{transactions[transactions.length-1].sendError=kind;throw sendError;}
 }
 recordStage(this.history,id,'rpcAcknowledged',performance.now()-sendStarted,{waitUntil,acceptanceOnly:asyncSend,...(knownAfterError?{source:'status-lookup-after-rejection'}:{})});
 transactions[transactions.length-1].timing.ackOffsetMs=clock?performance.now()-clock.start:null;
 if(asyncSend||knownAfterError)this.history.update(id,{status:'CONFIRMING',fundsSent:true});
 finalStarted=performance.now();
 const outcome=(asyncSend||knownAfterError)&&!accept.includes(submitted.final_execution_status)?await awaitFinal(this.rpc,hash,context.account,Number(process.env.NEAR_CONFIRM_TIMEOUT_MS)||60000,error=>recordStage(this.history,id,'blockchainPollError',undefined,{error:String(error),timeout:/timeout|excedió/i.test(String(error))}),accept):submitted;
 const reached=accept.includes(outcome.final_execution_status);
 if(reached)recordStage(this.history,id,outcome.final_execution_status==='FINAL'?'blockchainFinal':'blockchainExecuted',performance.now()-finalStarted,{source:'rpc-observation',level:outcome.final_execution_status});
 transactions[transactions.length-1].timing.finalOffsetMs=clock?performance.now()-clock.start:null;
 transactions[transactions.length-1].gasBurnt=[outcome.transaction_outcome,...outcome.receipts_outcome??[]].reduce((sum:bigint,r:any)=>sum+BigInt(r?.outcome?.tokens_burnt??'0'),0n).toString();
 transactions[transactions.length-1].status=outcome.final_execution_status==='FINAL'?'FINAL':reached?'EXECUTED':'UNKNOWN';
 // finality OPTIMISTIC: el vigilante de finalidad confirma después que llegó a FINAL (o reabre la recuperación).
 this.history.update(id,{lastOutcome:slimOutcome(outcome),txHash:hash,transactions,fundsSent:true,finality:outcome.final_execution_status==='FINAL'?'FINAL':'OPTIMISTIC',status:reached?'PREPARING':'UNKNOWN'});return outcome;
 }catch(error){if((error as any)?.rejected)throw error;const message=error instanceof Error?error.message:String(error);const acknowledged=transactions[transactions.length-1].timing.ackOffsetMs!==undefined;
 recordStage(this.history,id,acknowledged?'blockchainFinalError':'rpcAcknowledgedError',performance.now()-(acknowledged?finalStarted??sendStarted:sendStarted),{error:message,timeout:/timeout|excedió/i.test(message)});
 transactions[transactions.length-1].status='UNKNOWN';transactions[transactions.length-1].error=message;
 this.history.update(id,{status:'UNKNOWN',txHash:hash,transactions,error:message});throw new Error('Resultado incierto. GABNEAR recuperando automáticamente, sin reenviar. '+message);}
 }
 async reconcile(hash:string,signer=accountId()){return this.rpc.transactionStatus(hash,signer);}
 async exclusive<T>(fn:()=>Promise<T>,token?:string){if(this.busy)throw new Error('Ya hay una operación en curso.');if(this.history.rows.some(r=>blocksAccount(r,accountId(),token)))throw new Error('Hay una transacción incierta; GABNEAR recupera su resultado automáticamente.');this.busy=true;try{return await fn();}finally{this.busy=false;}}
}
