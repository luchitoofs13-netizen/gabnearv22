import {NearRpc} from './rpc.js';
import {display} from './validation.js';
import {executableExit} from './trading.js';
import {quoteAsset,WRAPPED_NEAR} from './quote-asset.js';
export type UsdPrice={usd:number;source:string;fetchedAt:string};
let cached:UsdPrice|null=null;
let pending:Promise<UsdPrice>|null=null;
export function parseTicker(ticker:any):UsdPrice {
 const usd=Number(ticker?.bid);
 if(!Number.isFinite(usd)||usd<=0)throw new Error('Precio NEAR/USD no válido.');
 return {usd,source:'Coinbase Exchange · NEAR/USD bid',fetchedAt:new Date().toISOString()};
}
export async function nearUsd():Promise<UsdPrice>{
 if(cached&&Date.now()-Date.parse(cached.fetchedAt)<30000)return cached;
 if(pending)return pending;
 pending=(async()=>{
  const response=await fetch('https://api.exchange.coinbase.com/products/NEAR-USD/ticker',{signal:AbortSignal.timeout(5000),headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error('Precio USD no disponible.');
  cached=parseTicker(await response.json());return cached;
 })();
 try{return await pending;}finally{pending=null;}
}
export async function estimateUsd(rpc:NearRpc,position:any,balance:bigint,bps:number,lookup:()=>Promise<UsdPrice>=nearUsd,quoteNear?:(rpc:NearRpc,quoteId:string)=>Promise<number|null>){
 const at=new Date().toISOString();
 if(balance===0n)return {status:'AVAILABLE',expectedUsd:0,minimumUsd:0,quotedAt:at,scope:'TOTAL_BALANCE'};
 if(quoteAsset(position).id!==WRAPPED_NEAR&&quoteNear){
  // Quote distinto de wNEAR (p. ej. RHEA): se cotiza la venta en ese quote y se convierte con el precio del quote en NEAR y el de NEAR en USD.
  try{
   const asset=quoteAsset(position),[q,price,qn]=await Promise.all([executableExit(rpc,position,balance,bps),lookup(),quoteNear(rpc,asset.id)]);
   if(qn===null)throw new Error('sin precio del quote');
   const k=qn*price.usd,expectedUsd=Number(display(q.raw,asset.decimals))*k,minimumUsd=Number(display(q.minRaw,asset.decimals))*k;
   if(!Number.isFinite(expectedUsd)||!Number.isFinite(minimumUsd))throw new Error('Valor USD fuera de rango.');
   return {status:'AVAILABLE',expectedUsd,minimumUsd,quotedAt:q.quotedAt,scope:'TOTAL_BALANCE',nearUsd:price.usd,source:price.source+` · ${asset.symbol}→NEAR por pool`,priceFetchedAt:price.fetchedAt};
  }catch{return {status:'UNAVAILABLE',expectedUsd:null,minimumUsd:null,quotedAt:at,scope:'TOTAL_BALANCE',error:'No se pudo cotizar el saldo, el precio del quote o NEAR/USD.'};}
 }
 if(quoteAsset(position).id!==WRAPPED_NEAR)return {status:'UNAVAILABLE',expectedUsd:null,minimumUsd:null,quotedAt:at,scope:'TOTAL_BALANCE',error:'Sin fuente USD validada para este quote FT. La venta se cotiza en su quote original.'};
 try{
  // Se cotiza el saldo entero; no se multiplica una cotización parcial por dos.
  const [q,price]=await Promise.all([executableExit(rpc,position,balance,bps),lookup()]);
  const expectedUsd=Number(display(q.raw))*price.usd,minimumUsd=Number(display(q.minRaw))*price.usd;
  if(!Number.isFinite(expectedUsd)||!Number.isFinite(minimumUsd))throw new Error('Valor USD fuera de rango.');
  return {status:'AVAILABLE',expectedUsd,minimumUsd,quotedAt:q.quotedAt,scope:'TOTAL_BALANCE',exitNear:display(q.raw),nearUsd:price.usd,source:price.source,priceFetchedAt:price.fetchedAt};
 }catch{return {status:'UNAVAILABLE',expectedUsd:null,minimumUsd:null,quotedAt:at,scope:'TOTAL_BALANCE',error:'No se pudo cotizar el saldo total o consultar NEAR/USD.'};}
}
