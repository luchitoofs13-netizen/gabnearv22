import {z} from 'zod';
const ACCOUNT_PART='[a-z0-9]+(?:[-_][a-z0-9]+)*';
const ACCOUNT_ID=new RegExp(`^${ACCOUNT_PART}(?:\\.${ACCOUNT_PART})*$`);
// Cuentas de contratos FT en mainnet: subcuentas de .near/.tg/.sweat/.aurora, implícitas (64 hex) y `aurora`.
const TOKEN_SUFFIXES=['.near','.tg','.sweat','.aurora'];
export function isTokenAccount(value:string):boolean {
 if(typeof value!=='string'||value.length<2||value.length>64||!ACCOUNT_ID.test(value))return false;
 if(/^[0-9a-f]{64}$/.test(value)||value==='aurora')return true;
 return TOKEN_SUFFIXES.some(suffix=>value.length>suffix.length&&value.endsWith(suffix));
}
export function extractToken(input:string):string {
 const bare=input.trim();
 if(isTokenAccount(bare)&&bare!=='wrap.near')return bare;
 if(bare==='wrap.near')throw new Error('wrap.near es el quote, no un token para comprar.');
 let u:URL; try {u=new URL(bare);} catch {throw new Error('Pegá la cuenta del token (ej. ai-8.nearlytrade.near) o un enlace HTTPS de nearly.trade / nearblocks.io.');}
 if(u.protocol!=='https:'||u.port||u.username||u.password||!['nearly.trade','nearblocks.io'].includes(u.hostname))throw new Error('El enlace debe pertenecer exactamente a https://nearly.trade o https://nearblocks.io.');
 let path=decodeURIComponent(u.pathname.replace(/^\//,'').replace(/\/$/,''));
 // nearblocks.io/token/<cuenta> y /address/<cuenta>
 if(u.hostname==='nearblocks.io')path=path.replace(/^(?:token|address)\//,'');
 if(!isTokenAccount(path)||path==='wrap.near')throw new Error('El enlace no contiene una cuenta de token NEAR válida.');
 return path;
}
export function units(value:string,decimals=24):bigint {
 if(!/^\d+(\.\d+)?$/.test(value))throw new Error('Importe inválido.');
 const [a,b='']=value.split('.'); if(b.length>decimals)throw new Error('Demasiados decimales.');
 return BigInt(a)*10n**BigInt(decimals)+BigInt(b.padEnd(decimals,'0')||'0');
}
export function display(raw:string|bigint,decimals=24):string {
 const n=BigInt(raw),scale=10n**BigInt(decimals);return `${n/scale}.${(n%scale).toString().padStart(decimals,'0')}`.replace(/\.?0+$/,'')||'0';
}
// display() no admite negativos (una pérdida realizada lo es): se formatea el valor absoluto y se antepone el signo.
export function displaySigned(raw:string|bigint,decimals=24):string {
 const n=BigInt(raw);return n<0n?'-'+display(-n,decimals):display(n,decimals);
}
export const requestSchema=z.object({url:z.string().max(300),amount:z.string().max(50),slippageBps:z.number().int().min(1).max(9900)});
export function checkRisk(amount:string,slippageBps:number,_legacyMaxNear:string,maxBps:number){
 const n=units(amount);if(n<=0n)throw new Error('El importe debe ser positivo.');
 if(!Number.isInteger(slippageBps)||slippageBps<1||slippageBps>Math.min(maxBps,9900))throw new Error(`Slippage máximo permitido: ${Math.min(maxBps,9900)/100}%.`);
 return n;
}
