import {randomBytes,scrypt as scryptCallback,createCipheriv,createDecipheriv,type ScryptOptions} from 'node:crypto';
import {promisify} from 'node:util';
const scrypt=promisify(scryptCallback) as (password:string,salt:Buffer,keylen:number,options?:ScryptOptions)=>Promise<Buffer>;
// v1: parámetros por defecto de Node (N=16384). v2: N=2^17 (~128 MB, ~0,3 s), guardados en el archivo para poder subirlos después.
const KDF_V2={N:2**17,r:8,p:1};
const MAX_MEM=512*1024*1024;
function kdfOptions(p:any){
 if(p.v===1)return undefined;
 const {N,r,p:par}=p.kdf??{};
 // Un archivo manipulado no puede pedir memoria/tiempo arbitrarios.
 if(!Number.isInteger(N)||N<2**14||N>2**20||(N&(N-1))!==0||r!==8||par!==1)throw new Error('kdf inválido');
 return {N,r,p:par,maxmem:MAX_MEM};
}
export async function seal(secret:string,password:string){
 if(password.length<12||password.length>256)throw new Error('Usá una contraseña local de 12 a 256 caracteres.');
 const salt=randomBytes(16),iv=randomBytes(12);const key=await scrypt(password,salt,32,{...KDF_V2,maxmem:MAX_MEM}) as Buffer;
 try{const cipher=createCipheriv('aes-256-gcm',key,iv);const ciphertext=Buffer.concat([cipher.update(secret,'utf8'),cipher.final()]);return JSON.stringify({v:2,kdf:KDF_V2,salt:salt.toString('base64'),iv:iv.toString('base64'),tag:cipher.getAuthTag().toString('base64'),ciphertext:ciphertext.toString('base64')});}finally{key.fill(0);}
}
export async function unseal(payload:string,password:string){
 try{const p=JSON.parse(payload);if(p.v!==1&&p.v!==2)throw new Error();const options=kdfOptions(p);const salt=Buffer.from(p.salt,'base64');const key=(options?await scrypt(password,salt,32,options):await scrypt(password,salt,32)) as Buffer;try{const cipher=createDecipheriv('aes-256-gcm',key,Buffer.from(p.iv,'base64'));cipher.setAuthTag(Buffer.from(p.tag,'base64'));return Buffer.concat([cipher.update(Buffer.from(p.ciphertext,'base64')),cipher.final()]).toString('utf8');}finally{key.fill(0);}}catch{throw new Error('Contraseña incorrecta o archivo local dañado.');}
}
