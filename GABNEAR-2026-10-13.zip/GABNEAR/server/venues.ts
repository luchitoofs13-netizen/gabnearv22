import {NearRpc} from './rpc.js';
import {DCL,DCL_FEES,REF_V1,WRAPPED_NEAR} from './constants.js';
import {quote as dclQuote} from './quotes.js';

// Una ruta es UN pool directo token/quote en un venue. No hay multi-hop: lo no soportado se bloquea, nunca se inventa.
export type Route={venue:'DCL'|'REF_V1';poolId:string;receiver:string;fee:number;quote:string;token:string;info?:Record<string,string|number|null>};
export type RouteQuote={raw:string;minRaw:string;quotedAt:string};
export type Ranked={route:Route;quote:RouteQuote|null;probe:RouteQuote|null;probeAmount:bigint;error?:string};

export const dclPoolId=(a:string,b:string,fee:number)=>`${[a,b].sort().join('|')}|${fee}`;
// `fee` es el nivel del pool DCL en partes por millón (10000 = 1%); la ruta lo guarda en bps como Ref v1 (total_fee: 30 = 0,30%).
export function dclRoute(token:string,quote:string,fee:number,poolId=dclPoolId(token,quote,fee),info?:Route['info']):Route{return {venue:'DCL',poolId,receiver:DCL,fee:Math.round(fee/100),quote,token,info};}
// Ruta DCL de un launch de Nearly (el pool lo dice la fábrica, no se construye).
export function routeFromRecord(record:{token?:string;pool_id:string;quote?:string},fee=0):Route{return dclRoute(record.token??'',record.quote??WRAPPED_NEAR,fee,record.pool_id);}
export function routeOf(position:any):Route{
 if(position?.route?.venue&&position.route.poolId)return position.route as Route;
 return routeFromRecord({token:position?.token,pool_id:position?.record?.pool_id,quote:position?.record?.quote});
}

// ── Ref v1 (AMM clásico): índice incremental de pools ───────────────────────────────────────────────
type RefPool={id:number;a:string;b:string};
export class RefIndex {
 private pairs=new Map<string,RefPool[]>();
 private next=0;
 private pending:Promise<void>|null=null;
 private checkedAt=0;
 constructor(readonly pageSize=500,readonly parallel=4){}
 get size(){return this.next;}
 private key(a:string,b:string){return [a,b].sort().join('|');}
 poolsFor(a:string,b:string){return this.pairs.get(this.key(a,b))??[];}
 refresh(rpc:NearRpc,maxAgeMs=3000):Promise<void>{
  if(this.pending)return this.pending;
  if(this.next>0&&Date.now()-this.checkedAt<maxAgeMs)return Promise.resolve();
  const work=this.load(rpc).finally(()=>{this.pending=null;});this.pending=work;return work;
 }
 // Solo pide lo nuevo: get_number_of_pools + páginas desde el último índice. El primer escaneo (~9 mil pools) tarda ~2 s.
 private async load(rpc:NearRpc){
  const total=Number(await rpc.view(REF_V1,'get_number_of_pools'));
  if(!Number.isInteger(total)||total<0)throw new Error('Ref v1: cantidad de pools inválida.');
  const starts:number[]=[];for(let from=this.next;from<total;from+=this.pageSize)starts.push(from);
  const pages=new Map<number,any[]>(),queue=[...starts];
  const worker=async()=>{for(let from=queue.shift();from!==undefined;from=queue.shift()){const page=await rpc.view<any[]>(REF_V1,'get_pools',{from_index:from,limit:this.pageSize});if(!Array.isArray(page))throw new Error('Ref v1: respuesta de pools inválida.');pages.set(from,page);}};
  await Promise.all(Array.from({length:Math.min(this.parallel,starts.length)},worker));
  for(const from of starts){
   const page=pages.get(from)!;
   page.forEach((p,i)=>{
    // Solo pools simples de 2 tokens: los estables/rated/degen tienen otra matemática y no se soportan.
    if(p?.pool_kind!=='SIMPLE_POOL'||!Array.isArray(p.token_account_ids)||p.token_account_ids.length!==2)return;
    const [a,b]=p.token_account_ids as [string,string],key=this.key(a,b),list=this.pairs.get(key)??[];list.push({id:from+i,a,b});this.pairs.set(key,list);
   });
   this.next=from+page.length;
  }
  this.checkedAt=Date.now();
 }
 reset(){this.pairs.clear();this.next=0;this.checkedAt=0;}
}
export const refIndex=new RefIndex();

const nonZero=(v:unknown)=>typeof v==='string'&&/^\d+$/.test(v)&&BigInt(v)>0n;
export async function findRefRoutes(rpc:NearRpc,token:string,quote:string,index=refIndex):Promise<Route[]>{
 await index.refresh(rpc);
 // Los más nuevos primero; tope para no disparar decenas de lecturas en pares muy poblados.
 const candidates=index.poolsFor(token,quote).slice(-16);
 if(!candidates.length)return [];
 // Una sola lectura en lote (get_pool_by_ids); los ids salen del índice, así que son válidos.
 const pools=await rpc.view<any[]>(REF_V1,'get_pool_by_ids',{pool_ids:candidates.map(c=>c.id)});
 const routes:Route[]=[];
 candidates.forEach((c,k)=>{
  const p=pools?.[k];if(!p||p.pool_kind!=='SIMPLE_POOL'||!Array.isArray(p.token_account_ids)||!Array.isArray(p.amounts))return;
  const i=p.token_account_ids.indexOf(token),j=p.token_account_ids.indexOf(quote);
  if(i<0||j<0||i===j||!nonZero(p.amounts[i])||!nonZero(p.amounts[j]))return;
  routes.push({venue:'REF_V1',poolId:String(c.id),receiver:REF_V1,fee:Number(p.total_fee)||0,quote,token,info:{reserveToken:p.amounts[i],reserveQuote:p.amounts[j],totalFeeBps:Number(p.total_fee)||0}});
 });
 return routes;
}

// ── Rhea DCL v2: el id del pool se construye (tokens ordenados + fee) y get_pool devuelve null si no existe ───
export async function findDclRoutes(rpc:NearRpc,token:string,quote:string):Promise<Route[]>{
 // get_pools devuelve un arreglo alineado con los ids pedidos (null si el pool no existe): 1 lectura en vez de 4.
 const ids=DCL_FEES.map(fee=>dclPoolId(token,quote,fee));
 const pools=await rpc.view<any[]>(DCL,'get_pools',{pool_ids:ids});
 const routes:Route[]=[];
 ids.forEach((poolId,k)=>{
  const pool=pools?.[k];
  if(!pool||pool.state!=='Running'||![pool.token_x,pool.token_y].includes(token)||![pool.token_x,pool.token_y].includes(quote))return;
  // total_x/total_y = cantidades totales de cada token en el pool (base de la liquidez que muestran DexScreener y GeckoTerminal).
  const tokenIsX=pool.token_x===token;
  routes.push(dclRoute(token,quote,DCL_FEES[k],poolId,{liquidity:String(pool.liquidity??'0'),currentPoint:Number(pool.current_point),totalQuote:String((tokenIsX?pool.total_y:pool.total_x)??'0'),totalToken:String((tokenIsX?pool.total_x:pool.total_y)??'0')}));
 });
 return routes;
}
// La existencia de pools casi no cambia en segundos: las rutas candidatas se reutilizan 10 s (y se deduplican las
// lecturas simultáneas). Las COTIZACIONES nunca se cachean: cada compra/venta cotiza de nuevo.
const routeCache=new Map<string,{at:number;work:Promise<Route[]>}>();
export function clearRouteCache(){routeCache.clear();}
export function findRoutes(rpc:NearRpc,token:string,quote=WRAPPED_NEAR):Promise<Route[]>{
 const key=`${token}|${quote}`,hit=routeCache.get(key);
 if(hit&&Date.now()-hit.at<10000)return hit.work;
 if(routeCache.size>128)routeCache.clear();
 let refError:unknown=null;
 const work=Promise.all([findDclRoutes(rpc,token,quote),findRefRoutes(rpc,token,quote).catch(e=>{refError=e;return [] as Route[];})]).then(([dcl,ref])=>{
  const all=[...dcl,...ref];
  // Si Ref v1 falló y no hay nada más, el problema es de lectura, no de falta de pools.
  if(!all.length&&refError)throw refError;
  return all;
 });
 routeCache.set(key,{at:Date.now(),work});
 // Sin rutas (token recién creado, pool aún inexistente) o con error: no se cachea, el próximo intento vuelve a leer.
 void work.then(routes=>{if(!routes.length&&routeCache.get(key)?.work===work)routeCache.delete(key);},()=>{if(routeCache.get(key)?.work===work)routeCache.delete(key);});
 return work;
}

// ── Cotización y mensaje de swap por ruta ───────────────────────────────────────────────────────────
export async function quoteRoute(rpc:NearRpc,route:Route,input:string,output:string,amount:bigint,slippageBps:number):Promise<RouteQuote>{
 if(route.venue==='DCL')return dclQuote(rpc,route.poolId,input,output,amount,slippageBps);
 if(!Number.isInteger(slippageBps)||slippageBps<1||slippageBps>9900)throw new Error('Slippage debe estar entre 0,01% y 99%.');
 if(amount<=0n)throw new Error('Importe de cotización inválido.');
 const out=await rpc.view<unknown>(REF_V1,'get_return',{pool_id:Number(route.poolId),token_in:input,amount_in:amount.toString(),token_out:output});
 if(typeof out!=='string'||!/^\d+$/.test(out)||BigInt(out)<=0n)throw new Error('La liquidez no permite cotizar este importe.');
 const min=BigInt(out)*BigInt(10000-slippageBps)/10000n;
 if(min<=0n)throw new Error('Salida mínima nula.');
 return {raw:out,minRaw:min.toString(),quotedAt:new Date().toISOString()};
}
// Argumentos de ft_transfer_call hacia el venue. Formatos de ref-sdk: DCL `Swap`, Ref v1 `actions` (force:0 legado).
export function swapCall(route:Route,input:string,output:string,amount:bigint,minRaw:string){
 if(route.venue==='DCL')return {receiver:DCL,gas:180,msg:JSON.stringify({Swap:{pool_ids:[route.poolId],output_token:output,min_output_amount:minRaw}})};
 return {receiver:REF_V1,gas:300,msg:JSON.stringify({force:0,actions:[{pool_id:Number(route.poolId),token_in:input,token_out:output,amount_in:amount.toString(),min_amount_out:minRaw}]})};
}

// Cotiza todas las rutas candidatas en paralelo (y una cotización pequeña para medir impacto) y ordena por salida.
export async function rankRoutes(rpc:NearRpc,routes:Route[],input:string,output:string,amount:bigint,slippageBps:number,withProbe=true):Promise<Ranked[]>{
 const probeAmount=withProbe&&amount>=20000n?amount/20n:0n;
 const ranked=await Promise.all(routes.map(async route=>{
  const [main,probe]=await Promise.allSettled([quoteRoute(rpc,route,input,output,amount,slippageBps),probeAmount>0n?quoteRoute(rpc,route,input,output,probeAmount,slippageBps):Promise.resolve(null)]);
  return {route,quote:main.status==='fulfilled'?main.value:null,probe:probe.status==='fulfilled'?probe.value:null,probeAmount,error:main.status==='rejected'?(main.reason as Error).message:undefined} as Ranked;
 }));
 return ranked.sort((a,b)=>{const x=BigInt(a.quote?.raw??0),y=BigInt(b.quote?.raw??0);return x>y?-1:x<y?1:0;});
}
export const bestRoute=(ranked:Ranked[])=>ranked.find(r=>r.quote!==null);

// ── Riesgo ──────────────────────────────────────────────────────────────────────────────────────────
export type Risk={impactBps:number|null;roundTripLossBps:number|null;reserveQuote:string|null;warnings:string[];blocked:string|null};
export const riskLimits=()=>({
 maxImpactBps:Math.max(1,Math.floor(Number(process.env.MAX_PRICE_IMPACT_BPS)||1500)),
 maxRoundTripBps:Math.max(1,Math.floor(Number(process.env.MAX_ROUNDTRIP_LOSS_BPS)||4000)),
 minReserveQuote:BigInt(Math.round((Number(process.env.MIN_POOL_NEAR)||1)*1000))*10n**21n
});
// impacto = cuánto peor es el precio medio del importe pedido frente al de una orden 20 veces menor (misma ruta y fee).
export function priceImpactBps(amount:bigint,out:bigint,probeAmount:bigint,probeOut:bigint):number|null{
 if(amount<=0n||probeAmount<=0n||out<=0n||probeOut<=0n)return null;
 const ratio=out*probeAmount*10000n/(probeOut*amount);
 const impact=10000n-ratio;
 return Number(impact<0n?0n:impact>10000n?10000n:impact);
}
export function assessRisk(ranked:Ranked,amount:bigint,roundTripLossBps:number|null=null):Risk{
 const {route,quote,probe,probeAmount}=ranked,limits=riskLimits(),warnings:string[]=[];let blocked:string|null=null;
 const impactBps=quote&&probe?priceImpactBps(amount,BigInt(quote.raw),probeAmount,BigInt(probe.raw)):null;
 const reserveQuote=route.venue==='REF_V1'&&route.info?.reserveQuote!=null?String(route.info.reserveQuote):null;
 if(impactBps===null)warnings.push('No se pudo medir el impacto de precio de esta orden.');
 else if(impactBps>limits.maxImpactBps)blocked=`Impacto de precio ${(impactBps/100).toFixed(1)}% supera el límite ${(limits.maxImpactBps/100).toFixed(1)}%: el pool es demasiado chico para este importe.`;
 else if(impactBps>300)warnings.push(`Impacto de precio ${(impactBps/100).toFixed(1)}%: el pool es chico para este importe.`);
 if(!blocked&&reserveQuote!==null&&BigInt(reserveQuote)<limits.minReserveQuote)blocked=`Liquidez del pool (${reserveQuote} yocto de quote) por debajo del mínimo configurado.`;
 if(!blocked&&roundTripLossBps!==null){
  if(roundTripLossBps>limits.maxRoundTripBps)blocked=`Comprar y vender de inmediato perdería ${(roundTripLossBps/100).toFixed(1)}% (límite ${(limits.maxRoundTripBps/100).toFixed(1)}%): fees/impuestos del pool o pool trampa.`;
  else if(roundTripLossBps>1500)warnings.push(`Ida y vuelta inmediata: pérdida estimada ${(roundTripLossBps/100).toFixed(1)}%.`);
 }
 if(route.fee>=500)warnings.push(`Fee del pool ${(route.fee/100).toFixed(2)}% (alto).`);
 return {impactBps,roundTripLossBps,reserveQuote,warnings,blocked};
}
// Resultado de la simulación de ida y vuelta hecha al pegar el contrato; vale 2 minutos.
const roundTrips=new Map<string,{at:number;loss:number}>();
export function cacheRoundTrip(token:string,poolId:string,loss:number){if(roundTrips.size>200)roundTrips.clear();roundTrips.set(`${token}|${poolId}`,{at:Date.now(),loss});}
export function cachedRoundTrip(token:string,poolId:string):number|null{const v=roundTrips.get(`${token}|${poolId}`);return v&&Date.now()-v.at<120000?v.loss:null;}
// Simula (solo lectura) vender de vuelta lo que daría la compra. No detecta contratos que bloqueen transfers.
export async function roundTripLoss(rpc:NearRpc,route:Route,quote:string,token:string,spent:bigint,quoted:RouteQuote):Promise<number|null>{
 try{
  const back=await quoteRoute(rpc,route,token,quote,BigInt(quoted.raw),100);
  const loss=10000n-BigInt(back.raw)*10000n/spent;
  return Number(loss<0n?0n:loss>10000n?10000n:loss);
 }catch(error){
  // Sin liquidez para vender de vuelta = trampa potencial (100% de pérdida). Un error de red NO se interpreta como riesgo.
  return /liquidez|nula|inválid/i.test((error as Error).message)?10000:null;
 }
}
