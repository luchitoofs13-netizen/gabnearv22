import {existsSync,readFileSync,writeFileSync,mkdirSync,renameSync,copyFileSync} from 'node:fs';
import {Account,KeyPair,KeyPairSigner,baseDecode,type KeyPairString} from 'near-api-js';
import {NearRpc} from './rpc.js';
import {decryptKey,encryptKey} from './secure-store.js';
import {generateSeedPhrase,parseSeedPhrase} from 'near-seed-phrase';
import {seal,unseal} from './vault.js';
import {createRequire} from 'node:module';
const {validateMnemonic}=createRequire(import.meta.url)('bip39-light') as {validateMnemonic:(value:string)=>boolean};
let unlockedKey:KeyPairString|null=null;
let unlockedAccount='';
let cachedSigner:KeyPairSigner|null=null;
let legacyKey:KeyPairString|null=null;
export function accountId(){return existsSync('data/selected-account.txt')?readFileSync('data/selected-account.txt','utf8').replace(/^﻿/,'').trim():process.env.BOT_ACCOUNT_ID|| (existsSync('data/account.txt')?readFileSync('data/account.txt','utf8').replace(/^﻿/,'').trim():'');}
export function walletPresent(){return existsSync('data/wallet-v2.dpapi')||existsSync('data/wallet.dpapi');}
export function walletState(){return {accountId:accountId(),hasLocalKey:walletPresent(),unlocked:!!unlockedKey&&unlockedAccount===accountId(),importedAccount:existsSync('data/account.txt')?readFileSync('data/account.txt','utf8').replace(/^﻿/,'').trim():null,implicit:/^[0-9a-f]{64}$/.test(accountId())};}
function select(account:string){mkdirSync('data',{recursive:true});writeFileSync('data/selected-account.txt.tmp',account);renameSync('data/selected-account.txt.tmp','data/selected-account.txt');lockWallet();}
export function lockWallet(){unlockedKey=null;unlockedAccount='';cachedSigner=null;legacyKey=null;}
export function disconnectWallet(){select('');return walletState();}
const ACCOUNT_RE=/^(?:[a-z0-9]+(?:[-_][a-z0-9]+)*(?:\.[a-z0-9]+(?:[-_][a-z0-9]+)*)*|[0-9a-f]{64})$/;
export async function connectPublic(rpc:NearRpc,account:string){
 if(!ACCOUNT_RE.test(account)||account.length<2||account.length>64||account.endsWith('.testnet'))throw new Error('Ingresá una cuenta NEAR mainnet válida.');
 await rpc.account(account);select(account);return walletState();
}
// La cuenta implícita de una clave ed25519 es el hex de su clave pública: no hace falta crearla, existe al recibir NEAR.
export function implicitAccountId(publicKey:string){return Buffer.from(baseDecode(publicKey.replace(/^ed25519:/,''))).toString('hex');}
// Antes de reemplazar una wallet local se archiva la bóveda anterior: sobrescribirla en silencio podía dejar fondos sin clave.
function archiveCurrent(){
 if(!existsSync('data/wallet-v2.dpapi')&&!existsSync('data/wallet.dpapi'))return null;
 mkdirSync('data/archive',{recursive:true});
 const old=(existsSync('data/account.txt')?readFileSync('data/account.txt','utf8').replace(/^﻿/,'').trim():'')||'desconocida',stamp=new Date().toISOString().replace(/[:.]/g,'-');
 for(const file of ['wallet-v2.dpapi','wallet.dpapi'])if(existsSync('data/'+file))copyFileSync('data/'+file,`data/archive/${old}.${stamp}.${file}`);
 return `data/archive/${old}.${stamp}`;
}
async function install(account:string,secretKey:string,password:string){
 const payload=await seal(secretKey,password);mkdirSync('data',{recursive:true});
 const archived=archiveCurrent();
 await encryptKey('data/wallet-v2.dpapi.tmp',payload);renameSync('data/wallet-v2.dpapi.tmp','data/wallet-v2.dpapi');writeFileSync('data/account.txt',account);select(account);
 unlockedKey=secretKey as KeyPairString;unlockedAccount=account;
 return archived;
}
// Wallet nueva y dedicada: la clave nace aquí y no pasa por ninguna otra wallet. La frase se devuelve UNA sola vez.
export async function generateWallet(password:string){
 if(password.length<12||password.length>256)throw new Error('Usá una contraseña local de 12 a 256 caracteres.');
 const fresh=generateSeedPhrase(),account=implicitAccountId(fresh.publicKey);
 const archived=await install(account,fresh.secretKey,password);
 return {...walletState(),seedPhrase:fresh.seedPhrase,publicKey:fresh.publicKey,archivedPrevious:archived,funded:false};
}
async function requireFullAccess(rpc:NearRpc,account:string,publicKey:string){
 let access:any;try{access=await rpc.deadline(rpc.provider.viewAccessKey({accountId:account,publicKey}));}catch{throw new Error('La clave no está autorizada en esa cuenta (o la cuenta todavía no existe). Revisá la cuenta y la clave.');}
 if(access.permission!=='FullAccess')throw new Error('La clave no tiene permisos suficientes para preparar almacenamiento y swaps.');
}
export async function importSeed(rpc:NearRpc,account:string,seed:string,password:string){
 if(password.length<12||password.length>256)throw new Error('Usá una contraseña local de 12 a 256 caracteres.');
 if(!account||account.length>64||account.endsWith('.testnet'))throw new Error('Cuenta mainnet inválida.');
 let key:ReturnType<typeof parseSeedPhrase>;
 try{const normalized=seed.trim().toLowerCase().split(/\s+/).join(' ');if(!validateMnemonic(normalized))throw new Error();key=parseSeedPhrase(normalized);}catch{throw new Error('Frase semilla NEAR inválida.');}
 // Solo se envía la clave PÚBLICA al RPC. Nunca la frase ni la clave privada.
 await requireFullAccess(rpc,account,key.publicKey);
 await install(account,key.secretKey,password);
 key.seedPhrase='';key.secretKey='';return walletState();
}
// Clave privada ed25519 (formato `ed25519:…`): menos exposición que una frase semilla, que puede gobernar otras cuentas.
// Sin cuenta indicada se usa la implícita de esa clave.
export async function importKey(rpc:NearRpc,account:string,secret:string,password:string){
 if(password.length<12||password.length>256)throw new Error('Usá una contraseña local de 12 a 256 caracteres.');
 const text=secret.trim();let keyPair:KeyPair;
 try{
  if(!/^ed25519:[1-9A-HJ-NP-Za-km-z]{60,100}$/.test(text)||baseDecode(text.slice(8)).length!==64)throw new Error();
  keyPair=KeyPair.fromString(text as KeyPairString);
  // Forma canónica: cualquier carácter de más o de menos que aún decodifique no se acepta.
  if(keyPair.toString()!==text)throw new Error();
 }catch{throw new Error('Clave privada inválida: debe tener el formato ed25519:…');}
 const publicKey=keyPair.getPublicKey().toString(),target=account.trim()||implicitAccountId(publicKey);
 if(target.length>64||target.endsWith('.testnet')||!ACCOUNT_RE.test(target))throw new Error('Cuenta mainnet inválida.');
 await requireFullAccess(rpc,target,publicKey);
 await install(target,text,password);return walletState();
}
export async function unlockWallet(password:string){
 if(!existsSync('data/wallet-v2.dpapi'))throw new Error('No hay una wallet importada con contraseña.');
 const key=await unseal(await decryptKey('data/wallet-v2.dpapi'),password);if(!key.startsWith('ed25519:'))throw new Error('Archivo local inválido.');const owner=readFileSync('data/account.txt','utf8').trim();if(owner!==accountId())throw new Error('La wallet seleccionada no coincide con la clave local.');unlockedKey=key as KeyPairString;unlockedAccount=owner;cachedSigner=null;return walletState();
}
async function secret():Promise<KeyPairString>{
 if(existsSync('data/wallet-v2.dpapi')){if(!unlockedKey||unlockedAccount!==accountId())throw new Error('Desbloqueá tu wallet local con su contraseña.');return unlockedKey;}
 if(process.platform!=='win32'||!walletPresent())throw new Error('Configurá una clave de cuenta secundaria con Windows DPAPI.');
 if(readFileSync('data/account.txt','utf8').replace(/^﻿/,'').trim()!==accountId())throw new Error('La cuenta seleccionada no coincide con la clave local.');
 // Descifrar DPAPI lanza PowerShell (~300-700 ms): se hace una vez y se conserva en memoria hasta bloquear.
 return legacyKey??=await decryptKey('data/wallet.dpapi') as KeyPairString;
}
export async function localWallet(rpc:NearRpc){const key=await secret();const signer=cachedSigner??=KeyPairSigner.fromSecretKey(key);return {signer,account:new Account(accountId(),rpc.provider,signer)};}
