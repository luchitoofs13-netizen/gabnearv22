import {useCallback,useEffect,useRef,useState} from 'react';
import {addAlert,checkAlerts,loadAlerts,saveAlerts,type PriceAlert} from './market/alerts';
import {fmtPrice} from './market/format';

// Alertas de precio en USD. Se evalúan en esta pestaña (con cada actualización de precio del token activo y de la lista de seguimiento),
// así que la terminal tiene que estar abierta. Cada alerta avisa una vez: sonido, aviso del navegador y, si lo configuraste, Telegram.
export function useAlerts(fire:(alert:PriceAlert,price:number)=>void){
 const [alerts,setAlerts]=useState<PriceAlert[]>(()=>loadAlerts());
 const ref=useRef(alerts),fireRef=useRef(fire);ref.current=alerts;fireRef.current=fire;
 useEffect(()=>{saveAlerts(alerts);},[alerts]);
 const evaluate=useCallback((token:string,priceUsd:number|null|undefined)=>{
  const r=checkAlerts(ref.current,token,priceUsd);
  if(!r.triggered.length)return;
  ref.current=r.remaining;setAlerts(r.remaining);                              // se borra antes de avisar: no puede dispararse dos veces
  for(const a of r.triggered)fireRef.current(a,priceUsd as number);
 },[]);
 const add=useCallback((input:{token:string;symbol:string;direction:'above'|'below';price:number})=>{const next=addAlert(ref.current,input);ref.current=next;setAlerts(next);},[]);
 const remove=useCallback((id:string)=>{const next=ref.current.filter(a=>a.id!==id);ref.current=next;setAlerts(next);},[]);
 return {alerts,add,remove,evaluate};
}

export function AlertsPanel({token,symbol,priceUsd,alerts,add,remove,telegram}:{token:string;symbol:string;priceUsd:number|null;alerts:PriceAlert[];add:(i:{token:string;symbol:string;direction:'above'|'below';price:number})=>void;remove:(id:string)=>void;telegram:boolean}){
 const [direction,setDirection]=useState<'above'|'below'>('above'),[price,setPrice]=useState(''),[error,setError]=useState('');
 const mine=alerts.filter(a=>a.token===token),others=alerts.length-mine.length;
 function submit(e:React.FormEvent){
  e.preventDefault();setError('');
  try{
   add({token,symbol,direction,price:Number(price)});setPrice('');
   // El permiso de avisos del navegador se pide al crear la primera alerta (un clic del usuario).
   if(typeof Notification!=='undefined'&&Notification.permission==='default')void Notification.requestPermission().catch(()=>{});
  }catch(x){setError((x as Error).message);}
 }
 const suggest=(factor:number)=>{if(priceUsd)setPrice(String(Number((priceUsd*factor).toPrecision(3))));};
 return <details className="panel alerts-panel">
  <summary>🔔 Alertas de precio{mine.length?` · ${mine.length} en este token`:''}{others?` · ${others} en otros`:''}</summary>
  <form onSubmit={submit} className="alert-form">
   <div className="seg"><button type="button" className={direction==='above'?'on':''} onClick={()=>setDirection('above')}>SUBE A</button><button type="button" className={direction==='below'?'on':''} onClick={()=>setDirection('below')}>BAJA A</button></div>
   <label className="inline">USD<input type="number" min="0" step="any" value={price} onChange={e=>setPrice(e.target.value)} placeholder={priceUsd?fmtPrice(priceUsd):'precio'} required/></label>
   <span className="alert-quick">{direction==='above'?<><button type="button" className="outline mini" onClick={()=>suggest(1.25)}>+25%</button><button type="button" className="outline mini" onClick={()=>suggest(2)}>×2</button></>:<><button type="button" className="outline mini" onClick={()=>suggest(0.8)}>−20%</button><button type="button" className="outline mini" onClick={()=>suggest(0.5)}>−50%</button></>}</span>
   <button className="outline mini on" type="submit">AVISAR</button>
  </form>
  {error&&<p className="error" role="alert">{error}</p>}
  {mine.length>0&&<div className="alert-list">{mine.map(a=><span key={a.id} className="chip-alert">{a.direction==='above'?'▲':'▼'} ${fmtPrice(a.price)}<button type="button" aria-label="Borrar alerta" onClick={()=>remove(a.id)}>×</button></span>)}</div>}
  <p className="hint">Avisa una vez (sonido y aviso del navegador{telegram?' + Telegram':''}) y se borra sola. Funciona mientras esta pestaña esté abierta.{!telegram&&' Para recibirlas en el celular configurá Telegram en el .env (TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID).'}</p>
 </details>;
}
