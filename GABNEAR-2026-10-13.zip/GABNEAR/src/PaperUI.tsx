import {useCallback,useEffect,useRef,useState} from 'react';
import {api} from './api';
import {loadPaper,openPaper,savePaper,sellPaper,valuePaper,type Paper} from './paper';
import {money} from './trade-info';

// Posiciones simuladas (DRY RUN) con su precio vivo: el del token activo viene del snapshot de mercado; el de los demás, de /api/watch.
export function usePaper(activeToken:string|null,activePrice:number|null){
 const [list,setList]=useState<Paper[]>(()=>loadPaper()),[prices,setPrices]=useState<Record<string,number|null>>({});
 const ref=useRef(list);ref.current=list;
 useEffect(()=>{savePaper(list);},[list]);
 const others=[...new Set(list.map(p=>p.token).filter(t=>t!==activeToken))].slice(0,8).join(',');
 useEffect(()=>{
  if(!others)return;let dead=false;
  const load=async()=>{try{const rows=await api('watch?'+others.split(',').map(t=>'token='+encodeURIComponent(t)).join('&'));if(!dead)setPrices(p=>({...p,...Object.fromEntries(rows.map((r:any)=>[r.token,typeof r.priceNear==='number'?r.priceNear:null]))}));}catch{/* se conserva el último precio */}};
  void load();const t=setInterval(load,20000);return()=>{dead=true;clearInterval(t);};
 },[others]);
 const priceOf=useCallback((token:string)=>token===activeToken&&activePrice!==null?activePrice:prices[token]??null,[activeToken,activePrice,prices]);
 const open=useCallback((buy:Parameters<typeof openPaper>[1])=>setList(l=>openPaper(l,buy)),[]);
 const sell=useCallback((token:string,pct:number):number|null=>{const r=sellPaper(ref.current,token,pct,priceOf(token));if(!r)return null;ref.current=r.list;setList(r.list);return r.receivedNear;},[priceOf]);
 const remove=useCallback((token:string)=>setList(l=>l.filter(p=>p.token!==token)),[]);
 return {list,open,sell,remove,priceOf,prices};
}

// Lista de posiciones simuladas con su P/L en vivo (pestaña Posiciones).
export function PaperPositions({paper,nearUsd,onPick}:{paper:ReturnType<typeof usePaper>;nearUsd:number|null;onPick:(t:string)=>void}){
 if(!paper.list.length)return null;
 return <section className="panel paper-panel">
  <div className="section-title"><h2>Posiciones simuladas</h2><span className="tag">DRY RUN · SIN FONDOS</span></div>
  <p className="hint">Lo que habrías comprado en simulación, valuado con el precio real. Sirve para practicar sin gastar; no es AUTO SELL.</p>
  {paper.list.map(p=>{const v=valuePaper(p,paper.priceOf(p.token),nearUsd),up=(v.pnlPct??0)>=0;
   return <article key={p.id} className={'paper-row '+(v.pnlPct===null?'':up?'pos':'neg')}>
    <div><b>${p.symbol||p.token}</b> <span className="mono">{p.token}</span></div>
    <div className="paper-nums"><strong>{v.pnlPct===null?'—':`${up?'+':''}${v.pnlPct.toFixed(1)}%`}</strong><span>{money(v.pnlUsd,true)}</span><small>costo {money(v.costUsd)} · vale {money(v.valueUsd)}{p.realizedNear?` · realizado ${money(v.realizedUsd,true)}`:''}</small></div>
    <div className="pos-actions"><button type="button" className="outline mini" onClick={()=>onPick(p.token)}>VER</button><button type="button" className="outline mini" onClick={()=>paper.remove(p.token)}>CERRAR</button></div>
   </article>;})}
 </section>;
}
