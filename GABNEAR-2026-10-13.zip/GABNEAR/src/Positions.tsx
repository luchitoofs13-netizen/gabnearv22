import {useEffect,useState} from 'react';
import {twoDecimals} from './format';
async function post(path:string,body:object){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Gabnear-Client':'local'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.error||'Error de conexión.');return data;}
const venueName=(v?:string)=>v==='REF_V1'?'Ref v1':v==='DCL'?'Rhea DCL':'—';
const pctText=(bps:number|null|undefined)=>bps===null||bps===undefined?'—':`${(bps/100).toFixed(1)}%`;
const eventLabels:Record<string,string>={BUY:'Compra',SELL:'Venta',TRIGGER:'Disparo',SOLD:'Vendida',SELL_FAILED:'Venta fallida',PAUSED:'Pausada',WOULD_SELL:'Habría vendido',SETTINGS:'Ajustes',SUBMIT_REJECTED:'Envío rechazado',PENDING_LOST:'Orden perdida',IMPORTED:'Importada',CLOSED:'Cerrada'};

// Vista previa de solo lectura al pegar un contrato: dónde se compra, a qué precio, qué tan riesgoso es el pool.
export function RoutePreview({launch,allowRisk,setAllowRisk,disabled}:{launch:any;allowRisk:boolean;setAllowRisk:(v:boolean)=>void;disabled:boolean}){
 const risk=launch?.risk,decimals=launch?.metadata?.decimals;
 return <div className="route-preview" aria-live="polite">
  <div className="route-head"><b>{launch.metadata?.name} <span className="green">${launch.metadata?.symbol}</span></b><span className="tag">{launch.generic?'TOKEN GENÉRICO · NEAR':'LAUNCH DE NEARLY'}</span></div>
  {launch.route&&<p className="hint">Mejor pool: <b>{venueName(launch.route.venue)}</b> · fee {(launch.route.fee/100).toFixed(2)}% · <span className="mono">{launch.route.poolId}</span>{launch.candidates?.length>1&&` · ${launch.candidates.length} pools comparados`}</p>}
  {!launch.route&&launch.routes?.length>0&&<p className="hint">{launch.routes.length} pool(es) directo(s) vs wNEAR. Cargá un importe para compararlos.</p>}
  {risk&&<div className="risk-row"><span>Impacto de precio <b className={risk.impactBps>300?'red':'green'}>{pctText(risk.impactBps)}</b></span><span>Ida y vuelta inmediata <b className={risk.roundTripLossBps>1500?'red':'green'}>{pctText(risk.roundTripLossBps)}</b></span></div>}
  {launch.candidates?.length>1&&<div className="candidates">{launch.candidates.map((c:any)=><span key={c.venue+c.poolId} className={c.poolId===launch.route?.poolId&&c.venue===launch.route?.venue?'best':''}>{venueName(c.venue)} {(c.fee/100).toFixed(2)}% → {c.expected?twoDecimals(c.expected):'sin cotización'}</span>)}</div>}
  {risk?.warnings?.map((w:string)=><p key={w} className="warn-line">⚠ {w}</p>)}
  {risk?.blocked&&<div className="blocked"><p className="error">⛔ {risk.blocked}</p><label className="ack"><input type="checkbox" checked={allowRisk} disabled={disabled} onChange={e=>setAllowRisk(e.target.checked)}/>Ignorar bloqueo de riesgo y comprar igual (puedo perder casi todo lo que ponga).</label></div>}
  {launch.generic&&!risk?.blocked&&<p className="hint">Fuera de Nearly no se conocen los impuestos ni restricciones del contrato del token. Probá con un importe chico antes de entrar fuerte.</p>}
 </div>;
}

function Field({label,value,onChange,suffix,placeholder,disabled}:{label:string;value:string;onChange:(v:string)=>void;suffix?:string;placeholder?:string;disabled?:boolean}){
 return <label>{label}<input type="number" min="0" step="any" inputMode="decimal" value={value} placeholder={placeholder??'—'} disabled={disabled} onChange={e=>onChange(e.target.value)}/>{suffix&&<small className="suffix">{suffix}</small>}</label>;
}
const numText=(v:number|null|undefined)=>v===null||v===undefined?'':String(v);
const toNum=(v:string)=>v.trim()===''?null:Number(v);

function PositionCard({p,reload,activity,onSelect}:{p:any;reload:()=>void;activity:(t:string)=>void;onSelect?:(token:string)=>void}){
 const s=p.settings,v=p.view,st=p.state,open=p.status==='OPEN';
 const [tp,setTp]=useState(numText(s.takeProfitPct)),[sl,setSl]=useState(numText(s.stopLossPct)),[trail,setTrail]=useState(numText(s.trailingPct)),[tpSell,setTpSell]=useState(String(s.tpSellPct)),[slip,setSlip]=useState(String(s.slippageBps/100)),[ticks,setTicks]=useState(String(s.confirmTicks)),[err,setErr]=useState(''),[busy,setBusy]=useState(false);
 // Si el servidor cambia los ajustes (p. ej. pausa por fallos), se reflejan en el formulario.
 useEffect(()=>{setTp(numText(s.takeProfitPct));setSl(numText(s.stopLossPct));setTrail(numText(s.trailingPct));setTpSell(String(s.tpSellPct));setSlip(String(s.slippageBps/100));setTicks(String(s.confirmTicks));},[p.id,s.takeProfitPct,s.stopLossPct,s.trailingPct,s.tpSellPct,s.slippageBps,s.confirmTicks]);
 async function save(enabled:boolean){setBusy(true);setErr('');try{await post(`positions/${p.id}/settings`,{enabled,takeProfitPct:toNum(tp),stopLossPct:toNum(sl),trailingPct:toNum(trail),tpSellPct:Number(tpSell),slippageBps:Math.round(Number(slip)*100),confirmTicks:Number(ticks)});activity(`${p.symbol}: AUTO SELL ${enabled?'activado':'desactivado'}.`);reload();}catch(e){setErr((e as Error).message);}finally{setBusy(false);}}
 async function untrack(){if(!window.confirm(`¿Dejar de seguir ${p.symbol}? Los tokens no se venden; solo se quita de esta lista.`))return;setBusy(true);setErr('');try{await post(`positions/${p.id}/untrack`,{});reload();}catch(e){setErr((e as Error).message);}finally{setBusy(false);}}
 const pnl=v.pnlPct,pnlClass=pnl===null?'':pnl>=0?'green':'red';
 return <article className={'pos-card '+(open?'':'closed')}>
  <div className="pos-head"><div><b>${p.symbol}</b> <span className="mono">{p.token}</span>{onSelect&&<button type="button" className="outline mini" onClick={()=>onSelect(p.token)} title="Ver chart y swaps de este token">VER CHART ↗</button>}<small>{venueName(p.route?.venue)} · fee {(p.route?.fee/100).toFixed(2)}%{p.sellBps>0?` · impuesto de venta ${p.sellBps/100}%`:''}</small></div>
   <span className={'tag '+(open&&s.enabled?'armed':'')}>{!open?'CERRADA':s.enabled?'AUTO SELL ACTIVO':st.pausedReason?'PAUSADO':'SOLO SEGUIMIENTO'}</span></div>
  <div className="pos-grid">
   <div><small>TOKENS</small><strong>{twoDecimals(v.tokens)}</strong></div>
   <div><small>COSTO ({p.quote.symbol})</small><strong>{twoDecimals(v.invested)}</strong></div>
   <div><small>VALOR DE SALIDA</small><strong>{v.exitValue===null?'…':twoDecimals(v.exitValue)}</strong></div>
   <div><small>P/L NO REALIZADO</small><strong className={pnlClass}>{pnl===null?'…':`${pnl>=0?'+':''}${pnl.toFixed(1)}%`}</strong></div>
   <div><small>P/L REALIZADO</small><strong className={Number(v.realized)>=0?'green':'red'}>{twoDecimals(v.realized)}</strong></div>
   <div><small>MÁXIMO NETO</small><strong>{twoDecimals(v.peakNet)}</strong></div>
  </div>
  {open&&<>
   <div className="autosell-form">
    <Field label="Take profit · +%" value={tp} onChange={setTp} placeholder="ej. 100" disabled={busy}/>
    <Field label="Stop loss · −%" value={sl} onChange={setSl} placeholder="ej. 30" disabled={busy}/>
    <Field label="Trailing · caída %" value={trail} onChange={setTrail} placeholder="ej. 25" disabled={busy}/>
    <label>El TP vende<select value={tpSell} onChange={e=>setTpSell(e.target.value)} disabled={busy}><option value="100">100%</option><option value="99">99%</option><option value="50">50%</option></select></label>
    <Field label="Slippage de salida · %" value={slip} onChange={setSlip} disabled={busy}/>
    <label>Confirmaciones<select value={ticks} onChange={e=>setTicks(e.target.value)} disabled={busy}>{[1,2,3,4,5].map(n=><option key={n} value={n}>{n} lectura{n>1?'s':''} seguidas</option>)}</select></label>
   </div>
   <div className="pos-actions"><button className="outline" disabled={busy} onClick={()=>save(!s.enabled)}>{s.enabled?'DESACTIVAR AUTO SELL':'GUARDAR Y ACTIVAR AUTO SELL'}</button>{s.enabled&&<button className="outline" disabled={busy} onClick={()=>save(true)}>GUARDAR CAMBIOS</button>}<button className="outline" disabled={busy} onClick={untrack}>DEJAR DE SEGUIR</button></div>
   <p className="hint">{s.enabled?(v.live&&!v.stopped?'Vigilando cada pocos segundos con la cotización ejecutable de salida. ':'Evalúa y avisa, pero NO vende hasta que actives REAL (o quites la parada). '):'Solo calcula P/L. '}Costo = lo gastado + gas y almacenamiento. El valor de salida descuenta impuesto y ≈{v.gasEstimate} NEAR de gas estimado. Vende sobre el saldo de la wallet de este token.</p>
  </>}
  {st.pending&&<p className="warn-line">Venta automática en curso: {st.pending.trigger} · {st.pending.percentage}%</p>}
  {st.pausedReason&&<p className="error">{st.pausedReason}</p>}
  {st.lastError&&open&&<p className="hint red">Última lectura fallida: {st.lastError}</p>}
  {err&&<p className="error" role="alert">{err}</p>}
  {st.events?.length>0&&<details><summary>Registro ({st.events.length})</summary><div className="pos-events">{st.events.slice(0,8).map((e:any,i:number)=><p key={i}><span>{new Date(e.at).toLocaleTimeString('es-AR')}</span> <b>{eventLabels[e.type]??e.type}</b> {e.detail}</p>)}</div></details>}
 </article>;
}

// SALIR DE TODO: vende el 100% de cada posición abierta, de a una, ignorando take profit / stop loss. Pide confirmar y se apaga solo al terminar
// o si REAL se desactiva. Cada venta usa la cotización ejecutable y el slippage de su posición.
function ExitAll({open,live,stopped,activity,reload}:{open:number;live:boolean;stopped:boolean;activity:(t:string)=>void;reload:()=>void}){
 const [state,setState]=useState({exitAll:false,open:0}),[confirm,setConfirm]=useState(false),[busy,setBusy]=useState(false),[err,setErr]=useState('');
 useEffect(()=>{let dead=false;const load=async()=>{try{const r=await fetch('/api/exit-all');if(r.ok&&!dead)setState(await r.json());}catch{/* se conserva */}};void load();const t=setInterval(load,2500);return()=>{dead=true;clearInterval(t);};},[]);
 async function set(enabled:boolean){setBusy(true);setErr('');try{const r=await post('exit-all',enabled?{enabled:true,acknowledge:true}:{enabled:false});setState(r);setConfirm(false);activity(enabled?'SALIR DE TODO activado: vendiendo todas las posiciones abiertas.':'SALIR DE TODO cancelado.');reload();}catch(e){setErr((e as Error).message);}finally{setBusy(false);}}
 if(state.exitAll)return <div className="exit-all on"><p><b>SALIDA TOTAL EN CURSO</b> · vendiendo el 100% de {state.open} posición{state.open===1?'':'es'}, de a una. Se apaga sola al terminar.</p><button className="outline" disabled={busy} onClick={()=>set(false)}>CANCELAR SALIDA</button>{err&&<p className="error" role="alert">{err}</p>}</div>;
 if(open===0)return null;
 return <div className="exit-all">
  {!confirm?<button className="stop" disabled={!live||stopped} onClick={()=>setConfirm(true)} title={live?'Vende todas las posiciones abiertas':'Necesita REAL activo'}>■ SALIR DE TODO ({open})</button>
  :<div className="exit-confirm"><p>¿Vender el <b>100%</b> de {open} posición{open===1?'':'es'} a mercado? Se hace de a una, ignorando take profit y stop loss.</p><div className="pos-actions"><button className="stop" disabled={busy} onClick={()=>set(true)}>{busy?'ACTIVANDO…':'SÍ, VENDER TODO'}</button><button className="outline" disabled={busy} onClick={()=>setConfirm(false)}>NO</button></div></div>}
  {!live&&<small className="hint"> Necesita REAL activo.</small>}{err&&<p className="error" role="alert">{err}</p>}
 </div>;
}

export function Positions({positions,reload,activity,hasAccount,onSelect,live=false,stopped=false}:{positions:any[];reload:()=>void;activity:(t:string)=>void;hasAccount:boolean;onSelect?:(token:string)=>void;live?:boolean;stopped?:boolean}){
 const [importOpen,setImportOpen]=useState(false),[url,setUrl]=useState(''),[cost,setCost]=useState(''),[tp,setTp]=useState(''),[sl,setSl]=useState(''),[busy,setBusy]=useState(false),[err,setErr]=useState('');
 async function importPosition(e:React.FormEvent){e.preventDefault();setBusy(true);setErr('');try{await post('positions/import',{url,cost,settings:{takeProfitPct:toNum(tp),stopLossPct:toNum(sl)}});activity('Posición importada.');setUrl('');setCost('');setTp('');setSl('');setImportOpen(false);reload();}catch(x){setErr((x as Error).message);}finally{setBusy(false);}}
 const open=positions.filter(p=>p.status==='OPEN'),closed=positions.filter(p=>p.status!=='OPEN').slice(0,5);
 return <section className="panel positions-panel">
  <div className="section-title"><h2>Posiciones · AUTO SELL</h2><span className="tag">{open.length} ABIERTA{open.length===1?'':'S'}</span></div>
  <ExitAll open={open.length} live={live} stopped={stopped} activity={activity} reload={reload}/>
  {open.length===0&&<p className="hint">Cada compra REAL completada abre una posición con su costo real. Poné take profit / stop loss / trailing en COMPRAR para que se arme sola, o ajustalo acá. DRY RUN no crea posiciones reales: sus posiciones simuladas aparecen arriba.</p>}
  {open.map(p=><PositionCard key={p.id} p={p} reload={reload} activity={activity} onSelect={onSelect}/>)}
  <button className="outline" style={{marginTop:12}} disabled={!hasAccount} onClick={()=>setImportOpen(o=>!o)}>{importOpen?'CANCELAR':'IMPORTAR TOKENS COMPRADOS POR FUERA'}</button>
  {importOpen&&<form className="import-form" onSubmit={importPosition}>
   <label>Contrato del token<input value={url} onChange={e=>setUrl(e.target.value)} placeholder="token.tkn.near" required spellCheck={false} autoComplete="off"/></label>
   <label>Costo total pagado (en NEAR)<input type="number" min="0" step="any" value={cost} onChange={e=>setCost(e.target.value)} placeholder="ej. 0.5" required/></label>
   <div className="two"><Field label="Take profit · +%" value={tp} onChange={setTp}/><Field label="Stop loss · −%" value={sl} onChange={setSl}/></div>
   <p className="hint">Toma todo el saldo actual de ese token en tu wallet y el costo que declares. El P/L depende de que ese costo sea correcto.</p>
   {err&&<p className="error" role="alert">{err}</p>}
   <button className="connect-wallet" disabled={busy}>{busy?'IMPORTANDO…':'IMPORTAR POSICIÓN'}</button>
  </form>}
  {closed.length>0&&<details style={{marginTop:14}}><summary>Cerradas recientes ({closed.length})</summary>{closed.map(p=><p key={p.id} className="hint"><b>${p.symbol}</b> · {p.closeReason} · realizado <b className={Number(p.view.realized)>=0?'green':'red'}>{twoDecimals(p.view.realized)} {p.quote.symbol}</b></p>)}</details>}
 </section>;
}
