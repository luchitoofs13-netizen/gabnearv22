import {useEffect,useState} from 'react';

// Valores rápidos configurables: 4 importes de compra (en NEAR) y 4 porcentajes de venta. Se guardan en este navegador.
export type Presets={buy:number[];sell:number[]};
export const DEFAULT_PRESETS:Presets={buy:[0.1,0.5,1,2],sell:[25,50,75,100]};
const KEY='gabnear-presets';

export function sanitizePresets(raw:any):Presets{
 const buy=Array.isArray(raw?.buy)?raw.buy.map(Number):[],sell=Array.isArray(raw?.sell)?raw.sell.map(Number):[];
 const okBuy=buy.length===4&&buy.every((n:number)=>Number.isFinite(n)&&n>0&&n<=1e6);
 const okSell=sell.length===4&&sell.every((n:number)=>Number.isInteger(n)&&n>=1&&n<=100);
 return {buy:okBuy?buy:DEFAULT_PRESETS.buy,sell:okSell?sell:DEFAULT_PRESETS.sell};
}
export function usePresets(){
 const [presets,setPresets]=useState<Presets>(()=>{try{return sanitizePresets(JSON.parse(localStorage.getItem(KEY)??'null'));}catch{return DEFAULT_PRESETS;}});
 useEffect(()=>{try{localStorage.setItem(KEY,JSON.stringify(presets));}catch{/* opcional */}},[presets]);
 return {presets,setPresets};
}

// Ruedita ⚙ con el formulario de valores rápidos.
export function PresetsGear({presets,onSave}:{presets:Presets;onSave:(p:Presets)=>void}){
 const [open,setOpen]=useState(false),[buy,setBuy]=useState(presets.buy.map(String)),[sell,setSell]=useState(presets.sell.map(String)),[error,setError]=useState('');
 useEffect(()=>{if(open){setBuy(presets.buy.map(String));setSell(presets.sell.map(String));setError('');}},[open]);
 function save(){
  const next={buy:buy.map(Number),sell:sell.map(Number)};
  const clean=sanitizePresets(next);
  if(clean.buy.some((v,i)=>v!==next.buy[i])){setError('Los importes de compra deben ser números mayores que 0.');return;}
  if(clean.sell.some((v,i)=>v!==next.sell[i])){setError('Los porcentajes de venta deben ser enteros de 1 a 100.');return;}
  onSave(clean);setOpen(false);
 }
 return <div className="presets-gear">
  <button type="button" className={'gear'+(open?' on':'')} aria-label="Configurar valores rápidos" aria-expanded={open} title="Configurar importes de compra y porcentajes de venta" onClick={()=>setOpen(o=>!o)}>⚙</button>
  {open&&<div className="presets-pop" role="dialog" aria-label="Valores rápidos">
   <h3>Valores rápidos</h3>
   <p className="hint">Los importes de COMPRAR solo cargan la cantidad (no compran): comprás con el botón verde. Los porcentajes de VENDER venden al apretarlos. Se guardan en este navegador.</p>
   <fieldset><legend>Compra · NEAR</legend><div className="presets-row">{buy.map((v,i)=><input key={i} type="number" min="0" step="any" inputMode="decimal" value={v} aria-label={`Importe ${i+1}`} onChange={e=>setBuy(b=>b.map((x,j)=>j===i?e.target.value:x))}/>)}</div></fieldset>
   <fieldset><legend>Venta · % del saldo</legend><div className="presets-row">{sell.map((v,i)=><input key={i} type="number" min="1" max="100" step="1" inputMode="numeric" value={v} aria-label={`Porcentaje ${i+1}`} onChange={e=>setSell(b=>b.map((x,j)=>j===i?e.target.value:x))}/>)}</div></fieldset>
   {error&&<p className="error" role="alert">{error}</p>}
   <div className="pos-actions"><button type="button" className="outline mini on" onClick={save}>GUARDAR</button><button type="button" className="outline mini" onClick={()=>{setBuy(DEFAULT_PRESETS.buy.map(String));setSell(DEFAULT_PRESETS.sell.map(String));setError('');}}>RESTABLECER</button><button type="button" className="outline mini" onClick={()=>setOpen(false)}>CERRAR</button></div>
  </div>}
 </div>;
}
