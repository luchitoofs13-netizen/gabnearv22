import {useEffect,useState} from 'react';
import {api} from './api';

const STATUS:Record<string,[label:string,tone:string]>={
 WATCHING:['VIGILANDO','on'],PAUSED:['EN PAUSA','warn'],FIRING:['COMPRA ENVIADA','on'],BOUGHT:['COMPRADO','ok'],SIMULATED:['SIMULADO','ok'],
 BLOCKED:['BLOQUEADO POR RIESGO','bad'],FAILED:['FALLÓ','bad'],EXPIRED:['VENCIÓ','off'],CANCELLED:['CANCELADO','off']
};
const ACTIVE=['WATCHING','PAUSED','FIRING'];
const left=(iso:string,now:number)=>{const s=Math.max(0,Math.round((Date.parse(iso)-now)/1000));return s>=3600?`${Math.floor(s/3600)} h ${Math.floor(s%3600/60)} min`:s>=60?`${Math.floor(s/60)} min`:`${s} s`;};

// Vigilancia de pool: para un contrato que todavía no se puede comprar. Cuando aparece un pool directo token/wNEAR con la liquidez mínima,
// compra UNA vez con el importe, el slippage y el AUTO SELL de COMPRAR. Una vigilancia = como máximo una compra.
export function SniperPanel({url,amount,slip,live,hasAccount,autoSell,activity,onOpen}:{url:string;amount:string;slip:string;live:boolean;hasAccount:boolean;autoSell:object;activity:(t:string)=>void;onOpen:(token:string)=>void}){
 const [targets,setTargets]=useState<any[]>([]),[max,setMax]=useState(3),[minLiq,setMinLiq]=useState('10'),[expiry,setExpiry]=useState('60'),[ack,setAck]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[now,setNow]=useState(Date.now());
 const load=async()=>{try{const r=await api('sniper');setTargets(r.targets);setMax(r.max);}catch{/* se conserva la lista */}};
 useEffect(()=>{void load();const t=setInterval(()=>{void load();setNow(Date.now());},2000);return()=>clearInterval(t);},[]);
 const active=targets.filter(t=>ACTIVE.includes(t.status));
 async function arm(e:React.FormEvent){
  e.preventDefault();if(busy)return;setBusy(true);setError('');
  try{
   const t=await api('sniper',{url,amount,slippageBps:Math.round(Number(slip)*100),mode:live?'REAL':'DRY RUN',minLiquidityNear:Number(minLiq),expiresInMin:Number(expiry),...autoSell});
   activity(`Vigilancia ${live?'REAL':'DRY RUN'} activada: ${t.symbol||t.token}.`);setAck(false);void load();
  }catch(x){setError((x as Error).message);}finally{setBusy(false);}
 }
 async function cancel(id:string){setError('');try{await api(`sniper/${id}/cancel`,{});void load();}catch(x){setError((x as Error).message);}}
 const canArm=!!url.trim()&&Number(amount)>0&&(!live||(hasAccount&&ack))&&active.length<max&&!busy;
 return <section className="panel sniper-panel">
  <div className="section-title"><h2>Vigilancia de pool</h2><span className="tag">{active.length}/{max} ACTIVAS</span></div>
  <p className="hint">Para un token que <b>todavía no tiene pool</b> (lanzamiento sin graduar, liquidez que se agrega después). GABNEAR lo mira cada ~1,5 s y, cuando aparece un pool directo con la liquidez que pediste, <b>compra una sola vez</b> con el importe y el slippage de COMPRAR (y su AUTO SELL, si lo cargaste). Respeta el análisis de riesgo y los topes de gasto. No compra «todo lo nuevo».</p>
  <form onSubmit={arm} className="sniper-form">
   <p className="mono sniper-target">{url.trim()||'Pegá arriba el contrato a vigilar'}</p>
   <div className="two">
    <label>Liquidez mínima del pool · NEAR<input type="number" min="0" step="any" value={minLiq} onChange={e=>setMinLiq(e.target.value)}/></label>
    <label>Vigilar durante · minutos<input type="number" min="1" max="720" step="1" value={expiry} onChange={e=>setExpiry(e.target.value)}/></label>
   </div>
   <p className="hint">Comprará <b>{amount||'—'} wNEAR</b> con slippage {slip||'—'}%. Con poca liquidez inicial un pool puede moverse mucho: por eso se espera el mínimo antes de disparar.</p>
   {live?<label className="ack"><input type="checkbox" checked={ack} onChange={e=>setAck(e.target.checked)}/>Entiendo que GABNEAR comprará <b>solo y con fondos reales</b> cuando aparezca el pool, sin que esté mirando. Una compra por vigilancia.</label>
    :<p className="hint">DRY RUN: cuando aparezca el pool simula la compra y te avisa; no gasta nada.</p>}
   {live&&!hasAccount&&<p className="error">Conectá y desbloqueá tu wallet para vigilar en REAL.</p>}
   {error&&<p className="error" role="alert">{error}</p>}
   <button className="connect-wallet" disabled={!canArm}>{busy?'ACTIVANDO…':live?'VIGILAR Y COMPRAR AL APARECER EL POOL':'VIGILAR (SIMULACIÓN)'}</button>
  </form>
  {targets.length>0&&<div className="sniper-list">{targets.map(t=>{const [label,tone]=STATUS[t.status]??[t.status,'off'];
   return <article key={t.id} className={'sniper-row '+tone}>
    <div><b>{t.symbol||t.token}</b> <span className="tag">{t.mode}</span> <span className={'sniper-status '+tone}>{label}</span>
     <small className="mono">{t.token}</small></div>
    <p className="hint">{t.detail}</p>
    <small>{t.amount} wNEAR · liquidez mín. {t.minLiquidityNear} NEAR{t.hasAutoSell?' · con AUTO SELL':''}{ACTIVE.includes(t.status)?` · ${t.checks} lecturas · vence en ${left(t.expiresAt,now)}`:''}</small>
    <div className="pos-actions">
     <button type="button" className="outline mini" onClick={()=>onOpen(t.token)}>VER TOKEN</button>
     {ACTIVE.includes(t.status)&&!(t.status==='FIRING'&&t.opId)&&<button type="button" className="outline mini" onClick={()=>cancel(t.id)}>CANCELAR</button>}
    </div>
   </article>;})}</div>}
 </section>;
}
