import {useState} from 'react';
import {api} from './api';

// Cuánto esperar antes de dar un paso por hecho. Cada opción rápida ahorra ~1,5 s de espera de finalidad.
export function SpeedPanel({speed,setSpeed,hotkeys,setHotkeys,sound,setSound}:{speed:any;setSpeed:(s:any)=>void;hotkeys:boolean;setHotkeys:(v:boolean)=>void;sound:boolean;setSound:(v:boolean)=>void}){
 const [error,setError]=useState('');
 async function change(patch:object){setError('');try{setSpeed(await api('speed',patch));}catch(e){setError((e as Error).message);}}
 if(!speed)return <details className="panel speed-panel"><summary>⚡ Velocidad</summary><p className="hint">Cargando…</p></details>;
 const Seg=({value,options,onPick}:{value:string;options:[string,string][];onPick:(v:string)=>void})=><div className="seg">{options.map(([v,l])=><button type="button" key={v} className={v===value?'on':''} onClick={()=>onPick(v)}>{l}</button>)}</div>;
 return <details className="panel speed-panel">
  <summary>⚡ Velocidad · <span className="green">{speed.confirmLevel==='optimistic'?'confirmación rápida':'confirmación final'}</span></summary>
  <label className="row">Compra / venta se da por hecha<Seg value={speed.confirmLevel} options={[['final','FINAL · irreversible'],['optimistic','RÁPIDA · al ejecutarse']]} onPick={v=>change({confirmLevel:v})}/></label>
  <p className="hint">«Rápida» confirma ~1,5 s antes: el swap ya se ejecutó en un bloque, aunque todavía no es irreversible. En la práctica no se revierte; si ocurriera, el vigilante lo detecta y la operación vuelve a «recuperando» sin reenviar. Probala primero con importes chicos.</p>
  <label className="row">Pasos previos (registro, wrap)<Seg value={speed.prepLevel} options={[['optimistic','RÁPIDO'],['final','SEGURO']]} onPick={v=>change({prepLevel:v})}/></label>
  <label className="ack"><input type="checkbox" checked={speed.autoArm} onChange={e=>change({autoArm:e.target.checked})}/>Armar automáticamente al pegar un contrato (en REAL): registra el token y deja wNEAR listo para que comprar sea UN solo swap. Cuesta ≈0,00125 NEAR por token abierto.</label>
  <label className="ack"><input type="checkbox" checked={hotkeys} onChange={e=>setHotkeys(e.target.checked)}/>Atajos de teclado: Alt+B compra · Alt+1 a Alt+4 venden tus 4 porcentajes (los de la ruedita ⚙).</label>
  <label className="ack"><input type="checkbox" checked={sound} onChange={e=>setSound(e.target.checked)}/>Sonido al completarse una compra o venta.</label>
  <p className="hint">Difusión de transacciones a {speed.broadcast} endpoint{speed.broadcast===1?'':'s'}{speed.broadcast===1?' (agregá más en NEAR_RPC_BROADCAST del .env: la misma firma llega por varios caminos y entra por el más rápido).':'.'} Cada paso secuencial paga la latencia a tu RPC: medila con <span className="mono">npm run rpc:latency</span>.</p>
  {error&&<p className="error">{error}</p>}
 </details>;
}
