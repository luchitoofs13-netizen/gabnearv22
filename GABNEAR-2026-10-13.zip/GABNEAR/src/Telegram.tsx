import {useEffect,useState} from 'react';
import {api} from './api';
import {shortAccount,timeAgo} from './market/format';

// Menciones de contratos en canales PÚBLICOS de Telegram que vos agregás (vista web pública, sin cuenta ni bot). X (Twitter) no se rastrea: API de pago.
export function Telegram({onPick}:{onPick:(t:string)=>void}){
 const [social,setSocial]=useState<any>(null),[socialErr,setSocialErr]=useState(''),[channel,setChannel]=useState('');
 useEffect(()=>{
  let dead=false;
  const loadSocial=async()=>{try{const s=await api('social');if(!dead){setSocial(s);setSocialErr('');}}catch(e){if(!dead)setSocialErr((e as Error).message);}};
  void loadSocial();const t=setInterval(()=>void loadSocial(),60000);return()=>{dead=true;clearInterval(t);};
 },[]);
 async function addChannel(e:React.FormEvent){e.preventDefault();setSocialErr('');try{await api('social/channels',{name:channel});setChannel('');setSocial(await api('social'));}catch(x){setSocialErr((x as Error).message);}}
 async function removeChannel(name:string){try{await api('social/channels/remove',{name});setSocial(await api('social'));}catch(x){setSocialErr((x as Error).message);}}
 return <section className="panel discover">
  <div className="section-title"><h2>Telegram</h2><span className="tag">{social?`actualizado ${timeAgo(social.fetchedAt)}`:'cargando…'}</span></div>
  <div className="disc-social tg-only">
   <p className="hint">Agregá el @usuario de canales <b>públicos</b> de tu nicho. GABNEAR lee su vista web pública (sin cuenta ni bot) y junta los contratos de tokens que mencionan; si varios canales mencionan el mismo, sube arriba. Se actualiza cada minuto con esta pestaña abierta. <b>X (Twitter)</b> no se rastrea: su API es de pago.</p>
   <form className="disc-add" onSubmit={addChannel}><input value={channel} onChange={e=>setChannel(e.target.value)} placeholder="@canal_publico" spellCheck={false} autoComplete="off"/><button className="outline mini on" type="submit" disabled={!channel.trim()}>AGREGAR</button></form>
   {socialErr&&<p className="error" role="alert">{socialErr}</p>}
   <div className="alert-list">{(social?.channels??[]).map((c:string)=><span key={c} className="chip-alert">@{c}<button type="button" aria-label={`Quitar ${c}`} onClick={()=>removeChannel(c)}>×</button></span>)}</div>
   {social?.errors?.length>0&&<p className="hint red">{social.errors.join(' · ')}</p>}
   {social&&social.channels.length>0&&social.mentions.length===0&&<p className="hint">Sin menciones de contratos en los últimos mensajes ({social.total} leídos).</p>}
   {(social?.mentions??[]).map((m:any)=><article key={m.token} className="disc-row" onClick={()=>onPick(m.token)} role="button" tabIndex={0} onKeyDown={e=>{if(e.key==='Enter')onPick(m.token);}}>
    <div className="disc-top"><b className="mono">{shortAccount(m.token)}</b>{m.launchpad&&<span className="tag">{m.launchpad}</span>}<span className="disc-chg">{m.count}× · {m.channels.length} canal{m.channels.length===1?'':'es'}</span></div>
    <p className="hint disc-sample">{m.sample}</p>
    <div className="disc-foot"><small>{m.channels.map((c:string)=>'@'+c).join(' ')}{m.lastAt?` · ${timeAgo(Date.parse(m.lastAt))}`:''}</small><button type="button" className="buy-mini" onClick={e=>{e.stopPropagation();onPick(m.token);}}>ABRIR</button></div>
   </article>)}
  </div>
 </section>;
}
