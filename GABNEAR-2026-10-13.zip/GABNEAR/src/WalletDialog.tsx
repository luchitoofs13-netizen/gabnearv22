import {useEffect,useRef,useState} from 'react';
async function walletApi(action:string,body:object){const response=await fetch('/api/wallet/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-Gabnear-Client':'local'},body:JSON.stringify(body)});const result=await response.json();if(!response.ok)throw new Error(result.error||'No se pudo conectar.');return result;}
type Mode='new'|'import'|'public'|'unlock';
const copy=(text:string)=>{void navigator.clipboard?.writeText(text).catch(()=>{});};

// Flujo recomendado: «Crear wallet nueva». La clave nace en tu PC (no pasa por Meteor ni por ninguna otra wallet), la cuenta es la
// implícita de esa clave y la fondeás con la cantidad que quieras arriesgar. Importar una semilla de tu wallet principal es lo menos seguro.
export function WalletDialog({onClose,onConnected}:{onClose:()=>void;onConnected:()=>void}){
 const [mode,setMode]=useState<Mode>('new'),[kind,setKind]=useState<'seed'|'key'>('key'),[account,setAccount]=useState(''),[secret,setSecret]=useState(''),[password,setPassword]=useState(''),[password2,setPassword2]=useState(''),[pending,setPending]=useState(false),[error,setError]=useState(''),[state,setState]=useState<any>(null);
 const [created,setCreated]=useState<any>(null),[saved,setSaved]=useState(false),[balance,setBalance]=useState<any>(null),[copied,setCopied]=useState('');
 const first=useRef<HTMLInputElement>(null);
 const locked=!!created&&!saved;
 useEffect(()=>{
  void fetch('/api/wallet').then(r=>r.json()).then(s=>{setState(s);setAccount(s.accountId||'');if(s.hasLocalKey&&!s.unlocked)setMode('unlock');else if(s.accountId)setMode('public');});
  const old=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{document.body.style.overflow=old;};
 },[]);
 useEffect(()=>{const listener=(e:KeyboardEvent)=>{if(e.key==='Escape'&&!locked)onClose();};document.addEventListener('keydown',listener);return()=>document.removeEventListener('keydown',listener);},[locked]);
 useEffect(()=>{first.current?.focus();},[mode,kind]);
 // Tras crear la wallet se consulta el saldo hasta que llegue el primer depósito.
 useEffect(()=>{
  if(!created)return;let dead=false;
  const poll=async()=>{try{const b=await (await fetch('/api/balances')).json();if(!dead)setBalance(b);}catch{/* se reintenta */}};
  void poll();const t=setInterval(poll,3000);return()=>{dead=true;clearInterval(t);};
 },[created]);
 const flash=(what:string,text:string)=>{copy(text);setCopied(what);setTimeout(()=>setCopied(''),1200);};
 async function submit(e:React.FormEvent){
  e.preventDefault();setPending(true);setError('');
  try{
   if(mode==='new'){
    if(password!==password2)throw new Error('Las contraseñas no coinciden.');
    setCreated(await walletApi('generate',{password}));setSaved(false);return;
   }
   await walletApi(mode==='public'?'connect':mode==='import'?(kind==='seed'?'import':'importKey'):'unlock',mode==='public'?{accountId:account}:mode==='import'?{accountId:account,...(kind==='seed'?{seed:secret}:{secret}),password}:{password});
   onConnected();onClose();
  }catch(x){setError((x as Error).message);}
  finally{setSecret('');setPassword('');setPassword2('');setPending(false);}
 }
 function tab(m:Mode,label:string){return <button type="button" className={mode===m?'active':''} disabled={locked} onClick={()=>{setMode(m);setError('');setSecret('');}}>{label}</button>;}
 const funded=balance?.exists&&Number(balance.near)>0;
 return <div className="wallet-backdrop"><section className="wallet-dialog" role="dialog" aria-modal="true" aria-labelledby="wallet-title">
  <div className="section-title"><div><div className="eyebrow">GABNEAR · LOCAL</div><h2 id="wallet-title">{created?'Tu wallet del bot':'Wallet'}</h2></div><button className="dialog-close" disabled={locked} aria-label="Cerrar" onClick={onClose}>×</button></div>
  {created?<div className="created">
   <p className="hint"><b className="green">Wallet creada.</b> La clave quedó cifrada en esta PC (contraseña + Windows). <b>La frase de abajo no se guarda en ningún lado y no se vuelve a mostrar.</b> Anotala en papel o en tu gestor de contraseñas: si perdés esta PC o el archivo, sin la frase los fondos se pierden.</p>
   <div className="seed-grid">{created.seedPhrase.split(' ').map((w:string,i:number)=><span key={i}><small>{i+1}</small>{w}</span>)}</div>
   <div className="two"><button type="button" className="outline" onClick={()=>flash('seed',created.seedPhrase)}>{copied==='seed'?'¡COPIADA!':'COPIAR FRASE'}</button><button type="button" className="outline" onClick={()=>flash('addr',created.accountId)}>{copied==='addr'?'¡COPIADA!':'COPIAR DIRECCIÓN'}</button></div>
   <label>Dirección de la cuenta (enviale NEAR desde tu wallet principal)<input readOnly value={created.accountId} onFocus={e=>e.currentTarget.select()}/></label>
   <p className={'fund '+(funded?'ok':'')}>{funded?`✔ Fondos recibidos: ${Number(balance.near).toFixed(3)} NEAR. Ya podés activar REAL.`:'Esperando el primer depósito… la cuenta se activa en la red al recibir NEAR. Enviá solo lo que estés dispuesto a arriesgar (con 5–20 NEAR alcanza para empezar).'}</p>
   {created.archivedPrevious&&<p className="hint">Tu wallet anterior se archivó en <span className="mono">{created.archivedPrevious}.*</span> (nada se sobrescribió).</p>}
   <label className="ack"><input type="checkbox" checked={saved} onChange={e=>setSaved(e.target.checked)}/>Guardé la frase de recuperación en un lugar seguro.</label>
   <button className="connect-wallet submit" disabled={!saved} onClick={()=>{setCreated(null);onConnected();onClose();}}>LISTO</button>
  </div>:<>
  <div className="wallet-tabs">{tab('new','Crear wallet nueva · recomendado')}{tab('import','Importar clave / semilla')}{tab('public','Solo dirección')}{state?.hasLocalKey&&tab('unlock','Desbloquear')}</div>
  <form onSubmit={submit} autoComplete="off">
   {mode==='new'&&<>
    <p className="hint"><b>La forma más segura y rápida:</b> el bot crea su propia cuenta (clave nueva generada acá, nunca expuesta a otra wallet), vos le mandás los NEAR que quieras usar y ya firma sin pedir confirmaciones. Si algo sale mal, solo arriesgás ese saldo y no tu wallet principal.</p>
    <label>Contraseña local (protege la clave en esta PC)<input ref={first} type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={12} maxLength={256} required autoComplete="new-password" placeholder="Mínimo 12 caracteres"/></label>
    <label>Repetí la contraseña<input type="password" value={password2} onChange={e=>setPassword2(e.target.value)} minLength={12} maxLength={256} required autoComplete="new-password"/></label>
    <p className="hint">Esta contraseña es solo de GABNEAR (no es la de Meteor) y hace falta cada vez que se reinicia el programa.</p>
   </>}
   {mode==='import'&&<>
    <div className="wallet-tabs sub"><button type="button" className={kind==='key'?'active':''} onClick={()=>setKind('key')}>Clave privada</button><button type="button" className={kind==='seed'?'active':''} onClick={()=>setKind('seed')}>Frase semilla</button></div>
    <p className="hint">{kind==='key'?'Preferí la clave privada (ed25519:…) de una cuenta SECUNDARIA: expone menos que una frase semilla, que puede gobernar otras cuentas.':'Importá solo la semilla de una cuenta secundaria dedicada al bot, nunca la de tu wallet principal.'} Se valida contra la cuenta en la red y se guarda cifrada; solo se envía la clave pública al RPC. Tu wallet actual, si hay una, se archiva antes de reemplazarla.</p>
    <label>Cuenta NEAR{kind==='key'?' (vacío = la cuenta implícita de esa clave)':''}<input ref={first} value={account} onChange={e=>setAccount(e.target.value)} placeholder="tubot.near" maxLength={64} spellCheck={false} required={kind==='seed'}/></label>
    <label>{kind==='key'?'Clave privada':'Frase semilla NEAR'}<input type="password" value={secret} onChange={e=>setSecret(e.target.value)} required autoComplete="off" spellCheck={false} maxLength={500} placeholder={kind==='key'?'ed25519:…':'frase de recuperación de la cuenta'}/></label>
    <label>Crear contraseña local<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={12} maxLength={256} required autoComplete="new-password" placeholder="Mínimo 12 caracteres"/></label>
   </>}
   {mode==='public'&&<><label>Dirección pública / cuenta NEAR<input ref={first} value={account} onChange={e=>setAccount(e.target.value)} placeholder="tunombre.near o cuenta implícita" required maxLength={64} spellCheck={false}/></label><p className="hint">Consultá balances y registración con cualquier cuenta mainnet. No concede permisos de firma.</p></>}
   {mode==='unlock'&&<><label>Contraseña local<input ref={first} type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={12} maxLength={256} required autoComplete="off"/></label><p className="hint">Se bloquea de nuevo al reiniciar el servidor. Cuenta: <span className="mono">{state?.accountId}</span></p></>}
   {error&&<p className="error" role="alert">{error}</p>}
   <button className="connect-wallet submit" disabled={pending}>{pending?'PROCESANDO…':mode==='new'?'CREAR WALLET':mode==='import'?'IMPORTAR Y CONECTAR':mode==='public'?'CONECTAR':'DESBLOQUEAR'}</button>
   <p className="hint wallet-note">Conectar, crear o importar no compra tokens. REAL permanece desactivado hasta habilitarlo expresamente en el panel.</p>
  </form>
  {state?.unlocked&&<button className="outline" onClick={async()=>{await walletApi('lock',{});onConnected();onClose();}}>BLOQUEAR FIRMA LOCAL</button>}{state?.accountId&&<button className="outline" style={{marginTop:10}} onClick={async()=>{await walletApi('disconnect',{});onConnected();onClose();}}>DESCONECTAR CUENTA</button>}
  </>}
 </section></div>;
}
