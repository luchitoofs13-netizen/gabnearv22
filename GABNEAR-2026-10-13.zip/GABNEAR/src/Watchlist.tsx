import {useEffect,useRef,useState} from 'react';
import {api} from './api';
import {fmtPrice,fmtPct} from './market/format';

type Pinned={token:string;symbol:string};
const KEY='gabnear-watch',MAX=8;
const read=():Pinned[]=>{try{const l=JSON.parse(localStorage.getItem(KEY)??'[]');return Array.isArray(l)?l.filter((x:any)=>x&&typeof x.token==='string').slice(0,MAX).map((x:any)=>({token:x.token,symbol:String(x.symbol??'')})):[];}catch{return [];}};
const write=(l:Pinned[])=>{try{localStorage.setItem(KEY,JSON.stringify(l));}catch{/* opcional */}};

// Lista de seguimiento: hasta 8 tokens con precio y variación 24 h, un clic para abrirlos. Se actualiza cada 20 s, también con la pestaña en segundo plano (las alertas de precio dependen de eso).
export function Watchlist({active,activeSymbol,onPick,onPrices}:{active:string|null;activeSymbol:string;onPick:(token:string)=>void;onPrices:(rows:any[])=>void}){
 const [pins,setPins]=useState<Pinned[]>(read),[rows,setRows]=useState<Record<string,any>>({});
 const onPricesRef=useRef(onPrices);onPricesRef.current=onPrices;
 const key=pins.map(p=>p.token).join(',');
 useEffect(()=>{
  if(!pins.length){setRows({});return;}
  let dead=false;
  const load=async()=>{
   try{
    const data=await api('watch?'+pins.map(p=>'token='+encodeURIComponent(p.token)).join('&'));
    if(dead)return;setRows(Object.fromEntries(data.map((r:any)=>[r.token,r])));onPricesRef.current(data);
   }catch{/* se conserva la última lectura */}
  };
  void load();const t=setInterval(load,20000);return()=>{dead=true;clearInterval(t);};
 },[key]);
 const pinned=!!active&&pins.some(p=>p.token===active);
 const toggle=()=>{if(!active)return;const next=pinned?pins.filter(p=>p.token!==active):[...pins,{token:active,symbol:activeSymbol}].slice(-MAX);setPins(next);write(next);};
 const remove=(token:string)=>{const next=pins.filter(p=>p.token!==token);setPins(next);write(next);};
 if(!pins.length&&!active)return null;
 return <div className="watchlist" aria-label="Lista de seguimiento">
  {pins.map(p=>{const r=rows[p.token],chg=r?.change24h;
   return <span key={p.token} className={'watch-chip'+(p.token===active?' on':'')}>
    <button type="button" className="watch-open" onClick={()=>onPick(p.token)} title={p.token}>
     <b>{r?.symbol||p.symbol||p.token.split('.')[0]}</b><span className="mono">{r?.error?'—':r?.priceUsd!=null?'$'+fmtPrice(r.priceUsd):'…'}</span>
     <small className={chg==null?'':chg>=0?'green':'red'}>{chg==null?'':fmtPct(chg)}</small>
    </button>
    <button type="button" className="watch-x" aria-label={`Quitar ${p.symbol||p.token}`} onClick={()=>remove(p.token)}>×</button>
   </span>;})}
  {active&&<button type="button" className={'outline mini'+(pinned?' on':'')} onClick={toggle} disabled={!pinned&&pins.length>=MAX} title={pinned?'Quitar de la lista de seguimiento':pins.length>=MAX?`Máximo ${MAX} tokens`:'Seguir este token'}>{pinned?'★ SIGUIENDO':'☆ SEGUIR'}</button>}
 </div>;
}
