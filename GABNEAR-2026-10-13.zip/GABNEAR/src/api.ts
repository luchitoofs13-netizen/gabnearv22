export class ApiError extends Error {constructor(message:string,readonly status:number){super(message);}}
export async function api(path:string,body?:object){
 const r=await fetch('/api/'+path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-Gabnear-Client':'local'}:undefined,body:body?JSON.stringify(body):undefined});
 const data=await r.json();
 if(!r.ok)throw new ApiError(data.error||'Error de conexión.',r.status);
 return data;
}
