// Solo presentación: los importes utilizados para operar conservan todos sus decimales.
export function twoDecimals(value?:string|number|null):string {
 if(value===null||value===undefined)return '—';
 if(typeof value==='number')return Number.isFinite(value)?value.toLocaleString('en-US',{useGrouping:false,minimumFractionDigits:2,maximumFractionDigits:2}):'—';
 const s=String(value);if(!/^-?\d+(?:\.\d+)?$/.test(s))return '—';
 const negative=s.startsWith('-');const [whole,fraction='']=s.replace(/^-/,'').split('.');
 let cents=BigInt(whole)*100n+BigInt((fraction+'00').slice(0,2));
 if(Number(fraction[2]??'0')>=5)cents++;
 return (negative&&cents>0n?'-':'')+(cents/100n).toString()+'.'+(cents%100n).toString().padStart(2,'0');
}
