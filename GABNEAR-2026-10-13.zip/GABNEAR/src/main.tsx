import React,{useEffect,useMemo,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
// Fuentes propias (sin pedirlas a Google en cada carga: no se filtra tu IP y la política de contenido puede cerrarse a 'self').
import '@fontsource/space-grotesk/latin-400.css';import '@fontsource/space-grotesk/latin-500.css';import '@fontsource/space-grotesk/latin-600.css';import '@fontsource/space-grotesk/latin-700.css';
import '@fontsource/ibm-plex-mono/latin-400.css';import '@fontsource/ibm-plex-mono/latin-500.css';import '@fontsource/ibm-plex-mono/latin-600.css';import '@fontsource/ibm-plex-mono/latin-700.css';
import './style.css';
import {twoDecimals} from './format';
import {api,ApiError} from './api';
import {WalletDialog} from './WalletDialog';
import {Positions,RoutePreview} from './Positions';
import {SpeedPanel} from './Speed';
import {AlertsPanel,useAlerts} from './Alerts';
import {Watchlist} from './Watchlist';
import {SniperPanel} from './Sniper';
import {Telegram} from './Telegram';
import {PresetsGear,usePresets} from './Presets';
import {money,usdOf,poolHealth,pnlSummary,totalPnl} from './trade-info';
import {usePaper,PaperPositions} from './PaperUI';
import {valuePaper,totalPaper} from './paper';
import type {PriceAlert} from './market/alerts';
import {fmtPrice,rawToNumber} from './market/format';
import {useMarket,useStream} from './market/useMarket';
import {TokenHeader} from './market/TokenHeader';
import {ChartPanel} from './market/ChartPanel';
import {TradesFeed} from './market/TradesFeed';
const pendingStates=['QUEUED','PREPARING','SIGNED','SUBMITTING','SENT','CONFIRMING','SETTLING','UNKNOWN','CONFIRMED_UNMEASURED','VERIFYING_TOKENS','WAITING_BUY'];
const labels:Record<string,string>={QUEUED:'EN COLA',PREPARING:'PREPARANDO',SIGNED:'FIRMADA',SENT:'ENVIADA',CONFIRMING:'ENVIADA · ESPERANDO CONFIRMACIÓN',SUBMITTING:'ENVIANDO AL RPC',SETTLING:'VERIFICANDO LO RECIBIDO',ANALYZED:'COMPRA · DRY RUN',ANALYZED_SELL:'VENTA · DRY RUN',READY:'wNEAR LISTO',FILLED:'COMPRA / VENTA COMPLETADA',PARTIAL:'LLENADO PARCIAL',REFUNDED:'REEMBOLSADA',FAILED:'FALLIDA',UNKNOWN:'RECUPERANDO ESTADO AUTOMÁTICAMENTE',INTERRUPTED:'INTERRUMPIDA',CONFIRMED_UNMEASURED:'CONFIRMADA ON-CHAIN · VERIFICANDO TOKENS',VERIFYING_TOKENS:'CONFIRMADA ON-CHAIN · VERIFICANDO TOKENS',WAITING_BUY:'VENTA PREPARADA · ESPERANDO TOKENS',CANCELLED:'INTENCIÓN CANCELADA'};
function operationLabel(row:any){
 if(row.status==='FILLED')return row.side==='SELL'?'VENTA COMPLETADA':'COMPRA COMPLETADA';
 if(row.side==='ARM')return row.status==='READY'?'ARMADO · LISTO PARA UN SOLO SWAP':row.status==='ANALYZED'?'ARMADO · DRY RUN':labels[row.status]||row.status;
 return row.side==='PREPARE'&&row.status==='ANALYZED'?'PREPARACIÓN · DRY RUN':labels[row.status]||row.status;
}
const sideTitle=(row:any)=>row.side==='SELL'?'VENTA '+row.percentage+'%':row.side==='PREPARE'?'PREPARACIÓN wNEAR':row.side==='ARM'?'ARMAR':'COMPRA';
function beep(){try{const ctx=new AudioContext(),osc=ctx.createOscillator(),gain=ctx.createGain();osc.frequency.value=880;gain.gain.value=0.04;osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+0.12);setTimeout(()=>void ctx.close(),300);}catch{/* sin audio */}}
function App(){
 const [walletOpen,setWalletOpen]=useState(false),[url,setUrl]=useState(''),[amount,setAmount]=useState(()=>preference('amount','0.1')),[slip,setSlip]=useState(()=>preference('slip','3')),[sellSlip,setSellSlip]=useState(()=>preference('sellSlip','3'));
 const [launch,setLaunch]=useState<any>(null),[tab,setTab]=useState<'trades'|'positions'|'telegram'|'sniper'|'history'|'activity'>('trades');
 const [positions,setPositions]=useState<any[]>([]),[tp,setTp]=useState(()=>preference('tp','')),[sl,setSl]=useState(()=>preference('sl','')),[trail,setTrail]=useState(()=>preference('trail','')),[tpSell,setTpSell]=useState(()=>preference('tpSell','100')),[allowRisk,setAllowRisk]=useState(false);
 const [speed,setSpeed]=useState<any>(null),[hotkeys,setHotkeys]=useState(()=>preference('hotkeys','0')==='1'),[sound,setSound]=useState(()=>preference('sound','1')==='1');
 const [health,setHealth]=useState<any>(null),[balances,setBalances]=useState<any>({}),[history,setHistory]=useState<any[]>([]),[result,setResult]=useState<any>(null),[position,setPosition]=useState<any>(null),[operation,setOperation]=useState<any>(null),[busy,setBusy]=useState(false),[quoteBusy,setQuoteBusy]=useState(false),[error,setError]=useState(''),[log,setLog]=useState<string[]>([]),[stopped,setStopped]=useState(false),[arming,setArming]=useState(false),[ack,setAck]=useState(false);
 const activeToken:string|null=launch?.token??null;
 const market=useMarket(activeToken),stream=useStream(activeToken);
 const [side,setSide]=useState<'BUY'|'SELL'>('BUY');
 useEffect(()=>{if(activeToken)setTab('trades');},[activeToken]);
 const {presets,setPresets}=usePresets(),presetsRef=useRef(presets);presetsRef.current=presets;
 const [nearUsdLive,setNearUsdLive]=useState<number|null>(null),[previewBusy,setPreviewBusy]=useState(false),busyRef=useRef(false);
 busyRef.current=busy;
 useEffect(()=>{let dead=false;const load=()=>void api('near-usd').then(r=>{if(!dead)setNearUsdLive(Number(r.usd)||null);}).catch(()=>{});load();const t=setInterval(load,30000);return()=>{dead=true;clearInterval(t);};},[]);
 const nearUsd:number|null=nearUsdLive??market.snapshot?.nearUsd??null;
 const paper=usePaper(activeToken,market.snapshot?.priceNear??null),paperRef=useRef(paper);paperRef.current=paper;
 // Un token que cotiza en otro token (p. ej. RHEA): se paga con NEAR y el bot lo cambia solo por ese token antes de comprar.
 const bridgeFlag=!!launch?.quoteAsset&&launch.quoteAsset.id!=='wrap.near';
 // Alertas de precio (sonido + aviso del navegador + Telegram opcional) y lista de seguimiento.
 const alertsApi=useAlerts(fireAlert);
 const [telegram,setTelegram]=useState(false),telegramRef=useRef(false);telegramRef.current=telegram;
 useEffect(()=>{void api('notify').then(r=>setTelegram(!!r.telegram)).catch(()=>{});},[]);
 useEffect(()=>{if(activeToken)alertsApi.evaluate(activeToken,market.snapshot?.priceUsd);},[market.snapshot]);
 useEffect(()=>{const nearUsd=market.snapshot?.nearUsd,l=stream.latest;if(!activeToken||!l||l.token!==activeToken||l.priceNear==null||!nearUsd)return;alertsApi.evaluate(activeToken,l.priceNear*nearUsd);},[stream.latest]);
 // Tus propias compras y ventas del token activo, para marcarlas sobre el chart.
 const fillsMine=useMemo(()=>{const me=health?.accountId;return me?stream.trades.filter((t:any)=>t.trader===me&&t.nearRaw).map((t:any)=>({ts:t.ts,side:t.side as 'BUY'|'SELL',near:rawToNumber(t.nearRaw,24)})):[];},[stream.trades,health?.accountId]);
 const openPosition=positions.find(p=>p.status==='OPEN'&&p.token===activeToken)??null;
 useEffect(()=>{try{localStorage.setItem('gabnear-amount',amount);localStorage.setItem('gabnear-slip',slip);localStorage.setItem('gabnear-sellSlip',sellSlip);localStorage.setItem('gabnear-tp',tp);localStorage.setItem('gabnear-sl',sl);localStorage.setItem('gabnear-trail',trail);localStorage.setItem('gabnear-tpSell',tpSell);localStorage.setItem('gabnear-hotkeys',hotkeys?'1':'0');localStorage.setItem('gabnear-sound',sound?'1':'0');}catch{/* preferencias opcionales */}},[amount,slip,sellSlip,tp,sl,trail,tpSell,hotkeys,sound]);
 async function loadPositions(){try{setPositions(await api('positions'));}catch{/* se conserva la última lista */}}
 useEffect(()=>{void loadPositions();const t=setInterval(loadPositions,3000);return()=>clearInterval(t);},[]);
 useEffect(()=>{void api('speed').then(setSpeed).catch(()=>{});},[]);
 useEffect(()=>{setAllowRisk(false);},[url]);
 const intent=useRef<{requestId:string;id?:string;url:string;bps:number;startedAt?:number}|null>(null),clickLock=useRef(false),pendingSide=useRef<string|null>(null),queuedBuy=useRef(false),submitRef=useRef<(side:'BUY'|'SELL'|'PREPARE'|'ARM',percentage?:number,amountOverride?:string)=>Promise<void>>(async()=>{}),soundRef=useRef(sound);
 soundRef.current=sound;
 function fireAlert(a:PriceAlert,price:number){
  const text=`${a.symbol||a.token}: el precio ${a.direction==='above'?'superó':'cayó por debajo de'} $${fmtPrice(a.price)} (ahora $${fmtPrice(price)})`;
  activity('🔔 '+text);if(soundRef.current){beep();setTimeout(beep,180);}
  try{if(typeof Notification!=='undefined'&&Notification.permission==='granted')new Notification('GABNEAR · alerta de precio',{body:text});}catch{/* sin avisos del navegador */}
  if(telegramRef.current)void api('notify',{text:'🔔 '+text}).catch(()=>{});
 }
 function activity(text:string){setLog(l=>[`${new Date().toLocaleTimeString('es-AR')}  ${text}`,...l].slice(0,40));}
 async function refresh(){try{const h=await api('health');setHealth(h);setStopped(h.stopped);}catch{setHealth((h:any)=>({...h,rpc:'ERROR'}));}try{setBalances(await api('balances'));setHistory(await api('history'));}catch{/* El panel conserva el último dato; RPC indica disponibilidad. */}}
 useEffect(()=>{
  const saved=sessionStorage.getItem('gabnear-pending');
  if(saved){try{intent.current=JSON.parse(saved);clickLock.current=true;setBusy(true);}catch{sessionStorage.removeItem('gabnear-pending');}}
  void refresh();const t=setInterval(refresh,15000);return()=>clearInterval(t);
 },[]);
 // Seguimiento de la orden en curso: SSE avisa cambios y un sondeo de respaldo la recupera por id (jamás se reenvía).
 useEffect(()=>{
  let cancelled=false,running=false,dirty=false;
  async function poll(){
   if(!intent.current||running)return;running=true;dirty=false;
   try{
    const order=intent.current;let r:any;
    if(order.id)r=await api('operations/'+order.id);
    else{const rows=await api('history');setHistory(rows);r=rows.find((x:any)=>x.requestId===order.requestId);if(!r)return;order.id=r.id;sessionStorage.setItem('gabnear-pending',JSON.stringify(order));}
    if(cancelled)return;
    setOperation(r);if(r.analysis)setResult(r.analysis);if(r.position)setPosition(r.position);
    if(r.lastOutcome?.final_execution_status==='FINAL'&&['VERIFYING_TOKENS','CONFIRMED_UNMEASURED','UNKNOWN'].includes(r.status)){clickLock.current=false;setBusy(false);}
    if(!pendingStates.includes(r.status)){
     if(order.startedAt)requestAnimationFrame(()=>requestAnimationFrame(()=>{void api('operations/'+r.id+'/visualized',{clientElapsedMs:Date.now()-order.startedAt!}).catch(()=>{});}));
     intent.current=null;sessionStorage.removeItem('gabnear-pending');clickLock.current=false;pendingSide.current=null;setBusy(false);
     activity(`${r.side} · ${operationLabel(r)} · ${r.elapsedMs??'—'} ms`);setError(r.error||'');void refresh();
     if(soundRef.current&&['FILLED','PARTIAL'].includes(r.status))beep();
     // Compra simulada: se anota lo que habrías recibido para ver el P/L en vivo.
     if(r.side==='BUY'&&r.mode==='DRY RUN'&&r.status==='ANALYZED'&&r.analysis?.quotation?.expectedTokens){
      const tokens=Number(r.analysis.quotation.expectedTokens),spendNear=r.bridge?.inRaw?Number(BigInt(r.bridge.inRaw)/10n**12n)/1e12:Number(r.amount);
      if(tokens>0&&spendNear>0){paperRef.current.open({token:r.token,symbol:r.analysis.metadata?.symbol??'',spendNear,tokens,feeBps:Number.isFinite(r.analysis.route?.fee)?r.analysis.route.fee:100});activity(`Posición simulada: ${spendNear} NEAR → ≈ ${tokens.toLocaleString('en-US',{maximumFractionDigits:0})} ${r.analysis.metadata?.symbol??''}`);}
     }
     if(r.side==='BUY'&&['FILLED','PARTIAL'].includes(r.status))void api('position',{url:order.url,slippageBps:order.bps,percentage:50,includeUsd:false}).then(p=>{if(!cancelled)setPosition(p);}).catch(()=>{});
     if(r.side==='SELL')void api('position',{url:order.url,slippageBps:order.bps,percentage:50,includeUsd:true}).then(p=>{if(!cancelled)setPosition(p);}).catch(()=>{});
     // Compra pedida mientras se armaba: sale apenas termina el armado.
     if(r.side==='ARM'&&queuedBuy.current){queuedBuy.current=false;if(['READY','ANALYZED'].includes(r.status)){activity('Armado listo: enviando la compra en cola.');setTimeout(()=>void submitRef.current('BUY'),0);}else setError('El armado falló; la compra en cola se canceló. '+(r.error||''));}
    }
   }catch{if(!cancelled)setError('No se pudo consultar el estado. Se seguirá consultando; la orden no se reenviará.');}
   finally{running=false;if(dirty&&!cancelled)void poll();}
  }
  const events=new EventSource('/api/events');events.onmessage=()=>{dirty=true;void poll();};
  const t=setInterval(poll,1000);void poll();
  return()=>{cancelled=true;events.close();clearInterval(t);};
 },[]);
 // Vista previa de solo lectura al pegar el contrato o cambiar importe/slippage.
 useEffect(()=>{
  if(!url.trim()){setLaunch(null);return;}
  let cancelled=false;
  const timer=setTimeout(()=>{setPreviewBusy(true);void api('prefetch',{url,amount,slippageBps:Math.round(Number(slip)*100)||300,...(bridgeFlag?{payWith:'NEAR'}:{})}).then(d=>{if(!cancelled){setLaunch(d);setPreviewBusy(false);}}).catch(e=>{if(!cancelled){setPreviewBusy(false);setLaunch(null);if(url.trim().length>=10&&url.includes('.'))setError(e.message+(/todavía no hay dónde comprar|todavía sin pool|no está activo/.test(e.message)?' Si lo esperás, usá la pestaña «Vigilancia»: compra apenas aparezca el pool.':''));}});},350);
  return()=>{cancelled=true;clearTimeout(timer);};
 },[url,amount,slip,bridgeFlag]);
 function autoSellBody(){const n=(v:string)=>v.trim()===''?null:Number(v);const t=n(tp),s=n(sl),r=n(trail);if(t===null&&s===null&&r===null)return {};return {autoSell:{takeProfitPct:t,stopLossPct:s,trailingPct:r,tpSellPct:Number(tpSell)}};}
 const canDiscard=(row:any)=>row?.status==='UNKNOWN'&&row.lastOutcome?.final_execution_status!=='FINAL'&&!!row.transactions?.some((t:any)=>t.hash===row.txHash&&t.signedAt&&Date.now()-Date.parse(t.signedAt)>180000);
 async function discard(id:string){if(!window.confirm('La red no conoce esta transacción tras más de 3 minutos. ¿Confirmás que NO se ejecutó y querés liberar la cuenta? Si luego apareciera ejecutada, la compra/venta habría ocurrido igual.'))return;setError('');try{const r=await api('operations/'+id+'/discard',{acknowledge:true});setOperation((o:any)=>o?.id===id?r:o);activity('Operación descartada: la red no conocía la transacción.');void refresh();}catch(e){setError((e as Error).message);}}
 async function submit(side:'BUY'|'SELL'|'PREPARE'|'ARM',percentage?:number,amountOverride?:string){
  if(clickLock.current)return;clickLock.current=true;pendingSide.current=side;setBusy(true);setError('');setOperation(null);
  const bps=Math.round(Number(side==='SELL'?sellSlip:slip)*100),requestId=crypto.randomUUID();
  intent.current={requestId,url,bps,startedAt:Date.now()};sessionStorage.setItem('gabnear-pending',JSON.stringify(intent.current));
  activity(`${side==='BUY'?'Compra':side==='PREPARE'?'Preparación wNEAR':side==='ARM'?'Armado':'Venta '+percentage+'%'} · ${health?.liveEnabled?'REAL':'DRY RUN'} · consultando mainnet…`);
  try{
   const r=await api('operations',{requestId,side,mode:health?.liveEnabled?'REAL':'DRY RUN',url,...side!=='SELL'?{amount:amountOverride??amount}:{percentage},slippageBps:bps,...(side==='BUY'?{...(allowRisk?{allowRisk:true}:{}),...(bridgeFlag?{payWith:'NEAR'}:{}),...autoSellBody()}:{})});
   if(intent.current?.requestId===requestId){intent.current.id=r.id;sessionStorage.setItem('gabnear-pending',JSON.stringify(intent.current));setOperation(r);}
  }catch(e){
   if(e instanceof ApiError){intent.current=null;sessionStorage.removeItem('gabnear-pending');clickLock.current=false;pendingSide.current=null;setBusy(false);}
   setError(e instanceof ApiError?e.message:'Respuesta de envío perdida. Se consultará el historial sin repetir la orden.');
  }
 }
 submitRef.current=submit;
 // En VENDER el saldo y su valor se leen solos (y se refrescan cada 12 s): no hace falta tocar «actualizar».
 useEffect(()=>{
  if(side!=='SELL'||!url.trim()||!health?.accountId)return;
  let dead=false;
  const run=async()=>{if(busyRef.current)return;try{const p=await api('position',{url,slippageBps:Math.round(Number(sellSlip)*100)||300,percentage:50,includeUsd:true});if(!dead)setPosition(p);}catch{/* se conserva el último saldo */}};
  const first=setTimeout(()=>void run(),600);                        // espera a que termines de escribir el contrato
  const t=setInterval(()=>void run(),12000);return()=>{dead=true;clearTimeout(first);clearInterval(t);};
 },[side,url,health?.accountId,sellSlip]);
 async function lookup(){setQuoteBusy(true);setError('');try{setPosition(await api('position',{url,slippageBps:Math.round(Number(sellSlip)*100),percentage:50,includeUsd:true}));}catch(e){setError((e as Error).message);}finally{setQuoteBusy(false);}}
 async function changeMode(){if(arming)return;setArming(true);setError('');try{const r=await api('live',{enabled:!health?.liveEnabled,acknowledgeMainnet:ack});setHealth((h:any)=>({...h,liveEnabled:r.enabled}));setAck(false);activity(r.enabled?'REAL habilitado para esta sesión. Los botones enviarán fondos.':'DRY RUN activado.');}catch(e){setError((e as Error).message);}finally{setArming(false);}}
 async function emergency(){try{const r=await api('emergency',{stopped:!stopped});setStopped(r.stopped);if(r.stopped)setHealth((h:any)=>({...h,liveEnabled:false}));activity(r.stopped?'PARADA DE EMERGENCIA activada':'Operaciones reanudadas en DRY RUN');}catch(e){setError((e as Error).message);}}
 async function reconcile(id:string){setError('');try{const r=await api('operations/'+id+'/reconcile',{});setOperation(r);void refresh();}catch(e){setError((e as Error).message);}}
 async function prepareSale(percentage:number){if(!intent.current?.id)return;setError('');try{const r=await api('operations/'+intent.current.id+'/sell-intent',{requestId:crypto.randomUUID(),side:'SELL',mode:'REAL',url,percentage,slippageBps:Math.round(Number(sellSlip)*100)});intent.current={requestId:r.requestId,id:r.id,url,bps:r.slippageBps,startedAt:Date.now()};sessionStorage.setItem('gabnear-pending',JSON.stringify(intent.current));setOperation(r);activity('Venta preparada: solo se enviará después de verificar los tokens de la compra.');}catch(e){setError((e as Error).message);}}
 const asset=launch?.quoteAsset??result?.quoteAsset??position?.quoteAsset,quoteSymbol=asset?.symbol??'quote del launch',isWnear=asset?.id==='wrap.near';
 const blocked=busy||stopped||arming,live=health?.liveEnabled===true;
 const canPrepareSale=busy&&operation?.side==='BUY'&&operation?.mode==='REAL'&&live&&!!intent.current?.id&&!stopped&&!arming;
 const armingNow=busy&&pendingSide.current==='ARM';
 const ready=launch?.ready;
 // Compra con el importe y slippage cargados. Si el contrato se está armando, la compra queda en cola y sale sola al terminar.
 const buyRef=useRef<HTMLButtonElement>(null);
 function buyNow(override?:string){if(override)setAmount(override);if(armingNow){queuedBuy.current=true;activity('Compra en cola: se envía apenas termine el armado.');return;}if(!blocked&&url.trim()&&!(live&&!health?.accountId))void submit('BUY',undefined,override);}
 // «⚡ COMPRAR» de las listas: abre el token y te deja parado en el botón de compra. Nunca compra solo.

 function quickBuyUnused(token:string){pickToken(token);setSide('BUY');setTimeout(()=>{buyRef.current?.scrollIntoView({behavior:'smooth',block:'center'});buyRef.current?.focus({preventScroll:true});},900);}
 const amountNum=Number(amount)||0,spendUsd=usdOf(amountNum,nearUsd),est=launch?.estimate,br=launch?.bridge,tokenSym=launch?.metadata?.symbol??'';
 const ph=poolHealth(market.snapshot?.liquidityUsd??null,launch?.risk?.impactBps??null,spendUsd);
 const pnl=openPosition?pnlSummary(openPosition):null,tot=useMemo(()=>totalPnl(positions),[positions]);
 const paperPos=paper.list.find(p=>p.token===activeToken)??null,pv=paperPos?valuePaper(paperPos,paper.priceOf(paperPos.token),nearUsd):null;
 const paperTot=totalPaper(paper.list,Object.fromEntries(paper.list.map(p=>[p.token,paper.priceOf(p.token)])),nearUsd);
 const showPaper=!live&&!!paperPos&&(!position||Number(position.balanceRaw)===0);
 function paperSell(pct:number){if(!activeToken)return;const got=paper.sell(activeToken,pct);if(got===null){setError('No hay precio disponible para simular la venta.');return;}activity(`Venta simulada ${pct}% de ${paperPos?.symbol??''}: ≈ ${got.toFixed(3)} NEAR`);}
 const sellTotalUsd=position?.usdValuation?.status==='AVAILABLE'?position.usdValuation.expectedUsd as number:null;
 const buyBlock=!url.trim()?'PEGÁ UN CONTRATO PARA COMPRAR':stopped?'PARADA DE EMERGENCIA ACTIVA':live&&!health?.accountId?'CONECTÁ Y DESBLOQUEÁ TU WALLET':'';
 const wnearEnough=isWnear&&Number(amount)>0&&Number(balances.wnear)>=Number(amount);
 // Armado automático: al pegar un contrato en REAL se deja todo listo para que comprar sea UN solo swap.
 const armedKey=useRef('');
 useEffect(()=>{
  if(!speed?.autoArm||!live||!launch||launch.risk?.blocked||ready?.armed||busy||stopped||arming||!health?.accountId||!isWnear)return;
  const key=`${launch.token}|${amount}`;if(armedKey.current===key)return;armedKey.current=key;
  activity('Armado automático del contrato pegado…');void submitRef.current('ARM');
 },[launch]);
 // Atajos opcionales (Alt+B compra; Alt+1/2/3 vende 50/99/100 %). Desactivados por defecto para evitar disparos accidentales.
 useEffect(()=>{
  if(!hotkeys)return;
  const handler=(e:KeyboardEvent)=>{
   if(!e.altKey||e.ctrlKey||e.metaKey||e.repeat||blocked)return;
   const k=e.key.toLowerCase();
   if(k==='b'&&url.trim()){e.preventDefault();void submitRef.current('BUY');}
   else if(['1','2','3','4'].includes(k)){e.preventDefault();void submitRef.current('SELL',presetsRef.current.sell[Number(k)-1]);}
  };
  window.addEventListener('keydown',handler);return()=>window.removeEventListener('keydown',handler);
 },[hotkeys,blocked,url]);
 function pickToken(token:string){setUrl(token);setPosition(null);setResult(null);setTab('trades');window.scrollTo({top:0,behavior:'smooth'});}
 return <main>
  {walletOpen&&<WalletDialog onClose={()=>setWalletOpen(false)} onConnected={()=>{setResult(null);setPosition(null);setBalances({});setHealth((h:any)=>({...h,liveEnabled:false}));void refresh();activity('Configuración de wallet actualizada. REAL desactivado.');}}/>}
  <header className="topbar">
   <div className="mascot-head"><img src="/assets/gabi-gabear-v1.png" alt="Gabi Gabear, humano con cabeza de oso y lentes"/></div>
   <div className="brand-copy"><div className="eyebrow">NEAR LAUNCH TERMINAL</div><h1>GAB<span>NEAR</span></h1><p>El dundo está al mando.</p></div>
   <div className="chips">
    <article><small>RPC</small><strong className={health?.rpc==='CONNECTED'?'green':'red'}>{health?.rpc==='CONNECTED'?`${health.latencyMs??'—'} ms`:'SIN CONEXIÓN'}</strong><span>{health?.block?`bloque ${health.block}`:'comprobando…'}</span></article>
    <article><small>NEAR</small><strong>{twoDecimals(balances.near)}</strong><span>disp. {twoDecimals(balances.available)}</span></article>
    {(tot.open>0||tot.realized!==0)?<article title="P/L de todas tus posiciones, en dólares: abierto (valor de salida neto de impuestos y gas estimado − costo) + realizado."><small>P/L</small><strong className={(tot.total??0)>=0?'green':'red'}>{tot.pct!=null?`${tot.pct>=0?'+':''}${tot.pct.toFixed(1)}%`:money(tot.total,true)}</strong><span>{money(tot.total,true)} · {tot.open} abierta{tot.open===1?'':'s'}</span></article>
    :paperTot.open>0?<article title="P/L de tus posiciones SIMULADAS (DRY RUN), valuadas con el precio real."><small>P/L SIM</small><strong className={(paperTot.pnlUsd??0)>=0?'green':'red'}>{paperTot.pct!=null?`${paperTot.pct>=0?'+':''}${paperTot.pct.toFixed(1)}%`:'—'}</strong><span>{money(paperTot.pnlUsd,true)} · {paperTot.open} simulada{paperTot.open===1?'':'s'}</span></article>:null}
    <article><small>wNEAR</small><strong>{twoDecimals(balances.wnear)}</strong><span>{balances.exists===false?'cuenta sin fondos':'listo para swaps'}</span></article>
   </div>
   <div className="header-state"><button className="connect-wallet" disabled={busy||arming} onClick={()=>setWalletOpen(true)}>{health?.accountId?'WALLET ↗':'CONECTAR WALLET ↗'}</button><b className={'badge '+(live?'live-badge':'')}>● {live?'REAL · MAINNET':'DRY RUN'}</b><small title={health?.accountId}>{health?.accountId?(health.accountId.length>22?health.accountId.slice(0,10)+'…'+health.accountId.slice(-8):health.accountId):'Sin wallet conectada'}</small></div>
  </header>
  <form className="panel launch-link" onSubmit={e=>e.preventDefault()}>
   <label>Contrato de cualquier token NEAR (Nearly, meme.cooking, Shore, JustHoot, tkn…) o enlace<input disabled={blocked&&!armingNow} value={url} onChange={e=>{setUrl(e.target.value);setPosition(null);setResult(null);setError('');}} placeholder="token.tkn.near · ai-8.nearlytrade.near · https://nearly.trade/…" autoComplete="off" spellCheck={false}/></label>
   {launch&&<RoutePreview launch={launch} allowRisk={allowRisk} setAllowRisk={setAllowRisk} disabled={blocked}/>}
   <div className="send-row"><span className="hint">{armingNow?'Armando: si comprás ahora, la compra sale apenas termine el armado.':'Pegá el contrato y comprá con los botones del panel de la derecha (importes de la ruedita ⚙).'}{live&&ready&&<b className={'ready '+(ready.armed?'ok':'')}>{ready.armed?' ⚡ ARMADO: un solo swap':` · falta: ${[!ready.tokenRegistered&&'registrar token',!ready.quoteRegistered&&'registrar wNEAR',ready.enough===false&&'wNEAR'].filter(Boolean).join(', ')}`}</b>}</span></div>
  </form>
  <Watchlist active={activeToken} activeSymbol={launch?.metadata?.symbol??market.snapshot?.symbol??''} onPick={pickToken} onPrices={rows=>{for(const r of rows)alertsApi.evaluate(r.token,r.priceUsd);}}/>
  <div className="terminal">
   <div className="col-main">
    {activeToken?<>
     <TokenHeader token={activeToken} snapshot={market.snapshot} error={market.error} live={stream.live} lastTradeAt={stream.lastTradeAt}/>
     <ChartPanel token={activeToken} decimals={launch?.metadata?.decimals??18} nearUsd={market.snapshot?.nearUsd??null} latest={stream.latest} position={openPosition} fills={fillsMine} quoteSymbol={market.snapshot?.quote?.symbol??'NEAR'}/>
     <AlertsPanel token={activeToken} symbol={launch?.metadata?.symbol??market.snapshot?.symbol??''} priceUsd={market.snapshot?.priceUsd??null} alerts={alertsApi.alerts} add={alertsApi.add} remove={alertsApi.remove} telegram={telegram}/>
    </>:<section className="panel empty-token"><h2>Pegá un contrato para empezar</h2><p className="hint">Acá vas a ver el chart en vivo, market cap, liquidez, holders y los swaps en el momento. Abajo, en «Lanzamientos», aparecen los tokens recién desplegados por los launchpads.</p></section>}
    <div className="tabs" role="tablist">{([['trades','Swaps en vivo'],['positions',`Posiciones${positions.filter(p=>p.status==='OPEN').length?` (${positions.filter(p=>p.status==='OPEN').length})`:''}`],['telegram','Telegram'],['sniper','Vigilancia'],['history','Historial'],['activity','Actividad']] as const).map(([k,l])=><button key={k} role="tab" aria-selected={tab===k} className={tab===k?'on':''} onClick={()=>setTab(k)}>{l}</button>)}</div>
    {tab==='trades'&&(activeToken?<TradesFeed trades={stream.trades} decimals={launch?.metadata?.decimals??18} symbol={launch?.metadata?.symbol??'TOKEN'} nearUsd={market.snapshot?.nearUsd??null} live={stream.live} me={health?.accountId??''}/>:<p className="hint panel">Los swaps del token aparecen acá apenas pegues un contrato.</p>)}
    {tab==='positions'&&<><PaperPositions paper={paper} nearUsd={nearUsd} onPick={pickToken}/><Positions positions={positions} reload={loadPositions} activity={activity} hasAccount={!!health?.accountId} onSelect={pickToken} live={live} stopped={stopped}/></>}
    {tab==='telegram'&&<Telegram onPick={pickToken}/>}
    {tab==='sniper'&&<SniperPanel url={url} amount={amount} slip={slip} live={live} hasAccount={!!health?.accountId} autoSell={autoSellBody()} activity={activity} onOpen={pickToken}/>}
    {tab==='history'&&<section className="panel"><h2>Historial</h2><div className="history">{history.length===0?<p className="hint">Todavía no hay operaciones.</p>:history.slice(0,30).map(r=><div key={r.id} className="history-row"><span>{new Date(r.at).toLocaleTimeString('es-AR')}<small>{sideTitle(r)} {r.token||'Análisis rechazado'} {r.quoteAsset&&`· quote ${r.quoteAsset.symbol} (${r.quoteAsset.id})`}</small></span><b className={['FILLED','ANALYZED','ANALYZED_SELL','READY'].includes(r.status)?'green':'red'}>{operationLabel(r)}</b><span>{r.fundsSent===false?'Sin envío':r.txHash?<a target="_blank" rel="noreferrer" href={'https://nearblocks.io/txns/'+r.txHash}>Hash ↗</a>:'Resultado en cadena'}<small>{r.error||`${r.elapsedMs??r.timings?.totalMs??'—'} ms${r.finality==='OPTIMISTIC'?' · confirmación rápida':''}${r.recovery?' · respuesta inicial; recuperada después':''}`}</small>{r.status==='UNKNOWN'&&<button className="outline" onClick={()=>reconcile(r.id)}>Consultar ahora · auto recuperación activa</button>}{canDiscard(r)&&<button className="outline discard" onClick={()=>discard(r.id)}>Descartar</button>}</span></div>)}</div></section>}
    {tab==='activity'&&<section className="panel"><h2>Actividad</h2><div className="console">{log.length?log.map((s,i)=><p key={i}>{s}</p>):<p>GABNEAR listo. Esperando enlace.</p>}</div></section>}
    <details className="panel analysis-panel"><summary>Ruta y cotización de la última compra {result?<span className="tag">CONSULTADO POR RPC</span>:<span className="tag">EN ESPERA</span>}</summary>
     {!result?<p className="hint">ENVIAR muestra el pool, los impuestos y la cotización. DRY RUN no crea una posición.</p>:<><h3>{result.metadata.name} <span className="green">${result.metadata.symbol}</span></h3><p className="mono">{result.token}</p><dl><dt>Pool</dt><dd className="mono">{result.record.pool_id}</dd><dt>Ruta</dt><dd>{result.direct?`${(result.quoteAsset?.symbol??'wNEAR')} (${(result.quoteAsset?.id??'wrap.near')}) → token · ${result.route?.venue==='REF_V1'?'Ref v1':'Rhea DCL'}${result.generic?' · token genérico':''}`:'Ruta no soportada · bloqueada'}</dd>{result.candidates?.length>1&&<><dt>Pools comparados</dt><dd>{result.candidates.map((c:any)=>`${c.venue==='REF_V1'?'Ref v1':'DCL'} ${(c.fee/100).toFixed(2)}%`).join(' · ')}</dd></>}{result.risk&&<><dt>Impacto de precio</dt><dd>{result.risk.impactBps===null?'No medido':`${(result.risk.impactBps/100).toFixed(2)}%`}{result.risk.blocked?' · BLOQUEADO':''}</dd></>}<dt>Saldo del quote al analizar</dt><dd>{twoDecimals(result.quoteBalance)} {(result.quoteAsset?.symbol??'wNEAR')}</dd><dt>Registración del quote</dt><dd>{result.quoteRegistered===null?'Sin cuenta':result.quoteRegistered?'Lista':'Necesaria'}</dd><dt>Salida estimada después de impuesto</dt><dd>{result.quotation?twoDecimals(result.quotation.expectedTokens):'No disponible'}</dd><dt>Mínimo después de impuesto</dt><dd>{result.quotation?twoDecimals(result.quotation.minTokens):'No disponible'}</dd><dt>Registración de token al analizar</dt><dd>{result.storageRegistered===null?'Sin cuenta':result.storageRegistered?'Lista':'Necesaria'}</dd></dl>{result.warnings.length>0&&<div className="warnings">{result.warnings.map((w:string)=><p key={w}>⚠ {w}</p>)}</div>}<div className="timings">{Object.entries(result.timings).map(([k,v])=><span key={k}>{k}: <b>{String(v)} ms</b></span>)}</div></>}
    </details>
   </div>
   <div className="col-side">
    {pnl&&openPosition?<div className={'pnl-strip '+((pnl.pnlUsd??0)<0?'neg':'pos')} aria-label="Tu posición en este token"><small>TU POSICIÓN · ${openPosition.symbol}</small><div><strong>{pnl.pnlPct!=null?`${pnl.pnlPct>=0?'+':''}${pnl.pnlPct.toFixed(1)}%`:'—'}</strong><span>{money(pnl.pnlUsd,true)}</span></div><small>Costo {money(pnl.costUsd)} · Vale ahora {money(pnl.valueUsd)}{pnl.realizedUsd?` · Realizado ${money(pnl.realizedUsd,true)}`:''}</small></div>
    :pv&&paperPos?<div className={'pnl-strip '+((pv.pnlPct??0)<0?'neg':'pos')} aria-label="Tu posición simulada en este token"><small>POSICIÓN SIMULADA · ${paperPos.symbol} · sin fondos</small><div><strong>{pv.pnlPct!=null?`${pv.pnlPct>=0?'+':''}${pv.pnlPct.toFixed(1)}%`:'—'}</strong><span>{money(pv.pnlUsd,true)}</span></div><small>Costo {money(pv.costUsd)} · Vale ahora {money(pv.valueUsd)}{paperPos.realizedNear?` · Realizado ${money(pv.realizedUsd,true)}`:''}</small></div>:null}
    <div className="trade-head"><div className="trade-tabs" role="tablist"><button role="tab" aria-selected={side==='BUY'} className={'buy'+(side==='BUY'?' on':'')} onClick={()=>setSide('BUY')}>COMPRAR</button><button role="tab" aria-selected={side==='SELL'} className={'sell-tab'+(side==='SELL'?' on':'')} onClick={()=>setSide('SELL')}>VENDER{openPosition?' ●':''}</button></div><PresetsGear presets={presets} onSave={setPresets}/></div>
    {side==='BUY'&&<section className="panel buy-panel"><div className="section-title"><h2>COMPRAR</h2><span className="tag">{live?'FONDOS REALES':'SIMULACIÓN'}</span></div>
     <div className="two"><label>Cuánto comprar · NEAR<input type="number" min="0" step="any" disabled={busy} inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)}/><small className="usd-line">{spendUsd===null?'≈ $—':'≈ '+money(spendUsd)}{balances.available?` · disponible ${twoDecimals(balances.available)} NEAR`:''}</small></label><label>Slippage de compra · %<input type="number" min="0.01" max={(health?.config?.maxBps??9900)/100} step="0.01" disabled={busy} inputMode="decimal" value={slip} onChange={e=>setSlip(e.target.value)}/></label></div>
     <div className="quick">{presets.buy.map(n=><button disabled={busy} key={n} className={amountNum===n?'on':''} onClick={()=>setAmount(String(n))} title={'Elige '+n+' NEAR'+(usdOf(n,nearUsd)===null?'':' (≈ '+money(usdOf(n,nearUsd))+')')+'. No compra: usá el botón verde.'}>{n}<small>{usdOf(n,nearUsd)===null?'':money(usdOf(n,nearUsd))}</small></button>)}</div>
     {launch&&<div className={'est-box '+ph.level} aria-live="polite">
      <div className="est-line"><span>Gastás</span><b>{amount||0} NEAR <small>≈ {money(spendUsd)}</small></b></div>
      {bridgeFlag&&br&&!br.error&&<div className="est-line"><span>Cambio automático a {br.quoteSymbol}</span><b>≈ {twoDecimals(br.expectedQuote)} {br.quoteSymbol}</b></div>}
      {est?<div className="est-line"><span>Recibís</span><b>≈ {twoDecimals(est.expectedTokens)} {tokenSym} <small>(mín. {twoDecimals(est.minTokens)})</small></b></div>:<div className="est-line"><span>Recibís</span><b>{previewBusy?'calculando…':'—'}</b></div>}
      <div className="est-health">{ph.level==='ok'?'✓':'⚠'} {ph.text}</div>
      {bridgeFlag&&br&&!br.error&&<p className="hint">Este token cotiza en <b>{br.quoteSymbol}</b>, no en NEAR: el bot cambia tus NEAR a {br.quoteSymbol} ({br.venue==='DCL'?'Rhea':'Ref'}{br.impactBps!=null?`, impacto ${(br.impactBps/100).toFixed(2)}%`:''}) y compra {tokenSym} con eso. Son 2 swaps.{br.blocked?' ⛔ '+br.blocked:''}</p>}
      {br?.error&&<p className="error">{br.error}</p>}
     </div>}
     <button ref={buyRef} type="button" className={'buy-big'+(live?' real':'')} disabled={(blocked&&!armingNow)||!url.trim()||(live&&!health?.accountId)} onClick={()=>buyNow()} title="Alt+B si activaste los atajos">{armingNow?'EN COLA · SALE AL TERMINAR EL ARMADO':busy?'EN CURSO…':buyBlock?buyBlock:<>{live?'COMPRAR':'SIMULAR COMPRA'} · {amount||'0'} NEAR{spendUsd!==null?` (${money(spendUsd)})`:''}</>}</button>
     <p className="buy-note">{live?'⚠ REAL: envía fondos de tu wallet al hacer clic.':'DRY RUN: analiza y cotiza, no envía nada.'}</p>
     {error&&<p className="error" role="alert">{error}</p>}
     <details className="buy-autosell" open={!!(tp||sl||trail)}><summary>AUTO SELL AL COMPRAR · opcional</summary>
      <div className="three"><label>Take profit · +%<input type="number" min="0" step="any" disabled={busy} inputMode="decimal" value={tp} placeholder="ej. 100" onChange={e=>setTp(e.target.value)}/></label><label>Stop loss · −%<input type="number" min="0" max="99.9" step="any" disabled={busy} inputMode="decimal" value={sl} placeholder="ej. 30" onChange={e=>setSl(e.target.value)}/></label><label>Trailing · caída %<input type="number" min="0" max="99.9" step="any" disabled={busy} inputMode="decimal" value={trail} placeholder="ej. 25" onChange={e=>setTrail(e.target.value)}/></label></div>
      <label>El take profit vende<select disabled={busy} value={tpSell} onChange={e=>setTpSell(e.target.value)}><option value="100">100% de los tokens</option><option value="99">99% (deja 1%)</option><option value="50">50% (deja correr el resto)</option></select></label>
      <p className="hint">{tp||sl||trail?'Al completarse la compra REAL se arma la posición y vigila estos niveles sola (ver «Posiciones»).':'Vacío = sin AUTO SELL; igual se registra la posición para ver el P/L.'}</p></details>
     {health?.config?.limits?.maxBuyNear&&Number(amount)>Number(health.config.limits.maxBuyNear)&&isWnear&&<p className="error">Este importe supera el tope por compra (MAX_BUY_NEAR={health.config.limits.maxBuyNear} NEAR): el servidor va a bloquear la compra REAL.</p>}
     {Number(slip)>=20&&<p className="error">Slippage de {slip}%: permite recibir hasta ese porcentaje menos que la cotización, antes del impuesto.</p>}
     <div className="two arm-row"><button className="outline" disabled={blocked||!health?.accountId||!isWnear||!url.trim()} onClick={()=>void submit('ARM')} title="Registra el token y deja wNEAR listo: comprar pasa a ser UN solo swap (≈1,5-3 s menos).">{live?'⚡ ARMAR (token + wNEAR)':'⚡ ANALIZAR ARMADO'}</button><button className="outline" disabled={blocked||!health?.accountId||!isWnear} onClick={()=>void submit('PREPARE')} title="Convierte NEAR en wNEAR (1:1) para tener fondos listos. No compra ningún token.">{live?'CONVERTIR NEAR → wNEAR':'ANALIZAR CONVERSIÓN'}</button></div>
     {isWnear?<div className={'fund-status '+(wnearEnough?'ok':'')}>
      <p>{wnearEnough?<>✓ <b>wNEAR listo</b> ({twoDecimals(balances.wnear)} ≥ {amount}). La compra será un solo swap.</>:<>○ Tenés <b>{twoDecimals(balances.wnear)} wNEAR</b> y vas a comprar con {amount}. El bot convierte NEAR → wNEAR solo, justo antes de comprar (suma un paso, ~1,5–3 s).</>}</p>
      <details><summary>¿Hace falta wNEAR? ¿Qué hace ARMAR?</summary>
       <p><b>No es obligatorio.</b> Los DEX de NEAR (Rhea, Ref) no aceptan NEAR directo: trabajan con <b>wNEAR</b>, que es tu mismo NEAR «envuelto» 1:1 y se puede volver a convertir cuando quieras.</p>
       <p>Una compra son hasta 3 pasos en cadena: <b>1)</b> convertir NEAR → wNEAR, <b>2)</b> registrarte en el token (la primera vez, ≈0,00125 NEAR), <b>3)</b> el swap. Cada paso espera ~1,5–3 s. Si dejás los pasos 1 y 2 hechos de antemano, al comprar solo corre el 3.</p>
       <p><b>ARMAR</b> hace los pasos 1 y 2 para el contrato pegado, sin comprar nada. <b>CONVERTIR</b> hace solo el 1. Si no armás nada, pegás el contrato y comprás igual: solo tarda más.</p>
       <p>Al vender recibís wNEAR; queda como wNEAR para la próxima compra (si querés NEAR normal, convertilo desde tu wallet).</p>
      </details></div>:<p className="hint">Se usa el saldo existente de {quoteSymbol}. No se convierte NEAR automáticamente.</p>}
    </section>}
    {side==='SELL'&&<section className="panel sell-panel"><div className="section-title"><h2>VENDER</h2><span className="tag">{live?'FONDOS REALES':'SIMULACIÓN'}</span></div>
     <div className="sell-balance">
      <div><small>TENÉS{showPaper?' (SIMULADO)':''}</small><strong title={position?.balance}>{showPaper&&paperPos?paperPos.tokens.toLocaleString('en-US',{maximumFractionDigits:2}):url.trim()&&health?.accountId?(position?twoDecimals(position.balance):'…'):'—'} <em>{showPaper?paperPos?.symbol:position?.metadata?.symbol??''}</em></strong></div>
      <div><small>VALEN</small><strong>{showPaper&&pv?money(pv.valueUsd):sellTotalUsd!==null?money(sellTotalUsd):quoteBusy?'…':'—'}</strong><span>{showPaper&&pv?.pnlPct!=null?`${pv.pnlPct>=0?'+':''}${pv.pnlPct.toFixed(1)}% desde que compraste`:position?.usdValuation?.status==='UNAVAILABLE'?'sin precio USD':'cotización de salida'}</span></div>
     </div>
     {!url.trim()&&<p className="hint">Pegá un contrato para ver tu saldo.</p>}{url.trim()&&!health?.accountId&&<p className="hint">Conectá tu wallet para ver tu saldo.</p>}
     {position&&Number(position.balanceRaw)===0&&!showPaper&&<p className="hint">No tenés saldo de este token.</p>}{showPaper&&<p className="hint">Posición simulada: vender acá la reduce en simulación, no envía nada.</p>}
     <label>Slippage de venta · %<input type="number" min="0.01" max={(health?.config?.maxBps??9900)/100} step="0.01" disabled={busy} inputMode="decimal" value={sellSlip} onChange={e=>{setSellSlip(e.target.value);setPosition(null);}}/></label>
     <div className="sell-actions">{presets.sell.map(p=><button key={p} className="sell" disabled={(blocked&&!canPrepareSale)||!url.trim()} onClick={()=>showPaper?paperSell(p):canPrepareSale?prepareSale(p):submit('SELL',p)} title={(showPaper&&pv?.valueUsd!=null?pv.valueUsd:sellTotalUsd)===null?undefined:'≈ '+money(((showPaper&&pv?.valueUsd!=null?pv.valueUsd:sellTotalUsd) as number)*p/100)}><b>{canPrepareSale&&!showPaper?'PREPARAR ':'VENDER '}{p}%</b><small>{(showPaper&&pv?.valueUsd!=null?pv.valueUsd:sellTotalUsd)===null?'':'≈ '+money(((showPaper&&pv?.valueUsd!=null?pv.valueUsd:sellTotalUsd) as number)*p/100)}</small></button>)}</div>
     <p className="buy-note">{live?'⚠ REAL: un clic inicia la venta.':'DRY RUN: cotiza la venta sin enviarla.'} El porcentaje se recalcula sobre tu saldo al operar.</p>
     {position&&position.quoteAsset?.id!=='wrap.near'&&position.quoteAsset&&<p className="hint">Este token se vende por <b>{position.quoteAsset.symbol}</b>. Para volver a NEAR, después vendé {position.quoteAsset.symbol} (<button type="button" className="outline mini" onClick={()=>{setUrl(position.quoteAsset.id);setPosition(null);setResult(null);}}>ABRIR {position.quoteAsset.symbol}</button>).</p>}
     {position?.quotation&&<p className="exit-quote">Vender {position.percentage}% ≈ {twoDecimals(position.quotation.expectedQuote??position.quotation.expectedNear)} {position.quoteAsset?.symbol??'wNEAR'}<br/><small>Mínimo cotizado: {twoDecimals(position.quotation.minimumQuote??position.quotation.minimumNear)} {position.quoteAsset?.symbol??'wNEAR'} · antes del gas</small></p>}
     {error&&<p className="error" role="alert">{error}</p>}
    </section>}
    {operation&&<section className="panel operation-status" aria-live="polite"><div><span className="eyebrow">{sideTitle(operation)} · {operation.mode}</span><h2>{operationLabel(operation)}</h2><p className="hint">{operation.elapsedMs?`${operation.elapsedMs} ms ${operation.recovery?'hasta respuesta inicial; resultado recuperado después':'medidos'} · `:''}{operation.lastOutcome?.final_execution_status==='FINAL'?(operation.receiptEvidence?'Ejecución final y tokens verificados en los recibos.':'Ejecución final; verificando importe recibido automáticamente.'):operation.finality==='OPTIMISTIC'?'Ejecutada (confirmación rápida); la finalidad se verifica en segundo plano.':operation.fundsSent===true?'RPC respondió al envío; esperando ejecución.':operation.fundsSent===false?'Sin fondos enviados.':'Hash registrado; recuperando estado automáticamente, sin reenviar.'}</p>{operation.error&&<p className="error" role="alert">{operation.error}</p>}{operation.timing?.events&&<details><summary>Tiempos por etapa ({operation.timing.events.length})</summary><div className="timings">{operation.timing.events.map((event:any,i:number)=><span key={i}>{event.stage}: <b>+{event.offsetMs} ms desde la orden{event.durationMs!==undefined?` · duración ${event.durationMs} ms`:''}{event.error?` · ${event.timeout?'TIMEOUT: ':''}${event.error}`:''}{event.clock==='wall-recovery'?' · observado durante recuperación':''}</b></span>)}</div></details>}{operation.receivedRaw&&<p>Recibido: <b className="green">{receivedLabel(operation)}</b></p>}</div>{operation.txHash&&<a target="_blank" rel="noreferrer" href={'https://nearblocks.io/txns/'+operation.txHash}>VER TRANSACCIÓN ↗</a>}{operation.status==='UNKNOWN'&&<button className="outline" onClick={()=>reconcile(operation.id)}>CONSULTAR AHORA · RECUPERACIÓN AUTOMÁTICA ACTIVA</button>}{canDiscard(operation)&&<button className="outline discard" onClick={()=>discard(operation.id)}>DESCARTAR · la red no conoce esta transacción</button>}</section>}
    <section className="panel mode-panel"><div><h3>{live?'REAL habilitado en esta sesión':'Modo predeterminado: DRY RUN'}</h3><p className="hint">{live?'Los botones compran y venden con tu wallet local.':'REAL requiere habilitación explícita.'} {limitsText(health?.config?.limits)} · slippage máximo {(health?.config?.maxBps??9900)/100}%.</p>{!live&&<label className="ack"><input type="checkbox" checked={ack} disabled={blocked} onChange={e=>setAck(e.target.checked)}/>Habilitar operaciones con fondos reales de esta wallet en mainnet.</label>}</div><div className="mode-actions"><button className="outline" disabled={blocked||(!live&&!ack)} onClick={changeMode}>{arming?'VERIFICANDO CLAVE…':live?'VOLVER A DRY RUN':'ACTIVAR REAL'}</button><button className="stop" onClick={emergency}>{stopped?'REANUDAR EN DRY RUN':'■ PARADA DE EMERGENCIA'}</button></div></section>
    <SpeedPanel speed={speed} setSpeed={setSpeed} hotkeys={hotkeys} setHotkeys={setHotkeys} sound={sound} setSound={setSound}/>
   </div>
  </div>
  <aside className="gabear-strip" aria-label="Club Gabear"><span>EL DUNDO</span><span>EL DUNDEZ</span><span>EL DUENDE DUNDIX</span><span>CATA OLIBEARI</span><span>PREGABEAR 150mg</span></aside>
  <footer>GABNEAR · LOCAL 127.0.0.1 · {live?'REAL MAINNET':'DRY RUN'} · AUTO SELL: monitor activo ({positions.filter(p=>p.status==='OPEN'&&p.settings?.enabled).length} posición(es) armada(s)) · datos: on-chain + DexScreener + GeckoTerminal + FastNEAR + Intear</footer>
 </main>;
}
function limitsText(l:any){
 if(!l)return 'Sin tope de gasto';
 if(l.error)return `Topes ilegibles (${l.error}): las compras REAL quedan bloqueadas hasta corregir el .env`;
 if(!l.maxBuyNear&&!l.maxDailyNear)return 'Sin tope de gasto (poné MAX_BUY_NEAR y MAX_DAILY_NEAR en el .env)';
 return [l.maxBuyNear&&`Tope por compra ${l.maxBuyNear} NEAR`,l.maxDailyNear&&`hoy ${twoDecimals(l.spentTodayNear)}/${l.maxDailyNear} NEAR`].filter(Boolean).join(' · ');
}
function receivedLabel(row:any){const isNear=['NEAR','wrap.near'].includes(row.outputToken);const m=row.side==='SELL'?(row.quoteAsset??row.position?.quoteAsset):(row.analysis?.metadata);return `${formatRaw(row.receivedRaw,isNear?24:m?.decimals??24)} ${isNear?'NEAR / wNEAR':m?.symbol??row.outputToken}`;}
function preference(key:string,fallback:string){try{return localStorage.getItem('gabnear-'+key)||fallback;}catch{return fallback;}}
function formatRaw(raw:string,decimals:number){const digits=raw.padStart(decimals+1,'0');const fraction=decimals?digits.slice(-decimals).replace(/0+$/,''):'';return twoDecimals(decimals?digits.slice(0,-decimals)+(fraction?'.'+fraction:''):digits);}
createRoot(document.getElementById('root')!).render(<App/>);
