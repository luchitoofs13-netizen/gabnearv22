import {useEffect,useRef,useState} from 'react';
import {createChart,createSeriesMarkers,CandlestickSeries,HistogramSeries,ColorType,CrosshairMode,type IChartApi,type ISeriesApi,type ISeriesMarkersPluginApi,type IPriceLine,type SeriesMarker,type Time,type UTCTimestamp} from 'lightweight-charts';
import {api} from '../api';
import {fmtPrice,applyTrade,rawToNumber,TIMEFRAME_SECONDS} from './format';
const FRAMES=['1m','5m','15m','1h','4h','1d'];
const UP='#86fcb5',DOWN='#ff9696';
type Bar={time:number;open:number;high:number;low:number;close:number;volume:number};
const volumeColor=(b:Bar)=>b.close>=b.open?'rgba(134,252,181,.30)':'rgba(255,150,150,.30)';
const pref=(key:string,fallback:string)=>{try{return localStorage.getItem('gabnear-'+key)||fallback;}catch{return fallback;}};

// Velas + volumen (TradingView Lightweight Charts). El histórico viene de GeckoTerminal (o de los swaps si el pool es nuevo)
// y cada swap en vivo actualiza la vela abierta. Si tenés una posición abierta se dibujan entrada, take profit y stop loss.
export function ChartPanel({token,decimals,nearUsd,latest,position,fills=[],quoteSymbol='NEAR'}:{token:string;decimals:number;nearUsd:number|null;latest:any;position:any|null;quoteSymbol?:string;fills?:{ts:number;side:'BUY'|'SELL';near:number}[]}){
 const host=useRef<HTMLDivElement>(null),chartRef=useRef<IChartApi|null>(null),candleSeries=useRef<ISeriesApi<'Candlestick'>|null>(null),volumeSeries=useRef<ISeriesApi<'Histogram'>|null>(null);
 const bars=useRef<Bar[]>([]),lines=useRef<IPriceLine[]>([]),seq=useRef(0),markers=useRef<ISeriesMarkersPluginApi<Time>|null>(null);
 const [tf,setTf]=useState(()=>pref('tf','5m')),[currency,setCurrency]=useState<'usd'|'near'>(()=>pref('currency','usd')==='near'?'near':'usd'),[state,setState]=useState({loading:true,source:'',error:''});
 useEffect(()=>{try{localStorage.setItem('gabnear-tf',tf);localStorage.setItem('gabnear-currency',currency);}catch{/* preferencia opcional */}},[tf,currency]);

 useEffect(()=>{
  if(!host.current)return;
  const chart=createChart(host.current,{autoSize:true,layout:{background:{type:ColorType.Solid,color:'transparent'},textColor:'#9bb3a4',fontFamily:"'IBM Plex Mono',monospace",fontSize:11},grid:{vertLines:{color:'#16241c'},horzLines:{color:'#16241c'}},crosshair:{mode:CrosshairMode.Normal},rightPriceScale:{borderColor:'#26382d',scaleMargins:{top:0.08,bottom:0.22}},timeScale:{borderColor:'#26382d',timeVisible:true,secondsVisible:false,rightOffset:6}});
  const candles=chart.addSeries(CandlestickSeries,{upColor:UP,downColor:DOWN,borderVisible:false,wickUpColor:UP,wickDownColor:DOWN,priceFormat:{type:'custom',minMove:1e-15,formatter:(p:number)=>fmtPrice(p)}});
  const volume=chart.addSeries(HistogramSeries,{priceFormat:{type:'volume'},priceScaleId:'vol',lastValueVisible:false,priceLineVisible:false});
  chart.priceScale('vol').applyOptions({scaleMargins:{top:0.82,bottom:0}});
  chartRef.current=chart;candleSeries.current=candles;volumeSeries.current=volume;markers.current=createSeriesMarkers(candles,[]);
  return()=>{chart.remove();chartRef.current=null;candleSeries.current=null;volumeSeries.current=null;markers.current=null;};
 // El chart se recrea al cambiar de token, timeframe o moneda: vaciar la serie con setData([]) mientras se repinta hace que
 // lightweight-charts lance «Value is null» desde el bucle de dibujo (sin posibilidad de capturarlo).
 },[token,tf,currency]);

 useEffect(()=>{
  let dead=false;const mine=++seq.current;
  setState(s=>({...s,loading:true,error:''}));
  bars.current=[];
  void api(`market/${encodeURIComponent(token)}/candles?tf=${tf}&currency=${currency}`).then(r=>{
   if(dead||mine!==seq.current)return;
   bars.current=r.candles as Bar[];
   candleSeries.current?.setData(bars.current.map(b=>({time:b.time as UTCTimestamp,open:b.open,high:b.high,low:b.low,close:b.close})));
   volumeSeries.current?.setData(bars.current.map(b=>({time:b.time as UTCTimestamp,value:b.volume,color:volumeColor(b)})));
   chartRef.current?.timeScale().fitContent();
   setState({loading:false,source:r.source,error:r.candles.length?'':'Todavía no hay velas para este pool. Aparecen con el primer swap.'});
  }).catch(e=>{if(!dead)setState({loading:false,source:'',error:(e as Error).message});});
  return()=>{dead=true;};
 },[token,tf,currency]);

 // Swap en vivo → actualiza (o abre) la vela del timeframe actual. En USD se convierte con el precio NEAR/USD vigente.
 useEffect(()=>{
  if(!latest||latest.token!==token||latest.priceNear==null||!candleSeries.current)return;
  const mult=currency==='usd'?nearUsd:1;if(!mult)return;
  const bar=applyTrade(bars.current,latest.priceNear*mult,rawToNumber(latest.nearRaw,24)*mult,latest.ts,tf);if(!bar)return;
  candleSeries.current.update({time:bar.time as UTCTimestamp,open:bar.open,high:bar.high,low:bar.low,close:bar.close});
  volumeSeries.current?.update({time:bar.time as UTCTimestamp,value:bar.volume,color:volumeColor(bar)});
 },[latest]);

 // Tus compras (▲ verde) y ventas (▼ rojo) sobre las velas, en la vela del timeframe en que ocurrieron.
 useEffect(()=>{
  const sec=TIMEFRAME_SECONDS[tf]??300;
  const list:SeriesMarker<Time>[]=fills.filter(f=>Number.isFinite(f.ts)).map(f=>({time:(Math.floor(f.ts/1000/sec)*sec) as UTCTimestamp,position:f.side==='BUY'?'belowBar':'aboveBar',shape:f.side==='BUY'?'arrowUp':'arrowDown',color:f.side==='BUY'?UP:DOWN,text:`${f.side==='BUY'?'C':'V'} ${f.near>=100?f.near.toFixed(0):f.near.toFixed(2)}`}));
  list.sort((a,b)=>(a.time as number)-(b.time as number));
  try{markers.current?.setMarkers(list);}catch{/* un marcador inválido no debe romper el chart */}
 },[fills,token,tf,currency,state.loading]);

 // Líneas de la posición abierta: precio de entrada (costo promedio incl. gas), TP y SL en el mismo eje.
 useEffect(()=>{
  const series=candleSeries.current;if(!series)return;
  for(const l of lines.current)series.removePriceLine(l);lines.current=[];
  if(!position||position.status!=='OPEN'||position.token!==token||position.quote?.id!=='wrap.near')return;
  const mult=currency==='usd'?nearUsd:1;if(!mult)return;
  const entry=rawToNumber(position.investedRaw,24)/rawToNumber(position.tokensRaw,position.decimals)*mult;if(!Number.isFinite(entry)||entry<=0)return;
  const add=(price:number,color:string,title:string,dashed=true)=>lines.current.push(series.createPriceLine({price,color,lineWidth:1,lineStyle:dashed?2:0,axisLabelVisible:true,title}));
  add(entry,'#7fb8ff','ENTRADA',false);
  const s=position.settings;
  if(s?.takeProfitPct)add(entry*(1+s.takeProfitPct/100),UP,'TP');
  if(s?.stopLossPct)add(entry*(1-s.stopLossPct/100),DOWN,'SL');
 },[position?.id,position?.investedRaw,position?.tokensRaw,position?.settings?.takeProfitPct,position?.settings?.stopLossPct,position?.status,currency,tf,nearUsd==null,token]);

 return <section className="panel chart-panel">
  <div className="chart-bar">
   <div className="seg">{FRAMES.map(f=><button key={f} className={f===tf?'on':''} onClick={()=>setTf(f)}>{f}</button>)}</div>
   <div className="seg"><button className={currency==='usd'?'on':''} onClick={()=>setCurrency('usd')}>USD</button><button className={currency==='near'?'on':''} onClick={()=>setCurrency('near')}>{quoteSymbol.toUpperCase()}</button></div>
   <span className="chart-src">{state.loading?'cargando velas…':state.source==='geckoterminal'?'velas: GeckoTerminal + swaps en vivo':state.source==='trades'?'velas propias a partir de los swaps (pool nuevo)':''}</span>
  </div>
  <div className="chart-host" ref={host}/>
  {state.error&&<p className="hint chart-note">{state.error}</p>}
 </section>;
}
