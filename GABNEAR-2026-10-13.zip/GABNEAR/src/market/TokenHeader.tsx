import {useEffect,useState} from 'react';
import {fmtPrice,fmtUsd,fmtCompact,fmtPct,timeAgo,shortAccount} from './format';
const venue=(v?:string)=>v==='REF_V1'?'Ref v1':v==='DCL'?'Rhea DCL':'—';
const Change=({label,value}:{label:string;value:number|null|undefined})=><span className={'chg '+(value==null?'':value>=0?'up':'down')}><small>{label}</small>{fmtPct(value)}</span>;
function Stat({label,value,sub,tone,hint}:{label:string;value:React.ReactNode;sub?:React.ReactNode;tone?:'warn'|'bad';hint?:string}){return <div className={'stat '+(tone??'')} title={hint}><small>{label}</small><strong>{value}</strong>{sub!==undefined&&<span>{sub}</span>}</div>;}

// Datos importantes del token. El precio, el market cap y la liquidez salen on-chain (cotización y reservas de los pools);
// volumen, txns y antigüedad vienen de DexScreener y los holders de FastNEAR. Si una fuente falla, ese dato aparece como «—».
export function TokenHeader({token,snapshot,error,live,lastTradeAt}:{token:string;snapshot:any;error:string;live:boolean;lastTradeAt:number}){
 const [now,setNow]=useState(Date.now());
 useEffect(()=>{const t=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(t);},[]);
 const [copied,setCopied]=useState(false);
 const s=snapshot,st=s?.stats,h=s?.holders;
 const buys=st?.txns?.h24?.buys,sells=st?.txns?.h24?.sells,total=(buys??0)+(sells??0);
 const fresh=s&&now-s.fetchedAt<12000;
 function copy(){void navigator.clipboard?.writeText(token).then(()=>{setCopied(true);setTimeout(()=>setCopied(false),1200);}).catch(()=>{});}
 if(!s)return <section className="panel token-header skeleton"><div className="th-top"><div><div className="th-name">{token}</div><p className="hint">{error?`No se pudieron cargar los datos de mercado: ${error}`:'Cargando precio, market cap y liquidez…'}</p></div></div></section>;
 return <section className="panel token-header">
  <div className="th-top">
   <div className="th-id">
    <div className="th-name"><b>{s.name}</b> <span className="green">${s.symbol}</span> <span className="tag">{s.launchpad??(s.generic?'TOKEN GENÉRICO':'NEARLY')}</span>{s.quote&&!s.quote.isNear&&<span className="tag warn" title={`Se compra y vende contra ${s.quote.symbol} (${s.quote.id}), no contra NEAR`}>PAR {s.quote.symbol}</span>}</div>
    <button className="copy mono" onClick={copy} title="Copiar contrato">{copied?'¡copiado!':shortAccount(token)} ⧉</button>
   </div>
   <div className="th-price" title="Precio spot on-chain del pool (sin comisión). DexScreener y el chart muestran el precio del último swap, que ya incluye la comisión del pool (~1%) y salta a un lado u otro según sea compra o venta."><strong>${fmtPrice(s.priceUsd)}</strong><span>{s.quote&&!s.quote.isNear?`${fmtPrice(s.priceQuote)} ${s.quote.symbol}`:`${fmtPrice(s.priceNear)} NEAR`}</span></div>
   <div className="th-changes"><Change label="5m" value={st?.priceChange?.m5}/><Change label="1h" value={st?.priceChange?.h1}/><Change label="6h" value={st?.priceChange?.h6}/><Change label="24h" value={st?.priceChange?.h24}/></div>
   <div className="th-live"><span className={'dot '+(live&&lastTradeAt&&now-lastTradeAt<120000?'on':live?'idle':'off')}/>{live?(lastTradeAt?`último swap hace ${timeAgo(lastTradeAt,now)}`:'en vivo · esperando swaps'):'sin conexión en vivo'}<small className={fresh?'':'stale'}>{fresh?'datos al día':'actualizando…'}</small></div>
  </div>
  <div className="th-stats">
   <Stat label="MARKET CAP" hint="Supply total on-chain × precio spot. DexScreener calcula su MC y su FDV con otro supply, por eso puede diferir unos puntos." value={fmtUsd(s.marketCapUsd)} sub={`${fmtCompact(s.marketCapNear)} NEAR · supply ${fmtCompact(s.supplyTokens)}`}/>
   <Stat label="LIQUIDEZ" hint={`Reservas de los pools leídas de la cadena (wNEAR + tokens al precio actual). DexScreener muestra ${fmtUsd(st?.liquidityUsd)}; una diferencia de ~2-3% es normal.`} value={fmtUsd(s.liquidityUsd)} sub={`${fmtCompact(s.liquidityNear)} NEAR · ${s.pools.length} pool${s.pools.length===1?'':'s'}`} tone={s.liquidityNear!==null&&s.liquidityNear<5?'bad':undefined}/>
   <Stat label="VOLUMEN 24h" hint="Volumen del pool principal según DexScreener." value={fmtUsd(st?.volumeUsd?.h24)} sub={`1h ${fmtUsd(st?.volumeUsd?.h1)}`}/>
   <Stat label="TXNS 24h" hint="Swaps de 24 h del pool principal según DexScreener (mismo número que ves en su página)." value={total?total.toLocaleString('en-US'):'—'} sub={total?<><b className="green">{buys} compras</b> · <b className="red">{sells} ventas</b></>:undefined}/>
   <Stat label="TOP HOLDER" hint="Porcentaje del supply que tiene el mayor holder real (sin contar contratos de pools). Alto = riesgo de venta masiva." value={h?.topHolderPct!=null?`${h.topHolderPct}%`:'—'} sub={h?`top 10: ${h.top10Pct}%${h.inPoolsPct?` · pools ${h.inPoolsPct}%`:''}`:undefined} tone={h?.topHolderPct>=30?'bad':h?.top10Pct>=70?'warn':undefined}/>
   <Stat label="ANTIGÜEDAD" hint="Desde que se creó el pool principal (dato de DexScreener)." value={timeAgo(st?.pairCreatedAt)} sub={`${venue(s.route?.venue)}${s.route?` · fee ${(s.route.fee/100).toFixed(2)}%`:''}${s.quote&&!s.quote.isNear?` · par ${s.quote.symbol}`:''}${s.tax?` · imp. ${s.tax.buyBps/100}/${s.tax.sellBps/100}%`:''}`}/>
  </div>
  {total>0&&<div className="pressure" title={`${buys} compras vs ${sells} ventas en 24 h`}><i style={{width:`${(buys/total)*100}%`}}/></div>}
  {s.warnings.length>0&&<div className="warnings">{s.warnings.map((w:string)=><p key={w}>⚠ {w}</p>)}</div>}
  <div className="th-links">
   {st?.url&&<a target="_blank" rel="noreferrer" href={st.url}>DexScreener ↗</a>}
   <a target="_blank" rel="noreferrer" href={'https://nearblocks.io/token/'+token}>Nearblocks ↗</a>
   {s.launchpad==='Nearly'&&<a target="_blank" rel="noreferrer" href={'https://nearly.trade/'+token}>Nearly ↗</a>}
   <span className="src" title="Estado de cada fuente de datos">fuentes: cadena {s.sources.onchain} · dexscreener {s.sources.dexscreener} · holders {s.sources.holders}</span>
  </div>
 </section>;
}
