import {useEffect,useMemo,useState} from 'react';
import {fmtPrice,fmtUsd,shortAccount,rawToNumber,timeAgo} from './format';
const clock=(ms:number)=>new Date(ms).toLocaleString('es-AR',{hour12:false});
const BIG_NEAR=25;   // desde este tamaño el swap se marca como «grande»
const amount=(n:number)=>n>=1000?Math.round(n).toLocaleString('en-US'):n>=100?n.toFixed(1):n>=1?n.toFixed(2):n>=0.01?n.toFixed(3):n.toFixed(4);
const tokenAmount=(n:number)=>n>=1000?Math.round(n).toLocaleString('en-US'):n>=1?n.toFixed(2):n.toPrecision(3);

// Swaps del token en tiempo real (Intear + historial reciente). Tus propios swaps se resaltan.
// Las clases de fila son t-buy / t-sell: «.sell» ya es el botón VENDER y pintaba las filas enteras de rosa.
export function TradesFeed({trades,decimals,symbol,nearUsd,live,me}:{trades:any[];decimals:number;symbol:string;nearUsd:number|null;live:boolean;me:string}){
 const [side,setSide]=useState<'ALL'|'BUY'|'SELL'|'MINE'>('ALL'),[min,setMin]=useState(''),[paused,setPaused]=useState(false),[frozen,setFrozen]=useState<any[]>([]),[now,setNow]=useState(Date.now());
 useEffect(()=>{if(paused)setFrozen(trades);},[paused]);
 useEffect(()=>{const t=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(t);},[]);
 const rows=useMemo(()=>{
  const source=paused?frozen:trades,minNear=Number(min)||0;
  return source.filter(t=>(side==='ALL'||(side==='MINE'?!!me&&t.trader===me:t.side===side))&&rawToNumber(t.nearRaw,24)>=minNear).slice(0,80);
 },[trades,frozen,paused,side,min,me]);
 const biggest=useMemo(()=>rows.reduce((m,t)=>Math.max(m,rawToNumber(t.nearRaw,24)),0),[rows]);
 // Presión de compra/venta de los últimos 60 swaps, por volumen en NEAR.
 const pressure=useMemo(()=>{let b=0,s=0;for(const t of trades.slice(0,60)){const n=rawToNumber(t.nearRaw,24);if(t.side==='BUY')b+=n;else s+=n;}return {b,s,pct:b+s>0?b/(b+s)*100:50};},[trades]);
 const mineCount=useMemo(()=>me?trades.filter(t=>t.trader===me).length:0,[trades,me]);
 return <section className="panel trades-feed">
  <div className="feed-bar">
   <div className="seg">{(['ALL','BUY','SELL','MINE'] as const).map(s=><button key={s} className={s===side?'on':''} onClick={()=>setSide(s)}>{s==='ALL'?'TODOS':s==='BUY'?'COMPRAS':s==='SELL'?'VENTAS':`MÍOS${mineCount?` ${mineCount}`:''}`}</button>)}</div>
   <label className="inline">mín. NEAR<input type="number" min="0" step="any" value={min} onChange={e=>setMin(e.target.value)} placeholder="0"/></label>
   <button className={'outline mini'+(paused?' on':'')} onClick={()=>setPaused(p=>!p)}>{paused?'▶ REANUDAR':'❚❚ PAUSAR'}</button>
   <span className="feed-live"><span className={'dot '+(live?'on':'off')}/>{live?'EN VIVO':'sin conexión'}</span>
  </div>
  <div className="pressure big" title={`Últimos 60 swaps: ${pressure.b.toFixed(2)} NEAR comprados vs ${pressure.s.toFixed(2)} vendidos`}><i style={{width:`${pressure.pct}%`}}/><span>{pressure.b.toFixed(1)} NEAR en compras</span><span>{pressure.s.toFixed(1)} NEAR en ventas</span></div>
  <div className="table-wrap"><table className="trades">
   <thead><tr><th>Hace</th><th>Tipo</th><th>USD</th><th>NEAR</th><th>{symbol}</th><th title="Precio efectivo del swap, con comisión del pool incluida">Precio</th><th>Trader</th><th/></tr></thead>
   <tbody>{rows.length===0?<tr className="empty"><td colSpan={8}>{side==='MINE'?'Todavía no hay swaps tuyos en este token.':live?'Esperando swaps de este token…':'Sin conexión con el stream en vivo.'}</td></tr>:rows.map(t=>{
    const near=rawToNumber(t.nearRaw,24),tokens=rawToNumber(t.tokenRaw,decimals),mine=!!me&&t.trader===me,buy=t.side==='BUY',bar=biggest>0?Math.max(4,near/biggest*100):0;
    return <tr key={t.tx} className={'tr '+(buy?'t-buy':'t-sell')+(mine?' t-mine':'')+(near>=BIG_NEAR?' t-big':'')+(t.fresh&&!paused?' fresh':'')}>
     <td className="mono time" title={clock(t.ts)}>{timeAgo(t.ts,now)}</td>
     <td><b className="side">{buy?'COMPRA':'VENTA'}</b></td>
     <td className="mono">{nearUsd?fmtUsd(near*nearUsd):'—'}</td>
     <td className="mono size"><i style={{width:`${bar}%`}}/><span>{amount(near)}</span></td>
     <td className="mono">{tokenAmount(tokens)}</td>
     <td className="mono" title={`${fmtPrice(t.priceNear)} NEAR`}>{nearUsd&&t.priceNear?'$'+fmtPrice(t.priceNear*nearUsd):fmtPrice(t.priceNear)}</td>
     <td className="mono who" title={t.trader}>{mine?<b className="me">TÚ</b>:shortAccount(t.trader)}</td>
     <td><a target="_blank" rel="noreferrer" href={'https://nearblocks.io/txns/'+t.tx} aria-label="Ver transacción">↗</a></td></tr>;})}</tbody>
  </table></div>
 </section>;
}
