// Alertas de precio (se guardan en este navegador). Una alerta avisa UNA vez cuando el precio en USD cruza el nivel y se borra sola.
export type PriceAlert={id:string;token:string;symbol:string;direction:'above'|'below';price:number;createdAt:number};
type Store=Pick<Storage,'getItem'|'setItem'>;
const KEY='gabnear-alerts',MAX_ALERTS=20;

export function parseAlerts(raw:string|null):PriceAlert[]{
 try{
  const list=JSON.parse(raw??'[]');if(!Array.isArray(list))return [];
  return list.filter((a:any)=>a&&typeof a.id==='string'&&typeof a.token==='string'&&(a.direction==='above'||a.direction==='below')&&Number.isFinite(a.price)&&a.price>0).slice(0,MAX_ALERTS).map((a:any)=>({id:a.id,token:a.token,symbol:String(a.symbol??''),direction:a.direction,price:Number(a.price),createdAt:Number(a.createdAt)||0}));
 }catch{return [];}
}
export function loadAlerts(store:Store|undefined=globalThis.localStorage):PriceAlert[]{try{return parseAlerts(store?.getItem(KEY)??null);}catch{return [];}}
export function saveAlerts(list:PriceAlert[],store:Store|undefined=globalThis.localStorage){try{store?.setItem(KEY,JSON.stringify(list.slice(0,MAX_ALERTS)));}catch{/* sin almacenamiento: las alertas viven solo en esta sesión */}}

export function addAlert(list:PriceAlert[],input:{token:string;symbol:string;direction:'above'|'below';price:number},now=Date.now(),id=`${now}-${Math.random().toString(36).slice(2,8)}`):PriceAlert[]{
 if(!Number.isFinite(input.price)||input.price<=0)throw new Error('Poné un precio mayor que cero.');
 if(list.length>=MAX_ALERTS)throw new Error(`Máximo ${MAX_ALERTS} alertas: borrá alguna.`);
 if(list.some(a=>a.token===input.token&&a.direction===input.direction&&a.price===input.price))throw new Error('Ya tenés esa alerta.');
 return [...list,{id,token:input.token,symbol:input.symbol,direction:input.direction,price:input.price,createdAt:now}];
}
const crossed=(a:PriceAlert,priceUsd:number)=>a.direction==='above'?priceUsd>=a.price:priceUsd<=a.price;
// Separa las alertas del token que ya se cumplieron (a disparar) del resto. Un precio ilegible jamás dispara.
export function checkAlerts(list:PriceAlert[],token:string,priceUsd:number|null|undefined){
 if(typeof priceUsd!=='number'||!Number.isFinite(priceUsd)||priceUsd<=0)return {triggered:[] as PriceAlert[],remaining:list};
 const triggered=list.filter(a=>a.token===token&&crossed(a,priceUsd));
 return {triggered,remaining:triggered.length?list.filter(a=>!triggered.includes(a)):list};
}
