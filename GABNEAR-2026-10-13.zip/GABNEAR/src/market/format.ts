// Formato de números de mercado. Los precios de memecoins llegan a 1e-12: se muestran con cifras significativas, no con decimales fijos.
export function fmtPrice(n?:number|null):string{
 if(n===null||n===undefined||!Number.isFinite(n))return '—';
 if(n===0)return '0';
 const abs=Math.abs(n);
 if(abs>=1000)return n.toLocaleString('en-US',{maximumFractionDigits:0});
 if(abs>=1)return n.toFixed(4).replace(/\.?0+$/,'');
 // 0.000003895 → 0.000003895 (4 cifras significativas) sin notación científica
 const decimals=Math.min(18,Math.max(2,3-Math.floor(Math.log10(abs))));
 return n.toFixed(decimals).replace(/0+$/,'');
}
export function fmtCompact(n?:number|null,prefix=''):string{
 if(n===null||n===undefined||!Number.isFinite(n))return '—';
 const abs=Math.abs(n);
 const units:[number,string][]=[[1e12,'T'],[1e9,'B'],[1e6,'M'],[1e3,'K']];
 for(const [v,s] of units)if(abs>=v)return `${prefix}${(n/v).toFixed(abs>=v*100?0:abs>=v*10?1:2)}${s}`;
 return `${prefix}${abs>=100?n.toFixed(0):abs>=1?n.toFixed(2):n.toFixed(4)}`;
}
export const fmtUsd=(n?:number|null)=>fmtCompact(n,'$');
export function fmtPct(n?:number|null,digits=1):string{
 if(n===null||n===undefined||!Number.isFinite(n))return '—';
 return `${n>0?'+':''}${n.toFixed(digits)}%`;
}
export function timeAgo(ms?:number|null,now=Date.now()):string{
 if(!ms)return '—';
 const s=Math.max(0,Math.floor((now-ms)/1000));
 if(s<60)return `${s}s`;if(s<3600)return `${Math.floor(s/60)}m`;if(s<86400)return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m`;
 return `${Math.floor(s/86400)}d`;
}
export const shortAccount=(a?:string)=>!a?'—':a.length>20?`${a.slice(0,8)}…${a.slice(-6)}`:a;
// raw (entero como texto) → número con decimales
export function rawToNumber(raw:string|number|null|undefined,decimals:number):number{
 if(raw===null||raw===undefined)return NaN;
 const s=String(raw);if(!/^\d+$/.test(s))return NaN;
 if(s.length<=15)return Number(s)/10**decimals;
 const cut=s.length-15;return Number(s.slice(0,15))*10**(cut-decimals);
}
export const TIMEFRAME_SECONDS:Record<string,number>={'1m':60,'5m':300,'15m':900,'1h':3600,'4h':14400,'1d':86400};
// Aplica un swap en vivo a la última vela (o abre una nueva). Devuelve la vela modificada.
export function applyTrade(candles:{time:number;open:number;high:number;low:number;close:number;volume:number}[],price:number,volume:number,tsMs:number,tf:string){
 const sec=TIMEFRAME_SECONDS[tf]??300,time=Math.floor(tsMs/1000/sec)*sec,last=candles[candles.length-1];
 if(last&&time<last.time)return null;                                       // un swap más viejo que la vela abierta no la modifica
 if(last&&last.time===time){last.high=Math.max(last.high,price);last.low=Math.min(last.low,price);last.close=price;last.volume+=volume;return last;}
 const open=last?.close??price,bar={time,open,high:Math.max(open,price),low:Math.min(open,price),close:price,volume};
 candles.push(bar);return bar;
}
