import {useEffect,useState} from 'react';
import {api} from '../api';
// Snapshot de mercado (precio, market cap, liquidez, volumen, holders): se refresca cada 5 s mientras haya un token activo.
export function useMarket(token:string|null){
 const [snapshot,setSnapshot]=useState<any>(null),[error,setError]=useState('');
 useEffect(()=>{
  setSnapshot(null);setError('');if(!token)return;
  let dead=false;
  const load=async()=>{try{const s=await api('market/'+encodeURIComponent(token));if(!dead){setSnapshot(s);setError('');}}catch(e){if(!dead)setError((e as Error).message);}};
  void load();const timer=setInterval(load,5000);
  return()=>{dead=true;clearInterval(timer);};
 },[token]);
 return {snapshot,error};
}
const mergeTrades=(a:any[],b:any[],limit=150)=>{const by=new Map<string,any>();for(const t of [...b,...a])by.set(t.tx,{...by.get(t.tx),...t});return [...by.values()].sort((x,y)=>y.ts-x.ts).slice(0,limit);};
// Swaps en vivo del token (SSE → un único WebSocket de Intear en el servidor) + historial reciente + lanzamientos nuevos.
export function useStream(token:string|null){
 const [trades,setTrades]=useState<any[]>([]),[launches,setLaunches]=useState<any[]>([]),[live,setLive]=useState(false),[latest,setLatest]=useState<any>(null),[lastTradeAt,setLastTradeAt]=useState(0);
 useEffect(()=>{
  setTrades([]);setLatest(null);setLastTradeAt(0);
  let dead=false;
  const es=new EventSource('/api/stream'+(token?'?token='+encodeURIComponent(token):''));
  es.addEventListener('ready',()=>setLive(true));
  es.addEventListener('trade',(ev:MessageEvent)=>{const t=JSON.parse(ev.data);setTrades(old=>mergeTrades(old,[{...t,fresh:true}]));setLatest(t);setLastTradeAt(Date.now());});
  es.addEventListener('launch',(ev:MessageEvent)=>{const l=JSON.parse(ev.data);setLaunches(old=>[l,...old.filter(x=>x.token!==l.token)].slice(0,60));});
  es.onerror=()=>setLive(false);
  if(token)void api(`market/${encodeURIComponent(token)}/trades?limit=80`).then(rows=>{if(!dead)setTrades(old=>mergeTrades(old,rows));}).catch(()=>{});
  void api('launches').then(rows=>{if(!dead)setLaunches(old=>{const by=new Map<string,any>();for(const l of [...old,...rows])by.set(l.token,l);return [...by.values()].sort((a:any,b:any)=>b.ts-a.ts).slice(0,60);});}).catch(()=>{});
  return()=>{dead=true;es.close();};
 },[token]);
 return {trades,launches,live,latest,lastTradeAt};
}
