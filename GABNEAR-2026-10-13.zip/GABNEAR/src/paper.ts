// Posiciones SIMULADAS (DRY RUN): al «comprar» en simulación se anota lo que habrías recibido y se valúa con el precio real del mercado, para ver
// cuánto estarías ganando o perdiendo sin gastar nada. Viven solo en este navegador. Las posiciones REALES salen del servidor (AUTO SELL).
export type Paper={id:string;token:string;symbol:string;at:number;spendNear:number;tokens:number;realizedNear:number;feeBps:number};
type Store=Pick<Storage,'getItem'|'setItem'>;
const KEY='gabnear-paper',MAX=20;

export function parsePaper(raw:string|null):Paper[]{
 try{
  const l=JSON.parse(raw??'[]');if(!Array.isArray(l))return [];
  return l.filter((p:any)=>p&&typeof p.token==='string'&&Number.isFinite(p.spendNear)&&p.spendNear>0&&Number.isFinite(p.tokens)&&p.tokens>0).slice(0,MAX)
   .map((p:any)=>({id:String(p.id??p.token),token:p.token,symbol:String(p.symbol??''),at:Number(p.at)||0,spendNear:Number(p.spendNear),tokens:Number(p.tokens),realizedNear:Number.isFinite(p.realizedNear)?Number(p.realizedNear):0,feeBps:Number.isFinite(p.feeBps)&&p.feeBps>=0&&p.feeBps<=5000?Number(p.feeBps):100}));
 }catch{return [];}
}
export const loadPaper=(store:Store|undefined=globalThis.localStorage):Paper[]=>{try{return parsePaper(store?.getItem(KEY)??null);}catch{return [];}};
export const savePaper=(list:Paper[],store:Store|undefined=globalThis.localStorage)=>{try{store?.setItem(KEY,JSON.stringify(list.slice(0,MAX)));}catch{/* sin almacenamiento */}};

// Una compra simulada. Si ya había una posición del mismo token se suma (costo y tokens): el precio de entrada queda promediado.
export function openPaper(list:Paper[],buy:{token:string;symbol:string;spendNear:number;tokens:number;feeBps?:number},now=Date.now(),id=`${now}-${buy.token}`):Paper[]{
 if(!(buy.spendNear>0)||!(buy.tokens>0)||!Number.isFinite(buy.spendNear)||!Number.isFinite(buy.tokens))return list;
 const feeBps=buy.feeBps??100,cur=list.find(p=>p.token===buy.token);
 if(cur)return list.map(p=>p===cur?{...p,spendNear:p.spendNear+buy.spendNear,tokens:p.tokens+buy.tokens,feeBps}:p);
 return [{id,token:buy.token,symbol:buy.symbol,at:now,spendNear:buy.spendNear,tokens:buy.tokens,realizedNear:0,feeBps},...list].slice(0,MAX);
}
// Valor de salida estimado: precio spot menos la comisión del pool (lo que de verdad cobrarías al vender). La compra ya incluye su comisión e impacto.
export function valuePaper(p:Paper,priceNear:number|null|undefined,nearUsd:number|null|undefined){
 const ok=typeof priceNear==='number'&&Number.isFinite(priceNear)&&priceNear>0;
 const valueNear=ok?p.tokens*priceNear*(1-p.feeBps/10000):null;
 const pnlNear=valueNear===null?null:valueNear-p.spendNear;
 const usd=(n:number|null)=>n===null||typeof nearUsd!=='number'||!Number.isFinite(nearUsd)?null:n*nearUsd;
 return {costNear:p.spendNear,valueNear,pnlNear,pnlPct:pnlNear===null?null:pnlNear/p.spendNear*100,costUsd:usd(p.spendNear),valueUsd:usd(valueNear),pnlUsd:usd(pnlNear),realizedUsd:usd(p.realizedNear),realizedNear:p.realizedNear};
}
// Vende `pct` % de lo que queda (simulado). Devuelve la lista nueva y lo «cobrado» en NEAR; la posición se cierra al quedar sin tokens.
export function sellPaper(list:Paper[],token:string,pct:number,priceNear:number|null|undefined):{list:Paper[];receivedNear:number}|null{
 const p=list.find(x=>x.token===token);
 if(!p||!Number.isFinite(pct)||pct<=0||pct>100||typeof priceNear!=='number'||!Number.isFinite(priceNear)||priceNear<=0)return null;
 const f=pct/100,soldTokens=p.tokens*f,receivedNear=soldTokens*priceNear*(1-p.feeBps/10000),costSold=p.spendNear*f;
 const left=p.tokens-soldTokens;
 if(pct>=100||left<=1e-12)return {list:list.filter(x=>x!==p),receivedNear};
 return {list:list.map(x=>x===p?{...x,tokens:left,spendNear:p.spendNear-costSold,realizedNear:p.realizedNear+receivedNear-costSold}:x),receivedNear};
}
export function totalPaper(list:Paper[],prices:Record<string,number|null|undefined>,nearUsd:number|null|undefined){
 let pnlUsd=0,costUsd=0,known=false;
 for(const p of list){const v=valuePaper(p,prices[p.token],nearUsd);if(v.pnlUsd!==null&&v.costUsd!==null){pnlUsd+=v.pnlUsd;costUsd+=v.costUsd;known=true;}}
 return {open:list.length,pnlUsd:known?pnlUsd:null,pct:known&&costUsd>0?pnlUsd/costUsd*100:null};
}
