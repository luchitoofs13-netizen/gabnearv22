// Cálculos de la pantalla de operar (puros, con prueba): conversión a dólares, salud del pool y resumen de P/L de una posición.
export const usdOf=(amount:number,usdPerUnit:number|null|undefined):number|null=>
 typeof usdPerUnit==='number'&&Number.isFinite(usdPerUnit)&&Number.isFinite(amount)?amount*usdPerUnit:null;
export function money(n:number|null|undefined,signed=false):string{
 if(n===null||n===undefined||!Number.isFinite(n))return '—';
 const abs=Math.abs(n),sign=n<0?'−':signed&&n>0?'+':'';
 const body=abs>=1000?abs.toLocaleString('en-US',{maximumFractionDigits:0}):abs>=1?abs.toFixed(2):abs>=0.01?abs.toFixed(3):abs===0?'0.00':abs.toPrecision(2);
 return `${sign}$${body}`;
}
export type PoolHealth={level:'ok'|'warn'|'bad';text:string};
// Avisa si el pool es chico o si la compra lo mueve mucho. Umbrales prudentes para tokens nuevos: no son una garantía.
export function poolHealth(liquidityUsd:number|null|undefined,impactBps:number|null|undefined,spendUsd:number|null=null):PoolHealth{
 const notes:string[]=[];let level:PoolHealth['level']='ok';
 const raise=(l:PoolHealth['level'])=>{if(l==='bad'||(l==='warn'&&level==='ok'))level=l;};
 if(typeof liquidityUsd==='number'&&Number.isFinite(liquidityUsd)){
  if(liquidityUsd<3000){raise('bad');notes.push(`pool muy chico (${money(liquidityUsd)})`);}
  else if(liquidityUsd<15000){raise('warn');notes.push(`pool chico (${money(liquidityUsd)})`);}
  if(spendUsd!==null&&liquidityUsd>0&&spendUsd/liquidityUsd>0.05){raise('bad');notes.push(`tu compra es ${(spendUsd/liquidityUsd*100).toFixed(0)}% del pool`);}
 }
 if(typeof impactBps==='number'&&Number.isFinite(impactBps)){
  if(impactBps>=500){raise('bad');notes.push(`mueve el precio ${(impactBps/100).toFixed(1)}%`);}
  else if(impactBps>=150){raise('warn');notes.push(`mueve el precio ${(impactBps/100).toFixed(1)}%`);}
 }
 return {level,text:notes.length?notes.join(' · '):'pool con liquidez razonable para este importe'};
}
export type PnlSummary={open:boolean;costUsd:number|null;valueUsd:number|null;pnlUsd:number|null;pnlPct:number|null;realizedUsd:number|null;totalUsd:number|null};
// Resume una posición (vista del servidor) en dólares. P/L abierto = valor de salida neto − costo; total = abierto + realizado.
export function pnlSummary(p:any):PnlSummary|null{
 const v=p?.view;if(!v)return null;
 const u=v.usd??{},open=p.status==='OPEN';
 const costUsd=u.invested??null,valueUsd=u.net??u.exitValue??null,pnlUsd=open?(u.unrealized??null):0,realizedUsd=u.realized??null;
 const pnlPct=open&&typeof v.pnlPct==='number'?v.pnlPct:null;
 const totalUsd=pnlUsd!==null||realizedUsd!==null?(pnlUsd??0)+(realizedUsd??0):null;
 return {open,costUsd,valueUsd,pnlUsd,pnlPct,realizedUsd,totalUsd};
}
export function totalPnl(positions:any[]){
 let open=0,unrealized=0,realized=0,invested=0,known=false;
 for(const p of positions){
  const s=pnlSummary(p);if(!s)continue;
  if(s.open)open++;
  if(s.pnlUsd!==null&&s.open){unrealized+=s.pnlUsd;known=true;}
  if(s.realizedUsd!==null){realized+=s.realizedUsd;known=true;}
  if(s.open&&s.costUsd!==null)invested+=s.costUsd;
 }
 return {open,unrealized,realized,total:known?unrealized+realized:null,pct:invested>0&&known?unrealized/invested*100:null};
}
