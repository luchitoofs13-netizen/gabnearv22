import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseAlerts,loadAlerts,saveAlerts,addAlert,checkAlerts,type PriceAlert} from '../src/market/alerts.js';

const T='ninu-4.nearlytrade.near';
const mem=()=>{const m=new Map<string,string>();return {getItem:(k:string)=>m.get(k)??null,setItem:(k:string,v:string)=>{m.set(k,v);},m};};

test('alertas: agregar valida precio, duplicados y máximo',()=>{
 let list:PriceAlert[]=[];
 list=addAlert(list,{token:T,symbol:'NINU',direction:'above',price:0.0003},1,'a');assert.equal(list.length,1);assert.equal(list[0].id,'a');
 for(const bad of [0,-1,NaN,Infinity])assert.throws(()=>addAlert(list,{token:T,symbol:'N',direction:'above',price:bad}),/mayor que cero|./);
 assert.throws(()=>addAlert(list,{token:T,symbol:'NINU',direction:'above',price:0.0003}),/Ya tenés/);
 list=addAlert(list,{token:T,symbol:'NINU',direction:'below',price:0.0003},2,'b');assert.equal(list.length,2);
 for(let i=0;i<18;i++)list=addAlert(list,{token:T,symbol:'N',direction:'above',price:1+i},3,'x'+i);
 assert.throws(()=>addAlert(list,{token:T,symbol:'N',direction:'above',price:99}),/Máximo 20/);
});
test('checkAlerts: cruce hacia arriba / abajo, solo del token pedido, una sola vez; un precio inválido no dispara',()=>{
 const list:PriceAlert[]=[{id:'1',token:T,symbol:'N',direction:'above',price:0.0003,createdAt:0},{id:'2',token:T,symbol:'N',direction:'below',price:0.0002,createdAt:0},{id:'3',token:'otro.near',symbol:'O',direction:'above',price:0.0001,createdAt:0}];
 let r=checkAlerts(list,T,0.00025);assert.equal(r.triggered.length,0);assert.equal(r.remaining.length,3);
 r=checkAlerts(list,T,0.0003);assert.deepEqual(r.triggered.map(a=>a.id),['1']);assert.deepEqual(r.remaining.map(a=>a.id),['2','3']);          // justo en el nivel dispara; la de otro token queda
 r=checkAlerts(list,T,0.0002);assert.deepEqual(r.triggered.map(a=>a.id),['2']);
 for(const bad of [null,undefined,NaN,0,-5,Infinity])assert.equal(checkAlerts(list,T,bad as any).triggered.length,0,String(bad));
 assert.equal(checkAlerts(checkAlerts(list,T,0.0004).remaining,T,0.0004).triggered.length,0);                                              // ya no vuelve a disparar
});
test('almacenamiento: persiste, descarta basura y tolera storage roto o ausente',()=>{
 const s=mem();saveAlerts([{id:'1',token:T,symbol:'N',direction:'above',price:2,createdAt:1}],s);assert.equal(loadAlerts(s).length,1);
 for(const raw of ['no json','{"a":1}','[1,null,{"id":1}]','[{"id":"x","token":"t","direction":"sideways","price":1}]','[{"id":"x","token":"t","direction":"above","price":-1}]'])assert.deepEqual(parseAlerts(raw),[]);
 assert.equal(parseAlerts(JSON.stringify(Array.from({length:50},(_,i)=>({id:'i'+i,token:T,symbol:'N',direction:'above',price:i+1})))).length,20);
 assert.deepEqual(loadAlerts({getItem:()=>{throw new Error('bloqueado');},setItem:()=>{}} as any),[]);assert.doesNotThrow(()=>saveAlerts([],{getItem:()=>null,setItem:()=>{throw new Error('lleno');}}));
 assert.deepEqual(loadAlerts(undefined as any),[]);
});
