import {test} from 'node:test';
import assert from 'node:assert/strict';
import {bridgeToQuote,setLiveSession} from '../server/trading.js';
import {bridgeRecord,type BridgePlan} from '../server/bridge.js';
import {dclRoute} from '../server/venues.js';
import {units,display} from '../server/validation.js';
import {limitsSummary,spentLast24h} from '../server/limits.js';

const ME='me.near',W='wrap.near',DCL='dclv2.ref-labs.near',RHEA='token.rhealab.near';
const asset={id:RHEA,name:'Rhea',symbol:'RHEA',decimals:18};
const OK={final_execution_status:'FINAL',status:{SuccessValue:''},transaction_outcome:{outcome:{status:{SuccessValue:''},tokens_burnt:'0'}},receipts_outcome:[]};
const route=dclRoute(RHEA,W,10000);
const plan=(inNear='2'):BridgePlan=>({asset,route,inRaw:units(inNear),expectedRaw:units('50',18),minRaw:units('48',18),risk:{impactBps:10,roundTripLossBps:null,blocked:null,warnings:[]} as any,venue:'DCL',poolId:route.poolId,feeBps:100});

function world(o:{refund?:boolean;wnear?:bigint;native?:bigint;confirm?:string}={}){
 process.env.BOT_ACCOUNT_ID=ME;
 let wnear=o.wnear??0n,rhea=0n;const calls:any[]=[],rows:any[]=[{id:'op',bridge:bridgeRecord(plan())}];
 const rpc:any={account:async()=>({amount:(o.native??units('10')).toString(),storage_usage:100}),
  view:async(c:string,m:string)=>{
   if(m==='ft_balance_of')return (c===W?wnear:rhea).toString();
   if(m==='storage_balance_of')return {total:'1',available:'0'};                          // ya registrado
   if(m==='quote')return {amount:units('50',18).toString()};
   throw new Error('mock '+c+'.'+m);
  }};
 const ex:any={rpc,history:{rows,update:(_id:string,p:any)=>Object.assign(rows[0],p)},exclusive:async(fn:()=>Promise<any>)=>fn(),
  call:async(_id:string,contract:string,method:string,args:any,deposit:bigint)=>{
   calls.push({contract,method,args,deposit});
   if(method==='near_deposit')wnear+=deposit;
   if(method==='ft_transfer_call'&&!o.refund){wnear-=BigInt(args.amount);rhea+=units('50',18);}
   const used=method==='ft_transfer_call'?(o.refund?'0':args.amount):null;
   return {...OK,final_execution_status:o.confirm??'FINAL',...(used===null?{}:{status:{SuccessValue:Buffer.from(JSON.stringify(used)).toString('base64')}})};
  }};
 return {ex,calls,rows};
}

test('puente NEAR → RHEA: envuelve NEAR, cambia en el pool contra wNEAR con mínimo y devuelve lo recibido medido por saldo',async()=>{
 setLiveSession(true);const w=world();
 const got=await bridgeToQuote(w.ex,'op',plan(),300);
 assert.equal(got,units('50',18));
 assert.deepEqual(w.calls.map(c=>c.method),['near_deposit','ft_transfer_call']);
 assert.equal(w.calls[0].contract,W);assert.equal(w.calls[0].deposit,units('2'));                                  // envuelve exactamente lo que hace falta
 const swap=w.calls[1];assert.equal(swap.contract,W);assert.equal(swap.args.receiver_id,DCL);assert.equal(swap.args.amount,units('2').toString());assert.equal(swap.deposit,1n);
 assert.ok(JSON.parse(swap.args.msg)&&swap.args.msg.includes(RHEA));
 assert.equal(w.rows[0].bridge.status,'DONE');assert.equal(w.rows[0].bridge.receivedRaw,units('50',18).toString());
});
test('puente: con wNEAR ya listo no vuelve a envolver; con saldo nativo insuficiente falla ANTES de enviar nada',async()=>{
 setLiveSession(true);
 const a=world({wnear:units('5')});await bridgeToQuote(a.ex,'op',plan(),300);assert.deepEqual(a.calls.map(c=>c.method),['ft_transfer_call']);
 const b=world({native:units('0.5')});await assert.rejects(()=>bridgeToQuote(b.ex,'op',plan('2'),300),/NEAR disponible insuficiente/);assert.equal(b.calls.length,0);
});
test('puente: si el pool reembolsa o la confirmación no llega, falla con un mensaje claro y el token objetivo NO se compra',async()=>{
 setLiveSession(true);
 const r=world({refund:true});await assert.rejects(()=>bridgeToQuote(r.ex,'op',plan(),300),/reembolsado/);
 const u=world({confirm:'NONE',wnear:units('5')});await assert.rejects(()=>bridgeToQuote(u.ex,'op',plan(),300),/no se confirmó/);
 setLiveSession(false);await assert.rejects(()=>bridgeToQuote(world().ex,'op',plan(),300),/Modo real bloqueado/);
});
test('tope diario: un puente ya hecho cuenta como NEAR gastado aunque la compra final haya fallado',()=>{
 const now=Date.now(),at=new Date(now-3600000).toISOString();
 const rows=[{id:'a',side:'BUY',mode:'REAL',status:'FAILED',at,costRaw:units('90',18).toString(),quoteAsset:{id:RHEA},bridge:{status:'DONE',inRaw:units('2').toString()}},
  {id:'b',side:'BUY',mode:'REAL',status:'FAILED',at,costRaw:units('90',18).toString(),quoteAsset:{id:RHEA},bridge:{status:'PLANNED',inRaw:units('3').toString()}},
  {id:'c',side:'BUY',mode:'REAL',status:'FILLED',at,costRaw:units('90',18).toString(),quoteAsset:{id:RHEA},bridge:{status:'DONE',inRaw:units('4').toString()}}];
 assert.equal(display(spentLast24h(rows,now)),'6');                                                           // 2 (falló después de cambiar) + 4; el puente nunca ejecutado no cuenta
 assert.equal(limitsSummary(rows,{MAX_DAILY_NEAR:'10'},now).spentTodayNear,'6');
});

test('venta con cualquier porcentaje entero 1–100 (los de la ruedita); 0, 101 y decimales se rechazan',async()=>{
 const {percentageAmount}=await import('../server/quotes.js');const {operationSchema}=await import('../server/operations.js');
 assert.equal(percentageAmount(1000n,33),330n);assert.equal(percentageAmount(1000n,1),10n);assert.equal(percentageAmount(1000n,100),1000n);
 for(const bad of [0,101,-5,2.5,NaN])assert.throws(()=>percentageAmount(1000n,bad),/porcentaje inválido/);
 const base={requestId:'3f2504e0-4f89-41d3-9a0c-0305e82c3301',side:'SELL',mode:'DRY RUN',url:'a.tkn.near',slippageBps:300};
 assert.equal(operationSchema.safeParse({...base,percentage:33}).success,true);assert.equal(operationSchema.safeParse({...base,percentage:0}).success,false);assert.equal(operationSchema.safeParse({...base,percentage:101}).success,false);
 assert.equal(operationSchema.safeParse({...base,side:'BUY',amount:'1',payWith:'NEAR'}).success,true);assert.equal(operationSchema.safeParse({...base,side:'BUY',amount:'1',payWith:'USDC'}).success,false);
});
