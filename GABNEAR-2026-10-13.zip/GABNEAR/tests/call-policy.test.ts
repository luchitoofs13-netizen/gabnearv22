import {test} from 'node:test';
import assert from 'node:assert/strict';
import {assertAllowedCall} from '../server/call-policy.js';
import {units} from '../server/validation.js';

const ME='me.near',W='wrap.near',DCL='dclv2.ref-labs.near',REF='v2.ref-finance.near',TOKEN='gen.tkn.near';
const blocked=(...a:Parameters<typeof assertAllowedCall>)=>assert.throws(()=>assertAllowedCall(...a),/política de firma/);

test('política de firma: solo las tres llamadas esperadas, con su forma exacta',()=>{
 assertAllowedCall(ME,W,'near_deposit',{},units('1'));
 assertAllowedCall(ME,TOKEN,'storage_deposit',{account_id:ME,registration_only:true},units('0.00125'));
 assertAllowedCall(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'1000',msg:'{"x":1}'},1n);
 assertAllowedCall(ME,TOKEN,'ft_transfer_call',{receiver_id:REF,amount:'5',msg:'{}'},1n);
});
test('política de firma: rechaza cualquier desvío (otro método, receptor, cuenta, depósito o campos extra)',()=>{
 blocked(ME,W,'near_withdraw',{amount:'1'},1n);blocked(ME,TOKEN,'ft_transfer',{receiver_id:'atacante.near',amount:'1'},1n);blocked(ME,W,'transfer',{},1n);
 blocked(ME,TOKEN,'near_deposit',{},units('1'));blocked(ME,W,'near_deposit',{x:1},units('1'));blocked(ME,W,'near_deposit',{},0n);
 blocked(ME,TOKEN,'storage_deposit',{account_id:'atacante.near',registration_only:true},units('0.001'));                     // registrar a un tercero
 blocked(ME,TOKEN,'storage_deposit',{account_id:ME,registration_only:false},units('0.001'));blocked(ME,TOKEN,'storage_deposit',{account_id:ME},units('0.001'));
 blocked(ME,TOKEN,'storage_deposit',{account_id:ME,registration_only:true},units('0.06'));blocked(ME,TOKEN,'storage_deposit',{account_id:ME,registration_only:true,extra:1},0n);
 blocked(ME,W,'ft_transfer_call',{receiver_id:'atacante.near',amount:'1',msg:''},1n);                                          // el swap solo va a un exchange conocido
 blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'1',msg:''},2n);blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'1',msg:''},0n);
 blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'0',msg:''},1n);blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'-5',msg:''},1n);blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:1,msg:''},1n);
 blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'1',msg:'x'.repeat(4001)},1n);blocked(ME,W,'ft_transfer_call',{receiver_id:DCL,amount:'1',msg:'',memo:'x'},1n);
 blocked(ME,'../evil','ft_transfer_call',{receiver_id:DCL,amount:'1',msg:''},1n);blocked(ME,W,'ft_transfer_call',null,1n);blocked(ME,W,'ft_transfer_call',[],1n);
});
