import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {KeyPair,KeyPairSigner} from 'near-api-js';
import {SignerDoesNotExistError,InvalidNonceError,NotEnoughBalanceError,UnknownTransactionError,TransactionExpiredError,InvalidSignatureError} from 'near-api-js/rpc-errors';
import {History,flushAllHistories} from '../server/history.js';
import {Executor,slimOutcome,rejectionKind,isUnknownTransaction,TX_VALIDITY_BLOCKS} from '../server/transactions.js';
import {Recovery,recoveringStates,blocksAccount} from '../server/recovery.js';
import {extractToken,isTokenAccount} from '../server/validation.js';
import {NearRpc} from '../server/rpc.js';
import {accountId} from '../server/wallet.js';

// ── Historial: telemetría diferida, hechos críticos inmediatos ───────────────────────────────────────
test('historial: la telemetría se agrupa en una escritura diferida; estado y hashes se persisten al instante',async()=>{
 const original=process.cwd(),dir=mkdtempSync(join(tmpdir(),'gabnear-hist-'));process.chdir(dir);
 try{
  const h=new History();const file=()=>readFileSync(h.path,'utf8');
  h.save({id:'a',status:'QUEUED'});assert.ok(file().includes('QUEUED'));
  assert.ok(!/\n\s/.test(file()),'JSON compacto, sin indentación');
  for(let i=0;i<30;i++)h.update('a',{timing:{events:Array.from({length:i},(_,k)=>({stage:'s'+k}))}});
  assert.ok(!file().includes('timing'),'no escribe al disco por cada marca de tiempo');
  h.update('a',{status:'SUBMITTING',txHash:'HASH'});                                       // crítico: dispara escritura inmediata (incluye lo pendiente)
  assert.ok(file().includes('HASH'));assert.ok(file().includes('"timing"'));
  h.update('a',{recovery:{attempts:1}});assert.ok(!file().includes('attempts'));
  flushAllHistories();assert.ok(file().includes('attempts'));
  h.update('a',{elapsedMs:5});await new Promise(r=>setTimeout(r,320));assert.ok(file().includes('"elapsedMs":5'),'el temporizador diferido termina escribiendo');
  assert.throws(()=>h.update('zzz',{status:'X'}),/desconocida/);
  assert.equal(JSON.parse(file())[0].txHash,'HASH');
 }finally{process.chdir(original);rmSync(dir,{recursive:true,force:true});}
});
test('outcome liviano: conserva lo que se consulta y descarta pruebas Merkle y perfiles de gas',()=>{
 const big={final_execution_status:'FINAL',status:{SuccessValue:''},transaction:{hash:'h',signer_id:'a.near'},transaction_outcome:{id:'h',block_hash:'b',proof:[{hash:'p'}],outcome:{logs:[],receipt_ids:['r'],gas_burnt:1,tokens_burnt:'7',executor_id:'a.near',status:{SuccessValue:''},metadata:{version:3,gas_profile:[{cost:'BASE'}]}}},receipts_outcome:[{id:'r',block_hash:'b2',proof:[{hash:'p'}],outcome:{logs:['x'],receipt_ids:[],gas_burnt:2,tokens_burnt:'9',executor_id:'t.near',status:{Failure:{}},metadata:{gas_profile:[]}}}]};
 const s=slimOutcome(big);assert.equal(s.final_execution_status,'FINAL');assert.equal(s.receipts_outcome[0].outcome.tokens_burnt,'9');assert.deepEqual(s.receipts_outcome[0].outcome.status,{Failure:{}});
 assert.equal(s.receipts_outcome[0].proof,undefined);assert.equal(s.transaction_outcome.outcome.metadata,undefined);assert.ok(JSON.stringify(s).length<JSON.stringify(big).length);
 assert.equal(slimOutcome(null),null);
});

// ── Clasificación de errores de envío ────────────────────────────────────────────────────────────────
test('rechazos de validación se reconocen por nombre; InvalidNonce es ambiguo; el resto no es rechazo',()=>{
 assert.equal(rejectionKind(new SignerDoesNotExistError('x.near','h','b')),'REJECTED');
 assert.equal(rejectionKind(new NotEnoughBalanceError(1n,2n,'x.near','h','b')),'REJECTED');
 assert.equal(rejectionKind(new TransactionExpiredError('h','b')),'REJECTED');
 assert.equal(rejectionKind(new InvalidSignatureError('h','b')),'REJECTED');
 assert.equal(rejectionKind(new InvalidNonceError(5,5,'h','b')),'NONCE');
 assert.equal(rejectionKind(new Error('RPC excedió 3000 ms (timeout).')),null);
 assert.equal(rejectionKind(undefined),null);
 assert.equal(isUnknownTransaction(new UnknownTransactionError('h')),true);
 assert.equal(isUnknownTransaction(new Error('UnknownTransaction')),true);
 assert.equal(isUnknownTransaction(new Error('timeout')),false);
});

async function sendHarness(sendError:unknown,lookup:'known'|'unknown'|'error'){
 const rows:any[]=[{id:'op',status:'PREPARING',fundsSent:false}];
 const history:any={rows,update:(_id:string,patch:any)=>Object.assign(rows[0],patch)};
 let sends=0,lookups=0;
 const final={final_execution_status:'FINAL',status:{SuccessValue:''},transaction_outcome:{outcome:{tokens_burnt:'1'}},receipts_outcome:[]};
 const rpc:any={deadline:(p:Promise<any>)=>p,provider:{sendTransactionUntil:async()=>{sends++;throw sendError;}},
  transactionStatus:async()=>{lookups++;if(lookup==='known')return final;if(lookup==='unknown')throw new UnknownTransactionError('h');throw new Error('red caída');}};
 const signer=KeyPairSigner.fromSecretKey(KeyPair.fromRandom('ed25519').toString());
 const context={signer,publicKey:await signer.getPublicKey(),account:accountId(),nonce:7n,blockHash:new Uint8Array(32),blockHeight:1234,at:Date.now()};
 const ex=new Executor(rpc,history,()=>false);
 return {rows,ex,context,sends:()=>sends,lookups:()=>lookups};
}
test('tx rechazada por validación y desconocida para la red → FALLIDA sin fondos y sin bloquear la cuenta',async()=>{
 const h=await sendHarness(new NotEnoughBalanceError(1n,2n,'x.near','h','b'),'unknown');
 await assert.rejects(()=>h.ex.call('op','wrap.near','near_deposit',{},1n,10,h.context),(e:any)=>e.rejected===true&&/rechazada por la red/.test(e.message));
 assert.equal(h.sends(),1);assert.equal(h.lookups(),1);
 assert.equal(h.rows[0].status,'FAILED');assert.equal(h.rows[0].fundsSent,false);assert.equal(h.rows[0].transactions[0].status,'REJECTED');
 assert.equal(h.rows[0].transactions[0].blockHeight,1234);assert.ok(h.rows[0].transactions[0].signedAt);
 assert.equal(blocksAccount(h.rows[0],accountId(),'t.near'),false,'una tx rechazada ya no bloquea la cuenta');
});
test('rechazo pero la red conoce el hash (un reintento interno la aceptó) → sigue como enviada, nunca se libera',async()=>{
 const h=await sendHarness(new InvalidNonceError(7,7,'h','b'),'known');
 const outcome=await h.ex.call('op','wrap.near','near_deposit',{},1n,10,h.context);
 assert.equal(outcome.final_execution_status,'FINAL');assert.equal(h.rows[0].transactions[0].status,'FINAL');assert.equal(h.rows[0].fundsSent,true);assert.equal(h.sends(),1);
});
test('InvalidNonce con hash desconocido es ambiguo → INCIERTO con marca para liberar con prueba; nunca reenvía',async()=>{
 const h=await sendHarness(new InvalidNonceError(9,7,'h','b'),'unknown');
 await assert.rejects(()=>h.ex.call('op','wrap.near','near_deposit',{},1n,10,h.context),/incierto/);
 assert.equal(h.rows[0].status,'UNKNOWN');assert.equal(h.rows[0].transactions[0].sendError,'NONCE');assert.equal(h.sends(),1);
});
test('rechazo cuando ni siquiera se pudo consultar el hash → incierto (no se asume que no existe)',async()=>{
 const h=await sendHarness(new SignerDoesNotExistError('x.near','h','b'),'error');
 await assert.rejects(()=>h.ex.call('op','wrap.near','near_deposit',{},1n,10,h.context),/incierto/);
 assert.equal(h.rows[0].status,'UNKNOWN');assert.ok(blocksAccount(h.rows[0],accountId()));
});

// ── Liberación de transacciones fantasma ─────────────────────────────────────────────────────────────
function ghost(txOver:any={},rowOver:any={}){
 const tx={hash:'H',signer:'me.near',publicKey:'ed25519:abc',nonce:'5',blockHeight:1000,signedAt:new Date(Date.now()-60000).toISOString(),status:'UNKNOWN',...txOver};
 const rows:any[]=[{id:'op',status:'UNKNOWN',txHash:'H',signer:'me.near',token:'t.near',mode:'REAL',fundsSent:true,transactions:[tx],...rowOver}];
 const history:any={rows,update:(_id:string,patch:any)=>Object.assign(rows[0],patch)};
 const env={height:1100,keyNonce:3,known:'unknown' as 'known'|'unknown'|'error'};
 const ex:any={busy:false,reconcile:async()=>{throw new UnknownTransactionError('H');},lookup:async()=>env.known.toUpperCase(),
  rpc:{status:async()=>({sync_info:{latest_block_height:env.height}}),deadline:(p:Promise<any>)=>p,provider:{viewAccessKey:async()=>({nonce:env.keyNonce})}}};
 return {rows,env,rec:new Recovery(history,ex)};
}
test('recuperación: tx desconocida cuya ventana de validez venció se libera como NUNCA ejecutada',async()=>{
 const g=ghost();g.env.height=1000+TX_VALIDITY_BLOCKS+50;await g.rec.reconcile('op');assert.equal(g.rows[0].status,'UNKNOWN');          // aún dentro del margen de seguridad (+100)
 g.env.height=1000+TX_VALIDITY_BLOCKS+101;await g.rec.reconcile('op');
 assert.equal(g.rows[0].status,'FAILED');assert.equal(g.rows[0].fundsSent,false);assert.equal(g.rows[0].transactions[0].status,'NEVER_EXECUTED');assert.match(g.rows[0].error,/venció/);
 assert.equal(blocksAccount(g.rows[0],'me.near','t.near'),false);
});
test('recuperación: con marca NONCE y nonce consumido por otra tx se libera; si no, se mantiene',async()=>{
 const young=ghost({sendError:'NONCE',signedAt:new Date(Date.now()-5000).toISOString()});young.env.keyNonce=9;await young.rec.reconcile('op');assert.equal(young.rows[0].status,'UNKNOWN');   // <30 s
 const g=ghost({sendError:'NONCE'});g.env.keyNonce=4;await g.rec.reconcile('op');assert.equal(g.rows[0].status,'UNKNOWN');                                                          // nonce aún no consumido
 g.env.keyNonce=5;await g.rec.reconcile('op');assert.equal(g.rows[0].status,'FAILED');assert.match(g.rows[0].error,/nonce/i);
 const plain=ghost();plain.env.keyNonce=99;await plain.rec.reconcile('op');assert.equal(plain.rows[0].status,'UNKNOWN','sin marca NONCE el nonce no prueba nada');
});
test('recuperación: una tx con resultado FINAL jamás se libera como fantasma',async()=>{
 const g=ghost({},{lastOutcome:{final_execution_status:'FINAL'}});g.env.height=10**9;await g.rec.reconcile('op');assert.notEqual(g.rows[0].status,'FAILED');
});
test('descarte manual: exige 3 minutos, que la red no conozca el hash y confirmación',async()=>{
 const early=ghost();await assert.rejects(()=>early.rec.discard('op'),/3 minutos/);
 const g=ghost({signedAt:new Date(Date.now()-240000).toISOString()});
 g.env.known='known';await assert.rejects(()=>g.rec.discard('op'),/La red conoce/);
 g.env.known='error';await assert.rejects(()=>g.rec.discard('op'),/No se pudo confirmar/);
 g.env.known='unknown';const r=await g.rec.discard('op');assert.equal(r.status,'FAILED');assert.match(r.error,/Descartada manualmente/);assert.equal(r.fundsSent,false);
 await assert.rejects(()=>g.rec.discard('op'),/no está pendiente/);
 const done=ghost({signedAt:new Date(Date.now()-240000).toISOString()},{lastOutcome:{final_execution_status:'FINAL'}});await assert.rejects(()=>done.rec.discard('op'),/resultado final/);
 assert.ok(recoveringStates.includes('UNKNOWN'));
});

// ── Bóveda de claves ─────────────────────────────────────────────────────────────────────────────────
import {randomBytes,scryptSync,createCipheriv} from 'node:crypto';
import {seal,unseal} from '../server/vault.js';
test('bóveda v2: scrypt N=2^17 guardado en el archivo; abre bóvedas v1 ya creadas; rechaza kdf manipulado',async()=>{
 const pw='clave local de prueba 123';
 const v2=JSON.parse(await seal('ed25519:SECRETO',pw));assert.equal(v2.v,2);assert.equal(v2.kdf.N,2**17);
 assert.equal(await unseal(JSON.stringify(v2),pw),'ed25519:SECRETO');
 await assert.rejects(()=>unseal(JSON.stringify(v2),'otra clave distinta 456'),/Contraseña incorrecta/);
 // bóveda v1 fabricada con los parámetros por defecto de Node, tal como la generaba la versión anterior
 const salt=randomBytes(16),iv=randomBytes(12),key=scryptSync(pw,salt,32),cipher=createCipheriv('aes-256-gcm',key,iv);
 const ct=Buffer.concat([cipher.update('ed25519:VIEJO','utf8'),cipher.final()]);
 const v1=JSON.stringify({v:1,salt:salt.toString('base64'),iv:iv.toString('base64'),tag:cipher.getAuthTag().toString('base64'),ciphertext:ct.toString('base64')});
 assert.equal(await unseal(v1,pw),'ed25519:VIEJO');
 // un archivo manipulado no puede pedir memoria arbitraria (N demasiado grande) ni cambiar r/p
 for(const kdf of [{N:2**30,r:8,p:1},{N:2**17,r:64,p:1},{N:3,r:8,p:1},{N:2**17,r:8,p:16},undefined])await assert.rejects(()=>unseal(JSON.stringify({...v2,kdf}),pw),/Contraseña incorrecta o archivo/);
 await assert.rejects(()=>unseal(JSON.stringify({...v2,v:3}),pw),/archivo/);
});

// ── Cuentas de token genéricas ───────────────────────────────────────────────────────────────────────
test('acepta tokens de cualquier launchpad NEAR y enlaces de nearly.trade / nearblocks.io',()=>{
 for(const ok of ['ai-8.nearlytrade.near','nene-2250.meme-cooking.near','soul.tkn.near','cocoon.tknx.near','hoot-8ecf65.launchpad.justhoot.near','shore-4lzt.launch.shoremarkets.near','usdt.tether-token.near','token.sweat','foo.tg','aurora','17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1'])assert.equal(extractToken(ok),ok);
 assert.equal(extractToken('https://nearblocks.io/token/abc.tkn.near'),'abc.tkn.near');
 assert.equal(extractToken('https://nearblocks.io/address/abc.tkn.near'),'abc.tkn.near');
 assert.equal(extractToken('https://nearly.trade/ai-8.nearlytrade.near'),'ai-8.nearlytrade.near');
 assert.equal(isTokenAccount('x.near'),true);
});
test('sigue rechazando lo peligroso: wNEAR, testnet, dominios, mayúsculas, hosts parecidos',()=>{
 assert.throws(()=>extractToken('wrap.near'),/quote/);assert.throws(()=>extractToken('https://nearblocks.io/token/wrap.near'));
 for(const bad of ['evil.com','x.testnet','AAA.near','ab','a'.repeat(70)+'.near','.near','a..near','-a.near','a.near/b','token.near other.near','https://nearblocks.io.evil.com/token/a.near','https://evil.com/token/a.near','https://nearblocks.io@evil.com/token/a.near','http://nearblocks.io/token/a.near','https://nearblocks.io/token/a.testnet','javascript:alert(1)',''])assert.throws(()=>extractToken(bad),Error,bad);
});

// ── RPC ──────────────────────────────────────────────────────────────────────────────────────────────
test('el provider no reintenta 12 veces: intentos acotados y configurables',()=>{
 const keep=process.env.NEAR_RPC_RETRIES;
 try{
  delete process.env.NEAR_RPC_RETRIES;assert.equal((new NearRpc('https://x.invalid').provider as any).options.retries,3);
  process.env.NEAR_RPC_RETRIES='5';assert.equal((new NearRpc('https://x.invalid').provider as any).options.retries,5);
  process.env.NEAR_RPC_RETRIES='0';assert.equal((new NearRpc('https://x.invalid').provider as any).options.retries,3);
  process.env.NEAR_RPC_RETRIES='basura';assert.equal((new NearRpc('https://x.invalid').provider as any).options.retries,3);
 }finally{if(keep===undefined)delete process.env.NEAR_RPC_RETRIES;else process.env.NEAR_RPC_RETRIES=keep;}
});
test('sin fallback, una lectura con 429 se reintenta una sola vez',async()=>{
 const rpc=new NearRpc('https://x.invalid');let calls=0;
 (rpc.provider as any).callFunction=async()=>{calls++;if(calls===1)throw new Error('{"code": -429, "message": "Rate limits exceeded"}');return '42';};
 assert.equal(await rpc.view('a.near','m'),'42');assert.equal(calls,2);
 let always=0;(rpc.provider as any).callFunction=async()=>{always++;throw new Error('429 Rate limits exceeded');};
 await assert.rejects(()=>rpc.view('a.near','m'),/Rate limits/);assert.equal(always,2);                           // 1 intento + 1 reintento, nunca más
 let other=0;(rpc.provider as any).callFunction=async()=>{other++;throw new Error('MethodNotFound');};
 await assert.rejects(()=>rpc.view('a.near','m'),/MethodNotFound/);assert.equal(other,1);                          // los errores de contrato no se reintentan
});
