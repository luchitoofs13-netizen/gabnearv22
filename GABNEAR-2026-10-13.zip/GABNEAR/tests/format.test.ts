import test from 'node:test';
import assert from 'node:assert/strict';
import {fmtPrice,fmtCompact,fmtUsd,fmtPct,timeAgo,shortAccount,rawToNumber,applyTrade,TIMEFRAME_SECONDS} from '../src/market/format.js';

test('fmtPrice: cifras significativas para precios de memecoin, sin notación científica',()=>{
 assert.equal(fmtPrice(0.000003895),'0.000003895');
 assert.equal(fmtPrice(1.2e-9),'0.0000000012');
 assert.equal(fmtPrice(0.0123456),'0.01235');
 assert.equal(fmtPrice(5.79),'5.79');assert.equal(fmtPrice(1),'1');assert.equal(fmtPrice(2500.7),'2,501');
 assert.equal(fmtPrice(0),'0');assert.equal(fmtPrice(null),'—');assert.equal(fmtPrice(undefined),'—');assert.equal(fmtPrice(NaN),'—');assert.equal(fmtPrice(Infinity),'—');
 assert.ok(!/e/i.test(fmtPrice(3e-13)),'sin exponente');
});
test('fmtCompact / fmtUsd / fmtPct / shortAccount / timeAgo',()=>{
 assert.equal(fmtUsd(36451.8),'$36.5K');assert.equal(fmtUsd(1234567),'$1.23M');assert.equal(fmtUsd(2.5e9),'$2.50B');assert.equal(fmtUsd(742),'$742');assert.equal(fmtUsd(44.4),'$44.40');assert.equal(fmtUsd(null),'—');
 assert.equal(fmtCompact(0.5),'0.5000');assert.equal(fmtCompact(994468909),'994M');
 assert.equal(fmtPct(13.74),'+13.7%');assert.equal(fmtPct(-2.04),'-2.0%');assert.equal(fmtPct(0),'0.0%');assert.equal(fmtPct(null),'—');
 assert.equal(shortAccount('a'.repeat(30)+'b'.repeat(34)),'aaaaaaaa…bbbbbb');                 // cuenta implícita: 8 + … + 6
 assert.equal(shortAccount('ai-8.nearlytrade.near'),'ai-8.nea…e.near');
 assert.equal(shortAccount('corta.near'),'corta.near');assert.equal(shortAccount(undefined),'—');
 const now=1_000_000_000;assert.equal(timeAgo(now-5000,now),'5s');assert.equal(timeAgo(now-125000,now),'2m');assert.equal(timeAgo(now-3_900_000,now),'1h 5m');assert.equal(timeAgo(now-3*86400000,now),'3d');assert.equal(timeAgo(null,now),'—');
});
test('rawToNumber: montos enteros a número con decimales, también para valores enormes',()=>{
 assert.equal(rawToNumber('1500000000000000000000000',24),1.5);
 assert.equal(rawToNumber('250',2),2.5);
 assert.ok(Math.abs(rawToNumber('994468909560735600000000000',18)-994468909.5607356)<1e-3);
 assert.ok(Number.isNaN(rawToNumber('abc',18)));assert.ok(Number.isNaN(rawToNumber(null,18)));assert.ok(Number.isNaN(rawToNumber('-5',18)));
});
test('applyTrade: un swap en vivo actualiza la vela abierta o abre otra; ignora swaps más viejos',()=>{
 const candles=[{time:0,open:1,high:2,low:1,close:2,volume:5},{time:300,open:2,high:3,low:2,close:3,volume:1}];
 // mismo bucket de 5 m (300–599 s)
 const a=applyTrade(candles,4,2,400_000,'5m')!;assert.deepEqual(a,{time:300,open:2,high:4,low:2,close:4,volume:3});assert.equal(candles.length,2);
 const b=applyTrade(candles,1.5,1,450_000,'5m')!;assert.equal(b.low,1.5);assert.equal(b.close,1.5);assert.equal(b.high,4);assert.equal(b.volume,4);
 // nueva vela: abre en el cierre anterior
 const c=applyTrade(candles,5,1,650_000,'5m')!;assert.deepEqual(c,{time:600,open:1.5,high:5,low:1.5,close:5,volume:1});assert.equal(candles.length,3);
 // más viejo que la vela abierta: no cambia nada
 assert.equal(applyTrade(candles,9,9,100_000,'5m'),null);assert.equal(candles.length,3);
 // sin velas previas
 const d:any[]=[];assert.deepEqual(applyTrade(d,3,2,61_000,'1m'),{time:60,open:3,high:3,low:3,close:3,volume:2});
 assert.equal(TIMEFRAME_SECONDS['1d'],86400);
});
