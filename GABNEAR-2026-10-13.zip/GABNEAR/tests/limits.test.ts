import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spendLimits,spentLast24h,checkSpend,limitsSummary} from '../server/limits.js';
import {units} from '../server/validation.js';

const W='wrap.near',NOW=Date.parse('2026-10-12T12:00:00Z'),hoursAgo=(h:number)=>new Date(NOW-h*3600000).toISOString();
const row=(over:any)=>({id:'r'+Math.random(),side:'BUY',mode:'REAL',status:'FILLED',costRaw:units('1').toString(),at:hoursAgo(1),quoteAsset:{id:W},...over});

test('spendLimits: vacío/0 = sin tope; valores en NEAR; un valor ilegible falla cerrado',()=>{
 assert.deepEqual(spendLimits({}),{maxBuyRaw:null,maxDailyRaw:null});assert.deepEqual(spendLimits({MAX_BUY_NEAR:'0',MAX_DAILY_NEAR:' '}),{maxBuyRaw:null,maxDailyRaw:null});
 assert.deepEqual(spendLimits({MAX_BUY_NEAR:'0.5',MAX_DAILY_NEAR:'3'}),{maxBuyRaw:units('0.5'),maxDailyRaw:units('3')});
 for(const bad of ['abc','-1','1,5','1e3','0x10'])assert.throws(()=>spendLimits({MAX_BUY_NEAR:bad}),/MAX_BUY_NEAR inválido/,bad);
});
test('checkSpend: tope por compra y tope diario (cuenta inciertas, ignora fallidas, viejas, ajenas y la propia fila)',()=>{
 const limits={maxBuyRaw:units('1'),maxDailyRaw:units('2')};
 checkSpend([],'x',W,units('1'),limits,NOW);                                                                       // justo en el tope: pasa
 assert.throws(()=>checkSpend([],'x',W,units('1.000000000000000000000001'),limits,NOW),/tope por compra.*MAX_BUY_NEAR=1/);
 const rows=[row({}),row({status:'UNKNOWN'}),row({status:'FAILED'}),row({status:'REFUNDED'}),row({mode:'DRY RUN'}),row({side:'SELL'}),row({at:hoursAgo(25)}),row({quoteAsset:{id:'usdc.near'}}),row({id:'mia',status:'PREPARING'})];
 assert.equal(spentLast24h(rows,NOW,'mia'),units('2'));                                                           // FILLED + UNKNOWN; el resto no cuenta
 assert.throws(()=>checkSpend(rows,'mia',W,units('0.1'),limits,NOW),/tope diario.*ya compraste 2 NEAR/);
 checkSpend(rows.slice(0,1),'mia',W,units('1'),limits,NOW);                                                       // 1 + 1 = 2: pasa
 checkSpend(rows,'mia','usdc.near',units('500'),limits,NOW);                                                      // otro quote: los topes son en NEAR
 checkSpend(rows,'mia',W,units('9'),{maxBuyRaw:null,maxDailyRaw:null},NOW);                                       // sin topes
});
test('limitsSummary: resume topes y gasto; un .env roto se informa en vez de romper /api/health',()=>{
 const s=limitsSummary([row({})],{MAX_BUY_NEAR:'1',MAX_DAILY_NEAR:'5'},NOW);assert.deepEqual(s,{maxBuyNear:'1',maxDailyNear:'5',spentTodayNear:'1',error:null});
 const bad=limitsSummary([],{MAX_BUY_NEAR:'x'},NOW);assert.equal(bad.maxBuyNear,null);assert.match(bad.error!,/MAX_BUY_NEAR/);
});
