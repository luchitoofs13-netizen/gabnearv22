import 'dotenv/config';
import {mkdirSync,writeFileSync} from 'node:fs';
import {NearRpc} from '../../server/rpc.js';
import {accountId} from '../../server/wallet.js';
import {analyze} from '../../server/analysis.js';
import {units,display} from '../../server/validation.js';
const rpc=new NearRpc(process.env.NEAR_RPC_URL||'https://free.rpc.fastnear.com');
await rpc.mainnet();const account=accountId();if(!account)throw new Error('Conectá una cuenta pública. No se necesita firma.');
const input={url:'ai-8.nearlytrade.near',amount:'0.1',slippageBps:300};
const [analysis,native,wrapped,price]=await Promise.all([analyze(rpc,input,{accountId:account,maxNear:'1',maxBps:500}),rpc.account(account),rpc.view('wrap.near','ft_balance_of',{account_id:account}),rpc.deadline(rpc.provider.viewGasPrice())]);
if(analysis.quoteAsset.id!=='wrap.near')throw new Error('Esta proyección de presupuesto en NEAR solo admite launches wNEAR.');
const storageContracts=[...!analysis.storageRegistered?[analysis.token]:[],...!analysis.wnearRegistered?['wrap.near']:[]];
const storage=await Promise.all(storageContracts.map(async contract=>({contract,min:String((await rpc.view(contract,'storage_balance_bounds')).min)})));
const storageReserve=storage.reduce((sum,row)=>sum+BigInt(row.min),0n);
// Proyección conservadora, NO garantía protocolar: doble precio de gas observado,
// hasta 300 TGas por transacción, más una reserva de overhead por transacción.
const transactionCount=1+(BigInt(wrapped)<units('0.1')?1:0)+storage.length;
const feesEstimate=BigInt(price.gas_price)*2n*300000000000000n*BigInt(transactionCount)+units('0.002')*BigInt(transactionCount);
const attempts=Math.max(0,Math.min(5,Number((units('0.5')-storageReserve)/(units('0.1')+feesEstimate))));
const report={at:new Date().toISOString(),account,token:analysis.token,fundsSent:false,native:display(native.amount),wrapped:display(wrapped),gasPrice:price.gas_price,storage,storageReserve:display(storageReserve),transactionCountPerFirstBuy:transactionCount,feesReserveEstimatePerAttempt:display(feesEstimate),projectedAttempts:attempts,projectedAllIn:display(storageReserve+BigInt(attempts)*(units('0.1')+feesEstimate)),warning:'Proyección de lectura, no autorización adicional ni límite garantizado de gas futuro. Recalcular con la wallet definitiva y antes de cada intento; contabilizar costos reales confirmados. No activa una campaña.'};
mkdirSync('data',{recursive:true});writeFileSync('data/benchmark-preflight.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
