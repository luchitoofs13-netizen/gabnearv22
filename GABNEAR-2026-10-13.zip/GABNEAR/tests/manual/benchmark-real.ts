import 'dotenv/config';
import {randomUUID} from 'node:crypto';
import {mkdirSync,writeFileSync,existsSync,openSync,closeSync,unlinkSync} from 'node:fs';
import {BenchmarkBudget} from '../../server/benchmark-budget.js';
import {NearRpc} from '../../server/rpc.js';
import {analyze} from '../../server/analysis.js';
import {units,display,extractToken} from '../../server/validation.js';
import {supportedRules,executableExit} from '../../server/trading.js';
import {afterTax,taxRate} from '../../server/quotes.js';
const base='http://127.0.0.1:4317/api/';
async function api(path:string,body?:object){const response=await fetch(base+path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-Gabnear-Client':'local'}:undefined,body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(10000)});const data=await response.json();if(!response.ok)throw new Error(data.error||'Error local.');return data;}
const authorized=process.env.BENCHMARK_ACCOUNT_ID;
if(!authorized)throw new Error('Definí BENCHMARK_ACCOUNT_ID con la cuenta secundaria autorizada. Nunca una semilla.');
const token=extractToken(process.env.BENCHMARK_TOKEN||'ninu-4.nearlytrade.near');
if(token==='ai-8.nearlytrade.near')throw new Error('El token de análisis AI está excluido de las compras de prueba por la instrucción original.');
const health=await api('health'),wallet=await api('wallet');
if(health.chain!=='mainnet'||health.accountId!==authorized||wallet.accountId!==authorized||!wallet.unlocked||!health.liveEnabled||health.stopped)throw new Error('La cuenta autorizada debe estar desbloqueada y en REAL en el panel local, sin parada. No se envió nada.');
mkdirSync('data',{recursive:true});const lock=openSync('data/benchmark-real.lock','wx');process.on('exit',()=>{closeSync(lock);unlinkSync('data/benchmark-real.lock');});
const purchase='0.05',purchaseRaw=units(purchase);
const ledger=new BenchmarkBudget('data/benchmark-real-ledger.json',authorized,purchaseRaw);
const rpc=new NearRpc(process.env.NEAR_RPC_URL||'https://free.rpc.fastnear.com');await rpc.mainnet();
const max=Math.min(5,Number(process.env.BENCHMARK_ATTEMPTS||2));if(!Number.isInteger(max)||max<1)throw new Error('Cantidad inválida.');
const rows:any[]=existsSync('data/benchmark-real-results.json')?JSON.parse((await import('node:fs')).readFileSync('data/benchmark-real-results.json','utf8')):[];
function publicRpc(url:string){try{return new URL(url).hostname;}catch{return "RPC configurado";}}
function report(){mkdirSync('data',{recursive:true});writeFileSync('data/benchmark-real-results.json',JSON.stringify(rows,null,2));const first=rows.find(r=>r.status==='FILLED');writeFileSync('docs/BENCHMARK_REAL.md',`# Benchmark real\n\nCuenta secundaria: ${authorized}. Hasta cinco intentos; importe de nuevos intentos 0,05 NEAR (incluye costos históricos previos en el ledger). Límite de campaña 0,5 NEAR con gas/depósitos. El ledger reserva costos antes de cada intento, conserva pendientes y cuenta fallos. Este script utiliza la configuración actual del servidor; no afirma comparar configuraciones distintas por sí mismo.\n\n| Intento | Estado | Configuración | Envío ms | FINAL ms | Verificación / total ms | Visualización ms | Hash swap | Principal usado NEAR | Gas NEAR | Depósitos storage NEAR | Cargo conservador ledger NEAR | Reducción total % |\n|---|---|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|\n${rows.map((r,i)=>{const swap=r.transactions?.find((t:any)=>t.method==='ft_transfer_call');const gas=(r.transactions??[]).reduce((sum:bigint,t:any)=>sum+BigInt(t.gasBurnt??0),0n);const storage=(r.transactions??[]).filter((t:any)=>t.method==='storage_deposit').reduce((sum:bigint,t:any)=>sum+BigInt(t.deposit??0),0n);const reduction=first&&r.status==='FILLED'&&first.elapsedMs>0?((first.elapsedMs-r.elapsedMs)/first.elapsedMs*100).toFixed(2):'—';return `| ${i+1} | ${r.status} | ${publicRpc(r.benchmarkRpc)} · async=${r.timing?.events?.find((e:any)=>e.stage==='rpcAcknowledged')?.acceptanceOnly??r.benchmarkAsync} | ${swap?.timing?.sendOffsetMs?.toFixed(1)??'—'} | ${swap?.timing?.finalOffsetMs?.toFixed(1)??'—'} | ${r.elapsedMs??'—'} | ${r.visualization?.clientElapsedMs??'No hubo navegador'} | ${swap?.hash??r.txHash??'Sin envío'} | ${r.usedRaw?display(r.usedRaw):'No verificado'} | ${display(gas)} | ${display(storage)} | ${r.benchmarkCharge??'Pendiente'} | ${reduction} |`;}).join('\n')}\n\nTiempos desde recepción backend, salvo visualización. Un ejecutor CLI no mide pintura del navegador. El cargo conservador cuenta el principal de cada intento más gas, depósitos storage y un yocto por swap, aunque haya reembolsos o wNEAR remanente; no es sinónimo de pérdida económica. Todos los hashes de preparación, cotizaciones y etapas se conservan en data/benchmark-real-results.json y el historial local. No se vende ni se reenvía una compra incierta.\n`);}
for(let i=ledger.attempts.length;i<max;i++){
 const current=await api('health');if(current.accountId!==authorized||!current.liveEnabled||current.stopped)throw new Error('Cuenta, modo o parada cambiaron.');
 const analysis=await analyze(rpc,{url:token,amount:purchase,slippageBps:300},{accountId:authorized,maxNear:purchase,maxBps:300});
 if(analysis.quoteAsset.id!=='wrap.near')throw new Error('Esta campaña tiene presupuesto en NEAR y solo admite wNEAR. No se envió nada.');
 if(!analysis.direct||!supportedRules(analysis.rules)||!analysis.quotation)throw new Error('Ruta/reglas no compatibles.');
 const exit=await executableExit(rpc,analysis,afterTax(BigInt(analysis.quotation.raw),taxRate(analysis.tax,'buy')),300);
 if(BigInt(exit.minRaw)<purchaseRaw*90n/100n)throw new Error('Cotización de salida insuficiente para la prueba.');
 const storageContracts=[...!analysis.storageRegistered?[analysis.token]:[],...!analysis.wnearRegistered?['wrap.near']:[]];
 const storage=await Promise.all(storageContracts.map(async contract=>BigInt((await rpc.view(contract,'storage_balance_bounds')).min)));
 if(storage.some(min=>min<0n||min>units('0.05')))throw new Error('Depósito storage no compatible antes de reservar.');
 const wrapped=BigInt(await rpc.view('wrap.near','ft_balance_of',{account_id:authorized}));const price=await rpc.deadline(rpc.provider.viewGasPrice());
 const txCount=1+(wrapped<purchaseRaw?1:0)+storage.length;
 const maximumExtra=storage.reduce((a,b)=>a+b,0n)+BigInt(price.gas_price)*2n*300000000000000n*BigInt(txCount)+units('0.002')*BigInt(txCount);
 const native=await rpc.account(authorized);if(BigInt(native.amount)-BigInt(native.storage_usage)*10000000000000000000n<purchaseRaw+maximumExtra)throw new Error('Saldo insuficiente para compra y costos reservados.');
 const requestId=randomUUID();ledger.reserve(requestId,purchaseRaw,maximumExtra);
 let row:any;
 try{row=await api('operations',{requestId,side:'BUY',mode:'REAL',url:token,amount:purchase,slippageBps:300});}catch{try{const existing=(await api('history')).find((r:any)=>r.requestId===requestId);if(existing){existing.benchmarkRpc=rpc.url;rows.push(existing);for(const tx of existing.transactions??[])ledger.recordHash(requestId,tx.hash);}}catch{/* Conservar reserva. */}report();throw new Error('Respuesta de envío perdida o rechazada; intento reservado. Consultar historial, NO repetir POST.');}
 const start=Date.now();while(['QUEUED','PREPARING','SIGNED','SUBMITTING','SENT','CONFIRMING','SETTLING'].includes(row.status)&&Date.now()-start<120000){await new Promise(r=>setTimeout(r,500));row=await api('operations/'+row.id);}
 row.benchmarkRpc=rpc.url;row.benchmarkAsync=process.env.NEAR_ASYNC_SEND!=='false';row.benchmarkPurchase=purchase;rows.push(row);
 for(const t of row.transactions??[])ledger.recordHash(requestId,t.hash);
 report();
 if(!['FILLED','PARTIAL','REFUNDED','FAILED'].includes(row.status))throw new Error('Resultado pendiente o incierto: campaña detenida, sin reintento.');
 const txs=row.transactions??[];if(txs.some((t:any)=>t.status!=='FINAL'||t.gasBurnt===undefined))throw new Error('Costos no confirmados; mantener reserva y detener.');
 const fees=txs.reduce((sum:bigint,t:any)=>sum+BigInt(t.gasBurnt)+(['storage_deposit','ft_transfer_call'].includes(t.method)?BigInt(t.deposit):0n),0n);
 const charge=purchaseRaw+fees;ledger.settle(requestId,charge);row.benchmarkCharge=display(charge);report();
 if(row.status!=='FILLED')throw new Error('Intento no llenado completamente: corregir y revisar antes de continuar.');
 console.log(JSON.stringify({attempt:ledger.attempts.length,status:row.status,hash:row.txHash,totalMs:row.elapsedMs,conservativeCharge:display(charge)}));
}
