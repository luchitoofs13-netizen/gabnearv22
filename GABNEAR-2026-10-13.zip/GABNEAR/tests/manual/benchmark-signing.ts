import {KeyPair,KeyPairSigner,createTransaction,actions,teraToGas} from 'near-api-js';
import {performance} from 'node:perf_hooks';
import {mkdirSync,writeFileSync} from 'node:fs';
import {stats} from '../../server/benchmark-stats.js';
// Clave aleatoria sin cuenta ni fondos. No hay RPC ni transmisión.
const key=KeyPair.fromRandom('ed25519'),signer=KeyPairSigner.fromSecretKey(key.toString());
const samples=[];
for(let i=0;i<20;i++){const start=performance.now();const tx=createTransaction('benchmark.near',key.getPublicKey(),'wrap.near',BigInt(i+1),[actions.functionCall('near_deposit',{},teraToGas(10),1n)],new Uint8Array(32));const built=performance.now();await signer.signTransaction(tx);const signed=performance.now();samples.push({constructionMs:built-start,signingMs:signed-built,totalMs:signed-start});}
const report={at:new Date().toISOString(),fundsSent:false,key:'synthetic-offline',construction:stats(samples.map(s=>s.constructionMs)),signing:stats(samples.map(s=>s.signingMs)),total:stats(samples.map(s=>s.totalMs)),samples};
mkdirSync('data',{recursive:true});writeFileSync('data/benchmark-signing.json',JSON.stringify(report,null,2));writeFileSync('docs/BENCHMARK_SIGNING.md',`# Construcción y firma offline\n\nFecha UTC: ${report.at}. Veinte muestras con clave sintética sin fondos, nonce y bloque ficticios. Sin RPC ni envíos. No representa una compra completa ni incluye acceso a la wallet, obtención de nonce, bloque o escritura del historial.\n\n| Etapa | p50 ms | p90 ms | p95 ms |\n|---|---:|---:|---:|\n${['construction','signing','total'].map(name=>{const s=report[name as 'construction'];return `| ${name} | ${s.p50!.toFixed(3)} | ${s.p90!.toFixed(3)} | ${s.p95!.toFixed(3)} |`;}).join('\n')}\n\nDatos completos locales en data/benchmark-signing.json. Repetir: npm run benchmark:signing.\n`);console.log(JSON.stringify({construction:report.construction,signing:report.signing,total:report.total,fundsSent:false},null,2));
