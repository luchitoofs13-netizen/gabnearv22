import 'dotenv/config';
import {performance} from 'node:perf_hooks';
import {mkdirSync,writeFileSync} from 'node:fs';
import {NearRpc} from '../../server/rpc.js';
import {analyze} from '../../server/analysis.js';
import {accountId} from '../../server/wallet.js';
import {stats,reduction} from '../../server/benchmark-stats.js';
const endpoints=[process.env.NEAR_RPC_URL||'https://free.rpc.fastnear.com','https://rpc.mainnet.near.org','https://1rpc.io/near','https://near.drpc.org'];
const user=accountId()||'wrap.near';
const round=(n:number)=>Number(n.toFixed(3));
const results:any[]=[];
for(const url of [...new Set(endpoints)]){
 const rpc=new NearRpc(url);const original:any=rpc.provider.sendJsonRpc.bind(rpc.provider);
 // Defensa: este proceso nunca puede transmitir una transacción, ni acceder a claves locales.
 rpc.provider.sendJsonRpc=async(method:string,params:any)=>{if(!['status','query','block','gas_price'].includes(method))throw new Error('Método no permitido en benchmark de lectura.');return original(method,params);};
 const samples:any[]=[];
 for(let run=0;run<3;run++){
  const times:Record<string,number>={};let error:string|null=null;
  async function measure(name:string,work:()=>Promise<unknown>){const t=performance.now();try{return await work();}finally{times[name]=round(performance.now()-t);}}
  try{
   await measure('status',()=>rpc.mainnet());
   // Status fresco para comparar latencia, sin la caché de identidad.
   if(run>0)await measure('status',()=>rpc.status());
   await Promise.all([measure('account',()=>rpc.account(user)),measure('block',()=>rpc.deadline(rpc.provider.viewBlock({finality:'final'}))),measure('wnearBalance',()=>rpc.view('wrap.near','ft_balance_of',{account_id:user}))]);
   const keys:any=await rpc.deadline(rpc.provider.query({request_type:'view_access_key_list',account_id:user,finality:'final'}));
   if(keys.keys?.[0])await measure('accessKey',()=>rpc.deadline(rpc.provider.viewAccessKey({accountId:user,publicKey:keys.keys[0].public_key})));
  }catch(e){error=e instanceof Error?e.message:'RPC no disponible';}
  samples.push({run:run+1,times,error});await new Promise(r=>setTimeout(r,500));
 }
 const valid=samples.filter(x=>!x.error);const methods=Object.fromEntries(['status','account','block','wnearBalance','accessKey'].map(name=>[name,stats(valid.map(x=>x.times[name]).filter((n:any)=>Number.isFinite(n)))]));
 results.push({url,errors:samples.filter(x=>x.error).length,methods,samples});mkdirSync('data',{recursive:true});writeFileSync('data/benchmark-rpc-samples.json',JSON.stringify(results,null,2));
 console.log(JSON.stringify({url,errors:results.at(-1).errors,methods}));
}
const candidates=results.filter(r=>r.errors===0&&r.methods.account.samples===3);
candidates.sort((a,b)=>a.methods.account.p50+a.methods.block.p50+a.methods.wnearBalance.p50-(b.methods.account.p50+b.methods.block.p50+b.methods.wnearBalance.p50));
if(!candidates.length)throw new Error('Ningún RPC pasó todas las consultas.');
const chosen=process.env.BENCHMARK_RPC_URL||candidates[0].url,rpc=new NearRpc(chosen);
const original:any=rpc.provider.sendJsonRpc.bind(rpc.provider);let calls=0;
rpc.provider.sendJsonRpc=async(method:string,params:any)=>{if(!['status','query','block'].includes(method))throw new Error('Solo lectura.');calls++;return original(method,params);};
const cohorts:any[]=[];
for(const name of ['baseline-readonly','cold','hot']){
 const samples:any[]=[];rpc.cacheEnabled=name!=='baseline-readonly';rpc.clearMetadata();
 // Calentar solo datos seguros; precios/pool/reglas se vuelven a consultar.
 if(name==='hot')await analyze(rpc,{url:'ai-8.nearlytrade.near',amount:'0.1',slippageBps:300},{accountId:accountId(),maxNear:'1',maxBps:500});
 for(let i=0;i<5;i++){
  if(name==='cold')rpc.clearMetadata();calls=0;const start=performance.now();
  if(name==='baseline-readonly')await rpc.status();else await rpc.mainnet();
  const result=await analyze(rpc,{url:'ai-8.nearlytrade.near',amount:'0.1',slippageBps:300},{accountId:accountId(),maxNear:'1',maxBps:500});
  samples.push({totalMs:round(performance.now()-start),calls,discoveryMs:result.timings.discoveryMs,quoteAndStorageMs:result.timings.quoteAndStorageMs,storageRegistered:result.storageRegistered,wnearRegistered:result.wnearRegistered});await new Promise(r=>setTimeout(r,1500));
 }
 cohorts.push({name,summary:stats(samples.map(x=>x.totalMs)),samples});
}
const report={at:new Date().toISOString(),fundsSent:false,account:user,token:'ai-8.nearlytrade.near',chosen,results,cohorts,reductionP50:reduction(cohorts[0].summary.p50,cohorts[2].summary.p50),limitations:'Muestras pequeñas. Solo lectura; no mide firma real, envío, wrap, registración, confirmación ni visualización.'};
mkdirSync('data',{recursive:true});writeFileSync('data/benchmark-readonly.json',JSON.stringify(report,null,2));
const n=(value:any)=>value===null?'—':Number(value).toFixed(1);
writeFileSync('docs/BENCHMARK_RPC.md',`# Benchmark de lectura\n\nFecha UTC: ${report.at}. Sin envío de fondos. Tres muestras por RPC; cinco por escenario. Percentiles descriptivos, insuficientes para inferir estabilidad a largo plazo.\n\n| RPC | Errores / 3 | Status p50 | Cuenta p50 | Bloque p50 | wNEAR p50 | Access key p50 |\n|---|---:|---:|---:|---:|---:|---:|\n${results.map(r=>`| ${r.url} | ${r.errors} | ${n(r.methods.status.p50)} | ${n(r.methods.account.p50)} | ${n(r.methods.block.p50)} | ${n(r.methods.wnearBalance.p50)} | ${n(r.methods.accessKey.p50)} |`).join('\n')}\n\nTiempos en ms. RPC utilizado para el análisis completo: ${chosen}. Puede elegirse con BENCHMARK_RPC_URL; la comparación de métodos simples no garantiza ausencia de cuotas en el flujo completo. No se modifica automáticamente .env.\n\n| Análisis | p50 ms | p90 ms | p95 ms | Consultas por muestra |\n|---|---:|---:|---:|---|\n${cohorts.map(c=>`| ${c.name} | ${n(c.summary.p50)} | ${n(c.summary.p90)} | ${n(c.summary.p95)} | ${c.samples.map((s:any)=>s.calls).join(', ')} |`).join('\n')}\n\nCambio de mediana baseline→hot: ${n(report.reductionP50)}% de reducción (negativo significa más lento). El baseline ejecuta el análisis actual sin caché y con status por orden; compara políticas de caché, no reproduce el código anterior ni una compra completa.\n\n${report.limitations}\n\nDatos detallados locales: data/benchmark-readonly.json. Repetir con npm run benchmark.\n`);
console.log(JSON.stringify({chosen,cohorts:cohorts.map(c=>({name:c.name,...c.summary})),reductionP50:report.reductionP50,fundsSent:false},null,2));
