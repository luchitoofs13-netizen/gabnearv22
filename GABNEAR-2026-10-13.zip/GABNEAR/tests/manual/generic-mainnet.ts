// Prueba de SOLO LECTURA contra mainnet: descubrimiento y cotización de tokens de distintos launchpads.
// No firma ni envía nada. Uso: npm run test:generic
import 'dotenv/config';
import assert from 'node:assert/strict';
import {NearRpc} from '../../server/rpc.js';
import {analyze,preview} from '../../server/analysis.js';
import {refIndex} from '../../server/venues.js';
const rpc=new NearRpc(process.env.NEAR_RPC_URL||'https://free.rpc.fastnear.com',process.env.NEAR_RPC_READ_FALLBACK);
const status=await rpc.status();assert.equal(status.chain_id,'mainnet');
const samples=[
 ['Nearly (fábrica)','ai-8.nearlytrade.near'],
 ['meme.cooking','nene-2250.meme-cooking.near'],
 ['JustHoot','wth-0b2227.launchpad.justhoot.near'],
 ['Shore','shore-4lzt.launch.shoremarkets.near'],
 ['tknx','cocoon.tknx.near'],
 ['tkn.near','soul.tkn.near']
] as const;
const results:any[]=[];
for(const [label,token] of samples){
 const t0=performance.now();
 try{
  const p=await preview(rpc,token,'0.1',300);
  const a=await analyze(rpc,{url:token,amount:'0.1',slippageBps:300},{accountId:'',maxNear:'',maxBps:9900});
  const row={label,token,generic:p.generic,routes:p.routes.length,best:`${a.route.venue}:${a.route.poolId}`,expected:a.quotation?.expectedTokens,symbol:a.metadata.symbol,impactPct:p.risk?.impactBps==null?null:p.risk.impactBps/100,roundTripLossPct:p.risk?.roundTripLossBps==null?null:p.risk.roundTripLossBps/100,blocked:p.risk?.blocked??null,ms:Math.round(performance.now()-t0)};
  results.push(row);console.log(JSON.stringify(row));
  assert.equal(a.fundsSent,false);assert.ok(a.quotation&&BigInt(a.quotation.raw)>0n);
 }catch(error){const row={label,token,error:(error as Error).message,ms:Math.round(performance.now()-t0)};results.push(row);console.log(JSON.stringify(row));}
}
console.log(JSON.stringify({refIndexPools:refIndex.size,ok:results.filter(r=>!r.error).length,failed:results.filter(r=>r.error).length},null,1));
// Un token inexistente debe fallar con un mensaje claro, sin pools.
await assert.rejects(()=>preview(rpc,'noexiste-12345.tkn.near','0.1',300),/NEP-141|Sin pools|no existe|does not exist/i);
console.log('token inexistente rechazado correctamente');
