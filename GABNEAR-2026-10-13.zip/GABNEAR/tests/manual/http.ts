import assert from 'node:assert/strict';
const base='http://127.0.0.1:4317/api/';
async function post(path:string,body:object,headers:Record<string,string>={}){return fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json','X-Gabnear-Client':'local',...headers},body:JSON.stringify(body)});}
const health=await fetch(base+'health');assert.equal(health.status,200);const settings=await health.json();assert.equal(settings.chain,'mainnet');assert.equal(settings.liveEnabled,false);
const input={url:'https://nearly.trade/ai-8.nearlytrade.near',amount:'0.1',slippageBps:300};
assert.equal((await post('analyze',{...input,amount:'0'})).status,400);
assert.equal((await post('analyze',{...input,slippageBps:settings.config.maxBps+1})).status,400);
assert.equal((await post('analyze',input,{Origin:'https://evil.example'})).status,403);
assert.equal((await post('live',{})).status,409);
try{assert.equal((await post('emergency',{stopped:true})).status,200);assert.equal((await post('analyze',input)).status,409);}finally{await post('emergency',{stopped:false});}
const response=await post('analyze',input);assert.equal(response.status,200);const r=await response.json();assert.equal(r.status,'ANALYZED');assert.equal(r.fundsSent,false);const history=await(await fetch(base+'history')).json();assert.ok(history.some((x:any)=>x.id===r.id&&x.fundsSent===false));
console.log(JSON.stringify({passed:true,checks:8,totalMs:r.timings.totalMs,realFundsSent:false}));
