// Prueba de SOLO LECTURA contra mainnet y las APIs públicas de datos de mercado (DexScreener, GeckoTerminal, FastNEAR, Intear).
// Uso: npm run test:market        (opcional: MARKET_TOKEN=cuenta.del.token)
import 'dotenv/config';
import assert from 'node:assert/strict';
import {NearRpc} from '../../server/rpc.js';
import {getMarket,getCandles,getTrades,getLaunches,defaultDeps} from '../../server/market.js';
import {MarketHub} from '../../server/market-hub.js';
const rpc=new NearRpc(process.env.NEAR_RPC_URL||'https://free.rpc.fastnear.com',process.env.NEAR_RPC_READ_FALLBACK);
const deps=defaultDeps(),hub=new MarketHub();
const tokens=process.env.MARKET_TOKEN?[process.env.MARKET_TOKEN]:['ai-8.nearlytrade.near','nene-2250.meme-cooking.near'];
for(const token of tokens){
 console.log(`\n══ ${token}`);
 const t0=performance.now();
 const m=await getMarket(rpc,token,deps);
 console.log(`snapshot ${Math.round(performance.now()-t0)} ms · ${m.symbol} · ${m.generic?'genérico':'Nearly'} · pool ${m.route?.venue} ${m.route?.poolId}`);
 console.log({priceNear:m.priceNear,priceUsd:m.priceUsd,mcapUsd:m.marketCapUsd,liquidityUsd:m.liquidityUsd,supplyTokens:m.supplyTokens,nearUsd:m.nearUsd});
 console.log('stats',JSON.stringify(m.stats)?.slice(0,330));
 console.log('holders',JSON.stringify(m.holders?.top.slice(0,3).map(h=>`${h.account} ${h.pct}%${h.label?' ['+h.label+']':''}`)),'top10 sin pools:',m.holders?.top10Pct);
 console.log('warnings',m.warnings,'· fuentes',m.sources);
 assert.ok(m.priceNear&&m.priceNear>0,'precio on-chain');assert.ok(m.liquidityNear!==null&&m.liquidityNear>0,'liquidez on-chain');assert.ok(m.marketCapNear!==null&&m.marketCapNear>0,'market cap');
 for(const tf of ['5m','1h'] as const){
  const c=await getCandles(rpc,token,tf,'usd',hub,deps);
  console.log(`velas ${tf}: ${c.candles.length} (${c.source}, ${c.pool}) última:`,JSON.stringify(c.candles.at(-1)));
  assert.ok(c.candles.length>0,'velas '+tf);
 }
 const tr=await getTrades(rpc,token,5,hub,deps);
 console.log(`swaps recientes: ${tr.length}`,tr.slice(0,2).map(t=>`${new Date(t.ts).toISOString().slice(11,19)} ${t.side} ${(Number(t.nearRaw)/1e24).toFixed(3)} NEAR @ ${t.priceNear?.toExponential(3)}`));
}
const launches=await getLaunches(hub,deps);
console.log(`\nlanzamientos recientes (${launches.length}):`,launches.slice(0,5).map(l=>`${l.launchpad}: ${l.token}`));
console.log('\nOK');
hub.close();
