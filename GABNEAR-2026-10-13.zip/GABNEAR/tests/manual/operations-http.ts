import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
const base='http://127.0.0.1:4317/api/';
async function post(path:string,body:object){return fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json','X-Gabnear-Client':'local'},body:JSON.stringify(body)});}
const h=await (await fetch(base+'health')).json();assert.equal(h.liveEnabled,false,'No probar este script si el usuario habilitó REAL.');
const body={requestId:randomUUID(),side:'BUY',mode:'DRY RUN',url:'ai-8.nearlytrade.near',amount:'0.1',slippageBps:300};
const response=await post('operations',body);assert.equal(response.status,202);const submitted=await response.json();
const duplicate=await post('operations',body);assert.equal(duplicate.status,202);assert.equal((await duplicate.json()).id,submitted.id);
assert.equal((await post('operations',{...body,amount:'0.2'})).status,400);
let order:any;
for(let i=0;i<45;i++){order=await(await fetch(base+'operations/'+submitted.id)).json();if(!['QUEUED','PREPARING','SUBMITTING','SETTLING'].includes(order.status))break;await new Promise(r=>setTimeout(r,500));}
assert.equal(order.status,'ANALYZED');assert.equal(order.fundsSent,false);assert.ok(order.analysis.quotation.expectedTokens);assert.equal(order.transactions,undefined);
assert.equal((await post('operations',{...body,requestId:randomUUID(),mode:'REAL'})).status,400);
assert.equal((await post('operations',{...body,requestId:randomUUID(),slippageBps:h.config.maxBps+1})).status,400);
assert.equal((await post('operations',{...body,requestId:randomUUID(),side:'SELL',percentage:101})).status,400);
const history=await (await fetch(base+'history')).json();assert.equal(history.filter((r:any)=>r.requestId===body.requestId).length,1);
console.log(JSON.stringify({passed:true,checks:11,state:order.status,elapsedMs:order.elapsedMs,mainnetFundsSent:false}));
