// Mide la latencia REAL desde esta PC a cada RPC de NEAR (solo lecturas `status` y `block`) y recomienda el orden.
// Uso: npm run rpc:latency            (agrega los tuyos con RPC_CANDIDATES="https://a,https://b")
import 'dotenv/config';
const builtin=['https://near.drpc.org','https://free.rpc.fastnear.com','https://rpc.mainnet.near.org','https://near.lava.build','https://1rpc.io/near','https://endpoints.omniatech.io/v1/near/mainnet/public','https://near-mainnet.api.pocket.network'];
const extra=(process.env.RPC_CANDIDATES??'').split(',').map(s=>s.trim()).filter(Boolean);
const own=[process.env.NEAR_RPC_URL,process.env.NEAR_RPC_READ_FALLBACK,...(process.env.NEAR_RPC_BROADCAST??'').split(',')].map(s=>s?.trim()).filter(Boolean) as string[];
const urls=[...new Set([...own,...extra,...builtin])];
const SAMPLES=Number(process.env.RPC_SAMPLES)||8;
async function call(url:string,method:string,params:unknown){
 const t0=performance.now();
 const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(8000)});
 const body:any=await r.json();const ms=performance.now()-t0;
 if(!r.ok||body.error)throw new Error(body?.error?.message??body?.error?.data??`HTTP ${r.status}`);
 return {ms,result:body.result};
}
const median=(a:number[])=>[...a].sort((x,y)=>x-y)[Math.floor(a.length/2)];
const rows:any[]=[];
for(const url of urls){
 const times:number[]=[];let chain='',height=0,error='';
 try{
  const first=await call(url,'status',[]);chain=first.result.chain_id;height=first.result.sync_info.latest_block_height;
  for(let i=0;i<SAMPLES;i++)times.push((await call(url,'block',{finality:'optimistic'})).ms);
 }catch(e){error=(e as Error).message.slice(0,60);}
 rows.push({endpoint:url.replace(/^https:\/\//,'').slice(0,46),ok:!error&&chain==='mainnet',p50_ms:times.length?Math.round(median(times)):null,min_ms:times.length?Math.round(Math.min(...times)):null,max_ms:times.length?Math.round(Math.max(...times)):null,height,error:error||(chain&&chain!=='mainnet'?'no es mainnet':'')});
}
rows.sort((a,b)=>(a.ok===b.ok?0:a.ok?-1:1)||((a.p50_ms??1e9)-(b.p50_ms??1e9)));
console.table(rows);
// Un endpoint lento no sirve ni de respaldo para operar: se descartan los de más de 1,5 s.
const good=rows.filter(r=>r.ok&&(r.p50_ms??1e9)<1500);
const slow=rows.filter(r=>r.ok&&(r.p50_ms??0)>=1500).map(r=>r.endpoint);
if(slow.length)console.log(`\nDemasiado lentos para operar (> 1,5 s): ${slow.join(', ')}`);
if(good.length){
 console.log('\nSugerencia para .env (lectura primaria + fallback + difusión de transacciones a los 3 más rápidos):');
 console.log(`NEAR_RPC_URL=https://${good[0].endpoint}`);
 if(good[1])console.log(`NEAR_RPC_READ_FALLBACK=https://${good[1].endpoint}`);
 if(good.length>1)console.log(`NEAR_RPC_BROADCAST=${good.slice(1,3).map(g=>'https://'+g.endpoint).join(',')}`);
 console.log('\nNota: cada paso secuencial de una compra paga este RTT. Un VPS cerca de los validadores (EE. UU. este / Europa) lo baja de ~300 ms a ~20-60 ms.');
}
