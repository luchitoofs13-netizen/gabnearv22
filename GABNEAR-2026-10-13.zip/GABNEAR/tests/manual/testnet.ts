import {mkdirSync,existsSync,readFileSync,writeFileSync} from 'node:fs';
import {Account,KeyPair,KeyPairSigner,actions,teraToGas,nearToYocto,baseEncode,type KeyPairString} from 'near-api-js';
import {NearRpc} from '../../server/rpc.js';
import {encryptKey,decryptKey} from '../../server/secure-store.js';
import assert from 'node:assert/strict';
import {inspectOutcome} from '../../server/transactions.js';
import {percentageAmount} from '../../server/quotes.js';
mkdirSync('data',{recursive:true});
const statePath='data/testnet-account.json',keyPath='data/testnet-wallet.dpapi',reportPath='data/testnet-verification.json';
let state:any;
if(existsSync(statePath))state=JSON.parse(readFileSync(statePath,'utf8'));else{const key=KeyPair.fromRandom('ed25519');state={accountId:`gabnear-${Date.now()}.testnet`,publicKey:key.getPublicKey().toString()};await encryptKey(keyPath,key.toString());writeFileSync(statePath,JSON.stringify(state));}
const rpc=new NearRpc('https://test.rpc.fastnear.com');const network=await rpc.status();assert.equal(network.chain_id,'testnet');
let exists=false;try{await rpc.account(state.accountId);exists=true;}catch{}
const report:any={at:new Date().toISOString(),network:'testnet',accountId:state.accountId,realFundsSent:false,stages:[]};
const persist=()=>writeFileSync(reportPath,JSON.stringify(report,null,2));
if(!exists){
 try{const response=await fetch('https://helper.nearprotocol.com/account',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({newAccountId:state.accountId,newAccountPublicKey:state.publicKey}),signal:AbortSignal.timeout(20000)});report.faucetHttpStatus=response.status;persist();if(!response.ok)throw new Error(`Faucet respondió HTTP ${response.status}`);await new Promise(r=>setTimeout(r,3000));await rpc.account(state.accountId);}catch(e){report.blocked=(e as Error).message;persist();console.log(JSON.stringify({network:'testnet',accountId:state.accountId,blocked:report.blocked,realFundsSent:false}));process.exitCode=2;}
}
if(!process.exitCode){
 const signer=KeyPairSigner.fromSecretKey(await decryptKey(keyPath) as KeyPairString);const account=new Account(state.accountId,rpc.provider,signer);
 async function call(method:string,args:object,deposit:bigint,contract='wrap.testnet',gas=30){
  // Si hubo timeout en la corrida previa, reconciliar su hash antes de construir una nueva tx.
  if(existsSync('data/testnet-pending.json')){const pending=JSON.parse(readFileSync('data/testnet-pending.json','utf8'));const prior:any=await rpc.provider.viewTransactionStatus({txHash:pending.hash,accountId:state.accountId,waitUntil:'FINAL'});if(prior.final_execution_status!=='FINAL')throw new Error('Transacción testnet pendiente.');if(!pending.resolved)throw new Error('Transacción previa confirmada: revisar reporte antes de repetir la prueba.');}
  const tx=await account.createTransaction({receiverId:contract,publicKey:await signer.getPublicKey(),actions:[actions.functionCall(method,args,teraToGas(gas),deposit)]});const signed=await signer.signTransaction(tx);const hash=baseEncode(signed.txHash);writeFileSync('data/testnet-pending.json',JSON.stringify({hash,method,resolved:false}));
  const result:any=await rpc.deadline(rpc.provider.sendTransactionUntil(signed.signedTransaction,'FINAL'));assert.equal(result.final_execution_status,'FINAL');assert.ok(!result.status?.Failure);assert.ok(!result.receipts_outcome?.some((r:any)=>r.outcome?.status?.Failure));writeFileSync('data/testnet-pending.json',JSON.stringify({hash,method,resolved:true}));report.stages.push({method,hash,status:'FINAL'});persist();return result;
 }
 try{
  if(!await rpc.view('wrap.testnet','storage_balance_of',{account_id:state.accountId})){const bounds=await rpc.view('wrap.testnet','storage_balance_bounds');await call('storage_deposit',{account_id:state.accountId,registration_only:true},BigInt(bounds.min));}
  assert.ok(await rpc.view('wrap.testnet','storage_balance_of',{account_id:state.accountId}));
  const before=BigInt(await rpc.view('wrap.testnet','ft_balance_of',{account_id:state.accountId}));await call('near_deposit',{},nearToYocto('0.01'));const after=BigInt(await rpc.view('wrap.testnet','ft_balance_of',{account_id:state.accountId}));assert.equal(after-before,nearToYocto('0.01'));await call('near_withdraw',{amount:nearToYocto('0.01').toString()},1n);
  report.preparationPassed=true;persist();
  const factory='dcl.nearpad-dev-4804.testnet',dcl='dclv2.ref-dev.testnet';
  const launches=await rpc.view(factory,'get_launches',{from_index:0,limit:100});
  let launch:any=null,buyQuote:any=null;
  for(const l of launches.filter((x:any)=>x.step==='Done').slice(0,3)){try{const q=await rpc.view(dcl,'quote',{pool_ids:[l.pool_id],input_token:'wrap.testnet',output_token:l.token,input_amount:nearToYocto('0.01').toString(),tag:null});if(BigInt(q.amount)>0n){launch=l;buyQuote=q;break;}}catch{}}
  if(!launch)throw new Error('No se encontró pool Nearly testnet cotizable en los tres lanzamientos disponibles consultados.');
  report.taxValidation='La fábrica testnet usa una versión anterior sin get_tax. Esta prueba valida liquidación DCL; no habilita impuestos mainnet.';
  if(!await rpc.view(launch.token,'storage_balance_of',{account_id:state.accountId})){const bounds=await rpc.view(launch.token,'storage_balance_bounds');await call('storage_deposit',{account_id:state.accountId,registration_only:true},BigInt(bounds.min),launch.token);}
  const tokenBefore=BigInt(await rpc.view(launch.token,'ft_balance_of',{account_id:state.accountId}));await call('near_deposit',{},nearToYocto('0.01'));
  buyQuote=await rpc.view(dcl,'quote',{pool_ids:[launch.pool_id],input_token:'wrap.testnet',output_token:launch.token,input_amount:nearToYocto('0.01').toString(),tag:null});
  const bought=await call('ft_transfer_call',{receiver_id:dcl,amount:nearToYocto('0.01').toString(),msg:JSON.stringify({Swap:{pool_ids:[launch.pool_id],output_token:launch.token,min_output_amount:(BigInt(buyQuote.amount)*97n/100n).toString()}})},1n,'wrap.testnet',180);
  assert.equal(inspectOutcome(bought).state,'CONFIRMED');const received=BigInt(await rpc.view(launch.token,'ft_balance_of',{account_id:state.accountId}))-tokenBefore;assert.ok(received>0n);report.buy={token:launch.token,pool:launch.pool_id,receivedRaw:received.toString()};persist();
  report.sells=[];
  let remaining=received;
  for(const percentage of [50,99]){
   const balanceBefore=BigInt(await rpc.view(launch.token,'ft_balance_of',{account_id:state.accountId}));
   const amount=percentageAmount(balanceBefore,percentage);
   const sq=await rpc.view(dcl,'quote',{pool_ids:[launch.pool_id],input_token:launch.token,output_token:'wrap.testnet',input_amount:amount.toString(),tag:null});assert.ok(BigInt(sq.amount)>0n);
   const nativeBefore=BigInt((await rpc.account(state.accountId)).amount),wrappedBefore=BigInt(await rpc.view('wrap.testnet','ft_balance_of',{account_id:state.accountId}));
   const sold=await call('ft_transfer_call',{receiver_id:dcl,amount:amount.toString(),msg:JSON.stringify({Swap:{pool_ids:[launch.pool_id],output_token:'wrap.testnet',min_output_amount:(BigInt(sq.amount)*97n/100n).toString()}})},1n,launch.token,180);
   assert.equal(inspectOutcome(sold).state,'CONFIRMED');
   remaining=BigInt(await rpc.view(launch.token,'ft_balance_of',{account_id:state.accountId}));assert.equal(remaining,balanceBefore-amount);
   const nativeAfter=BigInt((await rpc.account(state.accountId)).amount),wrappedAfter=BigInt(await rpc.view('wrap.testnet','ft_balance_of',{account_id:state.accountId}));
   const burnt=[sold.transaction_outcome,...sold.receipts_outcome].reduce((sum:bigint,r:any)=>sum+BigInt(r.outcome?.tokens_burnt??'0'),0n);
   const recovered=wrappedAfter>wrappedBefore?wrappedAfter-wrappedBefore:nativeAfter-nativeBefore+burnt+1n;
   assert.ok(recovered>=BigInt(sq.amount)*97n/100n);
   report.sells.push({percentage,amountRaw:amount.toString(),remainingRaw:remaining.toString(),receivedRaw:recovered.toString(),nativeDeltaIncludingGas:(nativeAfter-nativeBefore).toString(),wnearDelta:(wrappedAfter-wrappedBefore).toString(),quoteRaw:sq.amount,hash:report.stages.at(-1).hash});persist();
  }
  assert.ok(remaining>0n);report.remainingRaw=remaining.toString();
  report.passed=true;report.swapValidated=true;persist();console.log(JSON.stringify(report,null,2));
 }catch(e){report.blocked=(e as Error).message;persist();console.log(JSON.stringify({blocked:report.blocked,realFundsSent:false}));process.exitCode=2;}
}
