import assert from 'node:assert/strict';
const base='http://127.0.0.1:4317/api/';
const original=await(await fetch(base+'wallet')).json();
async function post(action:string,body:object){return fetch(base+'wallet/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-Gabnear-Client':'local'},body:JSON.stringify(body)});}
const invalid=await post('import',{accountId:'sample.near',seed:'invalid phrase',password:'synthetic-test-password'});assert.equal(invalid.status,400);assert.equal((await invalid.json()).error,'Frase semilla NEAR inválida.');
if(!original.accountId){try{const response=await post('connect',{accountId:'nearlytrade.near'});assert.equal(response.status,200);const state=await response.json();assert.equal(state.accountId,'nearlytrade.near');assert.equal(state.unlocked,false);const balances=await(await fetch(base+'balances')).json();assert.ok(balances.near!==null);}finally{await post('disconnect',{});}}
console.log(JSON.stringify({passed:true,publicMainnetConnection:true,invalidSeedRejected:true,realFundsSent:false}));
