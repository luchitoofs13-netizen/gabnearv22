import test,{afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {Fetcher} from '../server/fetcher.js';
import {parseSwap,candlesFromTrades,priceNear,IntearStream,TIMEFRAMES,quoteToNearRaw,type Trade,type WsLike} from '../server/trades.js';
import {MarketHub,launchpadOf,type HubEvent} from '../server/market-hub.js';
import {priceInQuote,quoteNearPrice,getMarket,getWatch,getCandles,getTrades,parseDexScreener,parseHolders,parseGeckoOhlcv,parseGeckoTrades,geckoPoolAddress,poolLiquidityNear,primaryRoute,clearMarketCache,type MarketDeps} from '../server/market.js';
import {clearRouteCache,refIndex,type Route} from '../server/venues.js';
import {units} from '../server/validation.js';
import type {NearRpc} from '../server/rpc.js';

const TOKEN='gen.tkn.near',W='wrap.near',ME='me.near',DCL='dclv2.ref-labs.near',REF='v2.ref-finance.near';
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
afterEach(()=>{clearMarketCache();clearRouteCache();refIndex.reset();});

// ── Fetcher ───────────────────────────────────────────────────────────────────────────────────────────
function fakeFetch(handler:(url:string)=>any,log:string[]=[]){return (async(url:string)=>{log.push(url);const body=handler(url);if(body instanceof Error)return {ok:false,status:500,json:async()=>({})} as any;return {ok:true,status:200,json:async()=>body} as any;}) as unknown as typeof fetch;}
test('Fetcher: caché con TTL, deduplica simultáneos y jamás cachea un fallo',async()=>{
 const log:string[]=[];let fail=true;const f=new Fetcher('X',0,1000,fakeFetch(()=>fail?new Error('x'):{ok:1},log));
 await assert.rejects(()=>f.json('http://a',{ttl:1000}),/HTTP 500/);fail=false;
 const [a,b]=await Promise.all([f.json('http://a',{ttl:1000}),f.json('http://a',{ttl:1000})]);assert.deepEqual(a,{ok:1});assert.deepEqual(b,{ok:1});assert.equal(log.length,2);
 await f.json('http://a',{ttl:1000});assert.equal(log.length,2,'dentro del TTL no vuelve a pedir');
 const g=new Fetcher('X',0,1000,fakeFetch(()=>({v:1}),log));await g.json('http://b',{ttl:20});await sleep(40);await g.json('http://b',{ttl:20});assert.equal(log.filter(u=>u==='http://b').length,2,'vencido el TTL pide de nuevo');
});
test('Fetcher: espacia los pedidos (límite por minuto de las APIs gratuitas) y respeta el plazo',async()=>{
 const stamps:number[]=[];const f=new Fetcher('X',60,1000,(async()=>{stamps.push(Date.now());return {ok:true,status:200,json:async()=>({})} as any;}) as unknown as typeof fetch);
 await Promise.all([f.json('http://1',{ttl:0}),f.json('http://2',{ttl:0}),f.json('http://3',{ttl:0})]);
 // minInterval 60 ms: con jitter de timers se tolera hasta la mitad; sin espaciado las tres salidas serían simultáneas (≈0 ms).
 assert.ok(stamps[1]-stamps[0]>=30&&stamps[2]-stamps[1]>=30&&stamps[2]-stamps[0]>=90,`separación ${stamps.map((s,i)=>i?s-stamps[i-1]:0)}`);
 const slow=new Fetcher('Lenta',0,50,((_u:string,init:any)=>new Promise((_r,reject)=>{init.signal.addEventListener('abort',()=>reject(new Error('abortado')));})) as unknown as typeof fetch);
 await assert.rejects(()=>slow.json('http://s'),/abortado|aborted|timeout/i);
});

// ── Swaps y velas ─────────────────────────────────────────────────────────────────────────────────────
const swap=(over:any={})=>({balance_changes:{[TOKEN]:'5000000000000000000',[W]:'-1000000000000000000000000'},block_height:100,block_timestamp_nanosec:'1700000000123456789',receipt_id:'R1',trader:'alice.near',transaction_id:'TX1',...over});
test('parseSwap: compra, venta, precio con BigInt, trader propio y descarte de lo que no es swap token↔wNEAR',()=>{
 const buy=parseSwap(swap(),TOKEN,18,ME)!;
 assert.equal(buy.side,'BUY');assert.equal(buy.tokenRaw,'5000000000000000000');assert.equal(buy.nearRaw,'1000000000000000000000000');assert.equal(buy.ts,1700000000123);assert.equal(buy.mine,false);
 assert.ok(Math.abs(buy.priceNear!-0.2)<1e-12);                                      // 1 NEAR por 5 tokens
 const sell=parseSwap(swap({balance_changes:{[TOKEN]:'-5000000000000000000',[W]:'1000000000000000000000000'},trader:ME}),TOKEN,18,ME)!;
 assert.equal(sell.side,'SELL');assert.equal(sell.mine,true);
 assert.equal(parseSwap(swap(),TOKEN,undefined,ME)!.priceNear,null,'sin decimales no se inventa precio');
 // precio minúsculo sin perder precisión
 const tiny=parseSwap(swap({balance_changes:{[TOKEN]:'1000000000000000000000000',[W]:'-1000000000000000000000'}}),TOKEN,18)!;assert.ok(Math.abs(tiny.priceNear!-1e-9)/1e-9<1e-9);
 for(const bad of [swap({balance_changes:{[TOKEN]:'5',[W]:'7'}}),swap({balance_changes:{[TOKEN]:'0',[W]:'-1'}}),swap({balance_changes:{[TOKEN]:'5'}}),swap({balance_changes:{other:'5',[W]:'-1'}}),swap({balance_changes:null}),swap({block_timestamp_nanosec:'x'}),swap({trader:undefined}),null,undefined,'texto'])assert.equal(parseSwap(bad,TOKEN,18),null);
 assert.equal(priceNear(0n,1n,18),null);assert.equal(priceNear(1n,0n,18),null);assert.equal(priceNear(1n,1n,99),null);
});
function trade(ts:number,price:number,near=1,id=String(ts)):Trade{return {id,ts,side:'BUY',tokenRaw:'1',nearRaw:units(String(near)).toString(),priceNear:price,trader:'a.near',tx:id,block:1,mine:false};}
test('velas desde swaps: buckets por timeframe, OHLC continuo, volumen y conversión a USD; tolera desorden',()=>{
 const t=[trade(61000,3),trade(10000,1),trade(59000,2),trade(130000,5,2),trade(70000,4)];     // minuto 0: 1,2 · minuto 1: 3,4 · minuto 2: 5
 const c=candlesFromTrades(t,60);
 assert.deepEqual(c.map(x=>x.time),[0,60,120]);
 assert.deepEqual([c[0].open,c[0].high,c[0].low,c[0].close],[1,2,1,2]);
 assert.deepEqual([c[1].open,c[1].high,c[1].low,c[1].close],[2,4,2,4],'la apertura es el cierre anterior (sin huecos de precio)');
 assert.equal(c[0].volume,2);assert.equal(c[2].volume,2);
 const usd=candlesFromTrades(t,60,5);assert.equal(usd[0].high,10);assert.equal(usd[0].volume,10);
 assert.deepEqual(candlesFromTrades([],60),[]);assert.deepEqual(candlesFromTrades([{...trade(1,1),priceNear:null}],60),[]);
 assert.equal(TIMEFRAMES['1h'],3600);
});
test('parseGeckoOhlcv descarta filas inválidas y ordena; parseGeckoTrades interpreta compra/venta y descarta otros pares',()=>{
 const c=parseGeckoOhlcv({data:{attributes:{ohlcv_list:[[200,2,3,1,2.5,10],[100,1,2,1,1.5,5],[300,0,1,1,1,1],[400,'x',1,1,1,1],[500,1,2,0.5,1,'y']]}}});
 assert.deepEqual(c.map(x=>x.time),[100,200]);assert.deepEqual(parseGeckoOhlcv(null),[]);assert.deepEqual(parseGeckoOhlcv({data:{attributes:{}}}),[]);
 const row=(over:any)=>({attributes:{tx_hash:'H1',tx_from_address:'bob.near',block_number:7,block_timestamp:'2026-10-12T10:32:41Z',kind:'buy',from_token_address:W,to_token_address:TOKEN,from_token_amount:'2',to_token_amount:'4000',...over}});
 const t=parseGeckoTrades({data:[row({}),row({tx_hash:'H2',kind:'sell',from_token_address:TOKEN,to_token_address:W,from_token_amount:'100',to_token_amount:'0.5'}),row({tx_hash:'H3',to_token_address:'otro.near'}),row({tx_hash:'H4',kind:'raro'}),row({tx_hash:'H5',to_token_amount:'0'}),{attributes:{}}]},TOKEN,18);
 assert.deepEqual(t.map(x=>[x.tx,x.side]),[['H1','BUY'],['H2','SELL']]);
 assert.equal(t[0].nearRaw,units('2').toString());assert.equal(t[0].tokenRaw,units('4000',18).toString());assert.ok(Math.abs(t[0].priceNear!-0.0005)<1e-12);assert.equal(t[1].trader,'bob.near');
});

// ── WebSocket de Intear ───────────────────────────────────────────────────────────────────────────────
class FakeWs{static all:FakeWs[]=[];sent:string[]=[];closed=false;onopen:any;onmessage:any;onerror:any;onclose:any;constructor(readonly url:string){FakeWs.all.push(this);}
 send(d:string){this.sent.push(d);} close(){this.closed=true;setTimeout(()=>this.onclose?.(),0);} open(){this.onopen?.();} push(data:unknown){this.onmessage?.({data:typeof data==='string'?data:JSON.stringify(data)});}}
const create=(url:string)=>new FakeWs(url) as any;
test('IntearStream: filtro vacío al abrir, solo arreglos de eventos, mensajes ilegibles no cortan, reconecta con backoff y se detiene',async()=>{
 FakeWs.all=[];const got:any[]=[];const s=new IntearStream('trade_swap',e=>got.push(...e),{create,initialBackoffMs:10,maxBackoffMs:40});
 s.start();s.start();assert.equal(FakeWs.all.length,1,'start es idempotente');assert.equal(FakeWs.all[0].url,'wss://ws-events-v3.intear.tech/events/trade_swap');
 const a=FakeWs.all[0];a.open();assert.equal(s.connected,true);assert.deepEqual(JSON.parse(a.sent[0]),{And:[]});
 a.push([{x:1}]);a.push('basura{');a.push({no:'arreglo'});a.push([{x:2}]);assert.deepEqual(got,[{x:1},{x:2}]);
 a.close();await sleep(60);assert.equal(s.connected,false);assert.equal(FakeWs.all.length,2,'reconectó solo');
 FakeWs.all[1].open();assert.equal(s.connected,true);
 s.stop();await sleep(30);assert.equal(FakeWs.all.length,2,'detenido no reconecta');assert.equal(FakeWs.all[1].closed,true);
});
test('IntearStream: un stream mudo (sin mensajes) se considera caído y se reabre',async()=>{
 FakeWs.all=[];const s=new IntearStream('trade_swap',()=>{},{create,staleMs:60,watchIntervalMs:20,initialBackoffMs:10});
 s.start();FakeWs.all[0].open();await sleep(200);
 assert.ok(FakeWs.all.length>=2,'reabrió tras el silencio');s.stop();
 FakeWs.all=[];const throwing=new IntearStream('x',()=>{},{create:()=>{throw new Error('sin red');},initialBackoffMs:10});throwing.start();await sleep(40);throwing.stop();
});

// ── MarketHub ─────────────────────────────────────────────────────────────────────────────────────────
test('MarketHub: un solo socket para todos, filtra por token, marca los swaps propios y deduplica',async()=>{
 FakeWs.all=[];const hub=new MarketHub({create,graceMs:30,initialBackoffMs:10});const got:HubEvent[]=[],other:HubEvent[]=[];
 const off=hub.subscribe([TOKEN],false,ME,e=>got.push(e));const off2=hub.subscribe([TOKEN],false,'bob.near',e=>other.push(e));
 hub.watch(TOKEN,18);assert.equal(FakeWs.all.length,1,'los launches no se piden si nadie los quiere');
 const ws=FakeWs.all[0];ws.open();
 ws.push([swap({trader:ME,receipt_id:'A',transaction_id:'TA'}),swap({receipt_id:'B',transaction_id:'TB'}),swap({receipt_id:'B',transaction_id:'TB'}),swap({balance_changes:{'otro.near':'5',[W]:'-1'},receipt_id:'C'})]);
 assert.equal(got.length,2);assert.deepEqual(got.map(e=>e.type==='trade'&&e.data.mine),[true,false]);assert.deepEqual(other.map(e=>e.type==='trade'&&e.data.mine),[false,false]);
 assert.equal(hub.recent(TOKEN).length,2);assert.ok(hub.recent(TOKEN,1).length===1);
 assert.equal((got[0] as any).data.priceNear!>0,true,'con decimales conocidos hay precio');
 off();off2();await sleep(80);assert.equal(FakeWs.all[0].closed,true,'sin clientes el socket se cierra tras la gracia');hub.close();
});
test('MarketHub: lanzamientos filtrados por launchpad, sin duplicados, solo para quien los pidió',async()=>{
 FakeWs.all=[];const hub=new MarketHub({create,graceMs:30});const withL:HubEvent[]=[],without:HubEvent[]=[];
 hub.subscribe([],true,'',e=>withL.push(e));hub.subscribe([],false,'',e=>without.push(e));
 const launches=FakeWs.all.find(w=>w.url.endsWith('newtoken_nep141'))!;launches.open();
 const ev=(account_id:string,tx='T')=>({account_id,block_timestamp_nanosec:'1700000000000000000',transaction_id:tx});
 launches.push([ev('nuevo.meme-cooking.near'),ev('nuevo.meme-cooking.near'),ev('eth-0xabc.omft.near'),ev('x.nearlytrade.near'),ev('y.launchpad.justhoot.near')]);
 assert.deepEqual(withL.map(e=>e.type==='launch'&&e.data.launchpad),['meme.cooking','Nearly','JustHoot']);assert.equal(without.length,0);
 assert.equal(hub.recentLaunches().length,3);assert.equal(launchpadOf('a.tknx.near'),'tknx');assert.equal(launchpadOf('wrap.near'),null);hub.close();
});
test('MarketHub.loadLaunches: mezcla la lista HTTP con los recibidos en vivo, ordenada y sin duplicados',async()=>{
 const hub=new MarketHub({create});const f=new Fetcher('I',0,1000,fakeFetch(()=>[{account_id:'b.tkn.near',block_timestamp_nanosec:'2000000000000000000'},{account_id:'a.tknx.near',block_timestamp_nanosec:'1000000000000000000'},{account_id:'x.omft.near',block_timestamp_nanosec:'3000000000000000000'}]));
 await hub.loadLaunches(f);assert.deepEqual(hub.recentLaunches().map(l=>l.token),['b.tkn.near','a.tknx.near']);await hub.loadLaunches(f);assert.equal(hub.recentLaunches().length,2);
});

// ── Snapshot de mercado ───────────────────────────────────────────────────────────────────────────────
function marketRpc(){
 const rpc:any={status:async()=>({chain_id:'mainnet'}),mainnet:async()=>({chain_id:'mainnet'}),account:async()=>({code_hash:'abc'}),
  view:async(c:string,m:string,a:any)=>{
   if(m==='ft_metadata')return {spec:'ft-1.0.0',name:'Gen',symbol:'GEN',decimals:c===W?24:18};
   if(m==='ft_total_supply')return units('1000000000',18).toString();
   if(c==='nearlytrade.near')return null;
   if(c===DCL&&m==='get_pools')return a.pool_ids.map((id:string)=>id.endsWith('|10000')?{pool_id:id,token_x:TOKEN,token_y:W,state:'Running',fee:10000,liquidity:'1',current_point:1,total_x:units('100000000',18).toString(),total_y:units('10').toString()}:null);
   if(c===DCL&&m==='quote')return {amount:(BigInt(a.input_amount)*1100n).toString()};
   if(c===REF&&m==='get_number_of_pools')return 1;
   if(c===REF&&m==='get_pools')return [{pool_kind:'SIMPLE_POOL',token_account_ids:[TOKEN,W],amounts:[units('1000000000',18).toString(),units('50').toString()],total_fee:30}];
   if(c===REF&&m==='get_pool_by_ids')return [{pool_kind:'SIMPLE_POOL',token_account_ids:[TOKEN,W],amounts:[units('1000000000',18).toString(),units('50').toString()],total_fee:30}];
   if(c===REF&&m==='get_return')return (BigInt(a.amount_in)*1000n).toString();
   throw new Error(`mock ${c}.${m}`);
  }};
 return rpc as NearRpc;
}
function deps(over:Partial<Record<'gecko'|'dex'|'fast'|'intear',(url:string)=>any>>={}):MarketDeps{
 const mk=(name:string,h:(u:string)=>any)=>new Fetcher(name,0,1000,fakeFetch(h));
 return {gecko:mk('G',over.gecko??(()=>new Error('sin gecko'))),dex:mk('D',over.dex??(()=>new Error('sin dex'))),fast:mk('F',over.fast??(()=>new Error('sin fast'))),intear:mk('I',over.intear??(()=>[])),nearUsd:async()=>({usd:5})};
}
test('getMarket: precio medio on-chain (descuenta fee), supply, market cap, liquidez de cada pool y USD',async()=>{
 const m=await getMarket(marketRpc(),TOKEN,deps());
 assert.equal(m.symbol,'GEN');assert.equal(m.generic,true);assert.equal(m.route!.venue,'DCL');             // DCL da más salida (1100 vs 1000)
 // 0,1 NEAR → 1,1e8 tokens; con fee 1% el precio medio es 0,099/1,1e8 = 9e-10 NEAR
 assert.ok(Math.abs(m.priceNear!-9e-10)/9e-10<1e-6,String(m.priceNear));assert.equal(m.nearUsd,5);assert.ok(Math.abs(m.priceUsd!-4.5e-9)/4.5e-9<1e-6);
 assert.equal(m.supplyTokens,1e9);assert.ok(Math.abs(m.marketCapNear!-0.9)/0.9<1e-6);assert.ok(Math.abs(m.marketCapUsd!-4.5)/4.5<1e-6);
 const v1=m.pools.find(p=>p.venue==='REF_V1')!,dcl=m.pools.find(p=>p.venue==='DCL')!;
 assert.equal(v1.liquidityNear,100);                                                                       // 2 × 50 NEAR
 assert.ok(Math.abs(dcl.liquidityNear!-(10+1e8*9e-10))/10.09<1e-6);                                       // wNEAR + tokens al precio
 assert.ok(Math.abs(m.liquidityNear!-(100+10.09))<1e-6);assert.equal(dcl.best,true);assert.equal(v1.best,false);
 assert.equal(m.stats,null);assert.equal(m.holders,null);assert.deepEqual(m.sources,{onchain:'ok',dexscreener:'error',holders:'error'});   // las APIs caídas no rompen el snapshot
 assert.ok(m.warnings.some(w=>/menos del 2%|muy baja/.test(w))===false);
});
test('parseDexScreener usa el par principal (no suma pools chicos ni pares donde el token es la cotización) y parseHolders separa contratos de liquidez, con advertencias',async()=>{
 const mk=(over:any)=>({chainId:'near',baseToken:{address:TOKEN},quoteToken:{address:W},...over});
 const body={pairs:[mk({url:'u1',liquidity:{usd:100},volume:{h24:10,h1:1},txns:{h24:{buys:3,sells:1}},priceChange:{h24:5},pairCreatedAt:2000}),
  mk({url:'u2',pairAddress:'main',priceUsd:'0.5',liquidity:{usd:900},volume:{h24:5,h1:2},txns:{h24:{buys:2,sells:2}},priceChange:{h24:-7},pairCreatedAt:1000,fdv:50,marketCap:40}),
  {chainId:'near',baseToken:{address:'otro.near'},quoteToken:{address:TOKEN},liquidity:{usd:50000},volume:{h24:777},txns:{h24:{buys:9,sells:9}},pairCreatedAt:1},   // el token es la cotización: no cuenta
  {chainId:'eth',liquidity:{usd:1e9},volume:{h24:1e9}}]};
 const s=parseDexScreener(body,TOKEN)!;assert.equal(s.pairs,2);assert.equal(s.volumeUsd.h24,5);assert.equal(s.liquidityUsd,1000);assert.deepEqual(s.txns.h24,{buys:2,sells:2});assert.equal(s.priceChange.h24,-7);assert.equal(s.pairCreatedAt,1000);
 assert.equal(s.url,'u2');assert.equal(s.priceUsd,0.5);assert.equal(s.fdvUsd,50);assert.equal(s.marketCapUsd,40);
 assert.equal(parseDexScreener(body)!.pairs,3);                                                                  // sin token: todos los pares de NEAR
 assert.equal(parseDexScreener({pairs:[{chainId:'eth'}]}),null);assert.equal(parseDexScreener(null),null);
const supply=units('1000',0);
 const h=parseHolders({accounts:[{account_id:REF,balance:'250'},{account_id:'whale.near',balance:'350'},{account_id:'b.near',balance:'100'},{account_id:'c.near',balance:'x'}]},supply)!;
 assert.equal(h.topHolder,'whale.near');assert.equal(h.topHolderPct,35);assert.equal(h.inPoolsPct,25);assert.equal(h.top10Pct,45);assert.equal(h.top[0].label,'Ref v1 (pools)');
 assert.equal(parseHolders({accounts:[]},supply),null);assert.equal(parseHolders({accounts:[{account_id:'a',balance:'1'}]},null),null);
 const m=await getMarket(marketRpc(),TOKEN,deps({dex:()=>body,fast:()=>({accounts:[{account_id:'whale.near',balance:units('400000000',18).toString()}]})}));
 assert.equal(m.stats!.volumeUsd.h24,5);assert.equal(m.holders!.topHolderPct,40);assert.ok(m.warnings.some(w=>/Un solo holder \(whale.near\) tiene 40%/.test(w)));
});
test('liquidez y rutas: v1 = 2×reserva; DCL = quote + tokens al precio; pool de Gecko según el venue',()=>{
 const v1:Route={venue:'REF_V1',poolId:'8943',receiver:REF,fee:30,quote:W,token:TOKEN,info:{reserveQuote:units('5').toString()}};
 const dcl:Route={venue:'DCL',poolId:`${TOKEN}|${W}|10000`,receiver:DCL,fee:100,quote:W,token:TOKEN,info:{totalQuote:units('4').toString(),totalToken:units('10',18).toString()}};
 assert.equal(poolLiquidityNear(v1,null,18),10);assert.equal(poolLiquidityNear(dcl,0.5,18),9);assert.equal(poolLiquidityNear(dcl,null,18),4);assert.equal(poolLiquidityNear({...v1,info:{}},1,18),null);
 assert.equal(geckoPoolAddress(v1),'refv1-8943');assert.equal(geckoPoolAddress(dcl),`refv2-${TOKEN}:${W}:10000`);
 assert.equal(primaryRoute([v1,dcl])!.venue,'REF_V1');assert.equal(primaryRoute([]),null);
});

// ── Velas y swaps de un token ─────────────────────────────────────────────────────────────────────────
test('getCandles: usa GeckoTerminal con la unidad y moneda pedidas; si falla, velas propias desde los swaps',async()=>{
 const urls:string[]=[];
 const gecko=(u:string)=>{urls.push(u);return {data:{attributes:{ohlcv_list:[[120,2,3,1,2,9],[60,1,2,1,2,5]]}}};};
 const a=await getCandles(marketRpc(),TOKEN,'15m','near',undefined,deps({gecko}));
 assert.equal(a.source,'geckoterminal');assert.deepEqual(a.candles.map(c=>c.time),[60,120]);
 assert.match(urls[0],/pools\/refv1-0\/ohlcv\/minute\?aggregate=15&limit=300&currency=token/);          // gana el pool con más liquidez (Ref v1)
 await getCandles(marketRpc(),TOKEN,'4h','usd',undefined,deps({gecko}));assert.match(urls[1],/ohlcv\/hour\?aggregate=4&limit=300&currency=usd/);
 const events=[swap({balance_changes:{[TOKEN]:'5000000000000000000',[W]:'-1000000000000000000000000'},block_timestamp_nanosec:'60000000000',transaction_id:'T1',receipt_id:'R1'}),swap({balance_changes:{[TOKEN]:'-5000000000000000000',[W]:'2000000000000000000000000'},block_timestamp_nanosec:'70000000000',transaction_id:'T2',receipt_id:'R2'})];
 const b=await getCandles(marketRpc(),TOKEN,'1m','usd',undefined,deps({intear:()=>events}));
 assert.equal(b.source,'trades');assert.equal(b.candles.length,1);assert.ok(Math.abs(b.candles[0].open-1)<1e-9,'0,2 NEAR/token × 5 USD');assert.ok(Math.abs(b.candles[0].high-2)<1e-9);
 const none=await getCandles(marketRpc(),TOKEN,'1m','near',undefined,deps());assert.equal(none.source,'none');assert.deepEqual(none.candles,[]);
 await assert.rejects(()=>getCandles(marketRpc(),TOKEN,'7m' as any,'usd'),/Timeframe/);
});
test('getTrades: combina swaps en vivo, Intear y GeckoTerminal sin duplicar por hash, marca los propios y ordena',async()=>{
 const hub=new MarketHub({create});FakeWs.all=[];
 hub.watch(TOKEN,18);
 const gt={data:[{attributes:{tx_hash:'TX-G',tx_from_address:ME,block_timestamp:'2026-10-12T10:00:03Z',kind:'buy',from_token_address:W,to_token_address:TOKEN,from_token_amount:'1',to_token_amount:'1000'}},{attributes:{tx_hash:'TX-I',tx_from_address:'z.near',block_timestamp:'2026-10-12T10:00:01Z',kind:'buy',from_token_address:W,to_token_address:TOKEN,from_token_amount:'1',to_token_amount:'1000'}}]};
 const intear=[swap({transaction_id:'TX-I',receipt_id:'RI',block_timestamp_nanosec:String(Date.parse('2026-10-12T10:00:01Z')*1_000_000)}),swap({transaction_id:'TX-OLD',receipt_id:'RO',block_timestamp_nanosec:String(Date.parse('2026-10-12T09:00:00Z')*1_000_000)})];
 const t=await getTrades(marketRpc(),TOKEN,10,hub,deps({gecko:()=>gt,intear:()=>intear}),ME);
 assert.deepEqual(t.map(x=>x.tx),['TX-G','TX-I','TX-OLD']);assert.equal(t[0].mine,true);assert.equal(t[1].id,'RI','gana la fuente con precio (Intear) sobre Gecko');
 assert.equal((await getTrades(marketRpc(),TOKEN,2,hub,deps({gecko:()=>gt,intear:()=>intear}),ME)).length,2);
 assert.deepEqual(await getTrades(marketRpc(),TOKEN,5,undefined,deps()),[],'sin fuentes devuelve vacío, no error');
 hub.close();
});

test('getWatch: precio y variación de varios tokens; uno que falla no tumba a los demás; sin pedir holders; máximo 8',async()=>{
 clearMarketCache();
 let holdersAsked=0;
 const dex=()=>({pairs:[{chainId:'near',baseToken:{address:TOKEN},liquidity:{usd:900},priceChange:{h24:12.5}}]});
 const rows=await getWatch(marketRpc(),[TOKEN,'roto.tkn.near'],deps({dex,fast:()=>{holdersAsked++;return {accounts:[]};}}));
 assert.equal(rows.length,2);assert.equal(rows[0].token,TOKEN);assert.equal(rows[0].symbol,'GEN');assert.equal(rows[0].change24h,12.5);assert.ok(rows[0].priceUsd!>0);assert.ok(rows[0].liquidityUsd!>0);
 assert.equal(holdersAsked,0);assert.ok(rows[1].error);assert.equal(rows[1].priceUsd,undefined);
 const many=await getWatch(marketRpc(),Array.from({length:12},(_,i)=>'t'+i+'.tkn.near'),deps());assert.equal(many.length,8);
});

test('quote distinto de wNEAR (p. ej. RHEA con 18 decimales): precio y liquidez se miden en ese quote; wNEAR vale 1',async()=>{
 // 2 RHEA entran, salen 4 tokens (ambos de 18 dec.) → 0,5 RHEA por token; con 24 decimales de quote el resultado es el mismo número
 assert.equal(priceInQuote(units('2',18),units('4',18),18,18),0.5);assert.equal(priceInQuote(units('2'),units('4',18),18,24),0.5);
 assert.equal(priceInQuote(0n,1n,18,18),null);assert.equal(priceInQuote(1n,0n,18,18),null);assert.equal(priceInQuote(1n,1n,99,18),null);
 const dcl:Route={venue:'DCL',poolId:'p',receiver:DCL,fee:100,quote:'rhea.near',token:TOKEN,info:{totalQuote:units('1000',18).toString(),totalToken:units('4000',18).toString()}};
 assert.equal(poolLiquidityNear(dcl,0.5,18,18),1000+4000*0.5);                                                      // en unidades de RHEA, no 1e-6 de eso
 const v1:Route={venue:'REF_V1',poolId:'1',receiver:REF,fee:30,quote:'rhea.near',token:TOKEN,info:{reserveQuote:units('250',18).toString()}};
 assert.equal(poolLiquidityNear(v1,null,18,18),500);
 assert.equal(await quoteNearPrice(marketRpc(),W),1);
});

test('swaps de un par que NO es wNEAR (p. ej. RHEA): se leen contra ese token y se convierten a NEAR al precio del quote',()=>{
 const RHEA='token.rhealab.near',q={id:RHEA,decimals:18,near:0.0146};
 const ev=(dT:string,dQ:string)=>({balance_changes:{[TOKEN]:dT,[RHEA]:dQ},block_timestamp_nanosec:'1700000000000000000',trader:'a.near',transaction_id:'TX'});
 const buy=parseSwap(ev(units('1000',18).toString(),'-'+units('10',18).toString()),TOKEN,18,'',q)!;
 assert.equal(buy.side,'BUY');assert.equal(buy.tokenRaw,units('1000',18).toString());assert.equal(buy.nearRaw,units('0.146').toString());          // 10 RHEA × 0,0146
 assert.ok(Math.abs(buy.priceNear!-0.000146)/0.000146<1e-9);
 assert.equal(parseSwap(ev('-'+units('50',18).toString(),units('1',18).toString()),TOKEN,18,'',q)!.side,'SELL');
 assert.equal(parseSwap(ev(units('1000',18).toString(),'-'+units('10',18).toString()),TOKEN,18),null);                                                    // sin quote: lo trata como wNEAR y no hay cambio de wNEAR
 assert.equal(parseSwap(ev(units('1000',18).toString(),'-'+units('10',18).toString()),TOKEN,18,'',{...q,near:0}),null);                                    // precio del quote desconocido: no inventa montos
 assert.equal(quoteToNearRaw(5n,{id:'wrap.near',decimals:24,near:1}),5n);
 const g=parseGeckoTrades({data:[{attributes:{tx_hash:'H',kind:'buy',from_token_address:RHEA,to_token_address:TOKEN,from_token_amount:'10',to_token_amount:'1000',block_timestamp:'2026-10-12T10:00:00Z',tx_from_address:'b.near',block_number:1}}]},TOKEN,18,q);
 assert.equal(g.length,1);assert.equal(g[0].nearRaw,units('0.146').toString());assert.equal(parseGeckoTrades({data:[{attributes:{tx_hash:'H',kind:'buy',from_token_address:RHEA,to_token_address:TOKEN,from_token_amount:'10',to_token_amount:'1000',block_timestamp:'2026-10-12T10:00:00Z'}}]},TOKEN,18).length,0);
});
