import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Notifier,describeOperation,describePositionEvent,describeSniper,describeAlert,MAX_PER_MINUTE,MAX_TEXT,type Fetch} from '../server/notify.js';

const GOOD={TELEGRAM_BOT_TOKEN:'123456789:ABCdefGhIJKlmNoPQRsTUVwxyz0123456789',TELEGRAM_CHAT_ID:'123456789'};
function rig(env:Record<string,string|undefined>=GOOD,res:{ok:boolean;status:number}|Error={ok:true,status:200}){
 const calls:any[]=[];let t=1_000_000;
 const fetchImpl:Fetch=async(url,init)=>{calls.push({url,init});if(res instanceof Error)throw res;return res;};
 return {n:new Notifier(env,fetchImpl,()=>t),calls,tick:(ms:number)=>{t+=ms;}};
}

test('Notifier: apagado sin configuración o con datos mal formados; encendido solo con token y chat válidos',()=>{
 for(const env of [{},{TELEGRAM_BOT_TOKEN:GOOD.TELEGRAM_BOT_TOKEN},{TELEGRAM_CHAT_ID:'1'},{...GOOD,TELEGRAM_BOT_TOKEN:'no-es-un-token'},{...GOOD,TELEGRAM_CHAT_ID:'abc'},{...GOOD,TELEGRAM_BOT_TOKEN:'123456789:corto'}])assert.equal(new Notifier(env,async()=>({ok:true,status:200})).enabled,false);
 assert.equal(new Notifier(GOOD,async()=>({ok:true,status:200})).enabled,true);assert.equal(new Notifier({...GOOD,TELEGRAM_CHAT_ID:'-1001234567890'}).enabled,true);assert.equal(new Notifier({...GOOD,TELEGRAM_CHAT_ID:'@micanal'}).enabled,true);
});
test('Notifier.send: solo a api.telegram.org, con el texto limpio y acotado; apagado no envía nada',async()=>{
 const off=rig({});assert.equal(await off.n.send('hola'),false);assert.equal(off.calls.length,0);
 const r=rig();assert.equal(await r.n.send('hola\u0007 mundo'+'x'.repeat(2000)),true);
 const {url,init}=r.calls[0];assert.equal(url,`https://api.telegram.org/bot${GOOD.TELEGRAM_BOT_TOKEN}/sendMessage`);assert.equal(init.method,'POST');
 const body=JSON.parse(init.body);assert.equal(body.chat_id,GOOD.TELEGRAM_CHAT_ID);assert.equal(body.text.length,MAX_TEXT);assert.ok(!body.text.includes('\u0007'));assert.equal(body.disable_web_page_preview,true);
 assert.equal(await r.n.send('   '),false);assert.equal(r.calls.length,1);
});
test('Notifier.send: nunca lanza (red caída, 429), no filtra el token al registro y limita la frecuencia',async()=>{
 const logs:string[]=[];const warn=console.warn;console.warn=(...a:any[])=>{logs.push(a.join(' '));};
 try{
  const down=rig(GOOD,new Error('fetch failed '+GOOD.TELEGRAM_BOT_TOKEN));assert.equal(await down.n.send('x'),false);
  const rate=rig(GOOD,{ok:false,status:429});assert.equal(await rate.n.send('x'),false);
 }finally{console.warn=warn;}
 assert.ok(logs.length>=2);assert.ok(logs.every(l=>!l.includes(GOOD.TELEGRAM_BOT_TOKEN)&&!l.includes('ABCdef')));
 const r=rig();let sent=0;for(let i=0;i<MAX_PER_MINUTE+5;i++)if(await r.n.send('m'+i))sent++;assert.equal(sent,MAX_PER_MINUTE);
 r.tick(61000);assert.equal(await r.n.send('otra'),true);
});
test('mensajes: solo estados finales de órdenes REAL; fallos con motivo; nada de DRY RUN ni de pasos intermedios',()=>{
 const TOKEN='ninu-4.nearlytrade.near';
 assert.match(describeOperation({mode:'REAL',side:'BUY',status:'FILLED',token:TOKEN,elapsedMs:2300})!,/✅ COMPRA .*ninu-4.*completada en 2300 ms/);
 assert.match(describeOperation({mode:'REAL',side:'SELL',percentage:50,status:'PARTIAL',token:TOKEN})!,/VENTA 50% .*\(parcial\) completada/);
 assert.match(describeOperation({mode:'REAL',side:'BUY',status:'FAILED',token:TOKEN,error:'Compra bloqueada por riesgo: impacto 9%.'})!,/⚠ COMPRA .*FAILED — Compra bloqueada por riesgo/);
 assert.match(describeOperation({mode:'REAL',side:'BUY',status:'UNKNOWN',token:TOKEN})!,/resultado incierto/);
 assert.match(describeOperation({mode:'REAL',side:'PREPARE',status:'FAILED',token:'wrap.near',error:'sin saldo'})!,/CONVERSIÓN wNEAR: FAILED — sin saldo/);
 for(const row of [{mode:'DRY RUN',side:'BUY',status:'FILLED'},{mode:'REAL',side:'BUY',status:'SETTLING'},{mode:'REAL',side:'BUY',status:'QUEUED'},{mode:'REAL',side:'ARM',status:'FILLED'},null])assert.equal(describeOperation(row),null);
 const p={symbol:'NINU',token:TOKEN};
 assert.match(describePositionEvent(p,'TRIGGER','STOP_LOSS: vendiendo 100% (P/L -31.0%).')!,/🎯 AUTO SELL disparado · NINU\nSTOP_LOSS/);
 assert.match(describePositionEvent(p,'SELL_FAILED','x')!,/falló/);assert.equal(describePositionEvent(p,'BUY','+1 tokens'),null);assert.equal(describePositionEvent(p,'WOULD_SELL','x'),null);
 assert.match(describeSniper({status:'FIRING',symbol:'NUEVO',mode:'REAL',detail:'Pool detectado'})!,/🎯 Vigilancia NUEVO \(REAL\): FIRING/);assert.equal(describeSniper({status:'WATCHING'}),null);assert.equal(describeSniper({status:'PAUSED'}),null);
 assert.equal(describeAlert('NINU','above',0.0003,0.00031),'🔔 NINU: el precio superó $0.0003 (ahora $0.00031)');
});
