import {test} from 'node:test';
import assert from 'node:assert/strict';
import {openPaper,valuePaper,sellPaper,totalPaper,parsePaper,loadPaper,savePaper} from '../src/paper.js';

const T='a.tkn.near';
const near=(a:number,b:number,eps=1e-9)=>assert.ok(Math.abs(a-b)<eps,`${a} ≉ ${b}`);

test('compra simulada: abre la posición y promedia compras del mismo token',()=>{
 let l=openPaper([],{token:T,symbol:'AAA',spendNear:2,tokens:1000,feeBps:100},5,'p1');
 assert.equal(l.length,1);assert.equal(l[0].id,'p1');
 l=openPaper(l,{token:T,symbol:'AAA',spendNear:1,tokens:400,feeBps:100});assert.equal(l.length,1);assert.equal(l[0].spendNear,3);assert.equal(l[0].tokens,1400);
 l=openPaper(l,{token:'b.tkn.near',symbol:'B',spendNear:1,tokens:10});assert.equal(l.length,2);
 for(const bad of [{spendNear:0,tokens:1},{spendNear:1,tokens:0},{spendNear:NaN,tokens:1},{spendNear:1,tokens:Infinity}])assert.equal(openPaper(l,{token:'c',symbol:'C',...bad}).length,2);
});
test('valuación: P/L en NEAR, % y USD con la comisión de salida; sin precio no inventa',()=>{
 const p=openPaper([],{token:T,symbol:'A',spendNear:2,tokens:1000,feeBps:100},1)[0];
 // precio de entrada 0,002; hoy 0,0024 → valor 1000×0,0024×0,99 = 2,376
 const v=valuePaper(p,0.0024,5);near(v.valueNear!,2.376);near(v.pnlNear!,0.376);near(v.pnlPct!,18.8);near(v.costUsd!,10);near(v.valueUsd!,11.88);near(v.pnlUsd!,1.88);
 const down=valuePaper(p,0.0015,5);assert.ok(down.pnlPct!<0);near(down.pnlPct!,(1000*0.0015*0.99-2)/2*100);
 const flat=valuePaper(p,0.002,5);assert.ok(flat.pnlPct!<0&&flat.pnlPct!>-2);                                             // al mismo precio solo pierdas la comisión
 for(const bad of [null,undefined,0,-1,NaN]){const x=valuePaper(p,bad as any,5);assert.equal(x.pnlPct,null);assert.equal(x.valueUsd,null);}
 assert.equal(valuePaper(p,0.0024,null).pnlUsd,null);
});
test('venta simulada: parcial reparte costo y registra lo realizado; 100 % cierra',()=>{
 const l0=openPaper([],{token:T,symbol:'A',spendNear:2,tokens:1000,feeBps:100},1);
 const r=sellPaper(l0,T,50,0.0024)!;
 near(r.receivedNear,500*0.0024*0.99);const p=r.list[0];near(p.tokens,500);near(p.spendNear,1);near(p.realizedNear,500*0.0024*0.99-1);
 const r2=sellPaper(r.list,T,100,0.0024)!;assert.equal(r2.list.length,0);near(r2.receivedNear,500*0.0024*0.99);
 assert.equal(sellPaper(l0,'otro',50,0.002),null);for(const bad of [0,-5,101,NaN])assert.equal(sellPaper(l0,T,bad,0.002),null);assert.equal(sellPaper(l0,T,50,null),null);assert.equal(sellPaper(l0,T,50,0),null);
});
test('total: suma P/L y % ponderado por costo; ignora tokens sin precio',()=>{
 let l=openPaper([],{token:T,symbol:'A',spendNear:2,tokens:1000,feeBps:0},1);l=openPaper(l,{token:'b.tkn.near',symbol:'B',spendNear:1,tokens:100,feeBps:0});l=openPaper(l,{token:'c.tkn.near',symbol:'C',spendNear:5,tokens:5,feeBps:0});
 const t=totalPaper(l,{[T]:0.003,'b.tkn.near':0.005},10);   // A: valor 3 (+1), B: valor 0,5 (−0,5), C sin precio
 assert.equal(t.open,3);near(t.pnlUsd!,5);near(t.pct!,5/30*100);
 assert.equal(totalPaper(l,{},10).pnlUsd,null);assert.equal(totalPaper([],{},10).pnlUsd,null);
});
test('almacenamiento: persiste y descarta basura',()=>{
 const m=new Map<string,string>();const s={getItem:(k:string)=>m.get(k)??null,setItem:(k:string,v:string)=>{m.set(k,v);}};
 savePaper(openPaper([],{token:T,symbol:'A',spendNear:2,tokens:1000},1),s);assert.equal(loadPaper(s).length,1);assert.equal(loadPaper(s)[0].feeBps,100);
 for(const raw of ['x','{}','[1]','[{"token":"a","spendNear":-1,"tokens":1}]','[{"token":"a","spendNear":1,"tokens":0}]'])assert.deepEqual(parsePaper(raw),[]);
 assert.deepEqual(loadPaper({getItem:()=>{throw new Error('x');},setItem:()=>{}} as any),[]);assert.doesNotThrow(()=>savePaper([],{getItem:()=>null,setItem:()=>{throw new Error('lleno');}}));
});
