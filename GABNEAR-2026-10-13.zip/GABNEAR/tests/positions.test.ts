import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {PositionStore,parseSettings,defaultSettings,evaluateExit,type Position} from '../server/positions.js';
import {ExitMonitor} from '../server/exit-monitor.js';
import {dclRoute} from '../server/venues.js';
import {units} from '../server/validation.js';

const ME='me.near',TOKEN='tok.meme-cooking.near';
const WNEAR={id:'wrap.near',symbol:'wNEAR',decimals:24};
function dir(){return mkdtempSync(join(tmpdir(),'gabnear-pos-'));}
function buyRow(id:string,spent:string,tokens:string,extra:any={}){
 return {id,side:'BUY',mode:'REAL',status:'FILLED',signer:ME,token:TOKEN,at:new Date().toISOString(),usedRaw:units(spent).toString(),receivedRaw:tokens,
  analysis:{metadata:{symbol:'TOK',decimals:18},quoteAsset:WNEAR,amountRaw:units(spent).toString(),route:dclRoute(TOKEN,'wrap.near',10000),record:{id:null,pool_id:'p'},tax:null},
  transactions:[{method:'near_deposit',status:'FINAL',gasBurnt:'1000000000000000000000',deposit:'0'},{method:'storage_deposit',status:'FINAL',deposit:'1250000000000000000000',gasBurnt:'500000000000000000000'},{method:'ft_transfer_call',status:'FINAL',gasBurnt:'2000000000000000000000',deposit:'1'}],...extra};
}
function sellRow(id:string,sold:string,proceeds:string){return {id,side:'SELL',mode:'REAL',status:'FILLED',signer:ME,token:TOKEN,usedRaw:sold,amountRaw:sold,receivedRaw:units(proceeds).toString(),outputToken:'NEAR',transactions:[{method:'ft_transfer_call',status:'FINAL',gasBurnt:'3000000000000000000000'}]};}

test('ajustes AUTO SELL: validan rangos y no se activan sin umbrales',()=>{
 const s=parseSettings({takeProfitPct:50,stopLossPct:30});assert.equal(s.enabled,true);assert.equal(s.takeProfitPct,50);assert.equal(s.tpSellPct,100);
 assert.equal(parseSettings({},defaultSettings()).enabled,false);
 assert.throws(()=>parseSettings({enabled:true}),/Definí al menos/);
 for(const bad of [{stopLossPct:100},{stopLossPct:0},{takeProfitPct:-5},{trailingPct:'abc'},{tpSellPct:75},{slippageBps:0},{slippageBps:9901},{confirmTicks:0},{confirmTicks:11},{gasCostNear:'2'}])assert.throws(()=>parseSettings(bad),Error,JSON.stringify(bad));
 const off=parseSettings({takeProfitPct:null,stopLossPct:null},s);assert.equal(off.enabled,false);
 assert.equal(parseSettings({takeProfitPct:50,stopLossPct:30,enabled:false}).enabled,false);
});

function pos(over:Partial<Position['settings']>={},invested='1',peak='0'):Position{
 const store=new PositionStore(join(dir(),'p.json'));
 const p=store.importPosition({signer:ME,token:TOKEN,symbol:'TOK',decimals:18,quote:WNEAR,route:dclRoute(TOKEN,'wrap.near',10000),launchId:null,sellBps:0,tokensRaw:10n**18n,costRaw:units(invested),settings:{takeProfitPct:50,stopLossPct:30,...over}});
 p.state.peakNetRaw=units(peak).toString();return p;
}
test('evaluateExit: take profit, stop loss y gas estimado de venta',()=>{
 const gas=units('0.005');
 assert.equal(evaluateExit(pos(),units('1.6')).trigger,'TAKE_PROFIT');
 assert.equal(evaluateExit(pos(),units('1.5')+gas).trigger,'TAKE_PROFIT');          // +50% neto de gas
 assert.equal(evaluateExit(pos(),units('1.5')).trigger,null);                         // el gas lo deja justo debajo de +50%
 assert.equal(evaluateExit(pos(),units('0.71')).trigger,null);                        // -29% bruto, pero el gas lo deja en -29,5%
 assert.equal(evaluateExit(pos(),units('0.7')).trigger,'STOP_LOSS');                  // -30% bruto con gas ya es peor que -30%
 assert.equal(evaluateExit(pos(),units('0.7')+gas).trigger,'STOP_LOSS');              // justo en el umbral (inclusive)
 assert.equal(evaluateExit(pos(),units('1.1')).trigger,null);
 assert.equal(evaluateExit(pos(),units('1.1')).pnlBps,Math.floor(Number((units('1.1')-gas-units('1'))*10000n/units('1'))));
});
test('evaluateExit: stop loss tiene prioridad y take profit ya ejecutado no se repite',()=>{
 const p=pos({takeProfitPct:50,stopLossPct:30});p.state.tpDone=true;assert.equal(evaluateExit(p,units('2')).trigger,null);
 const q=pos({stopLossPct:30,takeProfitPct:50});assert.equal(evaluateExit(q,units('0.1')).trigger,'STOP_LOSS');
});
test('evaluateExit: trailing stop solo actúa tras haber estado en ganancia',()=>{
 // sin ganancia previa: peak < costo → no hay trailing aunque caiga
 const a=pos({trailingPct:20,takeProfitPct:null,stopLossPct:null},'1','0.9');assert.equal(evaluateExit(a,units('0.6')).trigger,null);
 // peak 2.0, cae a 1.55 (<80% de 2.0 = 1.6) → dispara
 const b=pos({trailingPct:20,takeProfitPct:null,stopLossPct:null},'1','2');assert.equal(evaluateExit(b,units('1.55')).trigger,'TRAILING_STOP');
 assert.equal(evaluateExit(b,units('1.7')).trigger,null);
 // el pico se actualiza con nuevos máximos
 const c=pos({trailingPct:20,takeProfitPct:null,stopLossPct:null},'1','2');assert.equal(evaluateExit(c,units('3')).peakRaw,units('3')-units('0.005'));
});

test('libro de posiciones: costo promedio, comisiones, P/L realizado y cierre',()=>{
 const d=dir();try{
  const store=new PositionStore(join(d,'positions.json'));
  const p=store.ingest(buyRow('b1','1','1000'))!;
  assert.equal(p.status,'OPEN');assert.equal(p.tokensRaw,'1000');
  // costo = 1 wNEAR + gas (0.001+0.0005+0.002) + storage 0.00125
  assert.equal(p.investedRaw,(units('1')+units('0.0035')+units('0.00125')).toString());
  assert.equal(store.ingest(buyRow('b1','1','1000')),null);                       // idempotente
  const merged=store.ingest(buyRow('b2','2','500'))!;assert.equal(merged.id,p.id);assert.equal(merged.tokensRaw,'1500');
  assert.equal(merged.spentTotalRaw,units('3').toString());
  const invested=BigInt(merged.investedRaw);
  // vende 600 de 1500 por 1.5 NEAR: costo de lo vendido = invertido * 600 / 1500
  const s1=store.ingest(sellRow('s1','600','1.5'))!;
  const costOut=invested*600n/1500n;
  assert.equal(s1.tokensRaw,'900');assert.equal(s1.investedRaw,(invested-costOut).toString());
  assert.equal(s1.realizedRaw,(units('1.5')-costOut-units('0.003')).toString());
  assert.equal(store.ingest(sellRow('s1','600','1.5')),null);                     // idempotente
  const s2=store.ingest(sellRow('s2','900','0.1'))!;assert.equal(s2.status,'CLOSED');assert.equal(s2.tokensRaw,'0');assert.equal(s2.settings.enabled,false);
  // persistencia
  const again=new PositionStore(join(d,'positions.json'));assert.equal(again.positions.length,1);assert.equal(again.positions[0].status,'CLOSED');
  // una venta sin posición abierta no inventa nada
  assert.equal(store.ingest(sellRow('s3','10','1')),null);
 }finally{rmSync(d,{recursive:true,force:true});}
});
test('libro: solo operaciones REAL completadas con recibido verificable crean posiciones',()=>{
 const d=dir();try{
  const store=new PositionStore(join(d,'p.json'));
  for(const bad of [{...buyRow('x1','1','10'),mode:'DRY RUN'},{...buyRow('x2','1','10'),status:'UNKNOWN'},{...buyRow('x3','1','10'),receivedRaw:undefined},{...buyRow('x4','1','0')},{...buyRow('x5','1','10'),signer:''}])assert.equal(store.ingest(bad),null);
  assert.equal(store.positions.length,0);
  const withAuto=store.ingest({...buyRow('y','1','10'),autoSell:{takeProfitPct:100,stopLossPct:40}})!;
  assert.equal(withAuto.settings.enabled,true);assert.equal(withAuto.settings.stopLossPct,40);
 }finally{rmSync(d,{recursive:true,force:true});}
});
test('importar posición exige saldo y costo, y no duplica',()=>{
 const d=dir();try{
  const store=new PositionStore(join(d,'p.json'));
  const base={signer:ME,token:TOKEN,symbol:'T',decimals:18,quote:WNEAR,route:dclRoute(TOKEN,'wrap.near',10000),launchId:null,sellBps:0};
  assert.throws(()=>store.importPosition({...base,tokensRaw:0n,costRaw:1n}),/positivos/);
  store.importPosition({...base,tokensRaw:5n,costRaw:units('1')});
  assert.throws(()=>store.importPosition({...base,tokensRaw:5n,costRaw:units('1')}),/Ya hay/);
 }finally{rmSync(d,{recursive:true,force:true});}
});

// ── Monitor ──────────────────────────────────────────────────────────────────────────────────────────
function monitorSetup(settings:any={takeProfitPct:50,stopLossPct:30,confirmTicks:2},opts:{live?:boolean;stopped?:boolean;busy?:boolean}={}){
 const d=dir(),rows:any[]=[],history:any={rows,update:(id:string,p:any)=>Object.assign(rows.find(r=>r.id===id),p),listeners:new Set()};
 const store=new PositionStore(join(d,'p.json'));
 const p=store.importPosition({signer:ME,token:TOKEN,symbol:'T',decimals:18,quote:WNEAR,route:dclRoute(TOKEN,'wrap.near',10000),launchId:null,sellBps:0,tokensRaw:10n**18n,costRaw:units('1'),settings});
 const env={balance:(10n**18n).toString(),exit:units('1').toString(),quoteError:false,live:opts.live??true,stopped:opts.stopped??false,busy:opts.busy??false,submitted:[] as any[],submitThrows:false};
 const rpc:any={view:async(c:string,m:string)=>{if(m==='ft_balance_of')return env.balance;if(m==='quote'){if(env.quoteError)throw new Error('sin liquidez');return {amount:env.exit};}throw new Error(m);}};
 const monitor=new ExitMonitor({rpc,history,store,submit:raw=>{if(env.submitThrows)throw new Error('Ya hay una operación en curso.');env.submitted.push(raw);const r:any={id:'op'+env.submitted.length,...(raw as any),status:'QUEUED'};rows.unshift(r);return r;},busy:()=>env.busy,live:()=>env.live,stopped:()=>env.stopped,account:()=>ME});
 return {d,rows,store,p,env,monitor,cleanup:()=>rmSync(d,{recursive:true,force:true})};
}
test('monitor: stop loss exige confirmaciones consecutivas y vende 100% con requestId nuevo',async()=>{
 const m=monitorSetup();try{
  m.env.exit=units('0.5').toString();                 // -50%
  await m.monitor.tick();assert.equal(m.env.submitted.length,0);assert.equal(m.p.state.streak?.count,1);
  m.env.exit=units('1').toString();await m.monitor.tick();assert.equal(m.p.state.streak,null);   // se rompe la racha
  m.env.exit=units('0.5').toString();await m.monitor.tick();await m.monitor.tick();
  assert.equal(m.env.submitted.length,1);
  const order=m.env.submitted[0];assert.equal(order.side,'SELL');assert.equal(order.mode,'REAL');assert.equal(order.percentage,100);assert.equal(order.url,TOKEN);assert.match(order.requestId,/^[0-9a-f-]{36}$/);
  assert.equal(m.p.state.pending?.trigger,'STOP_LOSS');assert.equal(m.p.state.pending?.requestId,order.requestId);
  // persistido antes de enviar: el archivo ya contiene la intención
  assert.equal(JSON.parse(readFileSync(m.store.path,'utf8'))[0].state.pending.requestId,order.requestId);
  // mientras la orden está en curso no se envía otra
  await m.monitor.tick();await m.monitor.tick();assert.equal(m.env.submitted.length,1);
 }finally{m.cleanup();}
});
test('monitor: take profit parcial vende el porcentaje y no se repite tras llenarse',async()=>{
 const m=monitorSetup({takeProfitPct:50,confirmTicks:1,tpSellPct:50});try{
  m.env.exit=units('2').toString();await m.monitor.tick();
  assert.equal(m.env.submitted[0].percentage,50);
  // la orden se llena: se registra la venta y el TP no vuelve a dispararse
  const row=m.rows[0];Object.assign(row,sellRow(row.id,'500000000000000000','1'),{requestId:row.requestId,status:'FILLED'});m.store.ingest(row);
  await m.monitor.tick();
  assert.equal(m.p.state.pending,null);assert.equal(m.p.state.tpDone,true);assert.equal(m.p.tokensRaw,(5n*10n**17n).toString());
  await m.monitor.tick();await m.monitor.tick();assert.equal(m.env.submitted.length,1);
 }finally{m.cleanup();}
});
test('monitor: una cotización fallida jamás vende; sin REAL o con parada solo informa',async()=>{
 const m=monitorSetup({stopLossPct:30,confirmTicks:1});try{
  m.env.quoteError=true;await m.monitor.tick();await m.monitor.tick();assert.equal(m.env.submitted.length,0);assert.match(m.p.state.lastError??'',/liquidez/);
  m.env.quoteError=false;m.env.exit=units('0.1').toString();m.env.live=false;await m.monitor.tick();
  assert.equal(m.env.submitted.length,0);assert.ok(m.p.state.events.some(e=>e.type==='WOULD_SELL'&&/REAL desactivado/.test(e.detail)));
  m.env.live=true;m.env.stopped=true;await m.monitor.tick();assert.equal(m.env.submitted.length,0);
  m.env.stopped=false;m.env.busy=true;await m.monitor.tick();assert.equal(m.env.submitted.length,0);        // otra operación en curso
  m.env.busy=false;await m.monitor.tick();assert.equal(m.env.submitted.length,1);                            // ahora sí
 }finally{m.cleanup();}
});
test('monitor: AUTO SELL desactivado calcula P/L pero no vende',async()=>{
 const m=monitorSetup({takeProfitPct:50,stopLossPct:30,confirmTicks:1,enabled:false});try{
  m.env.exit=units('0.1').toString();await m.monitor.tick();await m.monitor.tick();
  assert.equal(m.env.submitted.length,0);assert.ok(m.p.state.lastPnlBps!<-5000);
 }finally{m.cleanup();}
});
test('monitor: rechazo de envío no deja intención pendiente; fallas repetidas pausan AUTO SELL',async()=>{
 const m=monitorSetup({stopLossPct:30,confirmTicks:1});try{
  m.env.exit=units('0.1').toString();m.env.submitThrows=true;await m.monitor.tick();
  assert.equal(m.p.state.pending,null);assert.ok(m.p.state.events.some(e=>e.type==='SUBMIT_REJECTED'));
  assert.ok(m.p.state.retryAt,'tras un rechazo espera antes de reintentar (no registra ni reintenta cada ciclo)');
  m.env.submitThrows=false;await m.monitor.tick();assert.equal(m.env.submitted.length,0);
  for(let attempt=1;attempt<=3;attempt++){
   m.p.state.retryAt=null;await m.monitor.tick();assert.equal(m.env.submitted.length,attempt);
   const row=m.rows[0];row.status='FAILED';row.error='slippage';
   await m.monitor.tick();                                   // resuelve la orden fallida
  }
  assert.equal(m.p.settings.enabled,false);assert.match(m.p.state.pausedReason??'',/pausado/);
  await m.monitor.tick();assert.equal(m.env.submitted.length,3);
 }finally{m.cleanup();}
});
test('monitor: saldo cero o valor menor al gas cierran la posición; tokens movidos prorratean el costo',async()=>{
 const a=monitorSetup({stopLossPct:30,confirmTicks:1});try{a.env.balance='0';await a.monitor.tick();assert.equal(a.p.status,'CLOSED');}finally{a.cleanup();}
 const b=monitorSetup({stopLossPct:30,confirmTicks:1});try{b.env.exit=units('0.005').toString();await b.monitor.tick();assert.equal(b.p.status,'CLOSED');assert.match(b.p.closeReason??'',/polvo/);}finally{b.cleanup();}
 // mitad de los tokens: el costo de referencia también es la mitad → mismo P/L
 const c=monitorSetup({stopLossPct:30,takeProfitPct:50,confirmTicks:1});try{c.env.balance=(5n*10n**17n).toString();c.env.exit=units('0.5').toString();await c.monitor.tick();assert.equal(c.p.state.lastPnlBps!,Math.floor(Number((units('0.5')-units('0.005')-units('0.5'))*10000n/units('0.5'))));assert.equal(c.env.submitted.length,0);}finally{c.cleanup();}
});
test('monitor: orden pendiente que nunca llegó al historial se descarta sin reenviar',async()=>{
 const m=monitorSetup({stopLossPct:30,confirmTicks:1});try{
  m.p.state.pending={requestId:'00000000-0000-4000-8000-000000000000',trigger:'STOP_LOSS',percentage:100,at:new Date(Date.now()-60000).toISOString()};
  m.env.exit=units('1').toString();await m.monitor.tick();
  assert.equal(m.p.state.pending,null);assert.equal(m.env.submitted.length,0);assert.ok(existsSync(m.store.path));
 }finally{m.cleanup();}
});

import {displaySigned,display} from '../server/validation.js';
test('displaySigned: una pérdida realizada se muestra con signo (display() no admite negativos)',()=>{
 assert.equal(displaySigned(-500000000000000000000000n,24),'-0.5');
 assert.equal(displaySigned(1500000000000000000000000n,24),'1.5');
 assert.equal(displaySigned(0n,24),'0');
 assert.equal(displaySigned(-3n,0),'-3');
 assert.equal(displaySigned('-1000000',6),'-1');
 assert.equal(display(500000000000000000000000n,24),'0.5');
});

test('SALIR DE TODO: vende 100% sin importar TP/SL ni confirmaciones, de a una orden, y se apaga sola',async()=>{
 const m=monitorSetup({takeProfitPct:500,stopLossPct:90,confirmTicks:5,enabled:false});try{
  await m.monitor.tick();assert.equal(m.env.submitted.length,0);                                // posición normal: nada que vender
  m.monitor.requestExitAll(true);assert.equal(m.monitor.exitingAll,true);
  await m.monitor.tick();
  assert.equal(m.env.submitted.length,1);const order=m.env.submitted[0];assert.equal(order.side,'SELL');assert.equal(order.mode,'REAL');assert.equal(order.percentage,100);assert.equal(order.url,TOKEN);
  assert.equal(m.p.state.pending?.trigger,'MANUAL_EXIT');
  await m.monitor.tick();await m.monitor.tick();assert.equal(m.env.submitted.length,1);          // no envía otra mientras la orden está en curso
  const row=m.rows[0];Object.assign(row,sellRow(row.id,(10n**18n).toString(),'1'),{requestId:row.requestId,status:'FILLED'});m.store.ingest(row);
  m.env.balance='0';await m.monitor.tick();                                                     // vendido todo: la posición se cierra
  await m.monitor.tick();assert.equal(m.monitor.exitingAll,false);assert.equal(m.env.submitted.length,1);   // sin posiciones abiertas → modo apagado
 }finally{m.cleanup();}
});
test('SALIR DE TODO: se cancela solo si REAL se desactiva o hay parada de emergencia; respeta el reintento tras un fallo',async()=>{
 const m=monitorSetup({confirmTicks:5,enabled:false},{});try{
  m.monitor.requestExitAll(true);m.env.live=false;await m.monitor.tick();
  assert.equal(m.monitor.exitingAll,false);assert.equal(m.env.submitted.length,0);                // nunca queda armado para disparar más tarde
  m.env.live=true;await m.monitor.tick();assert.equal(m.env.submitted.length,0);                   // y no vuelve a vender por su cuenta
  m.monitor.requestExitAll(true);m.env.stopped=true;await m.monitor.tick();assert.equal(m.monitor.exitingAll,false);assert.equal(m.env.submitted.length,0);
  m.env.stopped=false;m.monitor.requestExitAll(true);await m.monitor.tick();assert.equal(m.env.submitted.length,1);
  Object.assign(m.rows[0],{status:'FAILED',error:'sin liquidez'});await m.monitor.tick();         // falla: reintento con espera, no en el mismo ciclo
  assert.equal(m.env.submitted.length,1);assert.ok(m.p.state.retryAt);assert.ok(m.p.state.events.some(e=>e.type==='SELL_FAILED'));
  await m.monitor.tick();assert.equal(m.env.submitted.length,1);
 }finally{m.cleanup();}
});
