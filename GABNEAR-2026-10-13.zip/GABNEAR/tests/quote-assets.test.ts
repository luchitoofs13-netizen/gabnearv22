import test,{before,after,beforeEach,afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {discover,DCL,WNEAR} from '../server/pools.js';
import {analyze} from '../server/analysis.js';
import {buy,sell,setLiveSession,executableExit} from '../server/trading.js';
import {quoteAmount,quoteAsset,ftRaw} from '../server/quote-asset.js';
import {AutoSell} from '../server/autosell.js';
import {Operations} from '../server/operations.js';
import {estimateUsd} from '../server/usd.js';
import {Recovery} from '../server/recovery.js';
import {units} from '../server/validation.js';
import {beginTimeline} from '../server/timing.js';
import {randomUUID} from 'node:crypto';
const token='launch.nearlytrade.near',owner='quote-tests.near',cwd=process.cwd();
const saved={account:process.env.BOT_ACCOUNT_ID,limits:process.env.MAX_QUOTE_PER_TRADE_JSON,max:process.env.MAX_NEAR_PER_TRADE};
before(()=>{process.chdir(mkdtempSync(join(tmpdir(),'gabnear-quotes-')));process.env.BOT_ACCOUNT_ID=owner;});
beforeEach(()=>{process.env.MAX_QUOTE_PER_TRADE_JSON=JSON.stringify({'ria.near':'1000','qtc.near':'1000','future.token':'1000'});process.env.MAX_NEAR_PER_TRADE='99';setLiveSession(true);});
afterEach(()=>setLiveSession(false));
after(()=>{process.chdir(cwd);for(const [key,value] of Object.entries({BOT_ACCOUNT_ID:saved.account,MAX_QUOTE_PER_TRADE_JSON:saved.limits,MAX_NEAR_PER_TRADE:saved.max})){if(value===undefined)delete process.env[key];else process.env[key]=value;}});
function harness(id='ria.near',decimals=6){
 const registry=new Set<string>(),calls:any[]=[],quotes:any[]=[],rows:any[]=[{id:'op',status:'PREPARING',side:'BUY',signer:owner,method:'ft_transfer_call',txHash:'synthetic'}];
 const h:any={rows,update:(key:string,p:any)=>Object.assign(rows.find(r=>r.id===key),p),save:(r:any)=>{rows.unshift(r);return r;}};
 let balance=units('100',decimals).toString(),native=units('10').toString(),minimum=units('0.01').toString();
 const rpc:any={mainnet:async()=>({chain_id:'mainnet'}),account:async()=>({code_hash:'abc',amount:native,storage_usage:0}),view:async(c:string,m:string,a:any)=>{
  switch(m){
   case 'ft_metadata':return {spec:'ft-1.0.0',name:c,symbol:c===id?'QUOTE':'LAUNCH',decimals:c===id?decimals:18};
   case 'get_launch_by_token':return {id:1,token,quote:id,step:'Done',pool_id:'actual-pool'};
   case 'get_pool':return {token_x:token,token_y:id,state:'Running'};
   case 'get_tax':return {buy_bps:100,sell_bps:100};case 'get_rules':return null;
   case 'storage_balance_of':return registry.has(c)?{total:minimum,available:'0'}:null;
   case 'storage_balance_bounds':return {min:minimum,max:minimum};
   case 'ft_balance_of':return c===id?balance:units('2',18).toString();
   case 'quote':quotes.push(a);return {amount:a.output_token===token?units('1',18).toString():units('2',decimals).toString()};
   default:throw Error('unexpected '+m);
  }
 }};
 const ex:any={rpc,history:h,busy:false,exclusive:async(fn:any)=>fn(),call:async(key:string,c:string,m:string,a:any,deposit:bigint)=>{
  calls.push({contract:c,method:m,args:a,deposit});
  if(m==='storage_deposit')registry.add(c);
  if(m==='near_deposit')balance=(BigInt(balance)+deposit).toString();
  if(m!=='ft_transfer_call')return {final_execution_status:'FINAL',status:{SuccessValue:''},receipts_outcome:[]};
  const output=JSON.parse(a.msg).Swap.output_token,received=output===token?units('0.99',18):units('2',decimals),used=output===token?BigInt(a.amount):BigInt(a.amount)*99n/100n;
  return {final_execution_status:'FINAL',status:{SuccessValue:Buffer.from(JSON.stringify(String(used))).toString('base64')},receipts_outcome:[{id:'receipt',outcome:{executor_id:output,status:{SuccessValue:''},logs:['EVENT_JSON:'+JSON.stringify({standard:'nep141',event:'ft_transfer',data:[{old_owner_id:DCL,new_owner_id:owner,amount:received.toString()}]})]}}]};
 }};
 return {rpc,ex,h,calls,quotes,registry,row:rows[0],set balance(n:string){balance=n;},set native(n:string){native=n;},set minimum(n:string){minimum=n;}};
}
const config={accountId:owner,maxNear:'99',maxBps:9900};
const input={url:token,amount:'1.25',slippageBps:300};
test('ruta financiada difiere una sola cotización fresca hasta swap y conserva mínimos en history',async()=>{const t=harness();t.registry.add(token);t.registry.add('ria.near');const a=await analyze(t.rpc,input,config,{freshQuoteAtSwap:true});assert.equal(a.quotation,null);assert.equal(t.quotes.length,0);t.row.analysis=a;await buy(t.ex,'op',a,BigInt(a.amountRaw),300);assert.equal(t.quotes.length,1);assert.equal(t.row.analysis.quotation.minTokens,'0.9603');assert.equal(t.row.swapSnapshot.expectedMinimum,units('0.9603',18).toString());});
test('ruta que necesita storage conserva validación DCL antes de pagar preparación',async()=>{const t=harness(),old=t.rpc.view;t.rpc.view=async(c:string,m:string,a:any)=>{if(m==='quote')throw Error('Unsupported token');return old(c,m,a);};await assert.rejects(()=>analyze(t.rpc,input,config,{freshQuoteAtSwap:true}),/Quote ria.near no ejecutable/);assert.equal(t.calls.length,0);});
test('wNEAR con déficit conserva prequote antes del wrap',async()=>{const t=harness(WNEAR,24);t.registry.add(token);t.registry.add(WNEAR);t.balance='0';const a=await analyze(t.rpc,input,config,{freshQuoteAtSwap:true});assert.ok(a.quotation);assert.equal(t.quotes.length,1);assert.equal(t.calls.length,0);});
test('RIA, QTC y un quote futuro se descubren genéricamente en ambas orientaciones DCL',async()=>{
 for(const [id,decimals] of [['ria.near',6],['qtc.near',18],['future.token',0]] as const){const t=harness(id,decimals);const d=await discover(t.rpc,token);assert.equal(d.direct,true);assert.deepEqual(d.quoteAsset,{id,name:id,symbol:'QUOTE',decimals});const old=t.rpc.view;t.rpc.view=async(c:string,m:string,a:any)=>m==='get_pool'?{token_y:token,token_x:id,state:'Running'}:old(c,m,a);assert.equal((await discover(t.rpc,token)).direct,true);}
});
test('análisis y compra RIA usan sus seis decimales y un solo pool, sin wrap',async()=>{
 const t=harness(),a=await analyze(t.rpc,input,config);assert.equal(a.amountRaw,'1250000');assert.equal(a.quoteBalance,'100');assert.equal(a.wnearRegistered,null);assert.ok(a.steps.some(s=>s.contract==='ria.near'&&s.method==='storage_deposit'));assert.ok(!a.steps.some(s=>s.method==='near_deposit'));
 beginTimeline(t.h,'op');const r=await buy(t.ex,'op',a,BigInt(a.amountRaw),300);assert.equal(r.state,'FILLED');
 const transfer=t.calls.find(c=>c.method==='ft_transfer_call');assert.equal(transfer.contract,'ria.near');assert.equal(transfer.args.amount,'1250000');assert.equal(transfer.deposit,1n);assert.deepEqual(JSON.parse(transfer.args.msg).Swap.pool_ids,['actual-pool']);assert.equal(JSON.parse(transfer.args.msg).Swap.output_token,token);assert.equal(t.calls.filter(c=>c.method==='storage_deposit').length,2);assert.ok(!t.calls.some(c=>c.contract===WNEAR||c.method==='near_deposit'));assert.ok(t.row.timing.events.some((e:any)=>e.stage==='quotePreparation'));
});
test('QTC usa saldo FT existente y conserva impuesto/mínimo',async()=>{const t=harness('qtc.near',18),a=await analyze(t.rpc,input,config);await buy(t.ex,'op',a,BigInt(a.amountRaw),300);assert.equal(t.calls.find(c=>c.method==='ft_transfer_call').args.amount,units('1.25',18).toString());assert.equal(t.row.swapSnapshot.expectedMinimum,units('0.9603',18).toString());});
test('sin saldo del quote falla DRY RUN y compra REAL antes de cualquier envío',async()=>{const t=harness();t.balance='0';await assert.rejects(()=>analyze(t.rpc,input,config),/Saldo insuficiente.*ria.near/);const p={token,...await discover(t.rpc,token)};await assert.rejects(()=>buy(t.ex,'op',p,1250000n,300),/Saldo insuficiente/);assert.equal(t.calls.length,0);});
test('compra relee saldo del FT después del análisis',async()=>{const t=harness(),a=await analyze(t.rpc,input,config);t.balance='1';await assert.rejects(()=>buy(t.ex,'op',a,BigInt(a.amountRaw),300),/Saldo insuficiente/);assert.equal(t.calls.length,0);});
test('venta registra el quote y vuelve al mismo FT, cotiza entrada neta y transfiere bruto',async()=>{const t=harness(),p={token,...await discover(t.rpc,token)};t.row.side='SELL';const r=await sell(t.ex,'op',p,units('1',18),300);assert.equal(r.state,'FILLED');assert.equal(t.calls[0].contract,'ria.near');assert.equal(t.calls[0].method,'storage_deposit');const swap=t.calls.find(c=>c.method==='ft_transfer_call');assert.equal(swap.contract,token);assert.equal(swap.args.amount,units('1',18).toString());assert.equal(JSON.parse(swap.args.msg).Swap.output_token,'ria.near');assert.equal(t.quotes[0].input_amount,units('0.99',18).toString());assert.equal(t.row.outputToken,'ria.near');});
test('cotización de posición muestra cantidades en quote, sin rotularlas NEAR',async()=>{const t=harness(),ops=new Operations(t.rpc,t.h,t.ex,()=>false,()=>config);const p=await ops.position(token,300,50,true);assert.equal(p.quotation.expectedQuote,'2');assert.equal(p.quotation.minimumQuote,'1.94');assert.equal(p.quotation.expectedNear,undefined);assert.equal(p.usdValuation?.status,'UNAVAILABLE');});
test('wNEAR conserva wrap automático de solo el déficit y ruta directa',async()=>{const t=harness(WNEAR,24);t.balance=units('0.25').toString();const a=await analyze(t.rpc,input,config);await buy(t.ex,'op',a,BigInt(a.amountRaw),300);assert.equal(t.calls.find(c=>c.method==='near_deposit').deposit,units('1'));assert.equal(t.calls.find(c=>c.method==='ft_transfer_call').contract,WNEAR);});
test('wNEAR suficiente no vuelve a envolver; storage existente no se duplica',async()=>{const t=harness(WNEAR,24);t.registry.add(WNEAR);t.registry.add(token);const a=await analyze(t.rpc,input,config);await buy(t.ex,'op',a,BigInt(a.amountRaw),300);assert.deepEqual(t.calls.map(c=>c.method),['ft_transfer_call']);});
test('FT no exige límites por contrato ni lee configuraciones legacy',async()=>{const t=harness(),d=await discover(t.rpc,token);process.env.MAX_QUOTE_PER_TRADE_JSON='invalid';assert.equal(quoteAmount('1000000',d.quoteAsset,300,'1',500),1000000000000n);for(const amount of ['0','0.0000001'])assert.throws(()=>quoteAmount(amount,d.quoteAsset,300,'1',500));assert.throws(()=>quoteAmount('1',d.quoteAsset,501,'1',500));});
test('capital wNEAR no tiene tope configurado',async()=>{const t=harness(WNEAR,24),a=await analyze(t.rpc,{...input,amount:'1000000'},config);assert.equal(a.amountRaw,units('1000000').toString());assert.equal(t.calls.length,0);});
test('pool incompatible, quote inválido y metadata inválida producen error claro',async()=>{
 for(const mode of ['pool','account','metadata']){const t=harness(),old=t.rpc.view;t.rpc.view=async(c:string,m:string,a:any)=>{if(mode==='pool'&&m==='get_pool')return {token_x:token,token_y:WNEAR,state:'Running'};if(mode==='account'&&m==='get_launch_by_token')return {token,step:'Done',pool_id:'p',quote:'INVALID'};if(mode==='metadata'&&m==='ft_metadata'&&c==='ria.near')return {spec:'oops',decimals:6};return old(c,m,a);};await assert.rejects(()=>discover(t.rpc,token),/no soportado|NEP-141/);assert.equal(t.calls.length,0);}
});
test('reserva nativa cubre storage de ambos tokens y no depende del saldo quote',async()=>{const t=harness(),a=await analyze(t.rpc,input,config);t.native=units('0.105').toString();await assert.rejects(()=>buy(t.ex,'op',a,BigInt(a.amountRaw),300),/almacenamiento/);assert.equal(t.calls.length,0);});
test('storage excesivo o no soportado bloquea antes de firmar',async()=>{const t=harness(),a=await analyze(t.rpc,input,config);t.minimum=units('0.051').toString();await assert.rejects(()=>buy(t.ex,'op',a,BigInt(a.amountRaw),300),/excesivo/);assert.equal(t.calls.length,0);});
test('reglas desconocidas siguen bloqueando la compra genérica',async()=>{const t=harness(),a=await analyze(t.rpc,input,config);await assert.rejects(()=>buy(t.ex,'op',{...a,rules:{max_wallet_bps:100}},BigInt(a.amountRaw),300),/reglas/);assert.equal(t.calls.length,0);});
test('USD no inventa conversión FT a NEAR ni consulta precios externos',async()=>{const t=harness(),p={token,...await discover(t.rpc,token)};const v=await estimateUsd(t.rpc,p,100n,300,async()=>{throw Error('no consultar');});assert.equal(v.status,'UNAVAILABLE');assert.equal(t.quotes.length,0);});
test('auto-sell genérico exige gas en el mismo quote, luego vende al quote original',async()=>{const t=harness(),p={token,...await discover(t.rpc,token),id:'op',status:'FILLED',receivedRaw:units('1',18).toString(),costRaw:units('1',6).toString()};const settings={takeProfitBps:2000,stopLossBps:1000,slippageBps:300,estimatedGasYocto:units('0.01').toString()};const auto=new AutoSell(t.ex,()=>false);await assert.rejects(()=>auto.tick(p,settings),/costo de gas/);assert.equal(t.calls.length,0);await auto.tick(p,{...settings,estimatedGasQuoteRaw:'10000',gasQuoteAsset:'ria.near'});assert.equal(t.row.sold,true);assert.equal(JSON.parse(t.calls.find(c=>c.method==='ft_transfer_call').args.msg).Swap.output_token,'ria.near');});
test('recovery de venta FT verifica recibos del quote sin consultar balances posteriores',async()=>{const t=harness(),p={token,...await discover(t.rpc,token)};await sell(t.ex,'op',p,units('1',18),300);const swap=t.calls.find(c=>c.method==='ft_transfer_call');const outcome=await t.ex.call('op',swap.contract,swap.method,swap.args,1n);t.row.status='UNKNOWN';t.ex.reconcile=async()=>outcome;t.rpc.view=async()=>{throw Error('No consultar balances');};await new Recovery(t.h,t.ex).reconcile('op');assert.equal(t.row.status,'FILLED');assert.equal(t.row.outputToken,'ria.near');assert.equal(t.row.receivedRaw,'2000000');});
test('importe FT malformado o mayor a u128 se rechaza; legacy wNEAR se conserva',()=>{for(const value of ['-1','1.0',1,'340282366920938463463374607431768211456'])assert.throws(()=>ftRaw(value));assert.equal(quoteAsset({record:{pool_id:'legacy'}}).id,WNEAR);assert.throws(()=>quoteAsset({record:{quote:'ria.near'}}),/metadatos/);});
test('exit usa decimales del quote sin rutas intermedias',async()=>{const t=harness('future.token',0),p={token,...await discover(t.rpc,token)};await executableExit(t.rpc,p,100n,300);assert.equal(t.quotes[0].output_token,'future.token');assert.deepEqual(t.quotes[0].pool_ids,['actual-pool']);});
test('compra asincrónica conserva unidades, límite FT e historial sin usar el cap numérico NEAR',async()=>{const t=harness();t.balance=units('200',6).toString();const ops=new Operations(t.rpc,t.h,t.ex,()=>false,()=>({...config,maxNear:'1'}));const r=ops.submit({requestId:randomUUID(),side:'BUY',mode:'DRY RUN',url:token,amount:'100',slippageBps:300});for(let i=0;i<20&&ops.active;i++)await new Promise(resolve=>setTimeout(resolve,5));assert.equal(r.status,'ANALYZED');assert.equal(r.costRaw,'100000000');assert.equal(r.quoteAsset.id,'ria.near');assert.equal(t.calls.length,0);});
test('BUY asincrónico wNEAR ignora el antiguo cap de capital',async()=>{const t=harness(WNEAR,24),ops=new Operations(t.rpc,t.h,t.ex,()=>false,()=>({...config,maxNear:'1'}));const r=ops.submit({requestId:randomUUID(),side:'BUY',mode:'DRY RUN',url:token,amount:'2',slippageBps:300});for(let i=0;i<20&&ops.active;i++)await new Promise(resolve=>setTimeout(resolve,5));assert.equal(r.status,'ANALYZED');assert.equal(r.costRaw,units('2').toString());assert.equal(t.calls.length,0);assert.equal(t.quotes.length,1);});
test('venta preparada de compra FT usa quote original y se envía una sola vez',async()=>{const t=harness(),a=await analyze(t.rpc,input,config);Object.assign(t.row,{side:'BUY',mode:'REAL',token,status:'FILLED',analysis:a,receivedRaw:units('1',18).toString()});const ops=new Operations(t.rpc,t.h,t.ex,()=>false,()=>config);const r=ops.prepareSell('op',{requestId:randomUUID(),side:'SELL',mode:'REAL',url:token,percentage:50,slippageBps:300});await ops.maintenance();for(let i=0;i<20&&ops.active;i++)await new Promise(resolve=>setTimeout(resolve,5));assert.equal(r.status,'FILLED');await ops.maintenance();assert.equal(t.calls.filter(c=>c.method==='ft_transfer_call').length,1);assert.equal(r.quoteAsset.id,'ria.near');});
test('cambio de quote bloquea una venta preparada de compra anterior',async()=>{const t=harness(),a=await analyze(t.rpc,input,config);Object.assign(t.row,{side:'BUY',mode:'REAL',token,status:'FILLED',analysis:{...a,record:{...a.record,quote:'qtc.near'},quoteAsset:{...a.quoteAsset,id:'qtc.near'}},receivedRaw:'1000'});const ops=new Operations(t.rpc,t.h,t.ex,()=>false,()=>config);const r=ops.prepareSell('op',{requestId:randomUUID(),side:'SELL',mode:'REAL',url:token,percentage:50,slippageBps:300});await ops.maintenance();for(let i=0;i<20&&ops.active;i++)await new Promise(resolve=>setTimeout(resolve,5));assert.equal(r.status,'FAILED');assert.match(r.error,/quote.*cambió/);assert.equal(t.calls.length,0);});
test('venta FT exige gas más storage y no duplica un registro existente',async()=>{const t=harness(),p={token,...await discover(t.rpc,token)};t.native=units('0.105').toString();await assert.rejects(()=>sell(t.ex,'op',p,100n,300),/almacenamiento/);assert.equal(t.calls.length,0);t.native=units('1').toString();t.registry.add('ria.near');await sell(t.ex,'op',p,100n,300);assert.deepEqual(t.calls.map(c=>c.method),['ft_transfer_call']);});
test('error técnico DCL identifica el quote y no ejecuta ruta alternativa',async()=>{const t=harness(),old=t.rpc.view;t.rpc.view=async(c:string,m:string,a:any)=>{if(m==='quote')throw Error('Unsupported token');return old(c,m,a);};await assert.rejects(()=>analyze(t.rpc,input,config),/Quote ria.near no ejecutable en DCL/);assert.equal(t.calls.length,0);});
