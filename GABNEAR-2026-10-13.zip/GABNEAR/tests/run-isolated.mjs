// Ejecuta las pruebas desde un directorio de trabajo vacío: así NO leen tu data/ (cuenta conectada, posiciones, velocidad) ni tu .env
// (topes, slippage...), y ninguna prueba puede escribir ahí. Uso: npm test  ·  npm test -- tests/market.test.ts
import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync,rmSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),project=resolve(here,'..');
const cache=join(project,'.cache');mkdirSync(cache,{recursive:true});
const cwd=mkdtempSync(join(cache,'test-'));
const wanted=process.argv.slice(2).filter(a=>!a.startsWith('-')).map(f=>resolve(project,f));
const files=wanted.length?wanted:readdirSync(here).filter(f=>f.endsWith('.test.ts')).map(f=>join(here,f));
const env={...process.env,GABNEAR_TEST_ROOT:project};
for(const k of Object.keys(env))if(/^(MAX_BUY_NEAR|MAX_DAILY_NEAR|MAX_SLIPPAGE_BPS|BOT_ACCOUNT_ID|NEAR_RPC_|CONFIRM_LEVEL|PREP_LEVEL|AUTO_ARM|NEAR_ASYNC_SEND|PORT)/.test(k))delete env[k];
const r=spawnSync(process.execPath,[join(project,'node_modules','tsx','dist','cli.mjs'),'--test',...process.argv.slice(2).filter(a=>a.startsWith('-')),...files],{cwd,stdio:'inherit',env});
try{rmSync(cwd,{recursive:true,force:true});}catch{/* limpieza opcional */}
process.exit(r.status??1);
