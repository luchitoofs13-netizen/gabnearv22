// Pentest automatizado de la terminal local: levanta el servidor REAL (proceso aparte, directorio y datos propios, RPC falso)
// y le dispara los ataques que un sitio web malicioso o un proceso local intentaría. Ninguna prueba toca mainnet ni fondos.
import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import http,{type IncomingHttpHeaders} from 'node:http';
import {spawn,type ChildProcess} from 'node:child_process';
import {mkdirSync,writeFileSync,rmSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {securityHeaders,hostGuard,apiGuard,connectionCap,CSP} from '../server/security.js';

const PROJECT=process.env.GABNEAR_TEST_ROOT??resolve('.');
const MARKER='SECRETO-NO-SERVIR-'+randomBytes(4).toString('hex');
const root=join(PROJECT,'.cache','sec-'+randomBytes(4).toString('hex'));
let child:ChildProcess,rpc:http.Server,port=0;
type Res={status:number;headers:IncomingHttpHeaders;text:string};
const freePort=()=>new Promise<number>(ok=>{const s=http.createServer();s.listen(0,'127.0.0.1',()=>{const p=(s.address() as any).port;s.close(()=>ok(p));});});
function raw(path:string,o:{method?:string;headers?:Record<string,string>;body?:string}={}):Promise<Res>{
 return new Promise((ok,fail)=>{
  const req=http.request({host:'127.0.0.1',port,path,method:o.method??'GET',headers:{...(o.body!==undefined?{'Content-Length':String(Buffer.byteLength(o.body))}:{}),...o.headers}},res=>{
   let text='';res.setEncoding('utf8');res.on('data',c=>text+=c);res.on('end',()=>ok({status:res.statusCode!,headers:res.headers,text}));
  });
  req.on('error',fail);req.setTimeout(8000,()=>req.destroy(new Error('timeout')));if(o.body!==undefined)req.write(o.body);req.end();
 });
}
const GOOD={'X-Gabnear-Client':'local','Content-Type':'application/json'};
const post=(path:string,body:unknown,headers:Record<string,string>={})=>raw(path,{method:'POST',headers:{...GOOD,...headers},body:JSON.stringify(body)});

before(async()=>{
 // RPC falso: solo responde «status» de mainnet, para que las rutas con red no dependan de internet.
 rpc=http.createServer((req,res)=>{let b='';req.on('data',c=>b+=c);req.on('end',()=>{let id=1;try{id=JSON.parse(b).id;}catch{/* sin id */}res.setHeader('Content-Type','application/json');res.end(JSON.stringify({jsonrpc:'2.0',id,result:{chain_id:'mainnet',sync_info:{latest_block_height:1,syncing:false}}}));});});
 await new Promise<void>(ok=>rpc.listen(0,'127.0.0.1',ok));
 port=await freePort();
 mkdirSync(join(root,'dist'),{recursive:true});mkdirSync(join(root,'public','assets'),{recursive:true});mkdirSync(join(root,'data'),{recursive:true});
 writeFileSync(join(root,'dist','index.html'),'<!doctype html><title>x</title>');
 writeFileSync(join(root,'public','assets','ok.txt'),'ok');
 writeFileSync(join(root,'data','vault.json'),MARKER);
 writeFileSync(join(root,'.env'),`PORT=${port}\nNEAR_RPC_URL=http://127.0.0.1:${(rpc.address() as any).port}\nNEAR_RPC_READ_FALLBACK=\nSECRET_MARKER=${MARKER}\n`);
 child=spawn(process.execPath,[join(PROJECT,'node_modules','tsx','dist','cli.mjs'),join(PROJECT,'server','index.ts')],{cwd:root,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
 await new Promise<void>((ok,fail)=>{const t=setTimeout(()=>fail(new Error('el servidor no arrancó')),20000);child.stdout!.on('data',d=>{if(String(d).includes('GABNEAR http://')){clearTimeout(t);ok();}});child.on('exit',c=>{clearTimeout(t);fail(new Error('el servidor terminó: '+c));});});
});
after(async()=>{child?.kill();await new Promise<void>(ok=>rpc?.close(()=>ok()));await new Promise(r=>setTimeout(r,200));try{rmSync(root,{recursive:true,force:true});}catch{/* limpieza opcional */}});

test('DNS rebinding: un Host ajeno (también con aspecto de local) se rechaza en la API y en las páginas',async()=>{
 for(const host of ['evil.example','127.0.0.1.evil.example','localhost.evil.example','attacker.com:80','[::1]:'+port,'0.0.0.0'])
  for(const path of ['/api/health','/api/wallet','/','/assets/ok.txt'])assert.equal((await raw(path,{headers:{Host:host}})).status,403,`${host} ${path}`);
 assert.equal((await raw('/api/wallet',{headers:{Host:`localhost:${port}`}})).status,200);
 assert.equal((await raw('/api/wallet')).status,200);
});

test('CSRF: origen ajeno, «null», same-site / cross-site y POST sin cabecera propia se rechazan',async()=>{
 for(const origin of ['https://evil.example','null','http://127.0.0.1:9999','http://localhost.evil.example','http://127.0.0.1:'+port+'.evil.example'])
  assert.equal((await raw('/api/wallet',{headers:{Origin:origin}})).status,403,origin);
 assert.equal((await post('/api/emergency',{stopped:true},{Origin:'https://evil.example'})).status,403);
 for(const site of ['cross-site','same-site'])assert.equal((await raw('/api/wallet',{headers:{'Sec-Fetch-Site':site}})).status,403,site);
 for(const site of ['same-origin','none'])assert.equal((await raw('/api/wallet',{headers:{'Sec-Fetch-Site':site}})).status,200,site);
 assert.equal((await raw('/api/emergency',{method:'POST',headers:{'Content-Type':'application/json'},body:'{"stopped":true}'})).status,403);          // sin X-Gabnear-Client
 assert.equal((await raw('/api/emergency',{method:'POST',headers:{'Content-Type':'text/plain','X-Gabnear-Client':'otro'},body:'{"stopped":true}'})).status,403);
 const ok=await post('/api/emergency',{stopped:false},{Origin:`http://127.0.0.1:${port}`});assert.equal(ok.status,200);                          // la propia terminal sí pasa
});

test('CORS: ninguna respuesta autoriza a otro origen y la verificación previa no concede nada',async()=>{
 for(const path of ['/api/wallet','/api/health','/']){const r=await raw(path,{headers:{Origin:`http://127.0.0.1:${port}`}});assert.equal(r.headers['access-control-allow-origin'],undefined,path);}
 const pre=await raw('/api/operations',{method:'OPTIONS',headers:{Origin:'https://evil.example','Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'x-gabnear-client'}});
 assert.equal(pre.headers['access-control-allow-origin'],undefined);assert.notEqual(pre.status,200);
});

test('cabeceras de seguridad: CSP cerrada, sin iframes, sin sniffing y sin huella del framework',async()=>{
 for(const path of ['/','/api/wallet','/assets/ok.txt']){
  const h=(await raw(path)).headers;
  assert.equal(h['content-security-policy'],CSP,path);assert.equal(h['x-frame-options'],'DENY');assert.equal(h['x-content-type-options'],'nosniff');
  assert.equal(h['referrer-policy'],'no-referrer');assert.equal(h['x-powered-by'],undefined);assert.equal(h['cross-origin-resource-policy'],'same-origin');
 }
 assert.match(CSP,/default-src 'none'/);assert.match(CSP,/frame-ancestors 'none'/);assert.match(CSP,/connect-src 'self'/);assert.doesNotMatch(CSP,/script-src[^;]*unsafe/);assert.doesNotMatch(CSP,/https?:/);
 assert.match((await raw('/api/wallet')).headers['cache-control']??'',/no-store/);
});

test('recorrido de rutas: ni .env, ni data/, ni archivos fuera de dist/ se sirven',async()=>{
 const good=await raw('/assets/ok.txt');assert.equal(good.status,200);assert.equal(good.text,'ok');assert.equal((await raw('/')).status,200);   // el servidor de archivos funciona: que no filtre no es porque todo dé 404
 const attacks=['/.env','/..%2f.env','/%2e%2e/.env','/%2e%2e%2f.env','/assets/..%2f..%2f.env','/assets/../../.env','/assets/%2e%2e/%2e%2e/.env','/..%5c.env','/assets/..%5c..%5c.env',
  '/data/vault.json','/..%2fdata%2fvault.json','/assets/../../data/vault.json','/%2e%2e%2fdata%2fvault.json','/assets/%2e%2e%2f%2e%2e%2fdata%2fvault.json','/.%00env','/assets/ok.txt%00.png','//etc/passwd','/server/index.ts','/package.json','/assets/ok.txt/../../.env'];
 for(const p of attacks){const r=await raw(p);assert.ok(!r.text.includes(MARKER),`filtración con ${p}`);assert.doesNotMatch(r.text,/SECRET_MARKER|NEAR_RPC_URL/,p);}
 for(const p of ['/.env','/data/vault.json','/server/index.ts','/package.json'])assert.notEqual((await raw(p)).status,200,p);
});

test('cuerpos hostiles: demasiado grande, JSON roto, tipos inesperados y contaminación de prototipo no tumban ni filtran',async()=>{
 assert.equal((await raw('/api/analyze',{method:'POST',headers:GOOD,body:JSON.stringify({url:'x'.repeat(40000)})})).status,413);
 const bad=await raw('/api/analyze',{method:'POST',headers:GOOD,body:'{"url":'});assert.equal(bad.status,400);assert.match(bad.headers['content-type']??'',/json/);
 for(const body of ['null','[]','"texto"','{"__proto__":{"admin":true}}','{"constructor":{"prototype":{"admin":true}}}','{"url":{"$ne":1},"amount":[],"slippageBps":"9"}']){
  const r=await raw('/api/analyze',{method:'POST',headers:GOOD,body});assert.ok([400,409].includes(r.status),`${body} → ${r.status}`);assert.doesNotMatch(r.text,/\bat\s+\S+\s+\(|node_modules|\.ts:\d+|[A-Z]:\\/,body);
 }
 assert.equal((await raw('/api/wallet')).status,200);                                                                                                // sigue vivo
});

test('REAL no se puede activar ni operar sin confirmación, sin wallet o sin desbloqueo',async()=>{
 assert.equal((await post('/api/live',{enabled:true})).status,409);
 assert.equal((await post('/api/live',{enabled:true,acknowledgeMainnet:'true'})).status,409);                                                       // string, no booleano
 const r=await post('/api/live',{enabled:true,acknowledgeMainnet:true});assert.equal(r.status,409);assert.equal(JSON.parse(r.text).enabled,undefined);
 const op=await post('/api/operations',{requestId:'3f2504e0-4f89-41d3-9a0c-0305e82c3301',side:'BUY',mode:'REAL',url:'ai-8.nearlytrade.near',amount:'0.1',slippageBps:100});
 assert.equal(op.status,400);assert.match(JSON.parse(op.text).error,/Modo real bloqueado/);
 assert.equal(JSON.parse((await raw('/api/health')).text).liveEnabled,false);
});

test('rutas de mercado: contratos con caracteres de ruta, consultas o nombres hostiles se rechazan antes de llamar a terceros',async()=>{
 for(const t of ['..%2f..%2fapi','a%2fb.near','a.near%3fx%3d1','a.near%23x','A.NEAR','wrap.near','x'.repeat(80)+'.near','%00.near','a%20b.near','a.near%0d%0aX-Evil:1']){
  const r=await raw(`/api/market/${t}`);assert.equal(r.status,400,t);assert.doesNotMatch(r.text,/\bat\s+\S+\s+\(|node_modules|\.ts:\d+/);
 }
 assert.equal((await raw('/api/stream?token=..%2fx')).status,400);
});

test('métodos y rutas inesperados no abren nada',async()=>{
 for(const [m,p] of [['PUT','/api/live'],['DELETE','/api/history'],['PATCH','/api/operations'],['TRACE','/api/wallet'],['GET','/api/wallet/unlock'],['POST','/api/wallet/borrar']] as const){
  const r=await raw(p,{method:m,headers:GOOD,body:m==='POST'?'{}':undefined});assert.ok(r.status>=400&&r.status<500,`${m} ${p} → ${r.status}`);
 }
});

test('fuerza bruta de la contraseña: tras 5 intentos en un minuto se bloquea (sin RPC no hay respuesta útil)',async()=>{
 const codes:number[]=[];
 for(let i=0;i<7;i++)codes.push((await post('/api/wallet/unlock',{password:'incorrecta-'+i})).status);
 assert.equal(codes[5],429);assert.equal(codes[6],429);assert.ok(codes.slice(0,5).every(c=>c===400),codes.join());
 assert.equal((await post('/api/wallet/unlock',{password:'x'.repeat(300)})).status,429);
});

test('streams: el tope de conexiones abiertas evita agotar sockets',async()=>{
 const open:http.ClientRequest[]=[];
 try{
  const results:number[]=[];
  for(let i=0;i<14;i++)results.push(await new Promise<number>(ok=>{const q=http.get({host:'127.0.0.1',port,path:'/api/events'},res=>{ok(res.statusCode!);if(res.statusCode!==200)res.resume();});open.push(q);q.on('error',()=>ok(0));}));
  assert.equal(results.filter(c=>c===200).length,12);assert.equal(results.filter(c=>c===429).length,2);
 }finally{for(const q of open)q.destroy();}
 await new Promise(r=>setTimeout(r,300));
 const again=await new Promise<number>(ok=>{const q=http.get({host:'127.0.0.1',port,path:'/api/events'},res=>{ok(res.statusCode!);q.destroy();});});
 assert.equal(again,200);                                                                                                                           // el cupo se libera al cerrar
});

test('unidad: guardas aisladas (host, origen, cabecera, tope de conexiones, headers)',()=>{
 const res=()=>{const r:any={code:0,headers:{} as any,status(c:number){r.code=c;return r;},json(b:any){r.body=b;return r;},type(){return r;},send(b:any){r.body=b;return r;},set(h:any,v?:string){Object.assign(r.headers,typeof h==='string'?{[h]:v}:h);return r;},removeHeader(){},on(){}};return r;};
 const run=(mw:any,req:any)=>{const r=res();let nexted=false;mw(req,r,()=>{nexted=true;});return {r,nexted};};
 assert.equal(run(hostGuard(),{hostname:'127.0.0.1',path:'/'}).nexted,true);assert.equal(run(hostGuard(),{hostname:'evil.com',path:'/api/x'}).r.code,403);
 assert.equal(run(apiGuard(4317),{headers:{},method:'GET'}).nexted,true);assert.equal(run(apiGuard(4317),{headers:{origin:'http://x.com'},method:'GET'}).r.code,403);
 assert.equal(run(apiGuard(4317),{headers:{},method:'POST'}).r.code,403);assert.equal(run(apiGuard(4317),{headers:{'x-gabnear-client':'local'},method:'POST'}).nexted,true);
 assert.equal(run(securityHeaders as any,{}).r.headers['X-Frame-Options'],'DENY');
 const cap=connectionCap(1);const a=res(),handlers:Function[]=[];a.on=(e:string,f:Function)=>{if(e==='close')handlers.push(f);};let n1=false;cap({} as any,a,()=>{n1=true;});assert.equal(n1,true);
 assert.equal(run(cap,{}).r.code,429);handlers.forEach(f=>f());assert.equal(run(cap,{}).nexted,true);
});
