// Compartir con amigos: el paquete no lleva datos personales y cada PC arranca una terminal nueva con sus datos propios.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {spawn,type ChildProcess} from 'node:child_process';
import {copyFileSync,existsSync,mkdirSync,mkdtempSync,readdirSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {shouldExclude,listFiles,scanText,collectPersonal,scanFiles,stage} from '../scripts/share-lib.js';

const PROJECT=process.env.GABNEAR_TEST_ROOT??resolve('.');
const tmp=()=>mkdtempSync(join(PROJECT,'.cache','share-'+randomBytes(3).toString('hex')+'-'));

test('qué se excluye del paquete: datos, .env, wallets, claves, cachés y dependencias; se conserva .env.example y el código',()=>{
 for(const rel of ['data/history.json','data/wallet-v2.dpapi','data/selected-account.txt','.env','.env.local','.env.production','node_modules/x/index.js','dist/index.html','.cache/setup-version.txt','.git/config','wallet.json','mi-wallet.dpapi','data/archive/a.wallet-v2.dpapi','clave.pem','x.key','servidor.log','.npmrc','.near-credentials/mainnet/a.json','sub/dir/data/x.json','Thumbs.db','nearly-viejo.js'])
  assert.equal(shouldExclude(rel),true,rel);
 for(const rel of ['.env.example','package.json','package-lock.json','server/index.ts','src/main.tsx','public/assets/gabi-gabear-v1.png','Iniciar-GABNEAR.bat','README.md','scripts/empaquetar.ts','.gitignore','tests/security.test.ts'])
  assert.equal(shouldExclude(rel),false,rel);
});

test('detector de fugas: claves privadas, tokens de Telegram, RPC con clave y datos personales; ignora claves públicas y textos normales',()=>{
 const priv='ed25519:'+'3'.repeat(88),pub='ed25519:'+'5'.repeat(44);
 assert.equal(scanText(`clave ${priv}`,'a.ts').length,1);assert.equal(scanText(`pública ${pub}`,'a.ts').length,0);
 assert.equal(scanText('TELEGRAM_BOT_TOKEN=123456789:ABCdefGhIJKlmNoPQRsTUVwxyz0123456789','.env.x').length,1);
 assert.equal(scanText('NEAR_RPC_URL=https://rpc.example.com/?apikey=abcdef123456','.env.x').length,1);assert.equal(scanText('https://near.drpc.org y https://free.rpc.fastnear.com','a.md').length,0);
 assert.equal(scanText('mi cuenta es Amigo-Prueba.near','a.md',['amigo-prueba.near']).length,1);assert.equal(scanText('ninguna cuenta','a.md',['amigo-prueba.near']).length,0);assert.equal(scanText('x','a.md',['abc']).length,0);   // datos de <5 letras se ignoran
});

test('datos personales de la instalación: se leen de data/ y .env y se buscan en todo el paquete',()=>{
 const d=tmp();try{
  mkdirSync(join(d,'data'));writeFileSync(join(d,'data','selected-account.txt'),'﻿amigo-uno.near');writeFileSync(join(d,'data','history.json'),JSON.stringify([{signer:'firmante.near'},{signer:'wrap.near'}]));
  writeFileSync(join(d,'.env'),'PORT=4317\nBOT_ACCOUNT_ID=cuenta-bot.near\nTELEGRAM_CHAT_ID=987654321\nNEAR_RPC_URL=https://x\n');
  const p=collectPersonal(d);for(const v of ['amigo-uno.near','firmante.near','cuenta-bot.near','987654321'])assert.ok(p.includes(v),v);assert.ok(!p.includes('wrap.near'));
  writeFileSync(join(d,'README.md'),'ver cuenta-bot.near');writeFileSync(join(d,'ok.md'),'nada');
  const leaks=scanFiles(d,['README.md','ok.md'],p);assert.equal(leaks.length,1);assert.equal(leaks[0].file,'README.md');
  const vacio=mkdtempSync(join(PROJECT,'.cache','share-vacio-'));try{assert.deepEqual(collectPersonal(vacio),[]);}finally{rmSync(vacio,{recursive:true,force:true});}
 }finally{rmSync(d,{recursive:true,force:true});}
});

test('el proyecto real: ningún archivo del paquete contiene claves, tokens ni las cuentas de esta instalación; .env.example sin cuenta ni token',()=>{
 const files=listFiles(PROJECT);
 assert.ok(files.includes('.env.example')&&files.includes('Iniciar-GABNEAR.bat')&&files.includes('package-lock.json'));
 assert.ok(files.every(f=>!f.startsWith('data/')&&f!=='.env'&&!f.startsWith('node_modules/')&&!f.startsWith('dist/')));
 const leaks=scanFiles(PROJECT,files.filter(f=>!f.startsWith('tests/')),collectPersonal(PROJECT));
 assert.deepEqual(leaks,[]);
 const personalOnly=scanFiles(PROJECT,files.filter(f=>f.startsWith('tests/')),collectPersonal(PROJECT)).filter(l=>/dato personal/.test(l.reason));assert.deepEqual(personalOnly,[]);
 assert.doesNotMatch(readFileSync(join(PROJECT,'.env.example'),'utf8'),/^[ \t]*(BOT_ACCOUNT_ID|TELEGRAM_BOT_TOKEN|TELEGRAM_CHAT_ID)[ \t]*=[ \t]*\S+/m);
});

function get(port:number,path:string):Promise<any>{return new Promise((ok,fail)=>{http.get({host:'127.0.0.1',port,path,headers:{}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>{try{ok(JSON.parse(b));}catch{ok(b);}});}).on('error',fail);});}

test('terminal nueva en otra PC: el paquete copiado arranca con wallet, historial y posiciones VACÍOS y crea su propia data/',async()=>{
 const root=tmp(),dest=join(root,'GABNEAR');let child:ChildProcess|null=null;
 try{
  stage(PROJECT,dest);
  // Lo que hace el lanzador en una PC nueva: crea .env desde .env.example (acá, con otro puerto y sin red).
  const port=await new Promise<number>(ok=>{const s=http.createServer();s.listen(0,'127.0.0.1',()=>{const p=(s.address() as any).port;s.close(()=>ok(p));});});
  writeFileSync(join(dest,'.env'),readFileSync(join(dest,'.env.example'),'utf8').replace(/^PORT=.*$/m,`PORT=${port}`).replace(/^NEAR_RPC_URL=.*$/m,'NEAR_RPC_URL=http://127.0.0.1:9').replace(/^NEAR_RPC_BROADCAST=.*$/m,'NEAR_RPC_BROADCAST='));
  assert.equal(existsSync(join(dest,'data')),false);assert.equal(existsSync(join(dest,'node_modules')),false);
  child=spawn(process.execPath,[join(PROJECT,'node_modules','tsx','dist','cli.mjs'),join(dest,'server','index.ts')],{cwd:dest,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
  await new Promise<void>((ok,fail)=>{const t=setTimeout(()=>fail(new Error('no arrancó')),20000);child!.stdout!.on('data',d=>{if(String(d).includes('GABNEAR http://')){clearTimeout(t);ok();}});child!.on('exit',c=>{clearTimeout(t);fail(new Error('terminó '+c));});});
  const wallet=await get(port,'/api/wallet');
  assert.equal(wallet.accountId,'');assert.equal(wallet.hasLocalKey,false);assert.equal(wallet.unlocked,false);                              // sin cuenta ni clave: cada amigo crea la suya
  assert.deepEqual(await get(port,'/api/history'),[]);assert.deepEqual(await get(port,'/api/positions'),[]);
  const data=readdirSync(join(dest,'data'));assert.ok(!data.some(f=>/wallet|account|selected/.test(f)),data.join());                           // data/ propia, sin ningún dato heredado
 }finally{child?.kill();await new Promise(r=>setTimeout(r,300));rmSync(root,{recursive:true,force:true});}
});
