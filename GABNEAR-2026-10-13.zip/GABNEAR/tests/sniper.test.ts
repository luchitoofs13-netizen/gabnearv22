import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Sniper,MAX_ACTIVE,type ProbeResult,type SniperDeps} from '../server/sniper.js';

const TOKEN='nuevo.tkn.near',ME='me.near',T0=Date.parse('2026-10-12T12:00:00Z');
const READY=(liquidityNear:number|null=99):ProbeResult=>({ready:true,liquidityNear,venue:'DCL',poolId:'p'});
function setup(over:Partial<SniperDeps>={},st:{probe?:ProbeResult|Error;live?:boolean;stopped?:boolean;account?:string;submitError?:string}={}){
 const s={probe:st.probe??({ready:false,reason:'Sin pools'} as ProbeResult),live:st.live??true,stopped:st.stopped??false,account:st.account??ME,submitError:st.submitError??'',now:T0};
 const rows:any[]=[],submitted:any[]=[],events:string[]=[];
 const deps:SniperDeps={
  probe:async()=>{if(s.probe instanceof Error)throw s.probe;return s.probe;},
  verifyToken:async t=>{if(t==='roto.near')throw new Error('no existe');return {symbol:'NUEVO'};},
  submit:raw=>{if(s.submitError)throw new Error(s.submitError);submitted.push(raw);const r:any={id:'op'+submitted.length,...(raw as any),status:'QUEUED'};rows.unshift(r);return r;},
  rows:()=>rows,live:()=>s.live,stopped:()=>s.stopped,account:()=>s.account,maxBps:()=>1000,now:()=>s.now,onEvent:t=>events.push(t.status),...over};
 return {sn:new Sniper(deps),s,rows,submitted,events,advance:(ms:number)=>{s.now+=ms;}};
}
const input=(o:any={})=>({url:TOKEN,amount:'0.5',slippageBps:300,mode:'REAL',...o});

test('add: valida contrato, importe, slippage, liquidez, duración, modo REAL y límites',async()=>{
 const {sn,s}=setup();
 await assert.rejects(()=>sn.add(null),/inválidos/);await assert.rejects(()=>sn.add(input({url:'wrap.near'})),/./);await assert.rejects(()=>sn.add(input({url:'no es un token'})),/./);
 await assert.rejects(()=>sn.add(input({amount:'0'})),/Importe/);await assert.rejects(()=>sn.add(input({amount:'abc'})),/Importe/);await assert.rejects(()=>sn.add(input({amount:'-1'})),/Importe/);
 await assert.rejects(()=>sn.add(input({slippageBps:1500})),/Slippage máximo permitido: 10%/);await assert.rejects(()=>sn.add(input({slippageBps:0})),/Slippage/);
 await assert.rejects(()=>sn.add(input({minLiquidityNear:-1})),/liquidez mínima/);await assert.rejects(()=>sn.add(input({expiresInMin:0})),/dura entre/);await assert.rejects(()=>sn.add(input({expiresInMin:721})),/dura entre/);
 await assert.rejects(()=>sn.add(input({url:'roto.near'})),/no existe/);
 s.live=false;await assert.rejects(()=>sn.add(input()),/REAL no está activo/);s.live=true;s.stopped=true;await assert.rejects(()=>sn.add(input()),/Parada de emergencia/);s.stopped=false;
 s.account='';await assert.rejects(()=>sn.add(input()),/Conectá una wallet/);s.account=ME;
 const t=await sn.add(input({autoSell:{takeProfitPct:50}}));assert.equal(t.status,'WATCHING');assert.equal(t.minLiquidityNear,10);assert.equal(t.symbol,'NUEVO');assert.equal(Date.parse(t.expiresAt)-Date.parse(t.createdAt),3600000);
 await assert.rejects(()=>sn.add(input()),/Ya estás vigilando/);
 for(const n of ['a1','a2'])await sn.add(input({url:n+'.tkn.near'}));
 await assert.rejects(()=>sn.add(input({url:'a3.tkn.near'})),new RegExp(`Máximo ${MAX_ACTIVE}`));
 assert.equal(sn.view()[0].hasAutoSell,false);assert.equal(sn.view().find(v=>v.id===t.id)!.hasAutoSell,true);assert.equal((sn.view()[0] as any).autoSell,undefined);
});

test('add: si ya hay pool con la liquidez pedida no vigila (evita un disparo inmediato); sí vigila si falta liquidez o no hay lectura',async()=>{
 const a=setup({},{probe:READY(50)});await assert.rejects(()=>a.sn.add(input()),/ya tiene pool/);
 const b=setup({},{probe:READY(2)});assert.equal((await b.sn.add(input())).status,'WATCHING');
 const c=setup({},{probe:new Error('429')});assert.equal((await c.sn.add(input())).status,'WATCHING');
});

test('tick: espera sin pool; con poca liquidez espera; cuando cumple dispara UNA sola compra con requestId fijo y AUTO SELL',async()=>{
 const {sn,s,submitted,rows,events}=setup();const t=await sn.add(input({minLiquidityNear:20,autoSell:{takeProfitPct:80,stopLossPct:30}}));
 await sn.tick();await sn.tick();assert.equal(submitted.length,0);assert.equal(t.checks,2);assert.match(t.detail,/Sin pools/);
 s.probe={ready:true,liquidityNear:5,venue:'REF_V1',poolId:'8'};await sn.tick();assert.equal(submitted.length,0);assert.match(t.detail,/5\.00 NEAR.*esperando 20/);
 s.probe=READY(35);await sn.tick();
 assert.equal(submitted.length,1);assert.deepEqual(submitted[0],{requestId:t.requestId,side:'BUY',mode:'REAL',url:TOKEN,amount:'0.5',slippageBps:300,payWith:'NEAR',autoSell:{takeProfitPct:80,stopLossPct:30}});
 assert.equal(t.status,'FIRING');assert.equal(t.opId,'op1');assert.ok(t.poolAt);
 await sn.tick();await sn.tick();assert.equal(submitted.length,1);                                                          // jamás dos compras
 rows[0].status='SETTLING';await sn.tick();assert.equal(t.status,'FIRING');
 rows[0].status='FILLED';await sn.tick();assert.equal(t.status,'BOUGHT');await sn.tick();assert.equal(submitted.length,1);
 assert.deepEqual(events,['WATCHING','FIRING','BOUGHT']);
});

test('DRY RUN simula (SIMULATED, sin gastar); bloqueo por riesgo o tope = BLOCKED; otros fallos = FAILED',async()=>{
 const e=setup({},{live:false});const t5=await e.sn.add(input({mode:'DRY RUN',url:'q.tkn.near'}));assert.equal(t5.mode,'DRY RUN');e.s.probe=READY();
 await e.sn.tick();assert.equal(e.submitted[0].mode,'DRY RUN');e.rows[0].status='ANALYZED';await e.sn.tick();assert.equal(t5.status,'SIMULATED');
 const fail=async(error:string)=>{const x=setup();const t=await x.sn.add(input({url:'x.tkn.near'}));x.s.probe=READY();await x.sn.tick();x.rows[0].status='FAILED';x.rows[0].error=error;await x.sn.tick();return t;};
 const risk=await fail('Compra bloqueada por riesgo: impacto 9%.');assert.equal(risk.status,'BLOCKED');assert.match(risk.detail,/impacto/);
 assert.equal((await fail('Compra bloqueada por el tope diario: ya compraste 3 NEAR.')).status,'BLOCKED');
 assert.equal((await fail('Saldo nativo insuficiente.')).status,'FAILED');
});

test('si otra operación está en curso espera y reintenta; un rechazo definitivo termina FAILED sin reintentar',async()=>{
 const {sn,s,submitted}=setup();const t=await sn.add(input());s.probe=READY();
 s.submitError='Ya hay una operación en curso.';await sn.tick();assert.equal(t.status,'WATCHING');assert.match(t.detail,/esperando que termine/);assert.equal(submitted.length,0);
 s.submitError='Hay una transacción incierta. GABNEAR recupera automáticamente.';await sn.tick();assert.equal(t.status,'WATCHING');
 s.submitError='';await sn.tick();assert.equal(submitted.length,1);assert.equal(t.status,'FIRING');
 const o=setup();const t2=await o.sn.add(input());o.s.probe=READY();o.s.submitError='Modo real bloqueado: habilitá REAL.';await o.sn.tick();assert.equal(t2.status,'FAILED');o.s.submitError='';await o.sn.tick();assert.equal(o.submitted.length,0);
});

test('REAL: se pausa sin REAL o con parada, reanuda sola, se cancela si cambia la wallet y NO dispara estando pausada',async()=>{
 const {sn,s,submitted}=setup();const t=await sn.add(input());
 s.probe=READY();s.live=false;await sn.tick();assert.equal(t.status,'PAUSED');assert.equal(submitted.length,0);
 s.live=true;s.stopped=true;await sn.tick();assert.equal(t.status,'PAUSED');assert.equal(submitted.length,0);
 s.stopped=false;await sn.tick();assert.equal(t.status,'FIRING');assert.equal(submitted.length,1);
 const w=setup();const t2=await w.sn.add(input({url:'w.tkn.near'}));w.s.account='otra.near';w.s.probe=READY();await w.sn.tick();assert.equal(t2.status,'CANCELLED');assert.equal(w.submitted.length,0);
});

test('vence, se cancela y un error de lectura no dispara nada (429 espera 5 s)',async()=>{
 const {sn,s,submitted,advance}=setup();const t=await sn.add(input({expiresInMin:2}));
 s.probe=new Error('429 Too Many Requests');await sn.tick();assert.equal(submitted.length,0);assert.match(t.detail,/Error de lectura/);assert.equal(t.status,'WATCHING');
 s.probe=READY();await sn.tick();assert.equal(t.checks,0);assert.equal(submitted.length,0);                                    // en espera por el límite de cuota
 advance(5100);await sn.tick();assert.equal(submitted.length,1);
 const b=setup();const t2=await b.sn.add(input({expiresInMin:1}));b.advance(61000);await b.sn.tick();assert.equal(t2.status,'EXPIRED');assert.equal(b.submitted.length,0);
 const c=setup();const t3=await c.sn.add(input());c.sn.cancel(t3.id);assert.equal(t3.status,'CANCELLED');c.s.probe=READY();await c.sn.tick();assert.equal(c.submitted.length,0);
 assert.throws(()=>c.sn.cancel('nada'),/desconocida/);
 const d=setup();const t4=await d.sn.add(input());d.s.probe=READY();await d.sn.tick();assert.throws(()=>d.sn.cancel(t4.id),/ya se disparó/);
});

test('un contrato cancelado puede volver a vigilarse y el historial de terminadas es acotado',async()=>{
 const {sn}=setup();
 for(let i=0;i<25;i++){const t=await sn.add(input({url:`t${i}.tkn.near`}));sn.cancel(t.id);}
 assert.ok(sn.targets.filter(t=>t.status==='CANCELLED').length<=21);   // se poda al agregar: 20 viejas + la última recién canceladaassert.equal((await sn.add(input({url:'t0.tkn.near'}))).status,'WATCHING');
});
