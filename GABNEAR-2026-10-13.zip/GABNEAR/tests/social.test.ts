import {test} from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {extractContracts,extractCashtags,parseChannelHtml,aggregate,SocialTracker,CHANNEL} from '../server/social.js';
import {Fetcher} from '../server/fetcher.js';

const html=(posts:{id:string;at:string;text:string}[])=>posts.map(p=>`<div class="tgme_widget_message_wrap js-widget_message_wrap"><div class="tgme_widget_message text_not_supported_wrap js-widget_message" data-post="${p.id}"><div class="tgme_widget_message_text js-message_text" dir="auto">${p.text}</div><a class="tgme_widget_message_date" href="https://t.me/${p.id}"><time datetime="${p.at}" class="time">12:00</time></a></div></div>`).join('\n');

test('Telegram: extrae solo contratos de launchpads conocidos y cashtags; el HTML se trata como texto',()=>{
 assert.deepEqual(extractContracts('mirá ninu-4.nearlytrade.near y alice.near y wrap.near, NUEVO.MEME-COOKING.NEAR!'),['ninu-4.nearlytrade.near','nuevo.meme-cooking.near']);
 assert.deepEqual(extractContracts('sin nada .near ..near a..b.near'),[]);assert.deepEqual(extractCashtags('compren $ninu y $KINU, $ninu 100$ $1'),['$NINU','$KINU']);
 const msgs=parseChannelHtml(html([
  {id:'canal_test/10',at:'2026-10-12T10:00:00+00:00',text:'🔥 <b>NINU</b> <a href="https://nearly.trade/ninu-4.nearlytrade.near">link</a> $NINU<br/>entren &amp; vean <script>alert(1)</script>'},
  {id:'canal_test/11',at:'2026-10-12T11:00:00+00:00',text:'nada que ver'},
  {id:'otro_canal/5',at:'2026-10-12T11:30:00+00:00',text:'ajeno kinu-3.nearlytrade.near'}]),'canal_test');
 assert.equal(msgs.length,2);assert.deepEqual(msgs[0].contracts,['ninu-4.nearlytrade.near']);assert.deepEqual(msgs[0].cashtags,['$NINU']);assert.equal(msgs[0].link,'https://t.me/canal_test/10');
 assert.ok(!msgs[0].text.includes('<b>')&&msgs[0].text.includes('entren & vean'));assert.equal(msgs[1].contracts.length,0);
 assert.deepEqual(parseChannelHtml('<html>nada</html>','canal_test'),[]);
 const agg=aggregate([{...msgs[0],channel:'a_canal'},{...msgs[0],channel:'b_canal',at:'2026-10-12T12:00:00.000Z'},{...msgs[1],channel:'a_canal'}]);
 assert.equal(agg.length,1);assert.equal(agg[0].count,2);assert.deepEqual(agg[0].channels,['a_canal','b_canal']);assert.equal(agg[0].launchpad,'Nearly');
});

test('SocialTracker: valida y persiste canales, mezcla el .env, consulta cada canal una vez por minuto y tolera fallos',async()=>{
 assert.ok(CHANNEL.test('degen_corp')&&!CHANNEL.test('ab')&&!CHANNEL.test('1canal')&&!CHANNEL.test('../etc')&&!CHANNEL.test('a b c d e'));
 const dir=mkdtempSync(join(process.cwd(),'sec-'));const file=join(dir,'ch.json');
 try{
  let hits=0;const pages:Record<string,string>={'https://t.me/s/degen_corp':html([{id:'degen_corp/1',at:'2026-10-12T10:00:00Z',text:'ninu-4.nearlytrade.near'}])};
  const f=new Fetcher('T',0,1000,(async(url:string)=>{hits++;if(!pages[url])return {ok:false,status:404,text:async()=>''};return {ok:true,status:200,text:async()=>pages[url]};}) as any);
  const t=new SocialTracker(f,file,{TG_CHANNELS:'@degen_corp, invalido!, rota_canal'});
  assert.deepEqual(t.channels,['degen_corp','rota_canal']);
  assert.throws(()=>t.add('ab'),/inválido/);assert.throws(()=>t.add('https://t.me/s/degen_corp'),/Ya seguís/);assert.equal(t.add('https://t.me/s/nuevo_canal'),'nuevo_canal');
  const snap=await t.snapshot();assert.equal(snap.mentions[0].token,'ninu-4.nearlytrade.near');assert.equal(snap.errors.length,2);assert.equal(hits,3);
  await t.snapshot();assert.equal(hits,5);                                                                        // el canal que respondió está en caché (55 s); los 2 que fallaron se reintentan
  t.remove('ROTA_CANAL');assert.deepEqual(t.channels,['degen_corp','nuevo_canal']);
  assert.ok(existsSync(file));assert.deepEqual(new SocialTracker(f,file,{}).channels,['degen_corp','nuevo_canal']);       // persistió
  for(let i=0;i<8;i++)t.add('canal_num'+i);assert.throws(()=>t.add('canal_extra'),/Máximo 10/);
 }finally{rmSync(dir,{recursive:true,force:true});}
});
