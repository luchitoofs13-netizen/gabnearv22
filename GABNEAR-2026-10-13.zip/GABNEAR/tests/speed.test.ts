import test,{afterEach,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {KeyPair,KeyPairSigner} from 'near-api-js';
import {getSpeed,setSpeed,resetSpeed} from '../server/settings.js';
import {Executor} from '../server/transactions.js';
import {Recovery} from '../server/recovery.js';
import {swap,prepareWnear,setLiveSession} from '../server/trading.js';
import {Operations} from '../server/operations.js';
import {preview} from '../server/analysis.js';
import {NearRpc} from '../server/rpc.js';
import {dclRoute,refIndex,clearRouteCache} from '../server/venues.js';
import {units} from '../server/validation.js';
import type {History} from '../server/history.js';

const ME='me.near',TOKEN='gen.tkn.near',W='wrap.near',DCL='dclv2.ref-labs.near';
const saved={account:process.env.BOT_ACCOUNT_ID,confirm:process.env.CONFIRM_LEVEL,prep:process.env.PREP_LEVEL,arm:process.env.AUTO_ARM};
let dir='',original='';
before(()=>{original=process.cwd();dir=mkdtempSync(join(tmpdir(),'gabnear-speed-'));process.chdir(dir);process.env.BOT_ACCOUNT_ID=ME;});
after(()=>{process.chdir(original);rmSync(dir,{recursive:true,force:true});for(const [k,v] of [['BOT_ACCOUNT_ID',saved.account],['CONFIRM_LEVEL',saved.confirm],['PREP_LEVEL',saved.prep],['AUTO_ARM',saved.arm]] as const){if(v===undefined)delete process.env[k];else process.env[k]=v;}});
afterEach(()=>{resetSpeed();rmSync(join(dir,'data'),{recursive:true,force:true});delete process.env.NEAR_CONFIRM_TIMEOUT_MS;delete process.env.CONFIRM_LEVEL;delete process.env.PREP_LEVEL;delete process.env.AUTO_ARM;setLiveSession(false);clearRouteCache();refIndex.reset();});
function memory(rows:any[]=[]){return {rows,save(r:any){rows.unshift(r);return r;},update(id:string,p:any){Object.assign(rows.find(r=>r.id===id),p);}} as unknown as History;}

test('ajustes de velocidad: por defecto seguros, validados, persistentes y con .env como base',()=>{
 resetSpeed();assert.deepEqual(getSpeed(),{confirmLevel:'final',prepLevel:'optimistic',autoArm:false});
 process.env.CONFIRM_LEVEL='optimistic';process.env.PREP_LEVEL='final';process.env.AUTO_ARM='true';resetSpeed();
 assert.deepEqual(getSpeed(),{confirmLevel:'optimistic',prepLevel:'final',autoArm:true});
 delete process.env.CONFIRM_LEVEL;delete process.env.PREP_LEVEL;delete process.env.AUTO_ARM;resetSpeed();
 assert.deepEqual(setSpeed({confirmLevel:'optimistic'}),{confirmLevel:'optimistic',prepLevel:'optimistic',autoArm:false});
 resetSpeed();assert.equal(getSpeed().confirmLevel,'optimistic','se relee de data/speed.json');
 for(const bad of [{confirmLevel:'rapido'},{prepLevel:1},{autoArm:'si'}])assert.throws(()=>setSpeed(bad),/debe ser/);
 assert.equal(getSpeed().confirmLevel,'optimistic','un valor inválido no cambia nada');
 assert.deepEqual(setSpeed({}),getSpeed());
});

async function callHarness(statuses:string[]){
 const rows:any[]=[{id:'op',status:'PREPARING',fundsSent:false}];const history:any={rows,update:(_i:string,p:any)=>Object.assign(rows[0],p)};
 let polls=0,waits:string[]=[];
 const out=(status:string)=>({final_execution_status:status,status:{SuccessValue:''},transaction_outcome:{outcome:{tokens_burnt:'1'}},receipts_outcome:[]});
 const rpc:any={deadline:(p:Promise<any>)=>p,provider:{sendTransactionUntil:async(_s:any,w:string)=>{waits.push(w);return {final_execution_status:'NONE'};}},transactionStatus:async()=>out(statuses[Math.min(polls++,statuses.length-1)])};
 const signer=KeyPairSigner.fromSecretKey(KeyPair.fromRandom('ed25519').toString());
 const context={signer,publicKey:await signer.getPublicKey(),account:ME,nonce:7n,blockHash:new Uint8Array(32),blockHeight:10,at:Date.now()};
 return {rows,ex:new Executor(rpc,history,()=>false),context,polls:()=>polls,waits};
}
test('confirmación optimista termina en cuanto se ejecuta; la final sigue esperando FINAL',async()=>{
 const a=await callHarness(['INCLUDED','EXECUTED_OPTIMISTIC','EXECUTED','FINAL']);
 const o=await a.ex.call('op',W,'near_deposit',{},1n,10,a.context,{confirm:'OPTIMISTIC'});
 assert.equal(o.final_execution_status,'EXECUTED_OPTIMISTIC');assert.equal(a.polls(),2);
 assert.equal(a.rows[0].finality,'OPTIMISTIC');assert.equal(a.rows[0].transactions[0].status,'EXECUTED');assert.equal(a.rows[0].status,'PREPARING');
 const b=await callHarness(['INCLUDED','EXECUTED_OPTIMISTIC','EXECUTED','FINAL']);
 const f=await b.ex.call('op',W,'near_deposit',{},1n,10,b.context);
 assert.equal(f.final_execution_status,'FINAL');assert.equal(b.polls(),4);assert.equal(b.rows[0].finality,'FINAL');assert.equal(b.rows[0].transactions[0].status,'FINAL');
 process.env.NEAR_CONFIRM_TIMEOUT_MS='400';
 const n=await callHarness(['INCLUDED','INCLUDED_FINAL']);                       // nunca llega a ejecutarse: no se da por hecho
 await assert.rejects(()=>n.ex.call('op',W,'near_deposit',{},1n,10,n.context,{confirm:'OPTIMISTIC'}),/incierto/);
});

// ── swap con confirmación rápida ─────────────────────────────────────────────────────────────────────
function swapWorld(status:string){
 const row:any={id:'swap',status:'PREPARING',txHash:'synthetic-hash'};const history=memory([row]);const sent:any={};
 const rpc:any={view:async(c:string,m:string)=>{if(m==='get_return'||m==='quote')return m==='quote'?{amount:'1000'}:'1000';if(m==='ft_balance_of')return '0';throw new Error(m);},account:async()=>({amount:'1'})};
 const outcome={final_execution_status:status,status:{SuccessValue:Buffer.from(JSON.stringify('1000')).toString('base64')},transaction_outcome:{outcome:{tokens_burnt:'0'}},receipts_outcome:[{id:'r',outcome:{executor_id:TOKEN,status:{SuccessValue:''},logs:['EVENT_JSON:'+JSON.stringify({standard:'nep141',event:'ft_transfer',data:[{old_owner_id:DCL,new_owner_id:ME,amount:'990'}]})]}}]};
 const ex:any={rpc,history,call:async(_id:string,contract:string,method:string,args:any,_d:bigint,gas:number,_ctx:any,opts:any)=>{Object.assign(sent,{contract,method,gas,opts});return outcome;}};
 return {ex,row,sent};
}
test('swap: confirmación optimista da por llenada una ejecución optimista; en modo final la deja incierta',async()=>{
 setLiveSession(true);
 setSpeed({confirmLevel:'optimistic'});const fast=swapWorld('EXECUTED_OPTIMISTIC');
 const r=await swap(fast.ex,'swap',dclRoute(TOKEN,W,10000),W,TOKEN,1000n,300);
 assert.equal(r.state,'FILLED');assert.equal(fast.sent.opts.confirm,'OPTIMISTIC');assert.equal(fast.row.evidence,'nep141-receipts');
 setSpeed({confirmLevel:'final'});const slow=swapWorld('EXECUTED_OPTIMISTIC');
 const u=await swap(slow.ex,'swap',dclRoute(TOKEN,W,10000),W,TOKEN,1000n,300);
 assert.equal(u.state,'UNKNOWN');assert.equal(slow.sent.opts.confirm,'FINAL');assert.equal(slow.row.status,'UNKNOWN');           // sin FINAL no se declara compra
 const fin=swapWorld('FINAL');assert.equal((await swap(fin.ex,'swap',dclRoute(TOKEN,W,10000),W,TOKEN,1000n,300)).state,'FILLED');
});
test('pasos previos: registro/wrap aceptan ejecución optimista salvo que se pida FINAL',async()=>{
 setLiveSession(true);
 const mk=(status:string)=>{const calls:any[]=[];let regs=0;const ex:any={rpc:{view:async(_c:string,m:string)=>{if(m==='storage_balance_of')return regs++>0?{total:'1'}:null;if(m==='storage_balance_bounds')return {min:'1250000000000000000000'};if(m==='ft_balance_of')return calls.some(c=>c.method==='near_deposit')?units('1').toString():'0';throw new Error(m);}},call:async(_i:string,contract:string,method:string,_a:any,_d:bigint,_g:number,_c:any,opts:any)=>{calls.push({contract,method,opts});return {final_execution_status:status,status:{SuccessValue:''},receipts_outcome:[]};}};return {ex,calls};};
 setSpeed({prepLevel:'optimistic'});const a=mk('EXECUTED_OPTIMISTIC');await prepareWnear(a.ex,'x',units('1'));
 assert.deepEqual(a.calls.map(c=>c.method),['storage_deposit','near_deposit']);assert.ok(a.calls.every(c=>c.opts.confirm==='OPTIMISTIC'));
 setSpeed({prepLevel:'final'});const b=mk('EXECUTED_OPTIMISTIC');await assert.rejects(()=>prepareWnear(b.ex,'x',units('1')),/Registración no confirmada|Falló la preparación/);
 assert.ok(b.calls.every(c=>c.opts.confirm==='FINAL'));
});

// ── ARMAR ────────────────────────────────────────────────────────────────────────────────────────────
function armWorld(registered:{token:boolean;quote:boolean},wnear:bigint){
 const calls:any[]=[];const state={token:registered.token,quote:registered.quote,wnear};
 const rpc:any={status:async()=>({chain_id:'mainnet'}),mainnet:async()=>({chain_id:'mainnet'}),account:async()=>({code_hash:'abc',amount:units('10').toString(),storage_usage:0}),
  view:async(c:string,m:string,a:any)=>{
   if(m==='ft_metadata')return {spec:'ft-1.0.0',name:'Gen',symbol:'GEN',decimals:c===W?24:18};
   if(c==='nearlytrade.near')return null;
   if(c===DCL&&m==='get_pools')return a.pool_ids.map((id:string)=>id.endsWith('|10000')?{pool_id:id,token_x:TOKEN,token_y:W,state:'Running',fee:10000,liquidity:'1',current_point:1}:null);
   if(c===DCL&&m==='quote')return {amount:(BigInt(a.input_amount)*1000n).toString()};
   if(c==='v2.ref-finance.near'&&m==='get_number_of_pools')return 0;
   if(m==='storage_balance_of')return (c===TOKEN?state.token:state.quote)?{total:'1'}:null;
   if(m==='storage_balance_bounds')return {min:'1250000000000000000000'};
   if(m==='ft_balance_of')return c===TOKEN?'0':state.wnear.toString();
   throw new Error(`mock ${c}.${m}`);
  }};
 const history=memory(),ex=new Executor(rpc,history,()=>false);
 (ex as any).call=async(_i:string,contract:string,method:string,args:any,deposit:bigint,_g:number,_c:any,opts:any)=>{
  calls.push({contract,method,deposit,opts});
  if(method==='storage_deposit'){if(contract===TOKEN)state.token=true;else state.quote=true;}
  if(method==='near_deposit')state.wnear+=deposit;
  return {final_execution_status:'EXECUTED_OPTIMISTIC',status:{SuccessValue:''},receipts_outcome:[]};
 };
 return {rpc,history,ex,calls,state};
}
async function settled(ops:Operations){for(let i=0;i<100&&ops.active;i++)await new Promise(r=>setTimeout(r,5));assert.equal(ops.active,false);}
const cfg=()=>({accountId:ME,maxNear:'',maxBps:9900});
test('ARMAR en REAL registra el token y deja wNEAR listo, sin comprar ni vender nada',async()=>{
 setLiveSession(true);const w=armWorld({token:false,quote:true},0n);
 const ops=new Operations(w.rpc,w.history,w.ex,()=>false,cfg);
 const row=ops.submit({requestId:randomUUID(),side:'ARM',mode:'REAL',url:TOKEN,amount:'0.5',slippageBps:300});await settled(ops);
 assert.equal(row.status,'READY',row.error);assert.deepEqual(w.calls.map(c=>`${c.contract}.${c.method}`),[`${TOKEN}.storage_deposit`,`${W}.near_deposit`]);
 assert.equal(w.calls[1].deposit,units('0.5'));assert.ok(!w.calls.some(c=>c.method==='ft_transfer_call'),'armar jamás envía un swap');
 // una segunda orden ya encuentra todo listo: no repite registro ni wrap
 const again=ops.submit({requestId:randomUUID(),side:'ARM',mode:'REAL',url:TOKEN,amount:'0.5',slippageBps:300});await settled(ops);
 assert.equal(again.status,'READY');assert.equal(w.calls.length,2);
});
test('ARMAR en DRY RUN solo analiza; exige importe válido',async()=>{
 const w=armWorld({token:false,quote:false},0n);const ops=new Operations(w.rpc,w.history,w.ex,()=>false,cfg);
 const row=ops.submit({requestId:randomUUID(),side:'ARM',mode:'DRY RUN',url:TOKEN,amount:'0.5',slippageBps:300});await settled(ops);
 assert.equal(row.status,'ANALYZED');assert.equal(w.calls.length,0);assert.equal(row.fundsSent,false);
 assert.throws(()=>ops.submit({requestId:randomUUID(),side:'ARM',mode:'DRY RUN',url:TOKEN,slippageBps:300}),/Importe inválido/);
 assert.throws(()=>ops.submit({requestId:randomUUID(),side:'ARM',mode:'REAL',url:TOKEN,amount:'1',slippageBps:300}),/bloqueado/);
});
test('preview informa si la compra sería un solo swap (token y quote registrados + saldo)',async()=>{
 const full=armWorld({token:true,quote:true},units('5'));
 const a:any=await preview(full.rpc,TOKEN,'0.5',300,ME);assert.deepEqual({...a.ready},{tokenRegistered:true,quoteRegistered:true,quoteBalance:'5',enough:true,armed:true});
 const partial=armWorld({token:false,quote:true},units('0.1'));clearRouteCache();refIndex.reset();
 const b:any=await preview(partial.rpc,TOKEN,'0.5',300,ME);assert.equal(b.ready.armed,false);assert.equal(b.ready.tokenRegistered,false);assert.equal(b.ready.enough,false);
 clearRouteCache();refIndex.reset();assert.equal(((await preview(partial.rpc,TOKEN,'0.5',300,'')) as any).ready,null);
});

// ── vigilante de finalidad ───────────────────────────────────────────────────────────────────────────
function watchHarness(reconcile:(hash:string)=>Promise<any>){
 const rows:any[]=[{id:'a',status:'FILLED',finality:'OPTIMISTIC',txHash:'H',signer:ME,transactions:[{hash:'H',status:'EXECUTED'}]}];
 const history:any={rows,update:(_i:string,p:any)=>Object.assign(rows[0],p)};
 const ex:any={busy:false,reconcile:async(h:string)=>reconcile(h),rpc:{}};
 return {rows,rec:new Recovery(history,ex)};
}
test('vigilante: una operación optimista que llega a FINAL queda confirmada',async()=>{
 let n=0;const h=watchHarness(async()=>({final_execution_status:++n<2?'EXECUTED':'FINAL'}));
 await h.rec.watchFinality();assert.equal(h.rows[0].finality,'OPTIMISTIC');
 (h.rec as any).finalityDue.clear();await h.rec.watchFinality();
 assert.equal(h.rows[0].finality,'FINAL');assert.equal(h.rows[0].transactions[0].status,'FINAL');assert.equal(h.rows[0].status,'FILLED');
});
test('vigilante: si el hash desaparece de la red la fila vuelve a UNKNOWN para recuperarse por hash',async()=>{
 const unknown=Object.assign(new Error('unknown'),{name:'UnknownTransactionError'});
 const h=watchHarness(async()=>{throw unknown;});h.rec.lostAfterMisses=3;
 for(let i=0;i<3;i++){(h.rec as any).finalityDue.clear();await h.rec.watchFinality();}
 assert.equal(h.rows[0].status,'UNKNOWN');assert.equal(h.rows[0].finality,'LOST');assert.match(h.rows[0].error,/reorganización/);
 // otros errores (red caída) no se interpretan como pérdida
 const k=watchHarness(async()=>{throw new Error('red caída');});k.rec.lostAfterMisses=1;
 for(let i=0;i<3;i++){(k.rec as any).finalityDue.clear();await k.rec.watchFinality();}
 assert.equal(k.rows[0].status,'FILLED');
});

// ── difusión a varios RPC ────────────────────────────────────────────────────────────────────────────
function stubRpc(extraUrls:string[]){
 const rpc=new NearRpc('https://primary.invalid',undefined,extraUrls);const extras:any[]=(rpc as any).extras;
 const log:string[]=[];
 return {rpc,extras,log,primary(impl:()=>Promise<any>){(rpc.provider as any).sendTransactionUntil=async()=>{log.push('primary');return impl();};},extra(i:number,impl:()=>Promise<any>,chain='mainnet'){extras[i].sendTransactionUntil=async()=>{log.push('extra'+i);return impl();};extras[i].sendJsonRpc=async()=>({chain_id:chain});}};
}
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
test('difusión: solo https, sin duplicados, máximo 3 extras; sin extras todo sigue igual',()=>{
 const r=new NearRpc('https://p.invalid',undefined,['http://inseguro.invalid','https://a.invalid','https://a.invalid','https://p.invalid','','https://b.invalid','https://c.invalid','https://d.invalid','not a url']);
 assert.equal(r.broadcastCount,4);                                                  // principal + a, b, c
 assert.equal(new NearRpc('https://p.invalid',undefined,[]).broadcastCount,1);
});
test('difusión: devuelve la primera aceptación aunque el principal sea lento o falle',async()=>{
 const s=stubRpc(['https://extra.invalid']);
 s.primary(async()=>{await sleep(40);throw new Error('timeout del principal');});s.extra(0,async()=>({final_execution_status:'NONE',from:'extra'}));
 // primera pasada: el extra aún no está verificado como mainnet → solo se usa el principal
 await assert.rejects(()=>s.rpc.send({},'NONE',2000),/timeout del principal/);assert.deepEqual(s.log,['primary']);
 await sleep(30);                                                                    // la verificación de mainnet corre en segundo plano
 s.log.length=0;const r=await s.rpc.send({},'NONE',2000);
 assert.equal(r.from,'extra');assert.deepEqual([...s.log].sort(),['extra0','primary']);
});
test('difusión: un extra que no es mainnet jamás recibe la firma; si todos fallan se lanza el error del principal',async()=>{
 const s=stubRpc(['https://extra.invalid']);
 s.primary(async()=>({final_execution_status:'NONE',from:'primary'}));s.extra(0,async()=>({from:'extra'}),'testnet');
 await s.rpc.send({},'NONE',2000);await sleep(30);s.log.length=0;
 const r=await s.rpc.send({},'NONE',2000);assert.equal(r.from,'primary');assert.deepEqual(s.log,['primary']);
 const t=stubRpc(['https://extra.invalid']);t.primary(async()=>{throw Object.assign(new Error('rechazo principal'),{name:'NotEnoughBalanceError'});});t.extra(0,async()=>{throw new Error('error del extra');});
 await t.rpc.send({},'NONE',2000).catch(()=>{});await sleep(30);
 await assert.rejects(()=>t.rpc.send({},'NONE',2000),(e:any)=>e.name==='NotEnoughBalanceError'&&/rechazo principal/.test(e.message));
});
test('Executor usa rpc.send cuando existe (difusión) y respeta el nivel de espera',async()=>{
 const rows:any[]=[{id:'op',status:'PREPARING',fundsSent:false}];const history:any={rows,update:(_i:string,p:any)=>Object.assign(rows[0],p)};
 const seen:any[]=[];const rpc:any={deadline:(p:Promise<any>)=>p,send:async(_s:any,wait:string,timeout:number)=>{seen.push({wait,timeout});return {final_execution_status:'NONE'};},provider:{sendTransactionUntil:async()=>{throw new Error('no debería usarse');}},transactionStatus:async()=>({final_execution_status:'FINAL',status:{SuccessValue:''},transaction_outcome:{outcome:{tokens_burnt:'1'}},receipts_outcome:[]})};
 const signer=KeyPairSigner.fromSecretKey(KeyPair.fromRandom('ed25519').toString());
 const ctx={signer,publicKey:await signer.getPublicKey(),account:ME,nonce:1n,blockHash:new Uint8Array(32),blockHeight:1,at:Date.now()};
 await new Executor(rpc,history,()=>false).call('op',W,'near_deposit',{},1n,10,ctx);
 assert.deepEqual(seen,[{wait:'NONE',timeout:3000}]);
});
