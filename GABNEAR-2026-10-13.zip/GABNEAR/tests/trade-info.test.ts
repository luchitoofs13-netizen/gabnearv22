import {test} from 'node:test';
import assert from 'node:assert/strict';
import {usdOf,money,poolHealth,pnlSummary,totalPnl} from '../src/trade-info.js';
import {sanitizePresets,DEFAULT_PRESETS} from '../src/Presets.js';

test('usdOf y money: conversión a dólares, signos y números chicos',()=>{
 assert.equal(usdOf(4,5.7),22.8);assert.equal(usdOf(4,null),null);assert.equal(usdOf(NaN,5),null);assert.equal(usdOf(4,Infinity),null);
 assert.equal(money(22.8),'$22.80');assert.equal(money(1234.5),'$1,235');assert.equal(money(0.4567),'$0.457');assert.equal(money(0.000123),'$0.00012');assert.equal(money(0),'$0.00');
 assert.equal(money(-3.2,true),'−$3.20');assert.equal(money(3.2,true),'+$3.20');assert.equal(money(3.2),'$3.20');assert.equal(money(null),'—');assert.equal(money(NaN),'—');
});
test('poolHealth: avisa pool chico, compra grande contra el pool e impacto de precio',()=>{
 assert.equal(poolHealth(70000,50,10).level,'ok');assert.match(poolHealth(70000,50,10).text,/razonable/);
 assert.equal(poolHealth(10000,50).level,'warn');assert.equal(poolHealth(2000,50).level,'bad');assert.match(poolHealth(2000,50).text,/muy chico/);
 assert.equal(poolHealth(70000,200).level,'warn');assert.equal(poolHealth(70000,600).level,'bad');assert.match(poolHealth(70000,600).text,/6\.0%/);
 const big=poolHealth(20000,10,2000);assert.equal(big.level,'bad');assert.match(big.text,/10% del pool/);
 assert.equal(poolHealth(null,null).level,'ok');assert.equal(poolHealth(5000,700).level,'bad');
});
test('pnlSummary / totalPnl: P/L abierto, realizado y total en dólares; sin precio no inventa nada',()=>{
 const pos=(over:any={})=>({status:'OPEN',view:{pnlPct:12.5,usd:{invested:10,net:11.25,exitValue:11.5,unrealized:1.25,realized:0.5}},...over});
 const s=pnlSummary(pos())!;assert.deepEqual([s.costUsd,s.valueUsd,s.pnlUsd,s.pnlPct,s.realizedUsd,s.totalUsd],[10,11.25,1.25,12.5,0.5,1.75]);
 const closed=pnlSummary(pos({status:'CLOSED'}))!;assert.equal(closed.open,false);assert.equal(closed.pnlUsd,0);assert.equal(closed.totalUsd,0.5);
 const none=pnlSummary({status:'OPEN',view:{pnlPct:null,usd:{invested:null,net:null,exitValue:null,unrealized:null,realized:null}}})!;assert.equal(none.totalUsd,null);assert.equal(pnlSummary({status:'OPEN'}),null);
 const t=totalPnl([pos(),pos({view:{pnlPct:-10,usd:{invested:20,net:18,exitValue:18,unrealized:-2,realized:0}}}),pos({status:'CLOSED',view:{pnlPct:null,usd:{invested:5,net:null,exitValue:null,unrealized:null,realized:-1}}})]);
 assert.equal(t.open,2);assert.equal(t.unrealized,-0.75);assert.equal(t.realized,-0.5);assert.equal(t.total,-1.25);assert.ok(Math.abs(t.pct!-(-0.75/30*100))<1e-9);
 assert.equal(totalPnl([]).total,null);
});
test('presets: 4 importes > 0 y 4 porcentajes enteros 1–100; cualquier otra cosa vuelve al valor por defecto',()=>{
 assert.deepEqual(sanitizePresets({buy:[1,2,3,4],sell:[10,20,30,100]}),{buy:[1,2,3,4],sell:[10,20,30,100]});
 for(const bad of [null,{},{buy:[1,2,3],sell:[1,2,3,4]},{buy:[1,2,3,0],sell:[1,2,3,4]},{buy:[1,2,3,4],sell:[0,2,3,4]},{buy:[1,2,3,4],sell:[1,2,3,101]},{buy:[1,2,3,4],sell:[1.5,2,3,4]},{buy:['x',2,3,4],sell:[1,2,3,4]}])
  assert.deepEqual(sanitizePresets(bad).sell.length,4,JSON.stringify(bad));
 assert.deepEqual(sanitizePresets({buy:[1,2,3,0],sell:[1,2,3,4]}).buy,DEFAULT_PRESETS.buy);assert.deepEqual(sanitizePresets({buy:[1,2,3,4],sell:[1,2,3,101]}).sell,DEFAULT_PRESETS.sell);
});
