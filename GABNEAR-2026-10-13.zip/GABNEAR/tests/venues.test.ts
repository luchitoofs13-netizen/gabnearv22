import test,{before,after,afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {RefIndex,refIndex,findRoutes,findDclRoutes,findRefRoutes,clearRouteCache,quoteRoute,swapCall,rankRoutes,bestRoute,priceImpactBps,assessRisk,roundTripLoss,dclRoute,dclPoolId,routeOf,type Route} from '../server/venues.js';
import {rpcProbe} from '../server/sniper.js';
import {discover} from '../server/pools.js';
import {analyze,preview} from '../server/analysis.js';
import {swap,setLiveSession} from '../server/trading.js';
import {Operations} from '../server/operations.js';
import {Executor} from '../server/transactions.js';
import {nativeFromWithdrawReceipts,receivedFromTransferArgs,resolveReceived} from '../server/recovery.js';
import {units} from '../server/validation.js';
import type {NearRpc} from '../server/rpc.js';
import type {History} from '../server/history.js';

const ME='me.near',TOKEN='gen.tkn.near',DCL='dclv2.ref-labs.near',REF='v2.ref-finance.near',W='wrap.near';
const saved=process.env.BOT_ACCOUNT_ID;
before(()=>{process.env.BOT_ACCOUNT_ID=ME;});
after(()=>{if(saved===undefined)delete process.env.BOT_ACCOUNT_ID;else process.env.BOT_ACCOUNT_ID=saved;});
afterEach(()=>{clearRouteCache();refIndex.reset();setLiveSession(false);});
function memory(rows:any[]=[]){return {rows,save(r:any){rows.unshift(r);return r;},update(id:string,p:any){Object.assign(rows.find(r=>r.id===id),p);}} as unknown as History;}
const pool=(tokens:string[],amounts:string[],fee=30,kind='SIMPLE_POOL')=>({pool_kind:kind,token_account_ids:tokens,amounts,total_fee:fee,shares_total_supply:'1',amp:0});

// RPC simulado con: 1 pool DCL (fee 10000) y pools Ref v1 [0 estable, 1 otro par, 2 token/wNEAR vacío, 3 token/wNEAR con liquidez].
function world(over:{dclFactor?:bigint;refFactor?:bigint;refReserve?:string;noPools?:boolean;dclPool?:boolean}={}){
 const calls:string[]=[];
 const v1=[pool([W,'usdt.near'],['1','1'],5,'STABLE_SWAP'),pool(['other.near',W],['5','5']),pool([TOKEN,W],['0','0']),pool([TOKEN,W],['1000000000000000000000000000',over.refReserve??'50000000000000000000000000'],30)];
 const dclId=dclPoolId(TOKEN,W,10000);
 const rpc:any={
  calls,
  status:async()=>({chain_id:'mainnet'}),mainnet:async()=>({chain_id:'mainnet'}),
  account:async()=>({code_hash:'abc',amount:units('10').toString(),storage_usage:0}),
  view:async(c:string,m:string,a:any)=>{
   calls.push(`${c}.${m}`);
   if(m==='ft_metadata')return {spec:'ft-1.0.0',name:'Gen',symbol:'GEN',decimals:c===W?24:18};
   if(c==='nearlytrade.near'&&m==='get_launch_by_token')return null;
   if(c===DCL&&m==='get_pools')return a.pool_ids.map((id:string)=>over.noPools||over.dclPool===false||!id.endsWith('|10000')?null:{pool_id:id,token_x:TOKEN,token_y:W,state:'Running',fee:10000,liquidity:'1000',current_point:5});
   if(c===DCL&&m==='quote')return {amount:(BigInt(a.input_amount)*(over.dclFactor??1000n)).toString()};
   if(c===REF&&m==='get_number_of_pools')return over.noPools?0:v1.length;
   if(c===REF&&m==='get_pools')return v1.slice(a.from_index,a.from_index+a.limit);
   if(c===REF&&m==='get_pool_by_ids')return a.pool_ids.map((i:number)=>over.noPools?null:v1[i]);
   if(c===REF&&m==='get_return'){if(a.pool_id!==3)throw new Error('E85: invalid pool id');return (BigInt(a.amount_in)*(over.refFactor??900n)).toString();}
   if(m==='ft_balance_of')return c===TOKEN?units('1000',18).toString():units('5').toString();
   if(m==='storage_balance_of')return {total:'1',available:'0'};
   throw new Error(`mock: ${c}.${m}`);
  }
 };
 return rpc as NearRpc&{calls:string[]};
}

test('RefIndex: solo indexa pools simples de 2 tokens y las actualizaciones son incrementales',async()=>{
 const pools=[pool(['a.near',W],['1','1']),pool([W,'b.near'],['1','1'],30,'RATED_SWAP'),pool(['c.near',W],['1','1']),pool(['d.near','e.near'],['1','1']),pool(['f.near',W],['1','1'])];
 const pages:number[]=[];let total=3;
 const rpc:any={view:async(_c:string,m:string,a:any)=>{if(m==='get_number_of_pools')return total;pages.push(a.from_index);return pools.slice(a.from_index,Math.min(a.from_index+a.limit,total));}};
 const idx=new RefIndex(2,2);await idx.refresh(rpc,0);
 assert.deepEqual(pages.sort(),[0,2]);assert.equal(idx.size,3);
 assert.deepEqual(idx.poolsFor(W,'a.near').map(p=>p.id),[0]);assert.deepEqual(idx.poolsFor('b.near',W),[]);assert.deepEqual(idx.poolsFor('c.near',W).map(p=>p.id),[2]);
 total=5;pages.length=0;await idx.refresh(rpc,0);
 assert.deepEqual(pages,[3]);assert.equal(idx.size,5);assert.deepEqual(idx.poolsFor('f.near',W).map(p=>p.id),[4]);
 // dentro de la ventana de frescura no relee nada
 pages.length=0;await idx.refresh({view:async()=>{throw new Error('no debería leer');}} as any,60000);assert.equal(pages.length,0);
});
test('RefIndex: un fallo de lectura no avanza el índice ni deja un estado a medias',async()=>{
 let fail=true;const rpc:any={view:async(_c:string,m:string,a:any)=>{if(m==='get_number_of_pools')return 4;if(fail&&a.from_index===2)throw new Error('429');return [pool(['a.near',W],['1','1']),pool(['b.near',W],['1','1'])];}};
 const idx=new RefIndex(2,1);await assert.rejects(()=>idx.refresh(rpc,0),/429/);assert.equal(idx.size,0);
 fail=false;await idx.refresh(rpc,0);assert.equal(idx.size,4);
});
test('descubrimiento genérico: DCL por id construido + Ref v1 por índice; ignora pools vacíos',async()=>{
 const rpc=world();
 const dcl=await findDclRoutes(rpc,TOKEN,W);assert.equal(dcl.length,1);assert.equal(dcl[0].poolId,`${TOKEN}|${W}|10000`);assert.equal(dcl[0].venue,'DCL');
 assert.equal(dcl[0].fee,100,'el fee DCL 10000 ppm se guarda como 100 bps (1%), igual que Ref v1');assert.equal(dclRoute(TOKEN,W,400).fee,4);assert.equal(dclRoute(TOKEN,W,100).fee,1);
 const ref=await findRefRoutes(rpc,TOKEN,W,new RefIndex());assert.deepEqual(ref.map(r=>r.poolId),['3']);assert.equal(ref[0].venue,'REF_V1');assert.equal(ref[0].fee,30);
 assert.equal(rpc.calls.filter(c=>c===`${DCL}.get_pools`).length,1);                               // una sola lectura en lote
 assert.equal(rpc.calls.filter(c=>c===`${REF}.get_pool_by_ids`).length,1);
 clearRouteCache();const all=await findRoutes(rpc,TOKEN,W);assert.equal(all.length,2);
});
test('rutas candidatas se reutilizan 10 s pero un resultado vacío o fallido nunca se cachea',async()=>{
 const rpc=world();await findRoutes(rpc,TOKEN,W);const before=rpc.calls.length;await findRoutes(rpc,TOKEN,W);assert.equal(rpc.calls.length,before);
 clearRouteCache();refIndex.reset();const none=world({noPools:true});assert.deepEqual(await findRoutes(none,TOKEN,W),[]);const n=none.calls.length;await findRoutes(none,TOKEN,W);assert.ok(none.calls.length>n);
});
test('discover: token fuera de Nearly usa modo genérico; sin pools da un error claro',async()=>{
 const d=await discover(world(),TOKEN);assert.equal(d.generic,true);assert.equal(d.routes.length,2);assert.equal((d.record as any).source,'GENERIC');assert.equal(d.tax,null);assert.equal(d.quoteAsset.id,W);
 clearRouteCache();refIndex.reset();await assert.rejects(()=>discover(world({noPools:true}),TOKEN),(e:any)=>e.name==='PoolNotReady'&&/Sin pools directos/.test(e.message));
});
test('quoteRoute Ref v1: usa get_return, calcula mínimo y rechaza liquidez nula',async()=>{
 const rpc=world();const route:Route={venue:'REF_V1',poolId:'3',receiver:REF,fee:30,quote:W,token:TOKEN};
 const q=await quoteRoute(rpc,route,W,TOKEN,1000n,300);assert.equal(q.raw,'900000');assert.equal(q.minRaw,(900000n*9700n/10000n).toString());
 await assert.rejects(()=>quoteRoute(rpc,route,W,TOKEN,1000n,0),/Slippage/);await assert.rejects(()=>quoteRoute(rpc,route,W,TOKEN,0n,300),/inválido/);
 const zero:any={view:async()=>'0'};await assert.rejects(()=>quoteRoute(zero,route,W,TOKEN,1000n,300),/liquidez/);
});
test('mensaje de swap: formato exacto DCL (Swap) y Ref v1 (actions) con gas adecuado',()=>{
 const d=swapCall(dclRoute(TOKEN,W,10000),W,TOKEN,1000n,'5');
 assert.equal(d.receiver,DCL);assert.equal(d.gas,180);assert.deepEqual(JSON.parse(d.msg),{Swap:{pool_ids:[`${TOKEN}|${W}|10000`],output_token:TOKEN,min_output_amount:'5'}});
 const r=swapCall({venue:'REF_V1',poolId:'3',receiver:REF,fee:30,quote:W,token:TOKEN},W,TOKEN,1000n,'5');
 assert.equal(r.receiver,REF);assert.equal(r.gas,300);
 assert.deepEqual(JSON.parse(r.msg),{force:0,actions:[{pool_id:3,token_in:W,token_out:TOKEN,amount_in:'1000',min_amount_out:'5'}]});
});
test('rankRoutes ordena por salida y tolera rutas que no cotizan',async()=>{
 const rpc=world({dclFactor:1200n,refFactor:900n});const routes=await findRoutes(rpc,TOKEN,W);
 let ranked=await rankRoutes(rpc,routes,W,TOKEN,units('0.1'),300);
 assert.equal(bestRoute(ranked)!.route.venue,'DCL');assert.equal(ranked[0].quote!.raw,(units('0.1')*1200n).toString());assert.ok(ranked[0].probe);
 const rpc2=world({dclFactor:800n,refFactor:900n});clearRouteCache();ranked=await rankRoutes(rpc2,await findRoutes(rpc2,TOKEN,W),W,TOKEN,units('0.1'),300);
 assert.equal(bestRoute(ranked)!.route.venue,'REF_V1');
 const broken:any={view:async()=>{throw new Error('boom');}};ranked=await rankRoutes(broken,routes,W,TOKEN,units('0.1'),300);
 assert.equal(bestRoute(ranked),undefined);assert.match(ranked[0].error!,/boom/);
});
test('impacto de precio y reglas de riesgo',()=>{
 assert.equal(priceImpactBps(1000n,900n,100n,100n),1000);              // precio medio 10% peor que el de la orden chica
 assert.equal(priceImpactBps(1000n,1000n,100n,100n),0);
 assert.equal(priceImpactBps(1000n,1000n,100n,0n),null);
 const mk=(out:bigint,probeOut:bigint,fee=30,reserve?:string)=>({route:{venue:'REF_V1',poolId:'1',receiver:REF,fee,quote:W,token:TOKEN,info:reserve?{reserveQuote:reserve}:undefined} as Route,quote:{raw:out.toString(),minRaw:'1',quotedAt:''},probe:{raw:probeOut.toString(),minRaw:'1',quotedAt:''},probeAmount:50n});
 assert.equal(assessRisk(mk(1000n,50n),1000n).blocked,null);                                     // impacto 0%
 assert.match(assessRisk(mk(700n,50n),1000n).blocked!,/Impacto de precio 30\.0%/);                  // 30% > límite 15%
 const mid=assessRisk(mk(950n,50n),1000n);assert.equal(mid.blocked,null);assert.ok(mid.warnings.some(w=>/Impacto/.test(w)));
 assert.match(assessRisk(mk(1000n,50n,30,'1000'),1000n).blocked!,/Liquidez/);
 assert.match(assessRisk(mk(1000n,50n),1000n,6000).blocked!,/perdería 60\.0%/);
 assert.ok(assessRisk(mk(1000n,50n),1000n,2000).warnings.some(w=>/Ida y vuelta/.test(w)));
 assert.ok(assessRisk(mk(1000n,50n,1000),1000n).warnings.some(w=>/Fee del pool 10\.00%/.test(w)));
 const old=process.env.MAX_PRICE_IMPACT_BPS;process.env.MAX_PRICE_IMPACT_BPS='5000';try{assert.equal(assessRisk(mk(700n,50n),1000n).blocked,null);}finally{if(old===undefined)delete process.env.MAX_PRICE_IMPACT_BPS;else process.env.MAX_PRICE_IMPACT_BPS=old;}
});
test('ida y vuelta: sin liquidez de regreso es trampa (100%); un error de red no se interpreta como riesgo',async()=>{
 const route=dclRoute(TOKEN,W,10000);const q={raw:'1000',minRaw:'1',quotedAt:''};
 assert.equal(await roundTripLoss({view:async()=>({amount:'0'})} as any,route,W,TOKEN,100n,q),10000);
 assert.equal(await roundTripLoss({view:async()=>{throw new Error('429 rate limit');}} as any,route,W,TOKEN,100n,q),null);
 assert.equal(await roundTripLoss({view:async()=>({amount:'98'})} as any,route,W,TOKEN,100n,q),200);
});
test('analyze genérico: elige el pool con mayor salida, adjunta riesgo y arma el paso de swap del venue ganador',async()=>{
 const rpc=world({dclFactor:800n,refFactor:900n});
 const a=await analyze(rpc,{url:TOKEN,amount:'0.1',slippageBps:300},{accountId:'',maxNear:'',maxBps:9900});
 assert.equal(a.route.venue,'REF_V1');assert.equal(a.record.pool_id,'3');assert.equal(a.candidates.length,2);assert.ok(a.risk);assert.equal(a.generic,true);
 const step=a.steps.find((s:any)=>s.method==='ft_transfer_call');assert.equal(step.args.receiver_id,REF);assert.equal(step.gas,'300 TGas');
 assert.ok(a.warnings.some((w:string)=>/fuera de Nearly/.test(w)));
 assert.equal(a.fundsSent,false);assert.equal(a.quotation.raw,(units('0.1')*900n).toString());
});
test('compra REAL se bloquea por riesgo salvo allowRisk; DRY RUN solo informa',async()=>{
 const thin=()=>world({dclPool:false,refFactor:900n});
 // pool v1 con reservas diminutas → impacto alto: get_return cae mucho con el importe grande
 const rpc:any=thin();const base=rpc.view;rpc.view=async(c:string,m:string,a:any)=>{if(c===REF&&m==='get_return'){const amt=BigInt(a.amount_in);return amt>units('0.01')?(amt*500n).toString():(amt*900n).toString();}return base(c,m,a);};
 const history=memory(),ex=new Executor(rpc,history,()=>false);let sent=0;(ex as any).call=async()=>{sent++;throw new Error('no debería enviar');};
 const ops=new Operations(rpc,history,ex,()=>false,()=>({accountId:ME,maxNear:'',maxBps:9900}));
 const dry=ops.submit({requestId:randomUUID(),side:'BUY',mode:'DRY RUN',url:TOKEN,amount:'0.1',slippageBps:300});
 for(let i=0;i<50&&ops.active;i++)await new Promise(r=>setTimeout(r,5));
 assert.equal(dry.status,'ANALYZED');assert.match(dry.analysis.risk.blocked,/Impacto de precio/);
 setLiveSession(true);
 const real=ops.submit({requestId:randomUUID(),side:'BUY',mode:'REAL',url:TOKEN,amount:'0.1',slippageBps:300});
 for(let i=0;i<50&&ops.active;i++)await new Promise(r=>setTimeout(r,5));
 assert.equal(real.status,'FAILED');assert.match(real.error,/bloqueada por riesgo/);assert.equal(real.fundsSent,false);assert.equal(sent,0);
});
test('preview: simula ida y vuelta, la cachea y la compra REAL la reutiliza',async()=>{
 const rpc=world({dclPool:false});
 const p=await preview(rpc,TOKEN,'0.1',300);
 assert.equal(p.generic,true);assert.ok(p.risk);assert.equal(typeof p.risk!.roundTripLossBps,'number');
 const a=await analyze(rpc,{url:TOKEN,amount:'0.1',slippageBps:300},{accountId:'',maxNear:'',maxBps:9900});
 assert.equal(a.risk!.roundTripLossBps,p.risk!.roundTripLossBps);
 const none=await preview(world(),TOKEN);assert.equal(none.risk,null);
});
test('venta genérica cotiza todos los pools y elige el mejor (DRY RUN)',async()=>{
 const rpc=world({dclFactor:1100n,refFactor:900n});
 const history=memory(),ops=new Operations(rpc,history,new Executor(rpc,history,()=>false),()=>false,()=>({accountId:ME,maxNear:'',maxBps:9900}));
 const p:any=await ops.position(TOKEN,300,50);
 assert.equal(p.route.venue,'DCL');assert.equal(p.record.pool_id,`${TOKEN}|${W}|10000`);assert.equal(p.amountRaw,(units('1000',18)/2n).toString());
 assert.ok(BigInt(p.quotation.raw)>0n);
});

// ── swap por Ref v1 y evidencia de recibos ───────────────────────────────────────────────────────────
function swapWorld(evidence:'events'|'none',opts:{details?:any;balances?:string[]}={}){
 const row:any={id:'swap',status:'PREPARING',txHash:'synthetic-hash'};const history=memory([row]);const sent:any={};const balances=[...(opts.balances??['0','990'])];
 const rpc:any={view:async(c:string,m:string,a:any)=>{if(m==='get_return')return '1000';if(m==='ft_balance_of')return balances.length>1?balances.shift():balances[0];throw new Error(m);},account:async()=>({amount:'1'}),transactionDetails:opts.details?async()=>opts.details:undefined};
 const outcome=(output:string)=>({final_execution_status:'FINAL',status:{SuccessValue:Buffer.from(JSON.stringify('1000')).toString('base64')},transaction_outcome:{outcome:{tokens_burnt:'0'}},receipts_outcome:evidence==='events'?[{id:'r',outcome:{executor_id:output,status:{SuccessValue:''},logs:['EVENT_JSON:'+JSON.stringify({standard:'nep141',event:'ft_transfer',data:[{old_owner_id:REF,new_owner_id:ME,amount:'990'}]})]}}]:[]});
 const ex:any={rpc,history,call:async(_id:string,contract:string,method:string,args:any,_dep:bigint,gas:number)=>{Object.assign(sent,{contract,method,args,gas});return outcome(TOKEN);}};
 return {ex,row,sent};
}
const v1Route:Route={venue:'REF_V1',poolId:'3',receiver:REF,fee:30,quote:W,token:TOKEN};
test('swap por Ref v1: ft_transfer_call al exchange correcto, mínimo en el mensaje y verificación por eventos',async()=>{
 setLiveSession(true);const w=swapWorld('events');
 const r=await swap(w.ex,'swap',v1Route,W,TOKEN,1000n,300);
 assert.equal(w.sent.contract,W);assert.equal(w.sent.method,'ft_transfer_call');assert.equal(w.sent.args.receiver_id,REF);assert.equal(w.sent.args.amount,'1000');assert.equal(w.sent.gas,300);
 const msg=JSON.parse(w.sent.args.msg);assert.equal(msg.actions[0].pool_id,3);assert.equal(msg.actions[0].min_amount_out,'970');assert.equal(msg.actions[0].amount_in,'1000');
 assert.equal(r.state,'FILLED');assert.equal(w.row.evidence,'nep141-receipts');assert.equal(w.row.receiptEvidence,true);assert.equal(w.row.swapSnapshot.route.venue,'REF_V1');
});
test('token sin eventos NEP-297: el importe se prueba con el ft_transfer de los recibos de ese hash',async()=>{
 setLiveSession(true);
 const details={final_execution_status:'FINAL',receipts:[{predecessor_id:REF,receiver_id:TOKEN,receipt_id:'t1',receipt:{Action:{actions:[{FunctionCall:{method_name:'ft_transfer',args:Buffer.from(JSON.stringify({receiver_id:ME,amount:'985'})).toString('base64')}}]}}}],receipts_outcome:[{id:'t1',outcome:{status:{SuccessValue:''}}}]};
 const w=swapWorld('none',{details});const r=await swap(w.ex,'swap',v1Route,W,TOKEN,1000n,300);
 assert.equal(r.state,'FILLED');assert.equal((r as any).receivedRaw,'985');assert.equal(w.row.evidence,'ft-transfer-args');
 assert.equal(receivedFromTransferArgs({...details,final_execution_status:'EXECUTED'},TOKEN,ME),null);
 assert.equal(receivedFromTransferArgs(details,TOKEN,'other.near'),null);
 assert.equal(receivedFromTransferArgs(details,'other.token.near',ME),null);
 const failed={...details,receipts_outcome:[{id:'t1',outcome:{status:{Failure:{}}}}]};assert.equal(receivedFromTransferArgs(failed,TOKEN,ME),null);
});
test('último recurso en camino vivo: delta de saldo medido, marcado como tal; sin lectura no hay evidencia',async()=>{
 setLiveSession(true);
 const w=swapWorld('none',{balances:['0','985']});const r=await swap(w.ex,'swap',v1Route,W,TOKEN,1000n,300);
 assert.equal(r.state,'FILLED');assert.equal(w.row.evidence,'balance-delta');assert.equal(w.row.receiptEvidence,false);assert.equal((r as any).receivedRaw,'985');
 const none=swapWorld('none',{balances:['0','0']});await assert.rejects(()=>swap(none.ex,'swap',v1Route,W,TOKEN,1000n,300),/evidencia/);assert.equal(none.row.status,'SETTLING');
});
test('retiro nativo de wNEAR: reconoce DCL y Ref v1 como exchange, rechaza transferencias ajenas',()=>{
 const mk=(exchange:string,predecessorOfTransfer=exchange,withdrawn='5000',transfer='5000')=>({final_execution_status:'FINAL',
  receipts:[{predecessor_id:exchange,receiver_id:W,receipt_id:'w',receipt:{Action:{actions:[{FunctionCall:{method_name:'near_withdraw',args:Buffer.from(JSON.stringify({amount:withdrawn})).toString('base64')}}]}}},{predecessor_id:predecessorOfTransfer,receiver_id:ME,receipt_id:'x',receipt:{Action:{actions:[{Transfer:{deposit:transfer}}]}}}],
  receipts_outcome:[{id:'w',outcome:{status:{SuccessValue:''}}},{id:'x',outcome:{status:{SuccessValue:''}}}]});
 assert.equal(nativeFromWithdrawReceipts(mk(DCL),ME),5000n);
 assert.equal(nativeFromWithdrawReceipts(mk(REF),ME),5000n);
 assert.equal(nativeFromWithdrawReceipts(mk(REF,'stranger.near'),ME),null);
 assert.equal(nativeFromWithdrawReceipts(mk(REF,REF,'5000','6000'),ME),null);                    // no puede recibir más de lo retirado
});
test('resolvedor de recibos respeta el orden de evidencia y no inventa',async()=>{
 const events={final_execution_status:'FINAL',receipts_outcome:[{id:'r',outcome:{executor_id:TOKEN,status:{SuccessValue:''},logs:['EVENT_JSON:'+JSON.stringify({standard:'nep141',event:'ft_transfer',data:[{old_owner_id:REF,new_owner_id:ME,amount:'7'}]})]}}]};
 assert.deepEqual(await resolveReceived({},events,'h',ME,TOKEN),{amount:7n,asset:TOKEN,evidence:'nep141-receipts'});
 assert.equal(await resolveReceived({},{final_execution_status:'FINAL',receipts_outcome:[]},'h',ME,TOKEN),null);
 assert.equal(await resolveReceived({transactionDetails:async()=>({final_execution_status:'FINAL'})},{final_execution_status:'FINAL',receipts_outcome:[]},undefined,ME,TOKEN),null);
});
test('routeOf: usa la ruta guardada o reconstruye la DCL del launch',()=>{
 assert.equal(routeOf({route:v1Route}).venue,'REF_V1');
 const legacy=routeOf({token:TOKEN,record:{pool_id:'p|q|100',quote:W}});assert.equal(legacy.venue,'DCL');assert.equal(legacy.poolId,'p|q|100');
});

test('rpcProbe (vigilancia de pool): sin pool = no listo (no es un error); con pools = listo con liquidez; un fallo de red sí se propaga',async()=>{
 clearRouteCache();refIndex.reset();
 const none=await rpcProbe(world({noPools:true}))(TOKEN);assert.equal(none.ready,false);assert.match((none as any).reason,/Sin pools directos/);
 clearRouteCache();refIndex.reset();
 const ok=await rpcProbe(world())(TOKEN);assert.equal(ok.ready,true);if(ok.ready){assert.ok(['DCL','REF_V1'].includes(ok.venue));assert.ok(ok.liquidityNear===null||ok.liquidityNear>=0);}
 clearRouteCache();refIndex.reset();
 const broken:any=world();const view=broken.view.bind(broken);broken.view=async(c:string,m:string,a:any)=>{if(m==='ft_metadata')throw new Error('fetch failed');return view(c,m,a);};
 await assert.rejects(()=>rpcProbe(broken)(TOKEN),/./);
});
