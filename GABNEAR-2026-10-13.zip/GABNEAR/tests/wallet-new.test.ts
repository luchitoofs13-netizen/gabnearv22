import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readdirSync,readFileSync,existsSync,statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {KeyPair} from 'near-api-js';
import {parseSeedPhrase,generateSeedPhrase} from 'near-seed-phrase';
import {generateWallet,importKey,importSeed,unlockWallet,lockWallet,walletState,accountId,implicitAccountId,localWallet} from '../server/wallet.js';
import type {NearRpc} from '../server/rpc.js';

const win=process.platform==='win32';
function sandbox(){const original=process.cwd(),dir=mkdtempSync(join(tmpdir(),'gabnear-walletnew-'));process.chdir(dir);return {dir,done(){lockWallet();process.chdir(original);rmSync(dir,{recursive:true,force:true});}};}
function files(dir:string):string[]{return readdirSync(dir).flatMap(f=>{const p=join(dir,f);return statSync(p).isDirectory()?files(p):[p];});}
function rpcFor(permission:string|null,seen:string[]=[]){return {deadline:async(x:any)=>x,account:async()=>({}),provider:{viewAccessKey:async({accountId:a,publicKey}:any)=>{seen.push(a+'|'+publicKey);if(permission===null)throw new Error('UNKNOWN_ACCESS_KEY');return {permission};}}} as unknown as NearRpc;}
const PW='clave local de prueba 123';

test('cuenta implícita = hex de la clave pública (sin crear nada on-chain)',()=>{
 const k=KeyPair.fromRandom('ed25519'),pub=k.getPublicKey().toString(),id=implicitAccountId(pub);
 assert.match(id,/^[0-9a-f]{64}$/);assert.equal(Buffer.from(id,'hex').length,32);
 assert.equal(implicitAccountId(pub),id);
});
test('generar wallet: clave y frase nacen localmente, cuenta implícita, queda cifrada y desbloqueada',{skip:!win},async()=>{
 const s=sandbox();try{
  const w=await generateWallet(PW);
  assert.equal(w.seedPhrase.split(' ').length,12);assert.match(w.accountId,/^[0-9a-f]{64}$/);assert.equal(w.accountId,implicitAccountId(w.publicKey));
  assert.equal(parseSeedPhrase(w.seedPhrase).publicKey,w.publicKey);                 // la frase mostrada recupera exactamente esta clave
  assert.equal(w.unlocked,true);assert.equal(w.implicit,true);assert.equal(w.hasLocalKey,true);assert.equal(accountId(),w.accountId);
  const secretKey=parseSeedPhrase(w.seedPhrase).secretKey;
  // ni la frase ni la clave privada quedan en claro en ningún archivo
  for(const f of files(s.dir)){const text=readFileSync(f,'utf8');assert.ok(!text.includes(secretKey)&&!text.includes(w.seedPhrase),'secreto en claro en '+f);}
  const {signer}=await localWallet({provider:{}} as any);assert.equal((await signer.getPublicKey()).toString(),w.publicKey);
  lockWallet();assert.equal(walletState().unlocked,false);await assert.rejects(()=>localWallet({provider:{}} as any),/Desbloqueá/);
  await assert.rejects(()=>unlockWallet('otra clave distinta 456'),/Contraseña incorrecta/);
  assert.equal((await unlockWallet(PW)).unlocked,true);
 }finally{s.done();}
});
test('generar exige contraseña válida y no crea nada si falla',{skip:!win},async()=>{
 const s=sandbox();try{await assert.rejects(()=>generateWallet('corta'),/12 a 256/);assert.equal(existsSync('data'),false);}finally{s.done();}
});
test('reemplazar una wallet archiva la bóveda anterior (nunca se sobrescribe en silencio)',{skip:!win},async()=>{
 const s=sandbox();try{
  const first=await generateWallet(PW);
  const second=await generateWallet(PW+'2');
  assert.notEqual(first.accountId,second.accountId);assert.ok(second.archivedPrevious);
  const archived=files(join(s.dir,'data','archive'));assert.ok(archived.some(f=>f.includes(first.accountId)&&f.endsWith('wallet-v2.dpapi')),'la bóveda anterior queda archivada con su cuenta');
  assert.equal(accountId(),second.accountId);
 }finally{s.done();}
});
test('importar clave privada: valida formato, FullAccess on-chain y manda solo la clave PÚBLICA al RPC',{skip:!win},async()=>{
 const s=sandbox();try{
  const k=KeyPair.fromRandom('ed25519'),secret=k.toString(),pub=k.getPublicKey().toString(),seen:string[]=[];
  const st=await importKey(rpcFor('FullAccess',seen),'mibot.near',secret,PW);
  assert.equal(st.accountId,'mibot.near');assert.equal(st.unlocked,true);assert.deepEqual(seen,[`mibot.near|${pub}`]);
  assert.ok(!seen.join().includes(secret.slice(8)));
  for(const f of files(s.dir))assert.ok(!readFileSync(f,'utf8').includes(secret),'clave privada en claro en '+f);
  lockWallet();assert.equal((await unlockWallet(PW)).accountId,'mibot.near');
 }finally{s.done();}
});
test('importar clave: sin cuenta usa la implícita; rechaza formato, permisos, cuenta inexistente y testnet sin persistir nada',{skip:!win},async()=>{
 const s=sandbox();try{
  const k=KeyPair.fromRandom('ed25519');
  const st=await importKey(rpcFor('FullAccess'),'  ',k.toString(),PW);assert.equal(st.accountId,implicitAccountId(k.getPublicKey().toString()));
 }finally{s.done();}
 const t=sandbox();try{
  const k=KeyPair.fromRandom('ed25519');
  for(const bad of ['','ed25519:abc','secp256k1:'+'1'.repeat(70),k.toString()+'x',' texto cualquiera '])await assert.rejects(()=>importKey(rpcFor('FullAccess'),'a.near',bad,PW),/Clave privada inválida/,bad);
  await assert.rejects(()=>importKey(rpcFor('FullAccess'),'a.testnet',k.toString(),PW),/Cuenta mainnet/);
  await assert.rejects(()=>importKey(rpcFor('FullAccess'),'A.near',k.toString(),PW),/Cuenta mainnet/);
  await assert.rejects(()=>importKey(rpcFor({FunctionCall:{}} as any),'a.near',k.toString(),PW),/permisos suficientes|Cuenta|autorizada/);
  await assert.rejects(()=>importKey(rpcFor(null),'a.near',k.toString(),PW),/no está autorizada|todavía no existe/);
  await assert.rejects(()=>importKey(rpcFor('FullAccess'),'a.near',k.toString(),'corta'),/12 a 256/);
  assert.equal(existsSync('data/wallet-v2.dpapi'),false,'ningún intento fallido persiste una bóveda');
 }finally{t.done();}
});
test('importar semilla sigue funcionando y archiva la wallet previa',{skip:!win},async()=>{
 const s=sandbox();try{
  await generateWallet(PW);const g=generateSeedPhrase();
  const seen:string[]=[];const st=await importSeed(rpcFor('FullAccess',seen),'otra.near',g.seedPhrase,PW);
  assert.equal(st.accountId,'otra.near');assert.deepEqual(seen,[`otra.near|${g.publicKey}`]);
  assert.ok(files(join(s.dir,'data','archive')).length>=1);
 }finally{s.done();}
});
